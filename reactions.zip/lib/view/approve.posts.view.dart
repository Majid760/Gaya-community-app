// import 'dart:developer';
//
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:flutter/material.dart';
// import 'package:gaya/controller/group.controller.dart';
// import 'package:gaya/model/create.post.model.dart';
// import 'package:gaya/model/user.model.dart';
// import 'package:gaya/routing/getx_route_methods.dart';
// import 'package:gaya/services/notification/notification_api/notification_api.dart';
// import 'package:gaya/services/services.dart';
// import 'package:gaya/shared/view/widget/gaya_back_button.dart';
// import 'package:gaya/utils/const.dart';
// import 'package:gaya/utils/language/translation.dart';
// import 'package:gaya/widgets/home_view_widgets/home.post.widget.dart';
// import 'package:get/get.dart';
// import 'package:jiffy/jiffy.dart';
// import 'package:provider/provider.dart';
//
// import '../utils/strings.dart';
// import '../utils/textstyles.dart';
// import 'community/controllers/community_feed_controller.dart';
//
// class ApprovePostsView extends StatefulWidget {
//   final String communityId;
//
//   const ApprovePostsView({super.key, required this.communityId});
//
//   @override
//   State<ApprovePostsView> createState() => _ApprovePostsViewState();
// }
//
// class _ApprovePostsViewState extends State<ApprovePostsView> {
//   var approvePostsInstance;
//   final _commonServices = Services();
//   final _notificationApiHitting = NotificationApiHitting();
//
//   @override
//   void initState() {
//     final controller = context.read<GroupController>();
//     approvePostsInstance = controller.getApprovePosts(widget.communityId);
//     super.initState();
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     final approvePostsController = Provider.of<GroupController>(context, listen: false);
//     return Scaffold(
//         appBar: AppBar(
//           elevation: 0,
//           backgroundColor: const Color.fromRGBO(255, 255, 255, 0.0),
//           iconTheme: const IconThemeData(color: kBlackColor),
//           centerTitle: true,
//           automaticallyImplyLeading: false,
//           leading: const GayaBackButton(),
//           title: Text(GayaStrings.approve_post.tr, style: bodyStyle),
//           shape: Border(bottom: BorderSide(color: kBaseGrey.withOpacity(0.5))),
//         ),
//         body: getBody(approvePostsController));
//   }
//
//   Widget getBody(GroupController approvePostsController) {
//     return Column(
//       children: [
//         Expanded(
//           child: StreamBuilder<QuerySnapshot?>(
//               stream: approvePostsInstance,
//               builder: (context, totalPostssnap) {
//                 if (totalPostssnap.connectionState == ConnectionState.waiting) {
//                   return const Center(child: CircularProgressIndicator.adaptive());
//                 } else if (totalPostssnap.connectionState == ConnectionState.active) {
//                   if (totalPostssnap.hasData && totalPostssnap.data != null && totalPostssnap.data!.docs.isNotEmpty) {
//                     QuerySnapshot postQuery = totalPostssnap.data as QuerySnapshot;
//                     log("Total number of posts for approve : ${postQuery.docs.length}");
//
//                     return ListView.separated(
//                         separatorBuilder: (context, index) {
//                           return const SizedBox(height: 10);
//                         },
//                         itemCount: postQuery.docs.length,
//                         itemBuilder: (context, index) {
//                           Post createPostModel = Post.fromMap(postQuery.docs[index].data() as Map<String, dynamic>);
//
//                           final UserModel userModel = createPostModel.postedBy;
//                           return createPostModel.memberId == null
//                               ? const SizedBox.shrink()
//                               : HomePostWidget(
//                                   pdfFiles: createPostModel.pdfFiles,
//                                   createdAt: createPostModel.postCreatedOn,
//                                   postModel: createPostModel,
//                                   hasVideo: (createPostModel.video.isBlank ?? true) ? false : true,
//                                   videoLink: createPostModel.video,
//                                   crossAxis: (createPostModel.multipleImages?.length ?? 0) < 2 ? 1 : 2,
//                                   anonymousPost: createPostModel.isPostedAnonymously == true ? true : false,
//                                   onUserTap: () {
//                                     // if null or anonymous post then don't navigate to profile
//                                     if (userModel.uId == null || createPostModel.isPostedAnonymously == true) return;
//
//                                     Routes.viewProfile(uid: userModel.uId, model: userModel);
//                                   },
//                                   approveRequest: () async {
//                                     try {
//                                       FirebaseFirestore.instance.collection("communityposts").doc(createPostModel.postid).update({
//                                         'approve': true,
//                                       });
//                                       if (createPostModel.postedBy.uId != null) {
//                                         UserModel? userData = await _commonServices.getUserById(createPostModel.postedBy.uId,forcefullyServer: true);
//                                         final fcmPostModel = FcmCreatePostModel(
//                                           postid: createPostModel.postid,
//                                           messageContent: postIsApproved,
//                                           messageTitle: createPostModel.community.communityName ?? GayaStrings.post_approved.tr,
//                                           receiverFcm: userData?.fm_token ?? '',
//                                           communityId: createPostModel.community.communityId,
//                                         );
//
//                                         _notificationApiHitting.callOnFcmApiForPostRelatedNotifications(fcmPostModel);
//
//                                         if (userData != null) {
//                                           UserModel adminData = UserModel.to;
//
//                                           await _commonServices.addNotification(
//                                               isRead: false,
//                                               communityId: createPostModel.community.communityId,
//                                               message: postIsApproved,
//                                               receiverUserID: userData.uId ?? '',
//                                               senderId: adminData.uId ?? "",
//                                               senderName: createPostModel.community.communityName ?? "Gaya User",
//                                               time: DateTime.now().toString(),
//                                               type: "communityPostApproved",
//                                               userImage: adminData.profilePicture ?? "");
//
//                                           CommunityFeedController.to(tag: createPostModel.communityId)
//                                               .resetController(context: context, communityModel: createPostModel.community);
//                                         }
//                                       }
//                                     } catch (_) {}
//                                   },
//                                   declineRequest: () async {
//                                     try {
//                                       FirebaseFirestore.instance.collection("communityposts").doc(createPostModel.postid).delete();
//
//                                       if (createPostModel.postedBy.uId != null) {
//                                         UserModel? userData = await _commonServices.getUserById(createPostModel.postedBy.uId);
//                                         if (userData != null) {
//                                           await _notificationApiHitting.callOnFcmApiSendPushNotifications(
//                                               gaya_message: 'Your post in ${createPostModel.community.communityName}$postIsRejected2',
//                                               fcmToken: userData.fm_token);
//                                         }
//                                       }
//                                       UserModel? userData = await _commonServices.getUserById(createPostModel.postedBy.uId);
//
//                                       if (userData != null) {
//                                         UserModel adminData = UserModel.to;
//
//                                         await _commonServices.addNotification(
//                                             isRead: false,
//                                             // posId: postId,
//                                             communityId: createPostModel.community.communityId,
//                                             message:
//                                                 'Your post in ${createPostModel.community.communityName ?? 'Gaya Community'}$postIsRejected2',
//                                             receiverUserID: userData.uId ?? '',
//                                             senderId: adminData.uId ?? "",
//                                             senderName: adminData.name ?? "Gaya User",
//                                             time: DateTime.now().toString(),
//                                             type: "communityPostRejected",
//                                             userImage: adminData.profilePicture ?? "");
//                                       }
//                                     } catch (_) {}
//                                   },
//                                   approvalShow: true,
//                                   subtitle: Jiffy(createPostModel.postCreatedOn).fromNow(),
//                                   doNotshowBottomrow: true,
//                                   groupImage: userModel.profilePicture ?? "",
//                                   title: createPostModel.isPostedAnonymously == true ? anonymousUser : userModel.name!,
//                                   isPostHasImage: createPostModel.multipleImages == null
//                                       ? false
//                                       : createPostModel.multipleImages!.isEmpty == true
//                                           ? false
//                                           : true,
//                                   // isPostHasImage: createPostModel.postPicture == null || createPostModel.postPicture.toString().trim() == "" ,
//
//                                   content: createPostModel.postDescription.toString(),
//                                   postImage: createPostModel.multipleImages ?? [],
//                                   totalCommentsCount: '',
//                                   totalLikesCount: '',
//                                   totalCrownsCount: '',
//                                   posterCrownsCount: '',
//
//                                   ///// by waqar /////
//                                   postId: createPostModel.postid);
//                         });
//                   }
//                 }
//                 return  Center(child: Text(GayaStrings.no_data_found.tr));
//               }),
//         ),
//       ],
//     );
//   }
// }
