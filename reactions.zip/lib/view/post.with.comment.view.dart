// import 'dart:async';
// import 'dart:developer';
//
// import 'package:cached_network_image/cached_network_image.dart';
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:firebase_auth/firebase_auth.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter/services.dart';
// import 'package:flutter_svg/svg.dart';
// import 'package:gaya/controller/group.controller.dart';
// import 'package:gaya/gen/assets.gen.dart';
// import 'package:gaya/model/community.model.dart';
// import 'package:gaya/model/create.post.model.dart';
// import 'package:gaya/model/replies.model.dart';
// import 'package:gaya/utils/time.calculation.dart';
// import 'package:gaya/view/commenting.view.dart';
// import 'package:gaya/widgets/post.with.comments.widgets/comments.dart';
// import 'package:jiffy/jiffy.dart';
// import 'package:material_design_icons_flutter/material_design_icons_flutter.dart';
// import 'package:multiple_stream_builder/multiple_stream_builder.dart';
// import 'package:provider/provider.dart';
//
// import '../components/show.full.picture.dart';
// import '../components/skeleton.post.component.dart';
// import '../components/textfield.component.dart';
// import '../controller/app_config_controller.dart';
// import '../controller/comments.controller.dart';
// import '../controller/create.post.controller.dart';
// import '../controller/homepage.controller.dart';
// import '../controller/report_controller.dart';
// import '../model/comment.model.dart';
// import '../model/user.model.dart';
// import '../routing/routes.dart' as route;
// import '../services/notification/notification_api/notification_api.dart';
// import '../services/report_services.dart';
// import '../services/services.dart';
// import '../utils/const.dart';
// import '../utils/methods.dart';
// import '../utils/strings.dart';
// import '../utils/textstyles.dart';
// import '../widgets/home_view_widgets/home.post.widget.dart';
// import '../widgets/post.with.comments.widgets/actionrow.widget.dart';
//
// class PostVithCommentsView extends StatefulWidget {
//   final CreateCommunityModel communityModel;
//   final CreatePostModel postModel;
//   final UserModel userModel;
//
//   PostVithCommentsView({
//     Key? key,
//     required this.communityModel,
//     required this.postModel,
//     required this.userModel,
//   }) : super(key: key);
//
//   @override
//   State<PostVithCommentsView> createState() => _PostVithCommentsViewState();
// }
//
// class _PostVithCommentsViewState extends State<PostVithCommentsView> {
//   var getComments;
//   Stream<QuerySnapshot>? stream;
//   TimeCalculation timeCalculation = TimeCalculation();
//  final TextEditingController writeCommentController = TextEditingController();
//   @override
//   void initState() {
//     final groupController = context.read<GroupController>();
//     groupController.commentCountInstance = groupController.commentCount(widget.postModel.postid!);
//
//     // groupController.postFlowerInstance = groupController.flowerPost(widget.postModel.postid!);
//     // groupController.postLikeInstance = groupController.likePost(widget.postModel.postid!);
//     // groupController.likeCountInstance = groupController.likeCount(widget.postModel.postid!);
//     // groupController.flowerCountInstance = groupController.flowerCount(widget.postModel.postid!);
//     // groupController.postSaveInstance = groupController.checkIsSaved(widget.postModel.postid!);
//     final controller = context.read<CommentsController>();
//     getComments = controller.getAllTheCommentsOnThePost(widget.postModel.postid!);
//
//     super.initState();
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     final user = FirebaseAuth.instance.currentUser?.uid ?? "";
//     final groupController = Provider.of<GroupController>(context, listen: false);
//     final commentConroller = Provider.of<CommentsController>(context, listen: false);
//     return Scaffold(
//       appBar: AppBar(
//           systemOverlayStyle: SystemUiOverlayStyle.dark,
//           iconTheme: IconThemeData(color: kBlackColor),
//           shape: Border(bottom: BorderSide(color: kBaseGrey.withOpacity(0.25))),
//           automaticallyImplyLeading: true,
//           backgroundColor: kTransparentColor,
//           elevation: 0),
//       body: Column(
//         children: [
//           SizedBox(height: distance_10),
//           Expanded(
//             child: SingleChildScrollView(
//               controller: groupController.commentsScroll,
//               child: Column(
//                 children: [
//                   Padding(
//                     padding: const EdgeInsets.symmetric(horizontal: distance_20),
//                     child: StreamBuilder<DocumentSnapshot?>(
//                         stream: FirebaseFirestore.instance.collection('communityposts').doc(widget.postModel.postid).snapshots(),
//                         builder: (ctx, postSnap) {
//                           if (postSnap.connectionState == ConnectionState.waiting || postSnap.data?.data() == null) {
//                             return PostsSkeleton();
//                           }
//                           CreatePostModel createPostModel = CreatePostModel.fromMap(postSnap.data?.data() as Map<String, dynamic>);
//
//                           CreateCommunityModel _createCommunityModel = createPostModel.community;
//
//                           UserModel _userModel = createPostModel.postedBy;
//                           if (AppConfigurationController.to.isUserBlockedAlready(userId: _userModel.uId ?? "")) {
//                             print("Blocked User as SizedBox Shrink ${_userModel.uId} (user without communities widget)");
//                             return SizedBox.shrink();
//                           }
//                           return HomePostWidget(
//                             index: 0,
//                             currentUserPost: createPostModel.memberId == FirebaseAuth.instance.currentUser?.uid ? true : false,
//                             hasVideo: (widget.postModel.video == null || widget.postModel.video == '') ? false : true,
//                             videoLink: widget.postModel.video,
//                             onTap: null,
//
//                             crossAxis: widget.postModel.multipleImages == null
//                                 ? 1
//                                 : widget.postModel.multipleImages!.length < 2
//                                     ? 1
//                                     : 2,
//                             imageTap: (widget.postModel.multipleImages?.isEmpty ?? true)
//                                 ? null
//                                 : () {
//                                     Navigator.of(context).push(MaterialPageRoute(
//                                         builder: (context) => PostImages(
//                                               allImages: widget.postModel.multipleImages ?? [],
//                                             )));
//                                   },
//                             onUserTap: () {
//                               Navigator.of(context).pushNamed(route.group, arguments: {'communityModel': widget.communityModel});
//                             },
//                             // anonymousPost:
//                             //     widget.annoymous == false
//                             //         ? true
//                             //         : false,
//                             approvalShow: false,
//                             doNotshowBottomrow: false,
//                             isPostHasImage: widget.postModel.multipleImages == null
//                                 ? false
//                                 : widget.postModel.multipleImages!.isEmpty == true
//                                     ? false
//                                     : true,
//                             savePostColor: kSecondaryColor,
//                             // postSnap.docs.length == 0
//                             //     ? kSecondaryColor
//                             //     : kprimaryColor,
//
//                             totalFlowerCounts: createPostModel.flowersBy?.length.toString() ?? "0",
//                             totalLikesCount: createPostModel.likedBy?.length.toString() ?? "0",
//                             totalCommentsCount: createPostModel.totalCommentsCount ?? "0",
//
//                             overlapImage: GestureDetector(
//                               onTap: () {
//                                 if (widget.postModel.isPostedAnonymously == true) {
//                                 } else if (_userModel.uId == user) {
//                                   Navigator.of(context).pushNamed(route.profile);
//                                 } else {
//                                   Navigator.of(context).pushNamed(route.publicProfile, arguments: {
//                                     'userModel': _userModel,
//                                   });
//                                 }
//                               },
//                               child: widget.postModel.isPostedAnonymously == true
//                                   ? CircleAvatar(
//                                       radius: 17,
//                                       backgroundImage: AssetImage('Assets/images/anonymous_user.png'),
//                                       backgroundColor: kBaseGrey,
//                                     )
//                                   : widget.userModel.profilePicture == ''
//                                       ? CircleAvatar(
//                                           radius: 17,
//                                           backgroundColor: kBaseGrey,
//                                           backgroundImage: AssetImage('Assets/images/user.png'),
//                                         )
//                                       : CircleAvatar(
//                                           backgroundColor: kWhiteColor,
//                                           radius: 17,
//                                           child: CachedNetworkImage(
//                                             imageUrl: widget.userModel.profilePicture ?? '',
//                                             imageBuilder: (context, imageProvider) {
//                                               return Container(
//                                                 decoration: BoxDecoration(
//                                                   shape: BoxShape.circle,
//                                                   image: DecorationImage(
//                                                     image: imageProvider,
//                                                     fit: BoxFit.cover,
//                                                   ),
//                                                 ),
//                                               );
//                                             },
//                                             fit: BoxFit.cover,
//                                             errorWidget: (context, url, error) => Container(
//                                               decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.grey.shade200),
//                                               child: Center(
//                                                   child: Icon(
//                                                 Icons.error,
//                                                 color: Colors.red,
//                                               )),
//                                             ),
//                                             placeholder: (context, url) => Image.asset(
//                                               Assets.assets.images.userDefault,
//                                             ),
//                                           ),
//                                         ),
//                             ),
//                             postId: widget.postModel.postid,
//                             flowerIconColor: createPostModel.flowersBy?.contains(UserModel.to.uId) == true ? kYellowColor : kSecondaryColor,
//                             likeIconColor: createPostModel.likedBy?.contains(UserModel.to.uId) == true ? kRedColor : kSecondaryColor,
//
//                             groupImage: widget.communityModel.CommunityPic.toString(),
//                             groupName: widget.communityModel.communityName.toString(),
//                             postDetailsText: widget.postModel.postDescription.toString(),
//                             postImage: widget.postModel.multipleImages ?? [],
//                             dateTime: widget.postModel.isPostedAnonymously == true ? anonymousUser : widget.userModel.name.toString(),
//                             profileImage: widget.userModel.profilePicture,
//                             commentOntap: () {},
//                             report: () {
//                               if (createPostModel.postid == null) return;
//                               Navigator.of(context).pop();
//                               ReportController.to.reportPost(createPostModel.postid ?? "", context);
//                             },
//                             onTapSaved: () async {
//                               if (AppConfigurationController.to.savedPostsID.contains(createPostModel.postid) == true) {
//                                 Navigator.pop(context);
//                                 AppConfigurationController.to.savedPostsID.remove(createPostModel.postid);
//
//                                 await context
//                                     .read<HomePageController>()
//                                     .deleteUserSaveDocFromPostCollection(createPostModel.postid!, context);
//                                 await context.read<HomePageController>().deletePostFromUserCollection(createPostModel.postid!);
//                               } else {
//                                 Navigator.pop(context);
//                                 AppConfigurationController.to.savedPostsID.add(createPostModel.postid ?? "");
//                                 await context.read<CreatePostController>().savePost(
//                                       createPostModel.postid!,
//                                     );
//
//                                 await context.read<HomePageController>().setSavePostInUSerCollection({
//                                   'postId': createPostModel.postid,
//                                   'communityId': _createCommunityModel.communityId,
//                                   'userUid': UserModel.to.uId
//                                 }, context);
//                               }
//                             },
//                             // onTapSaved: () async {
//                             //   if (saveSNAP.docs.length < 1) {
//                             //     await context.read<GroupController>().savePost(widget.postModel.postid!);
//                             //
//                             //     await context.read<HomePageController>().setSavePostInUSerCollection(
//                             //         {'postId': widget.postModel.postid, 'communityId': widget.communityModel.communityId, 'userUid': widget.userModel.uId}, context);
//                             //   } else {
//                             //     await context.read<GroupController>().unSavePost(widget.postModel.postid!);
//                             //     await context.read<HomePageController>().deletePostFromUserCollection(widget.postModel.postid!);
//                             //   }
//                             // },
//                             //void call back on flower on tap
//                             likeOnTap: () async {
//                               if (createPostModel.likedBy?.contains(UserModel.to.uId) == false) {
//                                 context.read<CreatePostController>().likePost(
//                                       createPostModel.postid!,
//                                     );
//
//                                 if (_userModel.uId != UserModel.to.uId) {
//                                   bool isNotificationSet = await NotificationApiHitting().callOnFcmApiSendPushNotifications(
//                                       gaya_message: postIsLikedNotification, fcmToken: _userModel.fm_token);
//                                   if (isNotificationSet) {
//                                     log("Notification Sent:");
//                                   } else {
//                                     log("Notification Not Sent:");
//                                   }
//                                   DocumentSnapshot? profileUserData = await Services().getUserDetailsServices();
//                                   Services().addNotification(
//                                       isRead: false,
//                                       message: "Your Post is Liked.",
//                                       receiverUserID: _userModel.uId!,
//                                       senderId: profileUserData!.id,
//                                       senderName: profileUserData["name"],
//                                       time: DateTime.now().toString(),
//                                       type: "postLiked",
//                                       userImage: profileUserData["profilePic"]);
//                                 } else {
//                                   log("Cannot Create Notification on self Post.");
//                                 }
//                               } else {
//                                 FirebaseFirestore.instance.collection('communityposts').doc(createPostModel.postid).update({
//                                   'likedBy': FieldValue.arrayRemove([UserModel.to.uId]),
//                                 });
//                                 // .collection('likes')
//                                 // .where('userUid', isEqualTo: user)
//                                 // .get()
//                                 // .then((value) => value.docs.first.reference.delete());
//
//                               }
//                             },
//
//                             //void call back on like button
//                             flowerOnTap: () async {
//                               if (createPostModel.flowersBy?.contains(UserModel.to.uId) == false) {
//                                 context.read<CreatePostController>().flowerPost(
//                                       createPostModel.postid!,
//                                     );
//
//                                 if (_userModel.uId != UserModel.to.uId) {
//                                   bool isNotificationSet = await NotificationApiHitting().callOnFcmApiSendPushNotifications(
//                                       gaya_message: flowerGivenNotification, fcmToken: _userModel.fm_token);
//                                   if (isNotificationSet) {
//                                     log("Notification Sent:");
//                                   } else {
//                                     log("Notification Not Sent:");
//                                   }
//                                   DocumentSnapshot? profileUserData = await Services().getUserDetailsServices();
//                                   Services().addNotification(
//                                       isRead: false,
//                                       message: "Your Post was given a flower.",
//                                       receiverUserID: _userModel.uId!,
//                                       senderId: profileUserData!.id,
//                                       senderName: profileUserData["name"],
//                                       time: DateTime.now().toString(),
//                                       type: "postFlowered",
//                                       userImage: profileUserData["profilePic"]);
//                                 } else {
//                                   log("Cannot Create Notification on self Post.");
//                                 }
//                               } else {
//                                 FirebaseFirestore.instance.collection('communityposts').doc(createPostModel.postid).update({
//                                   'flowersBy': FieldValue.arrayRemove([UserModel.to.uId]),
//                                 });
//                                 // .collection('flowers')
//                                 // .where('userUid', isEqualTo: user)
//                                 // .get()
//                                 // .then((value) => value.docs.first.reference.delete());
//
//                               }
//                             },
//                           );
//                         }),
//                   ),
//                   Padding(
//                       padding: const EdgeInsets.symmetric(horizontal: distance_20),
//                       child: Column(
//                         children: [
//                           SizedBox(height: distance_10),
//                           BuildCommentsWiget(postModel: widget.postModel, userModel: widget.userModel)
//                         ],
//                       )),
//                 ],
//               ),
//             ),
//           ),
//           Container(
//             color: kWhiteColor,
//             padding: EdgeInsets.symmetric(vertical: distance_15),
//             child: Row(
//               children: [
//                 SizedBox(
//                   width: distance_15,
//                 ),
//                 Expanded(
//                   child: TextFormFieldComment(
//                     fillColor: borderColor.withOpacity(0.50),
//                     isFilled: true,
//                     isPassword: false,
//                     inputType: TextInputType.multiline,
//                     hintText: 'Type your comment',
//                     controller:  writeCommentController,
//                     borderColor: borderColor,
//                   ),
//                 ),
//                 SizedBox(width: distance_10),
//                 TextButton(
//                     onPressed: () async {
//                       if ( writeCommentController.text.isEmpty) {
//                       } else {
//                         /*Functions Added By Kamran ElAbd*/
//                         await commentConroller.commentPost(postId: widget.postModel.postid!, comment: writeCommentController.text.trim());
//                         writeCommentController.clear();
//
//                         if (widget.postModel.postedBy.uId != user) {
//                           //Sending Push Notification While Adding Comment
//                           await NotificationApiHitting().callOnFcmApiSendPushNotifications(
//                               gaya_message: "Flower Given on your Post.", fcmToken: widget.userModel.fm_token);
//
//                           DocumentSnapshot? profileUserData = await Services().getUserDetailsServices();
//                           Services().addNotification(
//                               posId: widget.postModel.postid ?? '',
//                               isRead: false,
//                               message: "Your Post was Commented.",
//                               receiverUserID: widget.userModel.uId!,
//                               senderId: profileUserData!.id,
//                               senderName: profileUserData["name"],
//                               time: DateTime.now().toString(),
//                               type: "postCommented",
//                               userImage: profileUserData["profilePic"]);
//                         } else {
//                           log("Cannot Create Notification on self Post.");
//                         }
//                       }
//                       //Function Ended
//                     },
//                     child: Text('Post', style: body4StylePrimary)),
//                 SizedBox(
//                   width: distance_10,
//                   height: TargetPlatform.iOS == true ? distance_5 : 0,
//                 ),
//               ],
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }
//
// class BuildCommentsWiget extends StatefulWidget {
//   final CreatePostModel postModel;
//   final UserModel userModel;
//
//   const BuildCommentsWiget({Key? key, required this.postModel, required this.userModel}) : super(key: key);
//
//   @override
//   State<BuildCommentsWiget> createState() => _BuildCommentsWigetState();
// }
//
// class _BuildCommentsWigetState extends State<BuildCommentsWiget> {
//   late Stream<QuerySnapshot<Object?>?> getComments;
//
//   @override
//   void initState() {
//     super.initState();
//     final controller = context.read<CommentsController>();
//     getComments = controller.getAllTheCommentsOnThePost(widget.postModel.postid!);
//   }
//
//   final Services services = Services();
//
//   @override
//   Widget build(BuildContext context) {
//     final commentConroller = Provider.of<CommentsController>(context, listen: false);
//     return StreamBuilder<QuerySnapshot?>(
//         stream: getComments,
//         builder: (context, commentssnapshot) {
//           if (commentssnapshot.connectionState == ConnectionState.waiting) {
//             return LinearProgressIndicator();
//           }
//             if (commentssnapshot.hasData && commentssnapshot.data != null && commentssnapshot.data?.docs.isNotEmpty == true) {
//               QuerySnapshot commentData = commentssnapshot.data as QuerySnapshot;
//
//               return ListView.separated(
//                 physics: BouncingScrollPhysics(),
//                 itemCount: commentData.docs.length,
//                 shrinkWrap: true,
//                 itemBuilder: (context, index) {
//                   CommentsModel _comments = CommentsModel.fromMap(commentData.docs[index].data() as Map<String, dynamic>);
//
//                   return Column(
//                     children: [
//                       FutureBuilder<UserModel?>(
//                           future: services.getUserById(_comments.userId),
//                           builder: (ctx, commentedUser) {
//                             if (commentedUser.data != null) {
//                               try {
//                                 UserModel userDetails = commentedUser.data!;
//
//                                 return Column(
//                                   children: [
//                                     Column(
//                                       children: [
//                                         CommentSection(
//                                             showDialogBox: () {
//                                               Methods.showModalSheetComment(context, () {
//                                                 ReportController.to.reportAComment(
//                                                     content: _comments.comment.toString(),
//                                                     reportedCommentId: commentData.docs[index].id,
//                                                     context: context,
//                                                     postId: widget.postModel.postid ?? "");
//                                               });
//                                             },
//                                             nameOnTap: () {
//                                               userDetails.uId == FirebaseAuth.instance.currentUser!.uid
//                                                   ? Navigator.of(context).pushNamed(route.profile)
//                                                   : Navigator.of(context).pushNamed(route.publicProfile, arguments: {
//                                                       "userModel": userDetails,
//                                                     });
//                                             },
//                                             userOntap: () {
//                                               userDetails.uId == FirebaseAuth.instance.currentUser!.uid
//                                                   ? Navigator.of(context).pushNamed(route.profile)
//                                                   : Navigator.of(context)
//                                                       .pushNamed(route.publicProfile, arguments: {"userModel": userDetails});
//                                             },
//                                             anonymousPic: widget.postModel.isPostedAnonymously,
//                                             userUid: userDetails.uId!,
//                                             uId: widget.userModel.uId,
//                                             profilepic: userDetails.profilePicture,
//                                             commentConroller: commentConroller,
//                                             content: _comments.comment.toString(),
//                                             name: userDetails.name,
//                                             time: Jiffy(_comments.commentTime).fromNow()),
//                                         Padding(
//                                           padding: const EdgeInsets.only(left: distance_50),
//                                           child: StreamBuilder2<QuerySnapshot?, QuerySnapshot?>(
//                                               streams: StreamTuple2(
//                                                   commentConroller.checkCommentLike(widget.postModel.postid!, _comments.commentId!),
//                                                   commentConroller.checkCommentFlower(widget.postModel.postid!, _comments.commentId!)),
//                                               builder: (context, multipleStreams) {
//                                                 if (multipleStreams.snapshot1.connectionState == ConnectionState.waiting ||
//                                                     multipleStreams.snapshot2.connectionState == ConnectionState.waiting) {
//                                                   return SizedBox.shrink();
//                                                 } else if (multipleStreams.snapshot1.connectionState == ConnectionState.active ||
//                                                     multipleStreams.snapshot2.connectionState == ConnectionState.active) {
//                                                   if (multipleStreams.snapshot1.hasData || multipleStreams.snapshot2.hasData) {
//                                                     QuerySnapshot likeOnCommentSnap = multipleStreams.snapshot1.data as QuerySnapshot;
//                                                     QuerySnapshot flowerOnCommentSnap = multipleStreams.snapshot2.data as QuerySnapshot;
//                                                     return ActionRow(
//                                                       likeWidget: likeOnCommentSnap.docs.length < 1
//                                                           ? Text('Like', style: body3MStyle)
//                                                           : Row(
//                                                               children: [
//                                                                 Text('Like', style: body5StylePrimary),
//                                                                 SizedBox(width: distance_5),
//                                                                 CircleAvatar(radius: 1, backgroundColor: kprimaryColor),
//                                                                 SizedBox(width: distance_5),
//                                                                 SvgPicture.asset(Assets.assets.icons.heartIcon),
//                                                               ],
//                                                             ),
//                                                       flowerWidget: flowerOnCommentSnap.docs.length < 1
//                                                           ? Text('Give a flower', style: body3MStyle)
//                                                           : Row(
//                                                               children: [
//                                                                 Text('Give a flower', style: yellowebodyStyle),
//                                                                 SizedBox(width: distance_5),
//                                                                 CircleAvatar(radius: 1, backgroundColor: kprimaryColor),
//                                                                 SizedBox(width: distance_5),
//                                                                 Icon(MdiIcons.flowerPoppy, color: kYellowColor, size: 12),
//                                                               ],
//                                                             ),
//                                                       likeOnTap: () async {
//                                                         if (likeOnCommentSnap.docs.length < 1) {
//                                                           await commentConroller.commentLike(
//                                                               widget.postModel.postid!, _comments.commentId!);
//                                                         } else {
//                                                           await context
//                                                               .read<CommentsController>()
//                                                               .unlikeComment(widget.postModel.postid!, _comments.commentId!);
//                                                         }
//                                                       },
//                                                       flowerOnTap: () async {
//                                                         if (flowerOnCommentSnap.docs.length < 1) {
//                                                           await commentConroller.commentFlower(
//                                                               widget.postModel.postid!, _comments.commentId!);
//                                                         } else {
//                                                           await context
//                                                               .read<CommentsController>()
//                                                               .unflowerComment(widget.postModel.postid!, _comments.commentId!);
//                                                         }
//                                                       },
//                                                       replyOnTap: () {
//                                                         Navigator.of(context).push(MaterialPageRoute(
//                                                             builder: (context) => CommentingView(
//                                                                   usermodel: widget.userModel,
//                                                                   userUid: userDetails.uId!,
//                                                                   anonymousUserUid: widget.userModel.uId!,
//                                                                   anonymous: widget.postModel.isPostedAnonymously!,
//                                                                   commentUserProfile: userDetails.profilePicture,
//                                                                   comment: _comments.comment,
//                                                                   commentUserName: userDetails.name,
//                                                                   commentDate: _comments.commentTime,
//                                                                   postId: widget.postModel.postid!,
//                                                                   commentId: _comments.commentId!,
//                                                                 )));
//                                                       },
//                                                     );
//                                                   }
//                                                 }
//                                                 return SizedBox.shrink();
//                                               }),
//                                         ),
//                                       ],
//                                     ),
//                                     SizedBox(height: distance_10),
//                                     Padding(
//                                       padding: EdgeInsets.only(left: distance_50),
//                                       child: StreamBuilder(
//                                           stream: FirebaseFirestore.instance
//                                               .collection('communityposts')
//                                               .doc(widget.postModel.postid!)
//                                               .collection('comments')
//                                               .doc(_comments.commentId)
//                                               .collection('replies')
//                                               .orderBy('replyTime', descending: true)
//                                               .snapshots(),
//                                           builder: (context, repliesSnapshot) {
//                                             if (repliesSnapshot.connectionState == ConnectionState.waiting) {
//                                               return Container(width: double.infinity, height: 50, color: kBaseGrey);
//                                             } else if (repliesSnapshot.connectionState == ConnectionState.active) {
//                                               if (repliesSnapshot.hasData && repliesSnapshot.data != null) {
//                                                 QuerySnapshot _repliesData = repliesSnapshot.data as QuerySnapshot;
//                                                 return ListView.separated(
//                                                   itemCount: _repliesData.docs.length,
//                                                   physics: NeverScrollableScrollPhysics(),
//                                                   shrinkWrap: true,
//                                                   itemBuilder: (context, repliesIndex) {
//                                                     RepliesModel _replies = RepliesModel.fromMap(
//                                                         _repliesData.docs[repliesIndex].data() as Map<String, dynamic>);
//
//                                                     return FutureBuilder<UserModel?>(
//                                                       future: services.getUserById(_comments.userId),
//                                                       builder: (ctx, repliedCommentedUser) {
//                                                         if (repliedCommentedUser.data != null) {
//                                                           final userModel = repliedCommentedUser.data!;
//                                                           return Column(
//                                                             children: [
//                                                               CommentSection(
//                                                                 showDialogBox: () {
//                                                                   Methods.showModalSheetComment(context, () {
//                                                                     ReportController.to.reportACommentReply(
//                                                                         commentReplyId: _replies.replyId ?? "",
//                                                                         content: _comments.comment.toString(),
//                                                                         commentId: commentData.docs[index].id,
//                                                                         context: context,
//                                                                         postId: widget.postModel.postid ?? "");
//                                                                   });
//                                                                 },
//                                                                 nameOnTap: () {
//                                                                   userModel.uId == FirebaseAuth.instance.currentUser!.uid
//                                                                       ? Navigator.of(context).pushNamed(route.profile)
//                                                                       : Navigator.of(context).pushNamed(route.publicProfile, arguments: {
//                                                                           "userModel": userModel,
//                                                                         });
//                                                                 },
//                                                                 userOntap: () {
//                                                                   userModel.uId == FirebaseAuth.instance.currentUser!.uid
//                                                                       ? Navigator.of(context).pushNamed(route.profile)
//                                                                       : Navigator.of(context).pushNamed(route.publicProfile, arguments: {
//                                                                           "userModel": userModel,
//                                                                         });
//                                                                 },
//                                                                 anonymousPic: widget.postModel.isPostedAnonymously!,
//                                                                 userUid: userModel.uId!,
//                                                                 uId: widget.userModel.uId,
//                                                                 profilepic: userModel.profilePicture,
//                                                                 commentConroller: commentConroller,
//                                                                 content: _replies.reply,
//                                                                 name: widget.postModel.isPostedAnonymously! == false
//                                                                     ? widget.userModel.uId == userDetails.uId
//                                                                         ? anonymousUser
//                                                                         : userModel.name
//                                                                     : userModel.name,
//                                                                 time: Jiffy(_replies.replyTime).fromNow(),
//                                                               ),
//                                                               Padding(
//                                                                 padding: const EdgeInsets.only(left: distance_50),
//                                                                 child: StreamBuilder2<QuerySnapshot?, QuerySnapshot?>(
//                                                                     streams: StreamTuple2(
//                                                                         commentConroller.checkReplyLike(widget.postModel.postid!,
//                                                                             _comments.commentId!, _replies.replyId!),
//                                                                         commentConroller.checkReplyFlower(widget.postModel.postid!,
//                                                                             _comments.commentId!, _replies.replyId!)),
//                                                                     builder: (context, mutipleReplySnapShot) {
//                                                                       if (mutipleReplySnapShot.snapshot1.connectionState ==
//                                                                               ConnectionState.waiting ||
//                                                                           mutipleReplySnapShot.snapshot2.connectionState ==
//                                                                               ConnectionState.waiting) {
//                                                                         return SizedBox.shrink();
//                                                                       } else if (mutipleReplySnapShot.snapshot1.connectionState ==
//                                                                               ConnectionState.active ||
//                                                                           mutipleReplySnapShot.snapshot2.connectionState ==
//                                                                               ConnectionState.active) {
//                                                                         if (mutipleReplySnapShot.snapshot1.hasData ||
//                                                                             mutipleReplySnapShot.snapshot2.hasData) {
//                                                                           QuerySnapshot likeSnapShotReply =
//                                                                               mutipleReplySnapShot.snapshot1.data as QuerySnapshot;
//                                                                           QuerySnapshot flowerSnapShotReply =
//                                                                               mutipleReplySnapShot.snapshot2.data as QuerySnapshot;
//                                                                           return ActionRow(
//                                                                             likeWidget: likeSnapShotReply.docs.length < 1
//                                                                                 ? Text(
//                                                                                     'Like',
//                                                                                     style: body3MStyle,
//                                                                                   )
//                                                                                 : Row(
//                                                                                     children: [
//                                                                                       Text('Like', style: body5StylePrimary),
//                                                                                       SizedBox(width: distance_5),
//                                                                                       CircleAvatar(
//                                                                                           radius: 1, backgroundColor: kprimaryColor),
//                                                                                       SizedBox(width: distance_5),
//                                                                                       SvgPicture.asset(Assets.assets.icons.heartIcon),
//                                                                                     ],
//                                                                                   ),
//                                                                             flowerWidget: flowerSnapShotReply.docs.length < 1
//                                                                                 ? Text('Give a flower', style: body3MStyle)
//                                                                                 : Row(
//                                                                                     children: [
//                                                                                       Text('Give a flower', style: yellowebodyStyle),
//                                                                                       SizedBox(width: distance_5),
//                                                                                       CircleAvatar(
//                                                                                           radius: 1, backgroundColor: kprimaryColor),
//                                                                                       SizedBox(width: distance_5),
//                                                                                       Icon(MdiIcons.flowerPoppy,
//                                                                                           color: kYellowColor, size: 12),
//                                                                                     ],
//                                                                                   ),
//                                                                             likeOnTap: () async {
//                                                                               if (likeSnapShotReply.docs.length < 1) {
//                                                                                 await context.read<CommentsController>().replyLike(
//                                                                                     widget.postModel.postid!,
//                                                                                     _comments.commentId!,
//                                                                                     _replies.replyId!);
//                                                                               } else {
//                                                                                 await context.read<CommentsController>().unlikeReply(
//                                                                                     widget.postModel.postid!,
//                                                                                     _comments.commentId!,
//                                                                                     _replies.replyId!);
//                                                                               }
//                                                                             },
//                                                                             flowerOnTap: () async {
//                                                                               if (flowerSnapShotReply.docs.length < 1) {
//                                                                                 await context.read<CommentsController>().replyFlower(
//                                                                                     widget.postModel.postid!,
//                                                                                     _comments.commentId!,
//                                                                                     _replies.replyId!);
//                                                                               } else {
//                                                                                 await context.read<CommentsController>().unflowerReply(
//                                                                                     widget.postModel.postid!,
//                                                                                     _comments.commentId!,
//                                                                                     _replies.replyId!);
//                                                                               }
//                                                                             },
//                                                                             replyOnTap: null, // () {},
//                                                                           );
//                                                                         }
//                                                                       }
//                                                                       return SizedBox.shrink();
//                                                                     }),
//                                                               ),
//                                                             ],
//                                                           );
//                                                         }
//                                                         return SizedBox.shrink();
//                                                       },
//                                                     );
//                                                   },
//                                                   separatorBuilder: (context, index) {
//                                                     return SizedBox(height: distance_20);
//                                                   },
//                                                 );
//                                               } else if (repliesSnapshot.hasError) {
//                                                 return Icon(Icons.error, color: kRedColor);
//                                               } else {
//                                                 return Text('Something went wrong');
//                                               }
//                                             }
//                                             return SizedBox.shrink();
//                                           }),
//                                     ),
//                                   ],
//                                 );
//                               } catch (_) {
//                                 return SizedBox.shrink();
//                               }
//                             }
//                             return SizedBox.shrink();
//                           }),
//
//                       //
//                     ],
//                   );
//                 },
//                 separatorBuilder: (context, index) {
//                   return SizedBox(height: distance_20);
//                 },
//               );
//             }
//
//           return Center(child: SizedBox.shrink());
//         });
//   }
// }
