// ignore_for_file: use_build_context_synchronously

import 'dart:async';
import 'dart:developer';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:gaya/components/button.component.dart';
import 'package:gaya/components/snackbar.component.dart';
import 'package:gaya/controller/firebase_analytics_controller.dart';
import 'package:gaya/controller/gaya_shared_controller.dart';
import 'package:gaya/controller/profile.controller.dart';
import 'package:gaya/generated/assets.dart';
import 'package:gaya/model/chatroom.model.dart';
import 'package:gaya/model/compliments_list.dart';
import 'package:gaya/routing/getx_route_methods.dart';
import 'package:gaya/shared/service/service/shared_service.dart';
import 'package:gaya/shared/view/widget/gaya_report_dialog.dart';
import 'package:gaya/shared/view/widget/gaya_snackbar.dart';
import 'package:gaya/utils/language/translation.dart';
import 'package:gaya/utils/theme/app_spaces.dart';
import 'package:gaya/view/chat/controllers/chat_controller.dart';
import 'package:gaya/view/profile/components/skeletons.dart';
import 'package:gaya/widgets/notification_widgets/nonotification.widget.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';
import 'package:share/share.dart';

import '../../../components/dialogue.dart';
import '../../../controller/block_controller.dart';
import '../../../controller/report_controller.dart';
import '../../../model/user.model.dart';
import '../../../services/services.dart';
import '../../../shared/service/friendship_status_service.dart';
import '../../../shared/view/widget/gaya_back_button.dart';
import '../../../utils/asset_images.dart';
import '../../../utils/const.dart';
import '../../../utils/enum.dart';
import '../../../utils/gaya_text_widget.dart';
import '../../../utils/methods.dart';
import '../../../utils/textstyles.dart';
import '../../../utils/theme/app_colors.dart';
import '../../../utils/theme/app_typography.dart';
import '../../../widgets/profile.widgets/button.widget.dart';
import '../../../widgets/profile.widgets/figure.widget.dart';
import '../../../widgets/profile.widgets/profileimage.widget.dart';
import '../../../widgets/topic_view_widgets/interest.widget.dart';

class PeopleProfileView extends StatefulWidget {
  PeopleProfileView({Key? key, required this.usermodel}) : super(key: key);

  UserModel usermodel;

  @override
  State<PeopleProfileView> createState() => _PeopleProfileViewState();
}

class _PeopleProfileViewState extends State<PeopleProfileView> {
  DocumentSnapshot? snapshot;
  FirebaseAuth firebaseAuth = FirebaseAuth.instance;

  Map<String, dynamic>? map;
  var profileDetails;
  late Future<UserModel?> futureUserModel;
  var otherProfileDetails;
  bool newChat = false;
  final Services services = Services();

  final performance = PerformanceController.to.instance;

  @override
  void initState() {
    performance.startUserProfileViewLoadTime();
    print("User Id: ${widget.usermodel.uId}");
    futureUserModel = services.getUserById(widget.usermodel.uId);
    profileDetails = getFriend();

    context.read<ProfileController>().getUserDetails();
    otherProfileDetails = context.read<ProfileController>().getOtherUserProfileDetails(widget.usermodel.uId ?? "");

    context.read<ProfileController>().loadTimerStatus();
    context.read<ProfileController>().startCooldownTimer();
    complimentList.shuffle();
    // adding other user profile view count
    context.read<ProfileController>().addUserProfileViewedCount(
          otherUserProfileId: widget.usermodel.uId!,
        );
    super.initState();
  }

  final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;

  QuerySnapshot? getFriends;

  Future getFriend() async {
    User? user = _firebaseAuth.currentUser;
    getFriends = await FirebaseFirestore.instance
        .collection('friendship')
        .where("senderUid", isEqualTo: widget.usermodel.uId)
        .where('Recieveruid', isEqualTo: user?.uid)
        .get();

    return getFriends;
  }

  @override
  Widget build(BuildContext context) {
    // _prefs?.remove('timerStartTime');
    // print(_prefs);
    User? user = firebaseAuth.currentUser;
    final controller = Provider.of<ProfileController>(context, listen: false);
    return CupertinoPageScaffold(
      navigationBar: CupertinoNavigationBar(
        backgroundColor: Colors.white,
        leading: const GayaBackButton(),
        middle: Text(GayaStrings.profile_txt.tr, style: GayaTypography.titleMedium),
        trailing: Material(
          color: Colors.transparent,
          borderRadius: BorderRadius.circular(20.r),
          child: IconButton(
            tooltip: GayaStrings.more_txt.tr,
            padding: EdgeInsets.zero,
            visualDensity: const VisualDensity(horizontal: -4, vertical: -4),
            splashRadius: 20.r,
            icon: SvgIcons.moreIconBlack,
            onPressed: () {
              user == null
                  ? Routes.loginView()
                  : Methods.showCircularModalSheet(
                      context,
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10).r,
                        width: MediaQuery.of(context).size.width,
                        decoration: const BoxDecoration(color: Colors.white),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            GayaButton(
                              title: GayaStrings.share_profile.tr,
                              onPressed: () async {
                                Get.back();

                                final shareAbleLink = await GayaSharedController.to.createAShareableProfileLink(user: widget.usermodel);
                                if (shareAbleLink != null) await Share.share(shareAbleLink);
                              },
                              borderColor: kTransparentColor,
                              height: 50.h,
                              primaryColor: kBaseGrey,
                              textStyle: GayaTypography.subtitleRegular,
                              width: MediaQuery.of(context).size.width,
                            ),
                            const SizedBox(height: 10),
                            GayaButton(
                              title: BlockController.to.isUserBlocked(widget.usermodel.uId ?? "")
                                  ? GayaStrings.user_blocked.tr
                                  : GayaStrings.block_user.tr,
                              onPressed: () async {
                                if (widget.usermodel.uId == null) return;
                                BlockController.to.block(userId: widget.usermodel.uId ?? "", context: context);

                                Get.back();
                              },
                              borderColor: kTransparentColor,
                              height: 50.h,
                              primaryColor: kBaseGrey,
                              textStyle: GayaTypography.subtitleRegular.copyWith(color: AppColors.error),
                              width: MediaQuery.of(context).size.width,
                            ),
                            const SizedBox(height: 10),
                            GayaButton(
                              title: GayaStrings.report.tr,
                              onPressed: () async {
                                Get.back();

                                reportTextFieldBottomModal(
                                  context,
                                  onSubmit: (String reportMsg) async {
                                    bool isExist = await controller.checkCurrentUserReportedThatUserAlready(widget.usermodel.uId!);
                                    if (!isExist) {
                                      await ReportController.to.reportAUser(widget.usermodel.uId!, context, reportMsg: reportMsg);
                                    } else {
                                      snackBar(context, GayaStrings.already_reported.tr, kRedColor);
                                    }
                                  },
                                );
                              },
                              borderColor: kTransparentColor,
                              height: 50.h,
                              primaryColor: kBaseGrey,
                              textStyle: GayaTypography.subtitleRegular.copyWith(color: AppColors.error),
                              width: MediaQuery.of(context).size.width,
                            ),
                          ],
                        ),
                      ),
                    );
            },
          ),
        ),
      ),
      child: SafeArea(
        child: Scaffold(
          backgroundColor: Colors.white,
          body: Padding(
            padding: const EdgeInsets.symmetric(horizontal: distance_20),
            child: SingleChildScrollView(
              child: FutureBuilder<UserModel?>(
                initialData: widget.usermodel,
                future: futureUserModel,
                builder: (context, userSnapshot) {
                  try {
                    print("userSnapshot.data ${userSnapshot.data}");
                    widget.usermodel = userSnapshot.data!;
                  } catch (e) {
                    print(e);
                    return const SizedBox.shrink();
                  }
                  return FutureBuilder(
                    future: profileDetails,
                    builder: (context, snapshot) {
                      if (snapshot.connectionState == ConnectionState.waiting) {
                        return SizedBox(
                          height: MediaQuery.of(context).size.height,
                          child: const SizedBox.shrink(),
                        );
                      } else if (snapshot.connectionState == ConnectionState.active) {
                        if (snapshot.hasData) {
                        } else if (snapshot.hasError) {
                          return Center(
                            child: Text(GayaStrings.some_error_occurred.tr),
                          );
                        }
                      }
                      performance.stopUserProfileViewLoadTime();
                      return Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const SizedBox(height: distance_15),
                          ProfilePicWidget(
                            oncovertap: () => Routes.openImages(urls: [widget.usermodel.coverPhoto ?? ""], index: 0, ctx: context),
                            onproftap: () => Routes.openImages(urls: [widget.usermodel.profilePicture ?? ""], index: 0, ctx: context),
                            coverPhoto: widget.usermodel.coverPhoto,
                            profilePic: widget.usermodel.profilePicture,
                          ),
                          Center(child: Text(widget.usermodel.name.toString(), style: subHeading)),
                          const SizedBox(height: distance_20),
                          Row(
                            children: [
                              Expanded(
                                flex: 1,
                                child: FutureBuilder<int>(
                                    future: context.read<ProfileController>().getOtherUserFriendsCount(widget.usermodel.uId ?? ""),
                                    builder: ((context, snapshot) {
                                      if (snapshot.connectionState == ConnectionState.waiting) {
                                        return const CountSkeletonWidget();
                                      } else if (snapshot.connectionState == ConnectionState.done) {
                                        return FiguresWidget(
                                          number: (snapshot.data ?? 0).toString(),
                                          title: GayaStrings.friends_txt.tr,
                                        );
                                      }
                                      return const SizedBox.shrink();
                                    })),
                              ),
                              Expanded(
                                flex: 1,
                                child: FutureBuilder<int>(
                                    future: context.read<ProfileController>().getOtherUserCommunityCount(widget.usermodel.uId ?? ""),
                                    builder: (context, communitesCountSnapshot) {
                                      if (communitesCountSnapshot.connectionState == ConnectionState.waiting) {
                                        return const CountSkeletonWidget();
                                      }
                                      return FiguresWidget(
                                          number: (communitesCountSnapshot.data ?? 0).toString(), title: GayaStrings.communities_txt.tr);
                                    }),
                              ),
                              Expanded(
                                flex: 1,
                                child: FiguresWidget(
                                  number: (widget.usermodel.userTotalCrowns ?? 0).toString(),
                                  title: GayaStrings.crowns_txt.tr,
                                  flower: SvgPicture.asset('Assets/images/filled_crown.svg', height: 10, width: 12),
                                ),
                              )
                            ],
                          ),
                          const SizedBox(
                            height: distance_15,
                          ),
                          Center(
                            child: GayaTextWidget(
                              (widget.usermodel.bio.toString()),
                              style: body4StyleLowWeight,
                              trimLines: 20,
                              shouldIgnoreSelectableText: false,
                              trimMode: TrimMode.line,
                              trimCollapsedText: GayaStrings.read_more.tr,
                              trimExpandedText: GayaStrings.read_less.tr,
                              colorClickableText: kprimaryColor,
                            ),
                          ),
                          const SizedBox(height: distance_10),
                          user == null
                              ? Row(
                                  children: [
                                    Expanded(
                                      child: ButtonWidget(
                                        icon: SvgPicture.asset("Assets/icons/Union.svg", color: Colors.white),
                                        onTap: () {
                                          Routes.loginView();
                                        },
                                        buttonColor: kprimaryColor,
                                        color: kBlackColor.withOpacity(0.5),
                                        title: GayaStrings.add_friend.tr,
                                        style: body4StyleWhite,
                                      ),
                                    ),
                                    const SizedBox(
                                      width: distance_5,
                                    ),
                                    Expanded(
                                      child: ButtonWidget(
                                          onTap: () {
                                            Routes.loginView();
                                          },
                                          title: GayaStrings.message_txt.tr,
                                          buttonColor: kBaseGrey,
                                          color: kBlackColor.withOpacity(0.5),
                                          icon: SvgPicture.asset(
                                            "Assets/images/outline_mesage.svg",
                                            color: Colors.black,
                                          ),
                                          style: body2StyleWeightBlack),
                                    ),
                                  ],
                                )
                              : StreamBuilder<QuerySnapshot>(
                                  stream: getFriends?.docs.isEmpty ?? true
                                      ? FirebaseFirestore.instance
                                          .collection('friendship')
                                          .where("Recieveruid", isEqualTo: widget.usermodel.uId)
                                          .where('senderUid', isEqualTo: user.uid)
                                          .snapshots()
                                      : FirebaseFirestore.instance
                                          .collection('friendship')
                                          .where("Recieveruid", isEqualTo: user.uid)
                                          .where('senderUid', isEqualTo: widget.usermodel.uId)
                                          .snapshots(),
                                  builder: (context, dataSnapshot) {
                                    if (dataSnapshot.connectionState == ConnectionState.waiting) {
                                      return Row(
                                        children: [
                                          Expanded(
                                            child: Container(
                                              height: distance_40,
                                              color: Colors.grey[300],
                                            ),
                                          ),
                                          const SizedBox(width: distance_5),
                                          Expanded(
                                            child: Container(height: distance_40, color: Colors.grey[300]),
                                          ),
                                        ],
                                      );
                                    } else if (dataSnapshot.connectionState == ConnectionState.active ||
                                        dataSnapshot.connectionState == ConnectionState.done) {
                                      if (dataSnapshot.hasError) {
                                        return Center(
                                          child: Text(GayaStrings.error_occurred.tr),
                                        );
                                      } else if (dataSnapshot.hasData) {
                                        return Row(
                                          children: [
                                            Expanded(
                                              child: Consumer<ProfileController>(
                                                builder: (context, profileContrl, __) {
                                                  return ButtonWidget(
                                                    icon: dataSnapshot.data!.docs.isEmpty
                                                        ? profileContrl.isRequestSend
                                                            ? SvgPicture.asset(
                                                                "Assets/icons/Union.svg",
                                                                color: Colors.grey,
                                                              )
                                                            : SvgPicture.asset(
                                                                "Assets/icons/Union.svg",
                                                                color: Colors.white,
                                                              )
                                                        : (FriendshipStatusService.instance.getFriendshipStatus(
                                                                  friendshipSnapshot: dataSnapshot,
                                                                  me: user.uid,
                                                                  other: widget.usermodel.uId ?? "",
                                                                ) ==
                                                                FriendshipStatus.requestSent)
                                                            ? const SizedBox()
                                                            : FriendshipStatusService.instance.getFriendshipStatus(
                                                                      friendshipSnapshot: dataSnapshot,
                                                                      me: user.uid,
                                                                      other: widget.usermodel.uId ?? "",
                                                                    ) ==
                                                                    FriendshipStatus.acceptRequest
                                                                ? SvgPicture.asset(
                                                                    "Assets/icons/Union.svg",
                                                                    color: Colors.white,
                                                                  )
                                                                : SvgPicture.asset(
                                                                    "Assets/icons/Union_del.svg",
                                                                    color: Colors.black,
                                                                  ),
                                                    onTap: () async {
                                                      await _onFriendshipButtonTap(dataSnapshot, user, profileContrl, controller, context);
                                                    },
                                                    buttonColor:
                                                        _getFriendshipButtonColor(dataSnapshot, user.uid, widget.usermodel.uId ?? ''),
                                                    color: kBlackColor.withOpacity(0.5),
                                                    title: _getFriendshipButtonTitle(dataSnapshot, user.uid, widget.usermodel.uId ?? ''),
                                                    style:
                                                        _getFriendshipButtonTextStyle(dataSnapshot, user.uid, widget.usermodel.uId ?? ''),
                                                  );
                                                },
                                              ),
                                            ),
                                            const SizedBox(
                                              width: distance_5,
                                            ),
                                            Expanded(
                                              child: newChat == true
                                                  ? ButtonWidget(
                                                      icon: SvgPicture.asset(
                                                        "Assets/images/outline_mesage.svg",
                                                        color: kWhiteColor,
                                                      ),
                                                      title: GayaStrings.message_txt.tr,
                                                      color: kprimaryColor,
                                                      style: body2StyleWeight,
                                                      buttonColor: kprimaryColor,
                                                      onTap: () async {
                                                        if (SharedService.isEnteredAgeValid(widget.usermodel.dob ?? DateTime(2000), 16) ==
                                                                false &&
                                                            FriendshipStatusService.instance.getFriendshipStatus(
                                                                  friendshipSnapshot: dataSnapshot,
                                                                  me: user.uid,
                                                                  other: widget.usermodel.uId ?? "",
                                                                ) !=
                                                                FriendshipStatus.unFriend) {
                                                          GayaSnackBar.show(
                                                              context: context,
                                                              type: GayaSnackBarType.problem,
                                                              text: GayaStrings.not_allowed_users_lower_than_16_years.tr);
                                                        } else {
                                                          if (widget.usermodel.allowToDm == false) {
                                                            GayaSnackBar.show(
                                                                context: context,
                                                                type: GayaSnackBarType.problem,
                                                                text: GayaStrings.cannot_send_message.tr);
                                                          } else {
                                                            if (ChatController.to().currentUser != null) {
                                                              ChatController.to()
                                                                  .helperFunc
                                                                  .openOrCreateCubeConversation(context, widget.usermodel.uId ?? "");
                                                            }
                                                            //ChatRoomModel? chatRoom = await getchatRoomCUstom();
                                                            //if ((chatRoom != null)) {
                                                            //EngagementScoreController.to.instance
                                                            //.onDirectMessage(toUserId: widget.usermodel.uId ?? "");
                                                            //Routes.personMessages(person: widget.usermodel, chatroom: chatRoom);
                                                            //}
                                                          }
                                                        }
                                                      },
                                                    )
                                                  : ButtonWidget(
                                                      onTap: () async {
                                                        if (SharedService.isEnteredAgeValid(widget.usermodel.dob ?? DateTime(2000), 16) ==
                                                                false &&
                                                            FriendshipStatusService.instance.getFriendshipStatus(
                                                                  friendshipSnapshot: dataSnapshot,
                                                                  me: user.uid,
                                                                  other: widget.usermodel.uId ?? "",
                                                                ) !=
                                                                FriendshipStatus.unFriend) {
                                                          GayaSnackBar.show(
                                                              context: context,
                                                              type: GayaSnackBarType.problem,
                                                              text: GayaStrings.not_allowed_users_lower_than_16_years.tr);
                                                        } else {
                                                          if (widget.usermodel.allowToDm == false &&
                                                              FriendshipStatusService.instance.getFriendshipStatus(
                                                                    friendshipSnapshot: dataSnapshot,
                                                                    me: user.uid,
                                                                    other: widget.usermodel.uId ?? "",
                                                                  ) !=
                                                                  FriendshipStatus.unFriend) {
                                                            GayaSnackBar.show(
                                                                context: context,
                                                                type: GayaSnackBarType.problem,
                                                                text: GayaStrings.cannot_send_message.tr);
                                                          } else {
                                                            if (ChatController.to().currentUser != null) {
                                                              ChatController.to()
                                                                  .helperFunc
                                                                  .openOrCreateCubeConversation(context, widget.usermodel.uId ?? "");
                                                            }
                                                            //ChatRoomModel? chatRoom = await getchatRoomCUstom();
                                                            //if ((chatRoom != null)) {
                                                            //EngagementScoreController.to.instance
                                                            //.onDirectMessage(toUserId: widget.usermodel.uId ?? "");
                                                            //Routes.personMessages(person: widget.usermodel, chatroom: chatRoom);
                                                            //}
                                                          }
                                                        }
                                                      },
                                                      title: (GayaStrings.message.tr),
                                                      buttonColor:
                                                          (SharedService.isEnteredAgeValid(widget.usermodel.dob ?? DateTime(2000), 16) ==
                                                                      true &&
                                                                  widget.usermodel.allowToDm != false)
                                                              ? kprimaryColor
                                                              : kBaseGrey,
                                                      color: kBlackColor.withOpacity(0.8),
                                                      icon: SvgPicture.asset(
                                                        "Assets/images/outline_mesage.svg",
                                                        color:
                                                            (SharedService.isEnteredAgeValid(widget.usermodel.dob ?? DateTime(2000), 16) ==
                                                                        true &&
                                                                    widget.usermodel.allowToDm != false)
                                                                ? Colors.white
                                                                : disableColor,
                                                      ),
                                                      style: (SharedService.isEnteredAgeValid(widget.usermodel.dob ?? DateTime(2000), 16) ==
                                                                  true &&
                                                              widget.usermodel.allowToDm != false)
                                                          ? body2StyleWeight
                                                          : body2StyleWeighGrey,
                                                    ),
                                            ),
                                          ],
                                        );
                                      } else {
                                        const NoNotificationWidget();
                                      }
                                    }

                                    return const NoNotificationWidget();
                                  },
                                ),
                          const SizedBox(
                            height: distance_12,
                          ),
                          FutureProvider<DocumentSnapshot?>(
                            initialData: null,
                            create: (context) => otherProfileDetails,
                            child: Consumer<DocumentSnapshot?>(
                              builder: (context, value, _) {
                                return value == null
                                    ? const SizedBox()
                                    : Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          StatefulBuilder(builder: (context, state) {
                                            return Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Text(
                                                  GayaStrings.compliment_txt.tr,
                                                  style: GayaTypography.titleMedium,
                                                ),
                                                SizedBox(
                                                  height: 4.h,
                                                ),
                                                Row(
                                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    SizedBox(
                                                      width: MediaQuery.of(context).size.width * 0.65,
                                                      child: Text(
                                                        '${'${GayaStrings.send_txt.tr} '}${widget.usermodel.name} ${GayaStrings.compliment_anonymously.tr}',
                                                        style: TextStyle(
                                                            fontWeight: FontWeight.w400,
                                                            color: Colors.grey,
                                                            fontSize: 14.sp,
                                                            fontFamily: GayaFontTheme.primaryFont),
                                                      ),
                                                    ),
                                                    SizedBox(width: 5.w),
                                                    Expanded(
                                                      child: GestureDetector(
                                                        onTap: () {
                                                          state(
                                                            () => complimentList.shuffle(),
                                                          );
                                                        },
                                                        child: Row(
                                                          children: [
                                                            SizedBox(
                                                              height: 20.h,
                                                              width: 20.w,
                                                              child: SvgPicture.asset(Assets.shuffleIcon),
                                                            ),
                                                            SizedBox(width: 10.w),
                                                            Expanded(
                                                              child: Text(
                                                                GayaStrings.shuffle_txt.tr,
                                                                overflow: TextOverflow.ellipsis,
                                                                style: GayaTypography.titleMedium,
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    )
                                                  ],
                                                ),
                                                SizedBox(
                                                  height: 4.h,
                                                ),
                                                Container(
                                                  padding: EdgeInsets.all(5.r),
                                                  decoration: BoxDecoration(
                                                    borderRadius: BorderRadius.circular(18.r),
                                                    boxShadow: <BoxShadow>[
                                                      BoxShadow(
                                                        color: Colors.grey.withOpacity(0.05),
                                                        blurRadius: 3.0,
                                                        offset: const Offset(0.0, 3.0),
                                                      ),
                                                    ],
                                                  ),
                                                  height: 175.h,
                                                  child: Center(
                                                    child: Card(
                                                      shape: RoundedRectangleBorder(
                                                        borderRadius: BorderRadius.circular(18.r),
                                                      ),
                                                      elevation: 6,
                                                      child: Padding(
                                                        padding: EdgeInsets.all(18.r),
                                                        child: GridView.builder(
                                                          physics: const NeverScrollableScrollPhysics(),
                                                          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                                                            mainAxisSpacing: 15.w,
                                                            crossAxisSpacing: 15.w,
                                                            crossAxisCount: 2,
                                                            mainAxisExtent: 50.h,
                                                          ),
                                                          itemCount: 4,
                                                          shrinkWrap: true,
                                                          itemBuilder: (context, index) => InkWell(
                                                            onTap: () {
                                                              // Todo: helping stuff
                                                              ComplimentSavedUser tappedUser = ComplimentSavedUser(
                                                                  id: widget.usermodel.uId.toString(),
                                                                  name: widget.usermodel.name.toString(),
                                                                  startTime: DateTime.now());
                                                              controller.startTimer(
                                                                  user: tappedUser, context: context, compliment: complimentList[index]);
                                                            },
                                                            child: Container(
                                                              decoration: BoxDecoration(
                                                                color: kprimaryColor,
                                                                borderRadius: BorderRadius.circular(5.r),
                                                              ),
                                                              child: Center(
                                                                child: Text(
                                                                  complimentList[index].tr,
                                                                  style: TextStyle(
                                                                      fontSize: 14.sp, fontWeight: FontWeight.w500, color: Colors.white),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            );
                                          }),
                                          SizedBox(
                                            height: 8.h,
                                          ),
                                          Text(
                                            GayaStrings.fav_topics.tr,
                                            style: GayaTypography.titleMedium,
                                          ),
                                          const SizedBox(
                                            height: 4,
                                          ),
                                          Builder(
                                            builder: (context) {
                                              var data = value.data() as Map<String, dynamic>;
                                              UserModel userDetailsModel = UserModel.fromMap(data);
                                              return Wrap(
                                                direction: Axis.horizontal,
                                                runAlignment: WrapAlignment.start,
                                                // runSpacing: distance_10,
                                                spacing: distance_10,
                                                children: List.generate(userDetailsModel.interests?.length ?? 0, (index) {
                                                  return InterestWidget(
                                                    color: kBaseGrey,
                                                    horizontalDistance: distance_40,
                                                    image: userDetailsModel.interests?[index].image ?? '',
                                                    title: userDetailsModel.interests?[index].title ?? '',
                                                    onTap: () {
                                                      Routes.seeAllInterestCommunitiesView(
                                                          communityName: userDetailsModel.interests?[index].title);
                                                    },
                                                  );
                                                }),
                                              );
                                            },
                                          ),
                                        ],
                                      );
                              },
                            ),
                          ),
                          MySpaces.bottom
                        ],
                      );
                    },
                  );
                },
              ),
            ),
          ),
        ),
      ),
    );
  }

  /// callback to pass on addFriend, removeFriend, acceptRequest, requestSent Button tap
  Future<void> _onFriendshipButtonTap(
    AsyncSnapshot<QuerySnapshot<Object?>> dataSnapshot,
    User user,
    ProfileController profileContrl,
    ProfileController controller,
    BuildContext context,
  ) async {
    switch (FriendshipStatusService.instance.getFriendshipStatus(
      friendshipSnapshot: dataSnapshot,
      me: user.uid,
      other: widget.usermodel.uId ?? '',
    )) {
      /* ----------------------- FriendshipStatus.addFriend ----------------------- */
      case FriendshipStatus.addFriend:
        if (dataSnapshot.data!.docs.isEmpty || profileContrl.isRequestSend == false) {
          final userDeatail = profileContrl.userDetails!;
          final userDetailModel = widget.usermodel;
          await profileContrl.createFriendShip(
            userDetailModel.uId ?? '',
            userDetailModel.name ?? '',
            userDeatail['name'] ?? '',
            userDeatail['profilePic'] ?? '',
            userDetailModel.fm_token,
          );
        }
        break;
      /* ------------------------ FriendshipStatus.unFriend ----------------------- */
      case FriendshipStatus.unFriend:
        log('unfriend sent.');
        DialogueC(
          widget.usermodel.name!,
          () {
            Get.back();
            controller.unFriend(widget.usermodel.uId!);
          },
          context,
        );

        break;
      /* --------------------- FriendshipStatus.acceptRequest --------------------- */
      case FriendshipStatus.acceptRequest:
        await profileContrl.acceptFriendRequest(dataSnapshot.data!.docs[0].id);
        break;
      /* ---------------------- FriendshipStatus.requestSent ---------------------- */
      case FriendshipStatus.requestSent:
        controller.unFriend(widget.usermodel.uId!);
        break;
    }
  }

  /// invoke to get button color
  Color _getFriendshipButtonColor(
    AsyncSnapshot<QuerySnapshot<Object?>> friendshipSnapshot,
    String myUid,
    String otherUid,
  ) {
    switch (FriendshipStatusService.instance.getFriendshipStatus(
      friendshipSnapshot: friendshipSnapshot,
      me: myUid,
      other: otherUid,
    )) {
      case FriendshipStatus.addFriend:
        return kprimaryColor;
      case FriendshipStatus.unFriend:
        return kBaseGrey;
      case FriendshipStatus.acceptRequest:
        return kprimaryColor;
      case FriendshipStatus.requestSent:
        return kprimaryColor;
    }
  }

  /// invoke to get button text style
  TextStyle _getFriendshipButtonTextStyle(
    AsyncSnapshot<QuerySnapshot<Object?>> friendshipSnapshot,
    String myUid,
    String otherUid,
  ) {
    switch (FriendshipStatusService.instance.getFriendshipStatus(
      friendshipSnapshot: friendshipSnapshot,
      me: myUid,
      other: otherUid,
    )) {
      case FriendshipStatus.addFriend:
        return body4StyleWhite;
      case FriendshipStatus.unFriend:
        return bodyStyle;
      case FriendshipStatus.acceptRequest:
        return body4StyleWhite;
      case FriendshipStatus.requestSent:
        return body4StyleWhite;
    }
  }

  /// invoke to get title of button
  String _getFriendshipButtonTitle(
    AsyncSnapshot<QuerySnapshot<Object?>> friendshipSnapshot,
    String myUid,
    String otherUid,
  ) {
    switch (FriendshipStatusService.instance.getFriendshipStatus(
      friendshipSnapshot: friendshipSnapshot,
      me: myUid,
      other: otherUid,
    )) {
      case FriendshipStatus.addFriend:
        return GayaStrings.add_friend.tr;
      case FriendshipStatus.unFriend:
        return GayaStrings.unfriend.tr;
      case FriendshipStatus.acceptRequest:
        return GayaStrings.accept_request.tr;
      case FriendshipStatus.requestSent:
        return GayaStrings.request_sent.tr;
    }
  }

  //Function to check whether the chatroom between the current user and reciver is created or not
  Future<ChatRoomModel?> getchatRoomCUstom({bool shouldRefresh = true}) async {
    newChat = true;
    if (shouldRefresh) setState(() {});
    ChatRoomModel chatRoom = ChatRoomModel();
    User? myUser = firebaseAuth.currentUser;
    if (myUser == null) {
      return null;
    }
    final participants = [myUser.uid, widget.usermodel.uId ?? ""]..sort();
    QuerySnapshot querySnapshot = await FirebaseFirestore.instance.collection('chatrooms').where("userIds", isEqualTo: participants).get();
    if (querySnapshot.docs.isNotEmpty) {
      chatRoom = ChatRoomModel.fromMap(querySnapshot.docs[0].data() as Map<String, dynamic>);
    } else {
      //create room if dont exist
      ChatRoomModel newChatRoom = ChatRoomModel(
          chatRoomId: participants.join(),
          typing: [],
          participants: participants,
          isReadSender: true,
          isReadReceiver: false,
          lastMessage: '',
          lastMesgUserId: myUser.uid);

      final UserModel? participant1 = await Services().getUserById(FirebaseAuth.instance.currentUser!.uid);
      final UserModel? participant2 = await Services().getUserById(widget.usermodel.uId);
      if (participant1 == null || participant2 == null) return null;
      await FirebaseFirestore.instance
          .collection('chatrooms')
          .doc(participants.join())
          .set(newChatRoom.toMapForCreateRoom(participant1: participant1, participant2: participant2));
      chatRoom = newChatRoom;
    }

    return chatRoom;
  }
}
