// import 'dart:io';
// import 'package:cached_network_image/cached_network_image.dart';
// import 'package:flutter_svg/flutter_svg.dart';
// import 'package:gaya/components/textfield.component.dart';
// import 'package:gaya/gen/assets.gen.dart';
// import 'package:gaya/model/user.model.dart';
// import 'package:gaya/utils/app_data.dart';
// import 'package:gaya/utils/asset_images.dart';
// import 'package:gaya/utils/const.dart';
// import 'package:gaya/utils/logger.dart';
// import 'package:gaya/utils/textstyles.dart';
// import 'package:gaya/utils/theme/app_colors.dart';
// import 'package:gaya/utils/theme/app_typography.dart';
// import 'package:gaya/view/chat/components/common.dart';
// import 'package:gaya/view/chat/components/connectyCubeUser_listTile_skeleton.dart';
// import 'package:gaya/view/chat/components/connectycube_user_listTile.dart';
// import 'package:gaya/view/chat/components/pick_image_bottomsheet.dart';
// import 'package:gaya/view/chat/components/selected_user_listTile.dart';
// import 'package:gaya/view/chat/controllers/chat_controller.dart';
// import 'package:gaya/widgets/profile.widgets/button.widget.dart';
// import 'package:get/get.dart';
// import 'package:flutter/material.dart';
// import 'package:gaya/view/chat/utils/consts.dart';
// import 'package:flutter/cupertino.dart';
// import 'package:flutter_screenutil/flutter_screenutil.dart';

// class NewGroupScreen extends StatelessWidget {
//   const NewGroupScreen({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//         appBar: AppBar(
//           title: Text(
//             'New Group',
//             style: TextStyle(color: primaryColor, fontWeight: FontWeight.bold),
//           ),
//           centerTitle: true,
//         ),
//         body: const NewGroupScreenBody(),
//         resizeToAvoidBottomInset: false);
//   }
// }

// class NewGroupScreenBody extends StatefulWidget {
//   const NewGroupScreenBody({super.key});

//   @override
//   // ignore: no_logic_in_create_state
//   State createState() => NewGroupScreenBodyState();
// }

// class NewGroupScreenBodyState extends State<NewGroupScreenBody> {
//   NewGroupScreenBodyState();

//   final chatController = ChatController.to();

//   // @override
//   // void initState() {
//   //   super.initState();
//   //   chatController.groupNameTextFieldListener();
//   // }

//   @override
//   void dispose() {
//     chatController.disposeOfCreateNewGroupScreen();
//     super.dispose();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//         body: Container(
//             padding: const EdgeInsets.all(16),
//             child: GetBuilder<ChatController>(
//               init: chatController,
//               builder: (chatController) {
//                 return Column(
//                   children: [
//                     // _buildGroupFields(),

//                     Column(
//                       children: <Widget>[
//                         Row(
//                           children: <Widget>[
//                             RawMaterialButton(
//                                 onPressed: () => chatController.pickAndUploadNewGroupImage(),
//                                 elevation: 2.0,
//                                 fillColor: Colors.white,
//                                 padding: const EdgeInsets.all(10.0),
//                                 shape: const CircleBorder(),
//                                 child: //getIcon(),
//                                     (chatController.selectedGroupImage == null)
//                                         ? const Icon(
//                                             Icons.photo_camera,
//                                             size: 45.0,
//                                             color: Colors.blue,
//                                           )
//                                         : Image.memory(chatController.selectedGroupImage!, width: 45.0, height: 45.0)),
//                             Flexible(
//                               child: TextField(
//                                 controller: chatController.groupNameTextField,
//                                 decoration: const InputDecoration(labelText: 'Group Name...'),
//                               ),
//                             )
//                           ],
//                         ),
//                         Container(
//                           alignment: Alignment.centerLeft,
//                           margin: const EdgeInsets.all(16.0),
//                           child: Text(
//                             'Please provide a group name and an optional group icon',
//                             style: TextStyle(color: primaryColor),
//                           ),
//                         ),
//                       ],
//                     ),
//                     // _buildDialogOccupants(),
//                     Expanded(
//                         child: //_getOccupants(),
//                             ListView.builder(
//                       shrinkWrap: true,
//                       padding: const EdgeInsets.symmetric(vertical: 20.0),
//                       scrollDirection: Axis.horizontal,
//                       itemCount: chatController.currentChat?.occupantsIds?.length,
//                       itemBuilder: (context, index) => groupSingleOccupantListTile(context, index),
//                     ))
//                   ],
//                 );
//               },
//             )),
//         floatingActionButton: FloatingActionButton(
//           heroTag: "New dialog",
//           backgroundColor: Colors.blue,
//           onPressed: () => chatController.createNewGroupChat(context),
//           child: const Icon(
//             Icons.check,
//             color: Colors.white,
//           ),
//         ),
//         resizeToAvoidBottomInset: false);
//   }

//   groupSingleOccupantListTile(BuildContext context, int index) {
//     return GetBuilder<ChatController>(
//       init: chatController,
//       builder: (chatController) {
//         return Column(
//           children: <Widget>[
//             Material(
//               borderRadius: const BorderRadius.all(Radius.circular(25.0)),
//               clipBehavior: Clip.hardEdge,
//               child: CircleAvatar(
//                 backgroundImage: chatController.selectedGroupUsers?[index]?.avatar != null &&
//                         chatController.selectedGroupUsers![index]!.avatar!.isNotEmpty
//                     ? NetworkImage(chatController.selectedGroupUsers![index]!.avatar!)
//                     : null,
//                 radius: 25,
//                 child: getAvatarTextWidget(
//                     chatController.selectedGroupUsers?[index]!.avatar != null &&
//                         chatController.selectedGroupUsers![index]!.avatar!.isNotEmpty,
//                     chatController.selectedGroupUsers?[index]!.fullName!.substring(0, 2).toUpperCase()),
//               ),
//             ),
//             Container(
//               margin: const EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 10.0),
//               child: Column(
//                 children: <Widget>[
//                   Container(
//                     width: MediaQuery.of(context).size.width / 4,
//                     alignment: Alignment.center,
//                     margin: const EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 5.0),
//                     child: Text(
//                       chatController.selectedGroupUsers?[index]?.fullName ?? 'Un-Available',
//                       style: TextStyle(color: primaryColor),
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//           ],
//         );
//       },
//     );
//   }
// }

// /////////////////////////////////////////////// New Group New UI ////////////////////////////////////////////////

// void showConnectyCubeNewChatSheets({required BuildContext ctx, required Function(UserModel?)? onUserTap}) {
//   final chatController = ChatController.to();
//   chatController.getAllCubeUsersList(shouldClearFields: true);
//   // editCommunityController.initializeCommunityMembersServices();
//   //   editCommunityController.requestMoreData(fromInit: true);
//   showModalBottomSheet(
//       context: ctx,
//       enableDrag: false,
//       isScrollControlled: true,
//       isDismissible: false,
//       shape: RoundedRectangleBorder(borderRadius: const BorderRadius.only(topLeft: Radius.circular(12), topRight: Radius.circular(12)).r),
//       builder: (context) {
//         return GetBuilder<ChatController>(
//           init: chatController,
//           builder: (chatController) {
//             return WillPopScope(
//               onWillPop: () async {
//                 chatController.clearSearchValues();
//                 chatController.update();
//                 return true;
//               },
//               child: SingleChildScrollView(
//                 child: SafeArea(
//                   child: Container(
//                     padding: EdgeInsets.only(
//                       bottom: MediaQuery.of(context).viewInsets.bottom,
//                       left: 20.w,
//                       right: 20.w,
//                     ),
//                     child: SizedBox(
//                       height: MediaQuery.of(context).size.height - (kBottomNavigationBarHeight),
//                       child: Column(
//                         mainAxisSize: MainAxisSize.min,
//                         children: [
//                           SizedBox(height: 12.h),
//                           Container(height: 4, width: 40, decoration: const BoxDecoration(color: kBaseGrey)),
//                           SizedBox(height: 12.h),
//                           Row(
//                             mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                             children: [
//                               InkWell(
//                                   child: Text((chatController.isCreateGroupEditFieldsScreenSelected == true) ? 'Back' : 'Cancel',
//                                       style: CustomTypography.modalSheetTitleStyle),
//                                   onTap: () {
//                                     if (chatController.isNewGroupChat == false) {
//                                       Navigator.pop(context);
//                                     } else {
//                                       if (chatController.isCreateGroupEditFieldsScreenSelected == true) {
//                                         chatController.goBackFromCreateGroupFieldsViewAndClearFields();
//                                         // editCommunityController.resetController(isDisposing: true);
//                                       } else {
//                                         Navigator.pop(context);
//                                       }
//                                     }
//                                   }),
//                               Text(
//                                   (chatController.isNewGroupChat == false)
//                                       ? 'New Chat'
//                                       : (chatController.isCreateGroupEditFieldsScreenSelected == true)
//                                           ? 'Add Participants'
//                                           : 'New Group',
//                                   style: GayaTypography.titleMedium.copyWith(fontWeight: FontWeight.w600)),
//                               InkWell(
//                                   child: Text(
//                                     (chatController.isCreateGroupEditFieldsScreenSelected == true) ? 'Create' : 'Next',
//                                     style: CustomTypography.modalSheetTitleStyle.copyWith(fontWeight: FontWeight.w600),
//                                   ),
//                                   onTap: () {
//                                     if (chatController.isNewGroupChat == false) {
//                                       if (chatController.searchedUsersList.isNotEmpty) {
//                                         chatController.createNewConversation(context, {chatController.searchedUsersList.first.id!}, false);
//                                       } else if (chatController.allCubeUsers.isNotEmpty) {
//                                         chatController.createNewConversation(context, {chatController.allCubeUsers.first.id!}, false);
//                                       }
//                                     } else {
//                                       if (chatController.isCreateGroupEditFieldsScreenSelected == false &&
//                                           chatController.selectedUsers.isNotEmpty) {
//                                         chatController.createNewConversation(context, chatController.selectedUsers, true);
//                                       } else if (chatController.isCreateGroupEditFieldsScreenSelected == true &&
//                                           chatController.groupNameTextField.text.isNotEmpty) {
//                                         chatController.createNewGroupChat(context);
//                                       } else {
//                                         MyLoggerServices.to.print('Error: No SelectedUsers available');
//                                       }
//                                     }
//                                   }),
//                             ],
//                           ),
//                           (chatController.isCreateGroupEditFieldsScreenSelected == false)
//                               ? SizedBox(
//                                   height: MediaQuery.of(context).size.height - (kBottomNavigationBarHeight + kToolbarHeight + 50.h),
//                                   child: Column(
//                                     children: [
//                                       SizedBox(height: 16.h),
//                                       CupertinoSearchTextField(
//                                           controller: chatController.groupNameTextField,
//                                           onSuffixTap: () {
//                                             chatController.clearSearchValues();
//                                             chatController.update();
//                                           },
//                                           onSubmitted: (value) {
//                                             chatController.searchUsers(value.trim());
//                                           }),
//                                       SizedBox(height: 16.h),
//                                       (chatController.isNewGroupChat == false)
//                                           ? Padding(
//                                               padding: const EdgeInsets.symmetric(horizontal: 4).w,
//                                               child: InkWell(
//                                                 highlightColor: AppColors.transparrent,
//                                                 hoverColor: AppColors.transparrent,
//                                                 onTap: () {
//                                                   chatController.toggleIsNewGroupChat();
//                                                 },
//                                                 child: Row(
//                                                   children: [
//                                                     SvgIcons.saveSolid(height: 18.h, width: 20.w),
//                                                     SizedBox(width: 8.w),
//                                                     Text('Create new group', style: GayaTypography.titleMedium.copyWith(fontSize: 14.sp)),
//                                                   ],
//                                                 ),
//                                               ))
//                                           : SizedBox(
//                                               height: (chatController.selectedCubeUsersList.isEmpty) ? 0.h : 58.h,
//                                               child: (chatController.selectedCubeUsersList.isEmpty)
//                                                   ? const SizedBox.shrink()
//                                                   : ListView.separated(
//                                                       separatorBuilder: (context, index) {
//                                                         return Padding(
//                                                           padding: const EdgeInsets.only(right: 24).w,
//                                                         );
//                                                       },
//                                                       scrollDirection: Axis.horizontal,
//                                                       itemCount: chatController.selectedCubeUsersList.length,
//                                                       padding: EdgeInsets.zero,
//                                                       itemBuilder: (BuildContext context, index) {
//                                                         try {
//                                                           return SelectedUserListTile(
//                                                             user: chatController.selectedCubeUsersList[index],
//                                                             onUserTap: () {
//                                                               MyLoggerServices.to.print('onUserTap is: $index,');
//                                                               chatController.removeSelectedUsers(
//                                                                   index, chatController.selectedCubeUsersList[index]);
//                                                             },
//                                                           );
//                                                         } catch (_) {
//                                                           return const SizedBox.shrink();
//                                                         }
//                                                       }),
//                                             ),
//                                       SizedBox(height: 8.h),
//                                       Expanded(
//                                           child: (chatController.searchedUsersList.isNotEmpty)
//                                               ? ListView.builder(
//                                                   itemCount: chatController.searchedUsersList.length,
//                                                   padding: EdgeInsets.zero,
//                                                   itemBuilder: (BuildContext context, index) {
//                                                     try {
//                                                       final user = chatController.searchedUsersList[index];
//                                                       return ConnectyCubeUserListTile(
//                                                         user: user,
//                                                         chatController: chatController,
//                                                         onUserTap: () {
//                                                           chatController.addRemoveUsersInNewGroupChatForSearchedUsers(index);
//                                                         },
//                                                       );
//                                                     } catch (_) {
//                                                       return const SizedBox.shrink();
//                                                     }
//                                                   })
//                                               : (chatController.isConnectyCubeUsersLoading)
//                                                   ? Column(
//                                                       children: const [
//                                                         ConnectyCubeUserListTileSkeleton(),
//                                                         ConnectyCubeUserListTileSkeleton(),
//                                                         ConnectyCubeUserListTileSkeleton(),
//                                                         ConnectyCubeUserListTileSkeleton(),
//                                                         ConnectyCubeUserListTileSkeleton(),
//                                                         ConnectyCubeUserListTileSkeleton(),
//                                                         ConnectyCubeUserListTileSkeleton(),
//                                                         ConnectyCubeUserListTileSkeleton(),
//                                                         ConnectyCubeUserListTileSkeleton(),
//                                                       ],
//                                                     )
//                                                   : (chatController.allCubeUsers.isEmpty)
//                                                       ? Center(child: Text("No user found!", style: body2DisableStyle))
//                                                       : ListView.builder(
//                                                           itemCount: chatController.allCubeUsers.length,
//                                                           shrinkWrap: true,
//                                                           padding: EdgeInsets.zero,
//                                                           itemBuilder: (BuildContext context, index) {
//                                                             try {
//                                                               final user = chatController.allCubeUsers[index];
//                                                               return ConnectyCubeUserListTile(
//                                                                 user: user,
//                                                                 onUserTap: () {
//                                                                   chatController.addRemoveUsersInNewGroupChatForAllUsersList(index);
//                                                                 },
//                                                                 chatController: chatController,
//                                                               );
//                                                             } catch (_) {
//                                                               return const SizedBox.shrink();
//                                                             }
//                                                           })),
//                                     ],
//                                   ),
//                                 )
//                               // ,
//                               : SizedBox(
//                                   height: MediaQuery.of(context).size.height - (kBottomNavigationBarHeight + 50.h),
//                                   child: Column(children: [
//                                     SizedBox(height: 16.h),
//                                     Row(
//                                       children: [
//                                         Text('Group subject', style: GayaTypography.subtitleRegular),
//                                       ],
//                                     ),
//                                     SizedBox(height: 8.h),
//                                     textField(
//                                       controller: chatController.groupNameTextField,
//                                       maxlines: null,
//                                       borderColor: borderColor,
//                                       isPassword: false,
//                                       textStyle: GayaTypography.subtitleRegular,
//                                       autovalidateModel: AutovalidateMode.onUserInteraction,
//                                       inputType: TextInputType.text,
//                                       textInputAction: TextInputAction.done,
//                                       validation: (value) {
//                                         if (value.toString().trim().isEmpty) {
//                                           return "Please enter group name.";
//                                         }
//                                         return null;
//                                       },
//                                       onChanged: (value) {},
//                                       hintTextStyle: GayaTypography.subtitleRegular.copyWith(color: MyColorHex().blackShade2),
//                                       hintText: 'Example: The best team ever',
//                                     ),
//                                     SizedBox(height: 16.h),
//                                     Row(
//                                       children: [
//                                         Text('Group icon', textAlign: TextAlign.left, style: GayaTypography.titleMedium),
//                                       ],
//                                     ),
//                                     SizedBox(height: 4.h),
//                                     Row(
//                                       children: [
//                                         Text('Provide optional group icon',
//                                             style: GayaTypography.subtitleRegular.copyWith(color: MyColorHex().blackShade2)),
//                                       ],
//                                     ),
//                                     SizedBox(height: 16.h),
//                                     chatController.isImageUploading == true
//                                         ? CircleAvatar(
//                                             radius: 60.r,
//                                             backgroundColor: Colors.grey.shade200,
//                                             child: CircularProgressIndicator.adaptive(
//                                               backgroundColor: AppColors.primary,
//                                             ),
//                                           )
//                                         : chatController.currentChat?.photo != null &&
//                                                 chatController.currentChat?.photo != '' &&
//                                                 chatController.isImageUploading == false
//                                             ? CircleAvatar(
//                                                 radius: 60.r,
//                                                 child: CachedNetworkImage(
//                                                   memCacheHeight: 100,
//                                                   memCacheWidth: 100,
//                                                   imageUrl: chatController.currentChat?.photo ?? '',
//                                                   imageBuilder: (context, imageProvider) {
//                                                     return Container(
//                                                       decoration: BoxDecoration(
//                                                           shape: BoxShape.circle,
//                                                           image: DecorationImage(image: imageProvider, fit: BoxFit.cover)),
//                                                     );
//                                                   },
//                                                   fit: BoxFit.cover,
//                                                   errorWidget: (context, url, error) => AppData.defaultGreyCircleImage,
//                                                   placeholder: (context, url) => AppData.defaultGreyCircleImage,
//                                                 ),
//                                               )
//                                             : CircleAvatar(
//                                                 radius: 60.r,
//                                                 child: AppData.defaultGreyCircleImage,
//                                               ),
//                                     SizedBox(height: 16.h),
//                                     ButtonWidget(
//                                       icon: SvgPicture.asset(Assets.assets.icons.galleryIcon),
//                                       onTap: () async {
//                                         // await communityEditCtrl.pickImageFromGallery(context: context, photoType: PhotoType.profile);
//                                         if (Platform.isIOS) {
//                                           showIosStyleSheet(context, chatController);
//                                         } else {
//                                           showAndroidSheet(context, chatController);
//                                         }
//                                       },
//                                       buttonColor: borderColor.withOpacity(0.4),
//                                       color: kSecondaryColor.withOpacity(0.6),
//                                       height: 40.h,
//                                       title: 'Edit group picture',
//                                       style: secondaryFontStyleBig,
//                                     ),
//                                   ])),
//                         ],
//                       ),
//                     ),
//                   ),
//                 ),
//               ),
//             );
//           },
//         );
//       });
// }
