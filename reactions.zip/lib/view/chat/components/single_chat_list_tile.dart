import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:gaya/routing/getx_route_methods.dart';
import 'package:gaya/utils/language/translation.dart';
import 'package:gaya/view/chat/controllers/chat_controller.dart';
import 'package:gaya/view/chat/utils/consts.dart';
import 'package:connectycube_sdk/connectycube_sdk.dart';
import 'package:get/get.dart';
import 'package:jiffy/jiffy.dart';

Widget singleChatListTile(BuildContext context, int index) {
  final chatController = ChatController.to();

  getDialogIcon() {
    var dialog = chatController.chatsList[index].data;
    if (dialog.type == CubeDialogType.PRIVATE) {
      return Icon(
        Icons.person,
        size: 40.0,
        color: greyColor,
      );
    } else {
      return Icon(
        Icons.group,
        size: 40.0,
        color: greyColor,
      );
    }
  }

  getDialogAvatarWidget() {
    var dialog = chatController.chatsList[index].data;
    if (dialog.photo == null) {
      return CircleAvatar(radius: 25, backgroundColor: greyColor3, child: getDialogIcon());
    } else {
      return CachedNetworkImage(
        placeholder: (context, url) => Container(
          width: 40.0,
          height: 40.0,
          padding: const EdgeInsets.all(70.0),
          decoration: BoxDecoration(
            color: greyColor2,
            borderRadius: const BorderRadius.all(
              Radius.circular(8.0),
            ),
          ),
          child: CircularProgressIndicator(
            valueColor: AlwaysStoppedAnimation<Color>(themeColor),
          ),
        ),
        imageUrl: chatController.chatsList[index].data.photo!,
        width: 45.0,
        height: 45.0,
        fit: BoxFit.cover,
      );
    }
  }

  return Container(
    margin: const EdgeInsets.only(left: 5.0, right: 5.0),
    child: TextButton(
      child: Row(
        children: <Widget>[
          Material(
            borderRadius: const BorderRadius.all(Radius.circular(25.0)),
            clipBehavior: Clip.hardEdge,
            child: getDialogAvatarWidget(),
          ),
          Flexible(
            child: Container(
              margin: const EdgeInsets.only(left: 20.0),
              child: Column(
                children: <Widget>[
                  Container(
                    alignment: Alignment.centerLeft,
                    margin: const EdgeInsets.fromLTRB(10.0, 0.0, 0.0, 5.0),
                    child: Text(
                      chatController.chatsList[index].data.name ?? GayaStrings.not_available.tr,
                      style: TextStyle(color: primaryColor, fontWeight: FontWeight.bold, fontSize: 20.0),
                    ),
                  ),
                  Container(
                    alignment: Alignment.centerLeft,
                    margin: const EdgeInsets.fromLTRB(10.0, 0.0, 0.0, 0.0),
                    child: Text(
                      chatController.chatsList[index].data.lastMessage ?? GayaStrings.not_available.tr,
                      style: TextStyle(color: primaryColor),
                    ),
                  ),
                ],
              ),
            ),
          ),
          Visibility(
            maintainSize: true,
            maintainAnimation: true,
            maintainState: true,
            visible: chatController.chatsList[index].isSelected,
            child: IconButton(
              iconSize: 25.0,
              icon: Icon(
                Icons.delete,
                color: themeColor,
              ),
              onPressed: () {
                _deleteDialog(context, chatController.chatsList[index].data);
              },
            ),
          ),
          Column(
            children: [
              Text(
                chatController.chatsList[index].data.lastMessageDateSent != null
                    ? Jiffy(DateTime.fromMillisecondsSinceEpoch(chatController.chatsList[index].data.lastMessageDateSent! * 1000)).fromNow()
                    : GayaStrings.not_available.tr,
                style: TextStyle(color: primaryColor),
              ),
            ],
          ),
        ],
      ),
      onLongPress: () {
        chatController.deleteSingleConversation(chatController.chatsList[index].data.dialogId ?? '', false);
        // setState(() {
        //   chatController.chatsList[index].isSelected = !chatController.chatsList[index].isSelected;
        // });
      },
      onPressed: () {
        _openDialog(context, chatController.chatsList[index].data);
      },
    ),
  );
}

void _deleteDialog(BuildContext context, CubeDialog dialog) async {
  log("_deleteDialog= $dialog");
  Fluttertoast.showToast(
    msg: GayaStrings.coming_soon.tr,
  );
  // bool force = false; // true - to delete everywhere, false - to delete for himself

  // deleteDialog(dialog.dialogId ?? '', force).then((voidResult) {}).catchError((error) {});
}

void _openDialog(BuildContext context, CubeDialog dialog) async {
  ChatController.to().updateCubeCurrentChat(dialog);
  // Navigator.push(context, MaterialPageRoute(builder: (context) => const ConversationScreen()))
  //     .then((value) => ChatController.to().refreshChatsList());
  Get.toNamed(
    RouteHelper.conversation,
  )?.then((value) => ChatController.to().refreshChatsList());
}
