import 'dart:math';

import 'package:flutter/material.dart';

class SeekBar extends StatefulWidget {
final Duration duration;
  final Duration position;
  final Duration bufferedPosition;
  final ValueChanged<Duration>? onChanged;
  final ValueChanged<Duration>? onChangeEnd;

  const SeekBar({
    Key? key,
    required this.duration,
    required this.position,
    required this.bufferedPosition,
    this.onChanged,
    this.onChangeEnd,
  }) : super(key: key);

  @override
  State<SeekBar> createState() => _SeekBarState();
}

class _SeekBarState extends State<SeekBar> {
   double? _dragValue;
  late SliderThemeData _sliderThemeData;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _sliderThemeData = SliderTheme.of(context).copyWith(trackHeight: 2.0,);
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      // clipBehavior: Clip.none,
      children: [
        // SliderTheme(
        //   data: _sliderThemeData.copyWith(
        //     // thumbShape: RoundSliderThumbShape(enabledThumbRadius: 0.r),
        //     activeTrackColor: Colors.grey,
        //     inactiveTrackColor: Colors.grey.shade300,
        //   ),
        //   child: ExcludeSemantics(
        //     child: Slider(
        //       thumbColor: Colors.transparent,
        //       min: 0.0,
        //       max: widget.duration.inMilliseconds.toDouble(),
        //       value: min(widget.bufferedPosition.inMilliseconds.toDouble(), widget.duration.inMilliseconds.toDouble()),
        //       onChanged: (value) {
        //         // setState(() {
        //         //   _dragValue = value;
        //         // });
        //         // if (widget.onChanged != null) {
        //         //   widget.onChanged!(Duration(milliseconds: value.round()));
        //         // }
        //       },
        //       onChangeEnd: (value) {
        //         // if (widget.onChangeEnd != null) {
        //         //   widget.onChangeEnd!(Duration(milliseconds: value.round()));
        //         // }
        //         // _dragValue = null;
        //       },
        //     ),
        //   ),
        // ),
        
        
        SliderTheme(
          data: _sliderThemeData.copyWith(
            inactiveTrackColor: Colors.grey,
            // overlayShape: SliderComponentShape.noThumb,
          ),
          child: Slider(
            min: 0.0,
            // secondaryActiveColor: Colors.green,
            secondaryTrackValue: 0,
            thumbColor: Colors.grey,
            max: widget.duration.inMilliseconds.toDouble(),
            value: min(_dragValue ?? widget.position.inMilliseconds.toDouble(), widget.duration.inMilliseconds.toDouble()),
            onChanged: (value) {
              setState(() {
                _dragValue = value;
              });
              if (widget.onChanged != null) {
                widget.onChanged!(Duration(milliseconds: value.round()));
              }
            },
            onChangeEnd: (value) {
              if (widget.onChangeEnd != null) {
                widget.onChangeEnd!(Duration(milliseconds: value.round()));
              }
              _dragValue = null;
            },
          ),
        ),
      ],
    );
  }

}
