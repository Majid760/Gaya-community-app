import 'package:connectycube_sdk/connectycube_sdk.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gaya/components/image_swiper.dart';
import 'package:gaya/components/profile_image_widget.dart';
import 'package:gaya/routing/getx_route_methods.dart';
import 'package:gaya/utils/const.dart';
import 'package:gaya/utils/theme/app_colors.dart';
import 'package:gaya/view/chat/components/audio_widget.dart';
import 'package:gaya/view/chat/components/network_pdf_view.dart';
import 'package:gaya/view/chat/components/play_video_widget.dart';
import 'package:gaya/view/chat/components/text_link_widget.dart';
import 'package:gaya/view/chat/components/user_image.dart';
import 'package:gaya/view/chat/helper/helper_functions.dart' as Helper;
import 'package:gaya/view/messaging/components/load_message_as_communitypreview.dart';
import 'package:gaya/view/messaging/components/load_message_as_postpreview.dart';
import 'package:get/get.dart';

class OtherUserMessageWidget extends StatefulWidget {
  final String profilePicture;
  final String uid;
  final String dialogId;

  // final Message currentMessage;
  final int index;
  final CubeMessage? message;
  final Helper.MessageType messageType;
  String sentTime = '';
  String deliveryStatus = '';

  OtherUserMessageWidget(
      {super.key,
      required this.profilePicture,
      required this.uid,
      required this.dialogId,
      // required this.currentMessage,
      required this.index,
      this.message,
      required this.messageType,
      required this.sentTime,
      required this.deliveryStatus});

  @override
  State<OtherUserMessageWidget> createState() => _OtherUserMessageWidgetState();
}

class _OtherUserMessageWidgetState extends State<OtherUserMessageWidget> {
  late Widget userImage;

  @override
  void initState() {
    super.initState();
    userImage = UserAvatar(url: widget.profilePicture, isActive: false, height: 40.r, width: 40.r);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: distance_10),
      child: Align(
          alignment: Alignment.bottomLeft,
          child: LayoutBuilder(
            builder: (context, constraints) {
              if ((widget.messageType == Helper.MessageType.nullAttachment) &&
                  (widget.message!.body == null && widget.message!.body!.isEmpty)) {
                return const SizedBox.shrink();
              } else {
                // returns type of widget whether it's text, image,video...
                if (widget.messageType == Helper.MessageType.community) {
                  return widget.message!.attachments != null && !Helper.isListEmptyOrNull(widget.message!.attachments)
                      ? Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(top: 8.0),
                              child: userImage,
                            ),
                            const SizedBox(width: 10),
                            LoadCommunityMessageWidget(
                              message: widget.message,
                              sentTime: widget.sentTime,
                              deliveryStatus: widget.deliveryStatus,
                              isCurrentUser: false,
                            ),
                            // LoadCommunityMessage(communityId: widget.message!.attachments!.first.data.toString()),
                          ],
                        )
                      : const SizedBox.shrink();
                } else if (widget.messageType == Helper.MessageType.post) {
                  return widget.message!.attachments != null && !Helper.isListEmptyOrNull(widget.message!.attachments)
                      ? Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(top: 8.0),
                              child: userImage,
                            ),
                            const SizedBox(width: 10),
                            LoadPostMessageWidget(
                              message: widget.message,
                              isCurrentUser: false,
                              sentTime: widget.sentTime,
                              deliveryStatus: widget.deliveryStatus,
                            ),
                          ],
                        )
                      : const SizedBox.shrink();
                } else if (widget.messageType == Helper.MessageType.link) {
                  return widget.message!.attachments != null && !Helper.isListEmptyOrNull(widget.message!.attachments)
                      ? TextlinkWidget(
                          isLink: GetUtils.isURL(widget.message!.attachments!.first.data.toString()),
                          text: widget.message!.attachments!.first.data ?? '',
                          currentMessage: widget.message!,
                          mySelf: false,
                          userAvatar: userImage,
                          sentTime: widget.sentTime,
                          deliveryStatus: widget.deliveryStatus,
                        )
                      : const SizedBox.shrink();
                } else if (widget.messageType == Helper.MessageType.image) {
                  return widget.message!.attachments != null && !Helper.isListEmptyOrNull(widget.message!.attachments)
                      ? Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(top: 8.0),
                              child: userImage,
                            ),
                            const SizedBox(width: 10),
                            SizedBox(
                                height: 200.h,
                                width: 150.w,
                                child: GestureDetector(
                                  onTap: () {
                                    if (widget.message!.attachments!.first.url != null) {
                                      List<String> images = [widget.message!.attachments!.first.url!];
                                      Routes.openImages(urls: images, index: 0, ctx: context);
                                    }
                                  },
                                  child: Stack(
                                    children: [
                                      Container(
                                          clipBehavior: Clip.antiAlias,
                                          decoration: BoxDecoration(borderRadius: BorderRadius.circular(12).r),
                                          child: ScrolledHero(
                                              tag: widget.message!.attachments!.first,
                                              topOffset: 56,
                                              bottomOffset: 0,
                                              transitionOnUserGestures: true,
                                              child: PostImageWidget(url: widget.message!.attachments!.first.url))),
                                      Positioned(
                                          bottom: 4.r,
                                          right: 4.r,
                                          child: Row(
                                            children: [
                                              Text(
                                                widget.sentTime,
                                                style: TextStyle(color: AppColors.white, fontSize: 10.0.sp, fontStyle: FontStyle.italic),
                                              ),
                                            ],
                                          ))
                                    ],
                                  ),
                                ))
                          ],
                        )
                      : const SizedBox.shrink();
                } else if (widget.messageType == Helper.MessageType.video) {
                  return widget.message!.attachments != null && !Helper.isListEmptyOrNull(widget.message!.attachments)
                      ? Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(top: 8.0),
                              child: userImage,
                            ),
                            const SizedBox(width: 10),
                            PlayVideoWidget(
                              currentMessage: widget.message!,
                              sentTime: widget.sentTime,
                              deliveryStatus: widget.deliveryStatus,
                              mySelf: false,
                            ),
                          ],
                        )
                      : const SizedBox.shrink();
                } else if (widget.messageType == Helper.MessageType.audio) {
                  return widget.message!.attachments != null && !Helper.isListEmptyOrNull(widget.message!.attachments)
                      ? AudioWidget(
                    userImage: userImage,
                          isCurrentUser: false,
                          audioPath: widget.message!.attachments!.first.url!,
                          sentTime: widget.sentTime,
                          deliveryStatus: widget.deliveryStatus,
                          duration: widget.message?.properties["duration"],
                        )
                      : const SizedBox.shrink();
                } else if (widget.messageType == Helper.MessageType.document) {
                  return widget.message!.attachments != null && !Helper.isListEmptyOrNull(widget.message!.attachments)
                      ? Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(top: 8.0),
                              child: userImage,
                            ),
                            const SizedBox(width: 10),
                            NetworkPDFView(
                              path: widget.message!.attachments!.first.url!,
                              filename: widget.message!.attachments!.first.name ?? '',
                              width: 230.w,
                              chatDialogId: widget.dialogId,
                              sentTime: widget.sentTime,
                              deliveryStatus: widget.deliveryStatus,
                              mySelf: false,
                            ),
                          ],
                        )
                      : const SizedBox.shrink();
                }
                return widget.message!.body != null && (widget.message!.body?.isNotEmpty ?? false)
                    ? TextlinkWidget(
                        isLink: GetUtils.isURL(widget.message!.body.toString()),
                        text: widget.message!.body ?? '',
                        currentMessage: widget.message!,
                        mySelf: false,
                        userAvatar: userImage,
                        sentTime: widget.sentTime,
                        deliveryStatus: widget.deliveryStatus,
                      )
                    : const SizedBox.shrink();
              }
            },
          )),
    );
  }
}
