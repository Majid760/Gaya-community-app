// import 'package:flutter/material.dart';
// import 'package:gaya/view/comments/components/speed_dial_button.dart';
// import 'package:gaya/view/comments/controller/comments_controller.dart';
// import 'package:get/get.dart';

// class SelectAttachmentWidget extends StatelessWidget {
//   const SelectAttachmentWidget({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return SpeedDialView(tapOnPhoto: () async {
//       final commentController = Get.find<CommentsController>(tag: postId);
//       await commentController.pickPhoto(context: context);
//     }, tapOnVideo: () async {
//       final commentController = Get.find<CommentsController>(tag: postId);
//       await commentController.pickVideo(context: context);
//     });
//   }
// }
