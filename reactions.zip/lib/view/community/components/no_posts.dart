import 'package:flutter/material.dart';
import 'package:gaya/utils/const.dart';
import 'package:gaya/utils/language/translation.dart';
import 'package:gaya/utils/textstyles.dart';
import 'package:get/get.dart';

class NoPostsWidget extends StatelessWidget {
  final bool isFeedWidget;
  const NoPostsWidget({Key? key, this.isFeedWidget = false}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Container(
            alignment: Alignment.center,
            width: double.infinity,
            child: //SvgPicture.asset('Assets/images/create_post.svg'),
                Image.asset('Assets/images/create_post.png', height: 80, width: 96)),
        const SizedBox(
          height: distance_30,
        ),
          Text(GayaStrings.create_post.tr, style: headingStyle24),
        const SizedBox(
          height: distance_10,
        ),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: distance_30),
          width: MediaQuery.of(context).size.width * 0.8,
          child: Text(
            isFeedWidget ? GayaStrings.be_first_share_in_topic.tr : GayaStrings.be_first_share_in_community.tr,
            style: secondaryFontStyleWeight,
            textAlign: TextAlign.center,
            maxLines: 2,
            overflow: TextOverflow.visible,
          ),
        ),
      ],
    );
  }
}
