import 'package:easy_refresh/easy_refresh.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gaya/components/skeleton.post.component.dart';
import 'package:gaya/model/community.model.dart';
import 'package:gaya/model/create.post.model.dart';
import 'package:gaya/utils/language/translation.dart';
import 'package:gaya/utils/refresh_builder_utils.dart';
import 'package:gaya/utils/theme/app_typography.dart';
import 'package:gaya/view/community/components/community_feed_post_tile.dart';
import 'package:gaya/view/community/components/no_posts.dart';
import 'package:get/get.dart';

import '../../../utils/theme/app_colors.dart';
import '../../feed/view/community_user_feed/controller/home_feed_user_communities_controller.dart';
import '../controllers/community_feed_controller.dart';

/// [Replacement of group discussion widget] - Inside a group view.dart
class CommunityFeedView extends StatelessWidget {
  final Community communityModel;

  const CommunityFeedView({Key? key, required this.communityModel}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: MediaQuery.of(context).size.width,
      height: MediaQuery.of(context).size.height,
      child: GetBuilder<CommunityFeedController>(
          init: CommunityFeedController.to(tag: communityModel.communityId),
          tag: communityModel.communityId,
          autoRemove: false,
          builder: (controller) {
            return EasyRefresh.builder(
              simultaneously: true,
              // noMoreLoad: false,
              controller: controller.refreshController,
              header: const CupertinoHeader(
                position: IndicatorPosition.above,
                userWaterDrop: false,
                safeArea: true,
                triggerOffset: 40,
                hapticFeedback: true,
                emptyWidget: SizedBox(),
              ),
              footer: RefreshBuilderUtils.footerAbove,
              onRefresh: () async => controller.resetController(context: context, communityModel: communityModel),
              onLoad: controller.isFeedEmpty
                  ? () {
                      return IndicatorResult.noMore;
                    }
                  : () async {
                      final isFetched = await controller.requestMoreData(topic: controller.selectedTopic);
                      if (!isFetched) {
                        return IndicatorResult.noMore;
                      }
                    },
              childBuilder: (context, physics) {
                if (controller.isLoading) {
                  return Padding(
                    padding: const EdgeInsets.all(20.0).r,
                    child: ListView(physics: const NeverScrollableScrollPhysics(), children: const [
                      PostsSkeleton(showTopDivider: false),
                      PostsSkeleton(),
                      PostsSkeleton(),
                    ]),
                  );
                }
                if (controller.isFeedEmpty) {
                  return Padding(
                    padding: const EdgeInsets.all(20.0).r,
                    child: ListView(physics: physics, children: [
                      (controller.selectedTopic == null || controller.selectedTopic == '')
                          ? const NoPostsWidget()
                          : const NoPostsWidget(isFeedWidget: true),
                    ]),
                  );
                }

                return ListView.separated(
                    keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
                    separatorBuilder: (ctx, index) => Container(color: AppColors.divider, height: 6.h),
                    itemCount: controller.posts.length,
                    physics: physics,
                    itemBuilder: (ctx, index) {
                      Post postModel = controller.posts[index];
                      postModel.community = communityModel;

                      return CommunityFeedPostTile(postModel: postModel, controller: controller, community: communityModel);
                    });
              },
            );
          }),
    );
  }
}

/// [Replacement of group discussion widget] - Specifically designed for HOME FEED
class CommunityFeedViewV2 extends StatelessWidget {
  final HomeFeedUserCommunities homeUserController;
  // final Community communityModel;
  const CommunityFeedViewV2({Key? key, required this.homeUserController}) : super(key: key);

  // const CommunityFeedViewV2({Key? key, required this.communityModel}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final _homeUserCommunities = homeUserController;
    separator(ctx, index) => Container(color: AppColors.divider, height: 6.h);
    return SizedBox(
      width: MediaQuery.of(context).size.width,
      height: MediaQuery.of(context).size.height,
      child: Obx(() {
        if (_homeUserCommunities.isLoading.value) {
          return const Center(child: CircularProgressIndicator.adaptive());
        }
        final communityModel = _homeUserCommunities.selectedCommunity;
        return GetBuilder<CommunityFeedController>(
            init:
                CommunityFeedController(communityId: communityModel.communityId ?? "", community: communityModel, shouldHaveSeenPost: true),
            tag: communityModel.communityId,
            builder: (controller) {
              return EasyRefresh.builder(
                simultaneously: true,
                controller: controller.refreshController,
                header: const CupertinoHeader(
                  position: IndicatorPosition.above,
                  userWaterDrop: false,
                  safeArea: true,
                  triggerOffset: 40,
                  hapticFeedback: true,
                  emptyWidget: SizedBox(),
                  clamping: true,
                ),
                footer: RefreshBuilderUtils.footerAbove,
                onRefresh: () async {
                  await controller.resetV2Controller(context: context, communityModel: communityModel);
                  return IndicatorResult.success;
                },
                onLoad: controller.isFeedEmpty
                    ? () {
                        return IndicatorResult.noMore;
                      }
                    : () async {
                        final isFetched = await controller.requestMoreData(topic: controller.selectedTopic);

                        if (!isFetched) {
                          return IndicatorResult.noMore;
                        }
                      },
                childBuilder: (context, physics) {
                  if (controller.isLoading) {
                    return Padding(
                      padding: const EdgeInsets.all(20.0).r,
                      child: ListView(physics: const NeverScrollableScrollPhysics(), children: const [
                        PostsSkeleton(showTopDivider: false),
                        PostsSkeleton(),
                        PostsSkeleton(),
                      ]),
                    );
                  }
                  if (controller.isFeedEmpty) {
                    return Padding(
                      padding: const EdgeInsets.all(20.0).r,
                      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                        SizedBox(
                          height: 115.h,
                        ),
                        (controller.selectedTopic == null || controller.selectedTopic == '')
                            ? const NoPostsWidget()
                            : const NoPostsWidget(isFeedWidget: true),
                      ]),
                    );
                  }

                  final shouldHaveSeenSeenSeparator = controller.newPosts.isNotEmpty && controller.oldPosts.isNotEmpty;
                  return SingleChildScrollView(
                    physics: physics,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        if (shouldHaveSeenSeenSeparator)
                          _PostSeparator(title: "${GayaStrings.new_posts_in.tr} ${communityModel.communityName}"),
                        if (controller.newPosts.isNotEmpty)
                          ListView.separated(
                            shrinkWrap: true,
                            keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
                            separatorBuilder: separator,
                            itemCount: controller.newPosts.length,
                            physics: const NeverScrollableScrollPhysics(),
                            itemBuilder: (ctx, index) {
                              Post postModel = controller.newPosts[index];
                              postModel.community = communityModel;

                              return HomeCommunityFeedPostTile(postModel: postModel, controller: controller);
                            },
                          ),
                        if (shouldHaveSeenSeenSeparator) _PostSeparator(title: GayaStrings.old_posts.tr),
                        if (controller.oldPosts.isNotEmpty)
                          ListView.separated(
                            shrinkWrap: true,
                            keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
                            separatorBuilder: separator,
                            itemCount: controller.oldPosts.length,
                            physics: const NeverScrollableScrollPhysics(),
                            itemBuilder: (ctx, index) {
                              Post postModel = controller.oldPosts[index];
                              postModel.community = communityModel;
                              return HomeCommunityFeedPostTile(postModel: postModel, controller: controller);
                            },
                          ),
                      ],
                    ),
                  );
                  return ListView.separated(
                      keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
                      separatorBuilder: (ctx, index) => Container(color: AppColors.divider, height: 6.h),
                      itemCount: controller.posts.length,
                      physics: physics,
                      itemBuilder: (ctx, index) {
                        Post postModel = controller.posts[index];
                        postModel.community = communityModel;
                        return HomeCommunityFeedPostTile(postModel: postModel, controller: controller);
                      });
                },
              );
            });
      }),
    );
  }
}

class _PostSeparator extends StatelessWidget {
  final String title;

  const _PostSeparator({Key? key, required this.title}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: MediaQuery.of(context).size.width,
      alignment: Alignment.bottomLeft,
      padding: const EdgeInsets.only(bottom: 4, left: 10, top: 12, right: 10).r,
      color: AppColors.divider,
      child: Text(
        title,
        style: CustomTypography.postCaptionStyle.copyWith(fontWeight: FontWeight.w500),
      ),
    );
  }
}
