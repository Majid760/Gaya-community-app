import 'dart:async';
import 'dart:io';

import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:connectycube_sdk/connectycube_sdk.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_lazy_indexed_stack/flutter_lazy_indexed_stack.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
// import 'package:fluttertoast/fluttertoast.dart';
import 'package:gaya/components/profile_image_widget.dart';
import 'package:gaya/controller/crowns_controller.dart';
import 'package:gaya/controller/firebase_analytics_controller.dart';
import 'package:gaya/controller/gaya_shared_controller.dart';
import 'package:gaya/model/user.model.dart';
import 'package:gaya/routing/getx_route_methods.dart';
import 'package:gaya/services/notification/fcm_helper.dart';
import 'package:gaya/services/notification/notification_inapp_watcher.dart';
import 'package:gaya/services/services.dart';
import 'package:gaya/shared/view/widget/gaya_alert_dialog.dart';
import 'package:gaya/utils/const.dart';
import 'package:gaya/utils/extension.dart';
import 'package:gaya/utils/language/translation.dart';
import 'package:gaya/utils/theme/app_colors.dart';
import 'package:gaya/utils/theme/app_typography.dart';
import 'package:gaya/view/Auth/controller/require.sigin.register.dart';
import 'package:gaya/view/chat/utils/pref_util.dart';
import 'package:gaya/view/chat/views/chats/ubaid_chats_screen.dart';
import 'package:gaya/view/home.view.dart';
import 'package:gaya/view/notification.view.dart';
import 'package:gaya/view/profile.view.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

import '../components/check_for_app_update.dart';
import '../controller/communities.controller.dart';
import '../controller/message.controller.dart';
import '../services/notification/awesome_notification.dart';
import '../services/notification/notification_routes.dart';
import '../utils/app_data.dart';
import '../utils/asset_images.dart';
import 'chat/controllers/chat_controller.dart';
import 'community/communities/communities_view.dart';
import 'feed/controller/feeds_view_controller.dart';
import 'feed/controller/for_you_controller.dart';

class SwitchViewBindings extends Bindings {
  int initialIndex;
  final BuildContext? context;

  SwitchViewBindings({this.initialIndex = 0, this.context});

  @override
  void dependencies() {
    final arguments = Get.arguments;
    if (arguments != null) {
      initialIndex = arguments['initialIndex'];
    }
    Get.lazyPut<SwitchViewController>(() => SwitchViewController(initialIndex: initialIndex, context: context));
    // Get.lazyPut<FeedPostsController>(() => FeedPostsController(), fenix: true);
    Get.lazyPut<ForYouFeedController>(() => ForYouFeedController(), fenix: true);
    Get.lazyPut<FeedPageViewController>(() => FeedPageViewController(), fenix: true);
    // Get.lazyPut(() => QuestionnaireController());
  }
}

class SwitchViewController extends GetxController with WidgetsBindingObserver {
  static SwitchViewController get to => Get.find();
  final int initialIndex;
  final BuildContext? context;
  final AnalyticsController analyticsController = Get.find();

  SwitchViewController({this.initialIndex = 0, this.context});

  final _selectedIndex = 0.obs;

  int get selectedIndex => _selectedIndex.value;

  void setIndex(int index, BuildContext ctx) {
    if (index == 0 && _selectedIndex.value == index) {
      if (FirebaseAuth.instance.currentUser?.uid == null) {
        Get.find<ForYouFeedController>().scrollToTop();
        return;
      } else {
        Get.find<FeedPageViewController>().scrollToTop();
        return;
      }
    } else if (index == 1 && _selectedIndex.value == index) {
      Provider.of<MessageController>(ctx, listen: false).scrollToTop();
      return;
    } else if (index == 2 && _selectedIndex.value == index) {
      Provider.of<CommunitiesController>(ctx, listen: false).scrollToTop();
      return;
    }

    if (FirebaseAuth.instance.currentUser?.uid == null) {
      if (index == 3 || index == 4 || index == 1) {
        Get.toNamed(RouteHelper.requireSignRegisterView);
        return;
      }
    }

    ///haptic feedback

    if (index == 1) {
      ChatController.to().getAllUpdatedChatListIfNeeded();
    }

    //analytics
    analyticsController.instance.setScreen(index == 0
        ? '/homefeed'
        : index == 1
            ? '/messages'
            : index == 2
                ? '/communities'
                : index == 3
                    ? '/notifications'
                    : '/profile');

    _selectedIndex.value = index;
    HapticFeedback.lightImpact();
  }

  /// A variable to check if the user is inactive for more than 30 minutes
  DateTime inactiveTime = DateTime.now();

  final _commonService = Services.to;

  /// Notification listener COUNT
  void listenToUnreadNotificationCount() {
    _unreadNotificationCount.bindStream(_commonService.getUnreadNotification());
  }

  final RxInt _unreadNotificationCount = 0.obs;
  final RxInt _unreadMessageCount = 0.obs;

  int get unreadMessageCount => _unreadMessageCount.value;

  set unreadMessageCount(int value) => _unreadMessageCount.value = value;

  int get unreadNotificationCount => _unreadNotificationCount.value;

  /// Unread Message Listener COUNT

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);

    super.dispose();
  }

  @override
  Future<void> onInit() async {
    super.onInit();
    WidgetsBinding.instance.addObserver(this);

    setIndex(initialIndex, context ?? Get.context!);
    listenToUnreadNotificationCount();
    GayaSharedController.to.initDynamicLinks();
    if (kIsWeb) {
      return;
    }
    //checks for version update from remote config
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      CubeChatConnection.instance.markInactive();
      FirebaseMessaging.instance.getInitialMessage().then((message) {
        debugPrint('getInitialMessage: $message');
        if (message != null) {
          Map<String, String>? newPayload;
          if (message.data['payload'] != null) {
            newPayload = NotificationNavigationService.getPayload(payload: message.data['payload']);
            NotificationApiController.navigate(newPayload!["messageType"], newPayload);
          } else {
            newPayload = {
              "user_id": message.data["user_id"] ?? '123',
              "dialog_type": message.data["dialog_type"] ?? 'Message',
              "title": message.data["title"] ?? '',
              "dialog_id": message.data["dialog_id"] ?? '123',
              "message_id": message.data["message_id"] ?? '132',
              "message": message.data["message"] ?? '',
              "messageType": "chatMessage",
            };
            NotificationApiController.navigate(newPayload["messageType"], newPayload);
          }
        }
      });

      /// 2. This method only call when App in foreground it mean app must be opened
      FirebaseMessaging.onMessage.listen((message) async {
        debugPrint('onMessage: $message');
        bool shouldNotify = true;
        bool isChatMessage = false;
        if (message.notification != null) {
          /// watcher for in app notification - to perform actions on in app notification
          InAppNotificationWatcher.instance.watchInAppNotification(message);
          Map<String, String>? newPayload;
          if (message.data['payload'] != null) {
            final myPayload = message.data['payload'];

            newPayload = NotificationNavigationService.getPayload(payload: myPayload);
            isChatMessage = newPayload?["messageType"] == "chatMessage";
            bool isPost = newPayload?["messageType"] == "post";
            if (isChatMessage && Get.currentRoute == RouteHelper.personMessage) {
              shouldNotify = false;
            } else if (isPost && Get.currentRoute == RouteHelper.commentWithPostScreen) {
              shouldNotify = false;
            }
          } else if (message.data['dialog_id'] != null) {
            isChatMessage = true;
            newPayload = {
              "user_id": message.data["user_id"] ?? '123',
              "dialog_type": message.data["dialog_type"] ?? 'Message',
              "title": message.data["title"] ?? '',
              "dialog_id": message.data["dialog_id"] ?? '123',
              "message_id": message.data["message_id"] ?? '132',
              "message": message.data["message"] ?? '',
              "messageType": "chatMessage",
            };
            if (Get.currentRoute == "/Conversation") {
              shouldNotify = false;
            }
          }

          /// if user open app from notification and it is a crown notification then update the user crowns
          if (message.notification?.title?.contains("crowns, use them now!") ?? false) {
            CrownsController.to.updateCurrentUser();
          }
          if (Platform.isAndroid && shouldNotify) {
            if (isChatMessage == true) {
              String data = message.data['message'];
              // FcmHelper.showNotification(title: data.split(':').first, body: data.split(':').last, id: 1, payload: newPayload);
            } else {
              FcmHelper.showNotification(title: message.notification?.title, body: message.notification?.body, id: 1, payload: newPayload);
            }
          }
        }
      });

      // /// 3. This method only call when App in background and not terminated(not closed)
      FirebaseMessaging.onMessageOpenedApp.listen((message) async {
        debugPrint('onMessageOpenedApp: $message');
        if (message.notification != null) {
          bool shouldNotify = true;
          bool isChatMessage = false;

          Map<String, String>? newPayload;
          if (message.data['payload'] != null) {
            newPayload = NotificationNavigationService.getPayload(payload: message.data['payload']);
            NotificationApiController.navigate(newPayload!["messageType"], newPayload);
            isChatMessage = newPayload["messageType"] == "chatMessage";
            bool isPost = newPayload["messageType"] == "post";
            if (isChatMessage && Get.currentRoute == "/PersonMessageView") {
              shouldNotify = false;
            } else if (isPost && Get.currentRoute == RouteHelper.commentWithPostScreen) {
              shouldNotify = false;
            }
          } else if (message.data['dialog_id'] != null) {
            isChatMessage = true;
            newPayload = {
              "user_id": message.data["user_id"] ?? '123',
              "dialog_type": message.data["dialog_type"] ?? 'Message',
              "title": message.data["title"] ?? '',
              "dialog_id": message.data["dialog_id"] ?? '123',
              "message_id": message.data["message_id"] ?? '132',
              "message": message.data["message"] ?? '',
              "messageType": "chatMessage",
            };
            NotificationApiController.navigate(newPayload["messageType"], newPayload);
            if (Get.currentRoute == "/Conversation") {
              shouldNotify = false;
            }
          }

          /// if user open app from notification and it is a crown notification then update the user crowns
          if (message.notification?.title?.contains("crowns, use them now!") ?? false) {
            CrownsController.to.updateCurrentUser();
          }

          if (Platform.isAndroid && shouldNotify) {
            log("on Message onMessageOpenedApp show notif");
            if (isChatMessage == true) {
              String data = message.data['message'];
              // FcmHelper.showNotification(title: data.split(':').first, body: data.split(':').last, id: 1, payload: newPayload);
            } else {
              FcmHelper.showNotification(title: message.notification?.title, body: message.notification?.body, id: 1, payload: newPayload);
            }
          }
        }
      });

      // Only after at least the action method is set, the notification events are delivered
      GayaAwesomeNotification.instance.init();
      // GayaAwesomeNotification.instance.setListeners(onActionReceivedMethod: NotificationApiController.onActionReceivedMethod);
      // versionCheck(context);
    });

    ////////////// connectycube calls below ///////////////
    // init(config.APP_ID, config.AUTH_KEY, config.AUTH_SECRET, onSessionRestore: () async {
    //   SharedPrefs sharedPrefs = await SharedPrefs.instance.init();
    //   CubeUser? user = sharedPrefs.getUser();

    //   return createSession(user);
    // });
    // if (UserModel.to.uId != null) {
    //   if (ChatController.to().currentUser != null) {
    //     init(
    //       config.APP_ID,
    //       config.AUTH_KEY,
    //       config.AUTH_SECRET,
    //     );
    //   } else {
    //     Provider.of<LoginController>(context ?? Get.context!, listen: false).connectyCubeLogin(
    //         context ?? Get.context!,
    //         CubeUser(
    //           login: UserModel.to.uId,
    //           password: UserModel.to.uId,
    //         ),
    //         saveUser: true);
    //   }
    // } else {
    //   init(
    //     config.APP_ID,
    //     config.AUTH_KEY,
    //     config.AUTH_SECRET,
    //   );
    // }
    // PushNotificationsManager.instance.init();
    // FcmHelper.onNotificationClicked = (payload) {
    //   return FcmHelper.onNotificationSelected(payload);
    // };
    // PushNotificationsManager.instance.onNotificationClicked = (payload) {
    //   return onNotificationSelected(
    //     payload,
    //   );
    // };

    connectivityStateSubscription = Connectivity().onConnectivityChanged.listen((connectivityType) {
      if (AppLifecycleState.resumed != appState) return;

      if (connectivityType != ConnectivityResult.none) {
        log("chatConnectionState = ${CubeChatConnection.instance.chatConnectionState}");
        bool isChatDisconnected = CubeChatConnection.instance.chatConnectionState == CubeChatConnectionState.Closed ||
            CubeChatConnection.instance.chatConnectionState == CubeChatConnectionState.ForceClosed;

        if (isChatDisconnected && CubeChatConnection.instance.currentUser != null) {
          CubeChatConnection.instance.relogin();
        }
      }
    });

    appState = WidgetsBinding.instance.lifecycleState;

    ////////////// connectycube ended ///////////////
  }

  late StreamSubscription<ConnectivityResult> connectivityStateSubscription;
  AppLifecycleState? appState;

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);
    if (state == AppLifecycleState.resumed) {
      if (inactiveTime.difference(DateTime.now()).inMinutes > 30) {
        Routes.switchView(initialIndex: _selectedIndex.value);
      }
      SharedPrefs.instance.init().then((sharedPrefs) {
        CubeUser? user = sharedPrefs.getUser();

        if (user != null) {
          if (!CubeChatConnection.instance.isAuthenticated()) {
            CubeChatConnection.instance.login(user);
            // CubeChatConnection.instance.markInactive();
          } else {
            // CubeChatConnection.instance.markInactive();
          }
        }
      });
    } else if (state == AppLifecycleState.inactive) {
      inactiveTime = DateTime.now();
    } else if (state == AppLifecycleState.paused) {
      inactiveTime = DateTime.now();
      if (CubeChatConnection.instance.isAuthenticated()) {
        // CubeChatConnection.instance.markInactive();
      }
    } else if (state == AppLifecycleState.detached) {
      inactiveTime = DateTime.now();
    }
  }

  List<Widget> screens = const [
    HomeView(),
    // MessageView(),
    UbaidChatScreen(),
    CommunitiesView(),
    NotificationView(),
    ProfileView(canPop: false),
  ];

  navigateToRequiredSignIn(BuildContext ctx) =>
      Get.to(() => const RequireSignRegisterView(userNotSigin: true), transition: Transition.cupertinoDialog, fullscreenDialog: true);

  @override
  onClose() {
    super.onClose();
    WidgetsBinding.instance.removeObserver(this);
  }
}

class SwitchView extends StatefulWidget {
  const SwitchView({Key? key}) : super(key: key);

  @override
  State<SwitchView> createState() => _SwitchViewState();
}

class _SwitchViewState extends State<SwitchView> {
  @override
  void initState() {
    super.initState();
    GayaRemoteConfig.to.checkAppVersion(context: context);
  }

  Widget getProfileIcon({required int currentIndex}) {
    final bool isSelected = currentIndex == 4;
    final color = isSelected ? AppColors.primary : kTransparentColor;

    return FirebaseAuth.instance.currentUser != null
        ? Container(
            alignment: Alignment.center,
            height: 25.r,
            width: 25.r,
            margin: const EdgeInsets.only(bottom: 12, top: 5).r,
            decoration: BoxDecoration(
              color: color,
              shape: BoxShape.circle,
              border: Border.all(color: color),
            ),
            child: CircleAvatar(
                backgroundColor: color,
                child: UserModel.to.profilePicture.toString().isBlank == true
                    ? AppData.defaultUserProfileWidget()
                    : ProfileImageWidget(size: Size(25.r, 25.r), url: UserModel.to.profilePicture)))
        : isSelected
            ? NavBarIcon(
                path: ImageAssetsUtils.profileSelectedIconPath,
                color: AppColors.primary,
              )
            : const NavBarIcon(path: ImageAssetsUtils.profileUnselectedIconPath);
  }

  @override
  Widget build(BuildContext context) {
    final controller = Get.find<SwitchViewController>();
    return WillPopScope(
      onWillPop: !kIsWeb && Platform.isAndroid
          ? () async {
              showConfirmationToCloseApp(context);
              return false;
            }
          : null,
      child: Scaffold(
        body: Obx(() {
          return Column(
            children: [
              Flexible(child: LazyIndexedStack(index: controller.selectedIndex, children: controller.screens)),
              BottomNavigationBar(
                  fixedColor: AppColors.transparrent,
                  enableFeedback: true,
                  useLegacyColorScheme: false,
                  type: BottomNavigationBarType.fixed,
                  currentIndex: controller.selectedIndex,
                  onTap: (selectedIndex) => controller.setIndex(selectedIndex, context),
                  elevation: 0,
                  selectedLabelStyle: GayaTypography.caption3Medium.copyWith(color: kprimaryColor),
                  unselectedLabelStyle: GayaTypography.caption3Medium.copyWith(color: kSecondaryColor),
                  items: [
                    /// Home
                    BottomNavigationBarItem(
                      tooltip: GayaStrings.home_txt.tr,
                      icon: const NavBarIcon(path: ImageAssetsUtils.homeUnselectedIconPath),
                      activeIcon: NavBarIcon(path: ImageAssetsUtils.homeUnselectedIconPath, color: AppColors.primary),
                      label: GayaStrings.home_txt.tr,
                    ),

                    /// Message
                    BottomNavigationBarItem(
                      tooltip: GayaStrings.message_txt.tr,
                      icon: Badge(
                        isLabelVisible: controller.unreadMessageCount > 0,
                        label: Text(controller.unreadMessageCount.toCount99Plus),
                        child: const NavBarIcon(path: ImageAssetsUtils.messageUnselectedIconPath),
                      ),
                      activeIcon: Badge(
                          isLabelVisible: controller.unreadMessageCount > 0,
                          label: Text(controller.unreadMessageCount.toCount99Plus),
                          child: NavBarIcon(path: ImageAssetsUtils.messageSelectedIconPath, color: AppColors.primary)),
                      label: GayaStrings.message_txt.tr,
                    ),

                    /// Communities
                    BottomNavigationBarItem(
                      tooltip: GayaStrings.communities_txt.tr,
                      icon: const NavBarIcon(path: ImageAssetsUtils.communityUnselectedIconPath),
                      activeIcon: NavBarIcon(path: ImageAssetsUtils.communitySelectedIconPath, color: AppColors.primary),
                      label: GayaStrings.communities_txt.tr,
                    ),

                    /// Notification
                    BottomNavigationBarItem(
                      tooltip: GayaStrings.notifications_txt.tr,
                      icon: Badge(
                          isLabelVisible: controller.unreadNotificationCount > 0,
                          label: Text(controller.unreadNotificationCount.toString()),
                          child: const NavBarIcon(path: ImageAssetsUtils.notificationUnselectedIconPath)),
                      activeIcon: Badge(
                          isLabelVisible: controller.unreadNotificationCount > 0,
                          label: Text(controller.unreadNotificationCount.toString()),
                          child: NavBarIcon(path: ImageAssetsUtils.notificationSelectedIconPath, color: AppColors.primary)),
                      label: GayaStrings.notifications_txt.tr,
                    ),

                    /// Profile
                    BottomNavigationBarItem(
                      tooltip: GayaStrings.profile_txt.tr,
                      icon: getProfileIcon(currentIndex: controller.selectedIndex),
                      activeIcon: getProfileIcon(currentIndex: controller.selectedIndex),
                      label: GayaStrings.profile_txt.tr,
                    ),
                  ]),
            ],
          );
        }),
      ),
    );
  }

  void showConfirmationToCloseApp(BuildContext context) {
    showGayaAlertDialogButton(
      context: context,
      actionMsg: GayaStrings.are_you_sure_you_want.tr,
      actionText: GayaStrings.close_app.tr,
      tapOnNo: () => Navigator.pop(context),
      tapOnYes: () {
        Navigator.pop(context);
        SystemNavigator.pop();
      },
    );
  }
}

class SvgCustomIcon extends StatelessWidget {
  final String svgAssetPath;

  const SvgCustomIcon({Key? key, required this.svgAssetPath}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SvgPicture.asset(svgAssetPath, height: 20);
  }
}

class NavBarItem extends StatelessWidget {
  final Widget child;
  final VoidCallback onTap;
  final bool isExpanded;

  const NavBarItem({Key? key, required this.child, required this.onTap, this.isExpanded = true}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Flexible(
      child: IconButton(
        splashRadius: 45.r,
        visualDensity: const VisualDensity(horizontal: -4),
        padding: EdgeInsets.zero,
        highlightColor: kSecondaryLightColor,
        onPressed: onTap,
        icon: child,
      ),
    );
  }
}

class NavBarIcon extends StatelessWidget {
  final String path;
  final Color? color;

  const NavBarIcon({Key? key, required this.path, this.color}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12, top: 5).r,
      child: GayaSvgAsset(
        path,
        height: 24.r,
        color: color,
      ),
    );
  }
}

showAlertDialog(BuildContext context, String name, CubeUser user) {
  // set up the buttons
  Widget cancelButton = TextButton(
    child: const Text("Cancel"),
    onPressed: () {
      Navigator.pop(context);
    },
  );
  Widget continueButton = TextButton(
    child: const Text("Continue"),
    onPressed: () {
      Navigator.pop(context);
    },
  );

  // set up the AlertDialog
  AlertDialog alert = AlertDialog(
    title: Text(name),
    content: Text("credencials are: ${user.login}, ${user.password}"),
    actions: [
      cancelButton,
      continueButton,
    ],
  );

  // show the dialog
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return alert;
    },
  );
}
