import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gaya/controller/firebase_analytics_controller.dart';
import 'package:gaya/controller/report_controller.dart';
import 'package:gaya/model/create.post.model.dart';
import 'package:gaya/model/user.model.dart';
import 'package:gaya/routing/getx_route_methods.dart';
import 'package:gaya/shared/view/widget/gaya_report_dialog.dart';
import 'package:gaya/utils/assets_icons.dart';
import 'package:gaya/utils/const.dart';
import 'package:gaya/utils/language/translation.dart';
import 'package:gaya/utils/methods.dart';
import 'package:gaya/utils/theme/app_colors.dart';
import 'package:gaya/utils/theme/app_typography.dart';
import 'package:gaya/view/comments/components/replies_listview.dart';
import 'package:gaya/view/comments/controller/comments_controller.dart';
import 'package:gaya/view/comments/controller/post_with_comment_controller.dart';
import 'package:gaya/view/comments/models/comment_custom_model.dart';
import 'package:gaya/view/comments/view/reply_comment_view.dart';
import 'package:gaya/widgets/post.with.comments.widgets/actionrow.widget.dart';
import 'package:gaya/widgets/post.with.comments.widgets/comments.dart';
import 'package:get/get.dart';
import 'package:jiffy/jiffy.dart';

/// Parent Comments List View
class ParentCommentsListView extends StatelessWidget {
  final MultiCommentModel comments;
  final UserModel commentBy;
  final List<CommentCustomModel> allReplies;
  final int index;
  final Post post;
  final CommentsController commentController;
  final PostWithCommentController postWithCommentController;

  const ParentCommentsListView({
    Key? key,
    required this.comments,
    required this.commentBy,
    required this.allReplies,
    required this.index,
    required this.post,
    required this.commentController,
    required this.postWithCommentController,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final bodyReactionStyle = GayaTypography.caption.copyWith(color: AppColors.secondary);
    final primaryReactionStyle = GayaTypography.caption.copyWith(color: AppColors.primary);
    final yellowReactionStyle = GayaTypography.caption.copyWith(color: AppColors.warning);

    return Column(
      children: [
        //parent comments
        Column(
          children: [
            CommentSection(
              showDialogBox: () {
                String? userId = FirebaseAuth.instance.currentUser?.uid;
                bool isMyComment = comments.comment.user.uId == userId || post.community.adminUid == userId;

                Methods.showModalSheetComment(
                    context,
                    () {
                      AnalyticsController.to.instance.logReportComment("parent_comment", comments.comment.id);
                      reportTextFieldBottomModal(
                        context,
                        onSubmit: (String reportMsg) async {
                          await ReportController.to.reportAComment(
                            content: comments.comment.comment.toString(),
                            reportedCommentId: comments.comment.id,
                            context: context,
                            reportMsg: reportMsg,
                            postId: postWithCommentController.post.postid ?? "",
                          );
                          Navigator.pop(context);
                        },
                      );
                    },
                    onCommentDelete: isMyComment ? () => commentController.deleteComment(comments.comment.id) : null,
                    onReply: () {
                      try {
                        Get.to(ReplyCommentView(
                            postModel: postWithCommentController.post,
                            userModel: postWithCommentController.post.postedBy,
                            indexForComment: index));
                      } catch (_) {}
                    });
              },
              mentionedListUsers: comments.comment.mentionedUsers,
              nameOnTap: () => Routes.viewProfile(uid: comments.comment.user.uId, model: comments.comment.user),
              userOntap: () => Routes.viewProfile(uid: commentBy.uId, model: commentBy),
              anonymousPic: postWithCommentController.post.isPostedAnonymously ?? false,
              userUid: commentBy.uId ?? '',
              uId: postWithCommentController.post.postedBy.uId,
              profilepic: commentBy.profilePicture,
              content: comments.comment.comment.toString(),
              name: commentBy.name,
              videoFile: comments.comment.videoFile,
              photoFile: comments.comment.photoFile,
              documentFile: comments.comment.documentFile,
              videoUrl: comments.comment.videoUrl,
              photoUrl: comments.comment.photoUrl,
              time: Jiffy(comments.comment.createdAt).fromNow(),
              pdfFiles: comments.comment.pdfFiles,
              postId: post.postid ?? '',
            ),
            Padding(
              padding: const EdgeInsets.only(left: distance_50),
              child: ActionRow(
                likeWidget: comments.comment.totalLikes < 1
                    ? Text(GayaStrings.like_txt.tr, style: bodyReactionStyle)
                    : Row(
                        children: [
                          Text(GayaStrings.like_txt.tr, style: (comments.comment.isLiked) ? primaryReactionStyle : bodyReactionStyle),
                          const SizedBox(width: distance_5),
                          CircleAvatar(radius: 1, backgroundColor: (comments.comment.isLiked) ? kprimaryColor : kBaseGrey),
                          const SizedBox(width: distance_5),
                          SvgIconWidget.heartFilled(
                              color: (comments.comment.isLiked) ? kprimaryColor : kBaseGrey, height: 12.h, width: 14.h),
                          // SvgPicture.asset(
                          //   Assets.assets.icons.heartIcon,
                          //   // ignore: deprecated_member_use
                          //   color: (comments.comment.isLiked) ? kprimaryColor : kBaseGrey,
                          // ),
                          const SizedBox(width: distance_5),
                          Text(comments.comment.totalLikes.toString(),
                              style: (comments.comment.isLiked) ? primaryReactionStyle : bodyReactionStyle),
                        ],
                      ),
                flowerWidget: comments.comment.totalCrowns < 1
                    ? Text(GayaStrings.crown_txt.tr, style: bodyReactionStyle)
                    : Row(
                        children: [
                          Text(GayaStrings.crown_txt.tr, style: (comments.comment.isCrown) ? yellowReactionStyle : bodyReactionStyle),
                          const SizedBox(width: distance_5),
                          CircleAvatar(radius: 1, backgroundColor: (comments.comment.isCrown) ? kYellowColor : kBaseGrey),
                          const SizedBox(width: distance_5),
                          SvgIconWidget.crownFilledd(color: kYellowColor, height: 12.h, width: 14.h),
                          // SvgPicture.asset(
                          //   'Assets/images/grey_crown.svg',
                          //   color: kYellowColor,
                          //   // color: (comments.comment.isCrown) ? kYellowColor : kBaseGrey,
                          //   height: 8,
                          //   width: 8,
                          // ),
                          const SizedBox(width: distance_5),
                          Text(comments.comment.totalCrowns.toString(),
                              style: (comments.comment.isCrown) ? yellowReactionStyle : bodyReactionStyle),
                        ],
                      ),
                likeOnTap: () async {
                  if (comments.comment.isLiked) {
                    commentController.unlikeAComment(commentId: comments.comment.id);
                  } else {
                    commentController.likeAComment(
                      commentId: comments.comment.id,
                      communityId: postWithCommentController.post.communityId ?? '',
                    );
                  }
                },
                flowerOnTap: () async {
                  if (comments.comment.isCrown) {
                  } else if (comments.comment.user.uId == UserModel.to.uId) {
                  } else if (UserModel.to.userDailyCrowns == 0) {
                    Methods.showCrownsTotalModalSheet(ctx: Get.context);
                  } else {
                    commentController.crownAComment(
                      commentId: comments.comment.id,
                      receiverUser: commentBy,
                      communityId: postWithCommentController.post.communityId,
                    );
                  }
                },
                replyOnTap: () => Get.to(ReplyCommentView(
                    postModel: postWithCommentController.post, userModel: postWithCommentController.post.postedBy, indexForComment: index)),
              ),
            ),
          ],
        ),
        const SizedBox(height: distance_10),
        //replies comment
        Padding(
          padding: const EdgeInsets.only(left: distance_50),
          child: ListView.separated(
            keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
            itemCount: allReplies.length,
            physics: const NeverScrollableScrollPhysics(),
            padding: EdgeInsets.zero,
            shrinkWrap: true,
            itemBuilder: (context, repliesIndex) {
              UserModel replyBy = allReplies[repliesIndex].user;
              CommentCustomModel reply = allReplies[repliesIndex];
              return RepliesListView(
                  postWithCommentController: postWithCommentController,
                  controller: commentController,
                  replyBy: replyBy,
                  reply: reply,
                  comments: comments,
                  index: index,
                  post: post);
            },
            separatorBuilder: (context, index) => const SizedBox(height: distance_20),
          ),
        ),
      ],
    );
  }
}
