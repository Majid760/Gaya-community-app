import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_mentions/flutter_mentions.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gaya/controller/report_controller.dart';
import 'package:gaya/model/create.post.model.dart';
import 'package:gaya/model/user.model.dart';
import 'package:gaya/routing/getx_route_methods.dart';
import 'package:gaya/shared/controller/mentioned_user_controller.dart';
import 'package:gaya/shared/view/widget/gaya_back_button.dart';
import 'package:gaya/shared/view/widget/gaya_report_dialog.dart';
import 'package:gaya/shared/view/widget/gaya_upload_document_madalsheet.dart';
import 'package:gaya/shared/view/widget/mentions_user_field_view.dart';
import 'package:gaya/shared/view/widget/pdf_view_widget.dart';
import 'package:gaya/utils/assets_icons.dart';
import 'package:gaya/utils/const.dart';
import 'package:gaya/utils/language/translation.dart';
import 'package:gaya/utils/methods.dart';
import 'package:gaya/view/comments/controller/comments_controller.dart';
import 'package:get/get.dart';
import 'package:jiffy/jiffy.dart';

import '../../../utils/strings.dart';
import '../../../utils/textstyles.dart';
import '../../../utils/theme/app_colors.dart';
import '../../../utils/theme/app_typography.dart';
import '../../../widgets/post.with.comments.widgets/actionrow.widget.dart';
import '../../../widgets/post.with.comments.widgets/comments.dart';
import '../components/speed_dial_button.dart';
import '../controller/post_with_comment_controller.dart';
import '../models/comment_custom_model.dart';
import 'comment_with_mediaview.dart';

class ReplyCommentView extends StatefulWidget {
  final Post postModel;
  final UserModel userModel;
  final int indexForComment;

  const ReplyCommentView(
      {Key? key,
      required this.postModel,
      required this.userModel,
      required this.indexForComment})
      : super(key: key);

  @override
  State<ReplyCommentView> createState() => _ReplyCommentViewState();
}

class _ReplyCommentViewState extends State<ReplyCommentView> {
  final _replyCommentC = TextEditingController();
  final focusReplyC = FocusNode();
  late ScrollController repliesScroll;
  GlobalKey<FlutterMentionsState> textFormFieldKey =
      GlobalKey<FlutterMentionsState>();

  @override
  void dispose() {
    super.dispose();
    _replyCommentC.dispose();
    focusReplyC.dispose();
    repliesScroll.dispose();
    textFormFieldKey.currentState?.controller?.dispose();
  }

  @override
  void initState() {
    super.initState();
    repliesScroll = ScrollController();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (repliesScroll.hasClients) {
        repliesScroll.jumpTo(repliesScroll.position.maxScrollExtent);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final PostWithCommentController postWithCommentController =
        PostWithCommentController.to(tag: widget.postModel.postid);
    final bodyReactionStyle =
        GayaTypography.caption.copyWith(color: AppColors.secondary);
    final primaryReactionStyle =
        GayaTypography.caption.copyWith(color: AppColors.primary);
    final yellowReactionStyle =
        GayaTypography.caption.copyWith(color: AppColors.warning);
    return Scaffold(
      backgroundColor: kWhiteColor,
      appBar: AppBar(
        systemOverlayStyle: SystemUiOverlayStyle.dark,
        iconTheme: const IconThemeData(color: kBlackColor),
        title: Text(GayaStrings.comment_replies.tr, style: bodyStyle),
        centerTitle: true,
        shape: Border(bottom: BorderSide(color: kBaseGrey.withOpacity(0.25))),
        automaticallyImplyLeading: false,
        leading: const GayaBackButton(),
        backgroundColor: const Color.fromRGBO(255, 255, 255, 0.0),
        elevation: 0,
      ),
      body: Column(
        children: [
          Expanded(
            child: SingleChildScrollView(
              controller: repliesScroll,
              child: GetBuilder<CommentsController>(
                autoRemove: false,
                init:
                    Get.find<CommentsController>(tag: widget.postModel.postid),
                builder: (controller) {
                  try {
                    MultiCommentModel comments =
                        controller.allComments[widget.indexForComment];
                    UserModel commentBy = comments.comment.user;
                    //replies
                    List<CommentCustomModel> allReplies = comments.replies;
                    return Padding(
                      padding: const EdgeInsets.symmetric(
                              horizontal: distance_20, vertical: distance_10)
                          .r,
                      child: Column(
                        children: [
                          // parent comment
                          Column(
                            children: [
                              CommentSection(
                                showDialogBox: () {
                                  String? userUid =
                                      FirebaseAuth.instance.currentUser?.uid;
                                  bool isMyComment =
                                      comments.comment.user.uId == userUid ||
                                          widget.postModel.community.adminUid ==
                                              userUid;
                                  Methods.showModalSheetComment(context, () {
                                    reportTextFieldBottomModal(
                                      context,
                                      onSubmit: (String reportMsg) async {
                                        await ReportController.to
                                            .reportAComment(
                                          content: comments.comment.comment
                                              .toString(),
                                          reportedCommentId:
                                              comments.comment.id,
                                          context: context,
                                          reportMsg: reportMsg,
                                          postId: postWithCommentController
                                                  .post.postid ??
                                              "",
                                        );
                                        Navigator.pop(context);
                                      },
                                    );
                                  },
                                      onCommentDelete: isMyComment
                                          ? () => controller.deleteComment(
                                              comments.comment.id)
                                          : null);
                                },
                                nameOnTap: () {
                                  Routes.viewProfile(
                                      uid: comments.comment.user.uId,
                                      model: comments.comment.user);
                                },
                                userOntap: () {
                                  Routes.viewProfile(
                                      uid: commentBy.uId, model: commentBy);
                                },
                                anonymousPic: postWithCommentController
                                    .post.isPostedAnonymously,
                                userUid: commentBy.uId!,
                                uId:
                                    postWithCommentController.post.postedBy.uId,
                                profilepic: commentBy.profilePicture,
                                content: comments.comment.comment.toString(),
                                name: commentBy.name,
                                time:
                                    Jiffy(comments.comment.createdAt).fromNow(),
                                videoFile: comments.comment.videoFile,
                                photoFile: comments.comment.photoFile,
                                videoUrl: comments.comment.videoUrl,
                                photoUrl: comments.comment.photoUrl,
                                mentionedListUsers:
                                    comments.comment.mentionedUsers,
                                documentFile: comments.comment.documentFile,
                                pdfFiles: comments.comment.pdfFiles,
                              ),
                              Padding(
                                padding:
                                    const EdgeInsets.only(left: distance_50),
                                child: ActionRow(
                                  likeWidget: comments.comment.totalLikes < 1
                                      ? Text(GayaStrings.like_txt.tr,
                                          style: bodyReactionStyle)
                                      : Row(
                                          children: [
                                            Text(GayaStrings.like_txt.tr,
                                                style:
                                                    (comments.comment.isLiked)
                                                        ? body5StylePrimary
                                                        : bodyReactionStyle),
                                            const SizedBox(width: distance_5),
                                            CircleAvatar(
                                                radius: 1,
                                                backgroundColor:
                                                    (comments.comment.isLiked)
                                                        ? kprimaryColor
                                                        : kBaseGrey),
                                            const SizedBox(width: distance_5),
                                            // ignore: deprecated_member_use
                                            SvgIconWidget.heartFilled(
                                                color: comments.comment.isLiked
                                                    ? kprimaryColor
                                                    : kBaseGrey,
                                                height: 12.h,
                                                width: 14.h),
                                            // SvgPicture.asset(Assets.assets.icons.heartIcon,
                                            //     // ignore: deprecated_member_use
                                            //     color: (comments.comment.isLiked) ? kprimaryColor : kBaseGrey),
                                            const SizedBox(width: distance_5),
                                            Text(
                                                comments.comment.totalLikes
                                                    .toString(),
                                                style:
                                                    (comments.comment.isLiked)
                                                        ? body5StylePrimary
                                                        : bodyReactionStyle),
                                          ],
                                        ),
                                  flowerWidget: comments.comment.totalCrowns < 1
                                      ? Text(GayaStrings.crown_txt.tr,
                                          style: bodyReactionStyle)
                                      : Row(
                                          children: [
                                            Text(GayaStrings.crown_txt.tr,
                                                style:
                                                    (comments.comment.isCrown)
                                                        ? yellowebodyStyle
                                                        : bodyReactionStyle),
                                            const SizedBox(width: distance_5),
                                            CircleAvatar(
                                                radius: 1,
                                                backgroundColor:
                                                    (comments.comment.isCrown)
                                                        ? kYellowColor
                                                        : kBaseGrey),
                                            const SizedBox(width: distance_5),
                                            SvgIconWidget.crownFilledd(
                                                color:
                                                    (comments.comment.isCrown)
                                                        ? kYellowColor
                                                        : kBaseGrey,
                                                height: 12.h,
                                                width: 14.h),
                                            // SvgPicture.asset(
                                            //   'Assets/images/grey_crown.svg',
                                            //   // color: (comments.comment.isCrown) ? kYellowColor : kBaseGrey,
                                            //   color: kYellowColor,
                                            //   height: 8,
                                            //   width: 8,
                                            // ),
                                            const SizedBox(width: distance_5),
                                            Text(
                                                comments.comment.totalCrowns
                                                    .toString(),
                                                style:
                                                    (comments.comment.isCrown)
                                                        ? yellowebodyStyle
                                                        : body3MStyle),
                                          ],
                                        ),
                                  likeOnTap: () async {
                                    if (comments.comment.isLiked) {
                                      controller.unlikeAComment(
                                          commentId: comments.comment.id);
                                    } else {
                                      controller.likeAComment(
                                        commentId: comments.comment.id,
                                        communityId: postWithCommentController
                                                .post.communityId ??
                                            '',
                                      );
                                    }
                                  },
                                  flowerOnTap: () async {
                                    if (comments.comment.isCrown) {
                                    } else if (comments.comment.user.uId ==
                                        UserModel.to.uId) {
                                    } else if (UserModel.to.userDailyCrowns ==
                                        0) {
                                      Methods.showCrownsTotalModalSheet(
                                          ctx: Get.context);
                                    } else {
                                      controller.crownAComment(
                                          commentId: comments.comment.id,
                                          receiverUser: commentBy);
                                    }
                                  },
                                  replyOnTap: () {},
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: distance_10),
                          // all replies
                          Padding(
                            padding: const EdgeInsets.only(left: distance_50),
                            child: ListView.separated(
                              keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
                              itemCount: allReplies.length,
                              physics: const NeverScrollableScrollPhysics(),
                              shrinkWrap: true,
                              itemBuilder: (context, repliesIndex) {
                                UserModel replyBy = allReplies[repliesIndex].user;
                                CommentCustomModel reply = allReplies[repliesIndex];

                                return Column(
                                  children: [
                                    CommentSection(
                                      showDialogBox: () {
                                        String? userUid = FirebaseAuth.instance.currentUser?.uid;
                                        bool isMyComment = replyBy.uId == userUid || widget.postModel.community.adminUid == userUid;
                                        Methods.showModalSheetComment(context, () {
                                          reportTextFieldBottomModal(context, onSubmit: (String reportMsg) async {
                                            await ReportController.to.reportAComment(
                                                content: comments.comment.comment.toString(),
                                                reportedCommentId: comments.comment.id,
                                                context: context,
                                                reportMsg: '',
                                                postId: widget.postModel.postid ?? "");
                                            Navigator.pop(context);
                                          });
                                        },
                                            onCommentDelete:
                                                isMyComment ? () => controller.deleteChildComment(comments.comment.id, reply.id) : null);
                                      },
                                      nameOnTap: () {
                                        Routes.viewProfile(
                                            uid: replyBy.uId, model: replyBy);
                                      },
                                      userOntap: () {
                                        Routes.viewProfile(
                                            uid: replyBy.uId, model: replyBy);
                                      },
                                      anonymousPic: widget.postModel.isPostedAnonymously ?? false,
                                      userUid: replyBy.uId ?? "",
                                      uId: widget.userModel.uId,
                                      profilepic: replyBy.profilePicture,
                                      content: reply.comment,
                                      name: (widget.postModel.isPostedAnonymously == true && widget.userModel.uId == reply.user.uId)
                                          ? anonymousUser
                                          : reply.user.name,
                                      time: Jiffy(reply.createdAt).fromNow(),
                                      videoFile: reply.videoFile,
                                      photoFile: reply.photoFile,
                                      videoUrl: reply.videoUrl,
                                      photoUrl: reply.photoUrl,
                                      mentionedListUsers: comments.comment.mentionedUsers,
                                      documentFile: reply.documentFile,
                                      pdfFiles: reply.pdfFiles,
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.only(
                                          left: distance_50),
                                      child: ActionRow(
                                        likeWidget: reply.totalLikes < 1
                                            ? Text(GayaStrings.like_txt.tr, style: bodyReactionStyle)
                                            : Row(
                                                children: [
                                                  Text(GayaStrings.like_txt.tr,
                                                      style: (reply.isLiked) ? primaryReactionStyle : bodyReactionStyle),
                                                  const SizedBox(width: distance_5),
                                                  CircleAvatar(radius: 1, backgroundColor: (reply.isLiked) ? kprimaryColor : kBaseGrey),
                                                  const SizedBox(width: distance_5),
                                                  SvgIconWidget.heartFilled(
                                                      color: (reply.isLiked) ? kprimaryColor : kBaseGrey, height: 12.h, width: 14.h),

                                                  // SvgPicture.asset(Assets.assets.icons.heartIcon,
                                                  //     // ignore: deprecated_member_use
                                                  //     color: (reply.isLiked) ? kprimaryColor : kBaseGrey),

                                                  const SizedBox(width: distance_5),
                                                  Text(reply.totalLikes.toString(),
                                                      style: (reply.isLiked) ? primaryReactionStyle : bodyReactionStyle),
                                                ],
                                              ),
                                        flowerWidget: reply.totalCrowns < 1
                                            ? Text(GayaStrings.crown_txt.tr, style: bodyReactionStyle)
                                            : Row(
                                                children: [
                                                  Text(GayaStrings.crown_txt.tr,
                                                      style: (reply.isCrown) ? yellowReactionStyle : bodyReactionStyle),
                                                  const SizedBox(width: distance_5),
                                                  CircleAvatar(radius: 1, backgroundColor: (reply.isCrown) ? kYellowColor : kBaseGrey),
                                                  const SizedBox(width: distance_5),
                                                  SvgIconWidget.crownFilledd(color: kYellowColor, height: 12.h, width: 14.h),
                                                  // SvgPicture.asset(
                                                  //   'Assets/images/grey_crown.svg',
                                                  //   color: kYellowColor,
                                                  //   // color: (reply.isCrown) ? kYellowColor : kBaseGrey,
                                                  //   height: 8,
                                                  //   width: 8,
                                                  // ),
                                                  const SizedBox(width: distance_5),
                                                  Text(reply.totalCrowns.toString(),
                                                      style: (reply.isCrown) ? yellowReactionStyle : bodyReactionStyle),
                                                ],
                                              ),
                                        likeOnTap: () async {
                                          if (reply.isLiked) {
                                            controller.unlikeACommentReply(
                                              commentId: comments.comment.id,
                                              replyId: reply.id,
                                              communityId: postWithCommentController.post.communityId ?? '',
                                            );
                                          } else {
                                            controller.likeACommentReply(
                                              commentId: comments.comment.id,
                                              replyId: reply.id,
                                              communityId: postWithCommentController.post.communityId ?? '',
                                            );
                                          }
                                        },
                                        flowerOnTap: () async {
                                          if (reply.isCrown) {
                                          } else if (reply.user.uId == UserModel.to.uId) {
                                          } else if (UserModel.to.userDailyCrowns == 0) {
                                            Methods.showCrownsTotalModalSheet(ctx: Get.context);
                                          } else {
                                            controller.crownAReplyComment(
                                                commentId: comments.comment.id, replyCommentId: reply.id, receiverUser: reply.user);
                                          }
                                        },
                                      ),
                                    ),
                                  ],
                                );
                              },
                              separatorBuilder: (context, index) {
                                return const SizedBox(height: distance_20);
                              },
                            ),
                          ),
                        ],
                      ),
                    );
                  } catch (_) {
                    return SizedBox(
                      height: MediaQuery.of(context).size.height * .79,
                      child: Center(
                          child: Text(GayaStrings.no_comments_replies.tr)),
                    );
                  }
                },
              ),
            ),
          ),

          //textfield
          GetBuilder<CommentsController>(
              autoRemove: false,
              init: Get.find<CommentsController>(tag: widget.postModel.postid),
              builder: (controller) {
                return SafeArea(
                    child: //textfield
                        Container(
                  color: kWhiteColor,
                  padding: const EdgeInsets.symmetric(vertical: distance_15) +
                      const EdgeInsets.only(left: distance_10),
                  child: Column(
                    children: [
                      // image and video showing area
                      if (controller.commentsMedia != null &&
                          controller.isVideo)
                        CommentMediaView(
                          mediaFile: controller.commentsMedia!,
                          isVideo: true,
                          tapOnImageRemove: () {
                            controller.removeSelectedCommentsMedia();
                          },
                        ),
                      if (controller.commentsMedia != null &&
                          !controller.isVideo)
                        CommentMediaView(
                          mediaFile: controller.commentsMedia!,
                          tapOnImageRemove: () {
                            controller.removeSelectedCommentsMedia();
                          },
                        ),
                      if (controller.isPdf && controller.pdfFiles.isNotEmpty)
                        ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child: Padding(
                              padding: const EdgeInsets.only(
                                      left: 20, right: 20, bottom: 8)
                                  .r,
                              child: LocalCommentPdfviewWidget(
                                path: controller.pdfFiles.first.path,
                                postId: widget.postModel.postid ?? '',
                                tapOnImageRemove: () {
                                  controller.removeSelectedCommentsMedia();
                                },
                              ),
                            )),

                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          SpeedDialView(
                            tapOnPhoto: () async {
                              final commentController =
                                  Get.find<CommentsController>(
                                      tag: widget.postModel.postid);
                              await commentController.pickPhoto(
                                  context: context);
                            },
                            tapOnVideo: () async {
                              final commentController =
                                  Get.find<CommentsController>(
                                      tag: widget.postModel.postid);
                              await commentController.pickVideo(
                                  context: context);
                            },
                            tapOnDocument: () async {
                              final commentController =
                                  Get.find<CommentsController>(
                                      tag: widget.postModel.postid);
                              await commentController.getPdfDocument(context);
                              // ignore: use_build_context_synchronously
                              uploadDocumentModelSheet(context,
                                  isPost: false,
                                  postId: widget.postModel.postid ?? '',
                                  onSubmit: (String msg) async {
                                // Navigator.pop(context);
                              });
                            },
                          ),
                          const SizedBox(width: 4),
                          Expanded(
                            child: GayaMentionedField(
                                autoFocus: true,
                                textFormFieldKey: textFormFieldKey,
                                fillColor: borderColor.withOpacity(0.50),
                                isFilled: true,
                                isPassword: false,
                                inputType: TextInputType.multiline,
                                hintText: GayaStrings.type_comment.tr,
                                borderColor: borderColor),
                          ),
                          // Expanded(
                          //   child: TextFormFieldComment(
                          //     fillColor: borderColor.withOpacity(0.50),
                          //     isFilled: true,
                          //     isPassword: false,
                          //     inputType: TextInputType.multiline,
                          //     hintText: 'Type your comment',
                          //     controller: _replyCommentC,
                          //     borderColor: borderColor,
                          //   ),
                          // ),
                          const SizedBox(width: distance_10),
                          TextButton(
                              onPressed: () async {
                                final commentController =
                                    Get.find<CommentsController>(
                                        tag: widget.postModel.postid);
                                final mentionedCntrl =
                                    Get.find<MentionedUserController>();

                                //increament the post

                                if (textFormFieldKey
                                        .currentState!.controller!.text
                                        .trim()
                                        .isNotEmpty ||
                                    commentController.commentsMedia != null ||
                                    commentController.pdfFiles.isNotEmpty) {
                                  PostWithCommentController.to(
                                          tag: widget.postModel.postid)
                                      .incrementCommentCount();
                                  commentController.postNewReply(
                                      myNewComment: textFormFieldKey
                                          .currentState!.controller!.text,
                                      commentIndex: widget.indexForComment,
                                      postModel: widget.postModel,
                                      mentionedUser:
                                          mentionedCntrl.mentionedUsers);
                                  _replyCommentC.clear();
                                  textFormFieldKey.currentState!.controller!
                                      .clear();
                                  mentionedCntrl.resetMentionedUser();

                                  FocusScope.of(context).unfocus();
                                }

                                // Function Ended
                              },
                              child: Text(GayaStrings.post_txt.tr,
                                  style: body4StylePrimary)),
                          SizedBox(
                            width: distance_10,
                            height: DeviceCheck.isIOS == true ? distance_5 : 0,
                          ),
                        ],
                      ),
                    ],
                  ),
                ));
              })
        ],
      ),
    );
  }
}
