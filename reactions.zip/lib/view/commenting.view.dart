// import 'dart:developer';
//
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:firebase_auth/firebase_auth.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter/services.dart';
// import 'package:flutter_svg/svg.dart';
// import 'package:gaya/components/snackbar.component.dart';
// import 'package:gaya/utils/time.calculation.dart';
// import 'package:gaya/widgets/post.with.comments.widgets/comments.dart';
// import 'package:material_design_icons_flutter/material_design_icons_flutter.dart';
// import 'package:provider/provider.dart';
//
// import '../components/replies.model.dart';
// import '../components/textfield.component.dart';
// import '../controller/comments.controller.dart';
// import '../controller/report_controller.dart';
// import '../gen/assets.gen.dart';
// import '../model/replies.model.dart';
// import '../model/user.model.dart';
// import "../routing/routes.dart" as route;
// import '../utils/const.dart';
// import '../utils/strings.dart';
// import '../utils/textstyles.dart';
// import '../widgets/post.with.comments.widgets/actionrow.widget.dart';
//
// class CommentingView extends StatefulWidget {
//   final String? commentUserProfile;
//   final String? comment;
//   final String? commentUserName;
//   final DateTime? commentDate;
//   final String postId;
//   final String commentId;
//   final String userUid;
//   final String anonymousUserUid;
//   final bool anonymous;
//   final UserModel usermodel;
//
//   const CommentingView({
//     Key? key,
//     this.commentUserProfile,
//     this.comment,
//     this.commentUserName,
//     this.commentDate,
//     required this.postId,
//     required this.commentId,
//     required this.userUid,
//     required this.anonymous,
//     required this.anonymousUserUid,
//     required this.usermodel,
//   }) : super(key: key);
//
//   @override
//   State<CommentingView> createState() => _CommentingViewState();
// }
//
// class _CommentingViewState extends State<CommentingView> {
//   TimeCalculation timeCalculation = TimeCalculation();
//   final TextEditingController replyController = TextEditingController();
//   @override
//   Widget build(BuildContext context) {
//     final commentConroller = Provider.of<CommentsController>(context, listen: true);
//     return Scaffold(
//         appBar: AppBar(
//           systemOverlayStyle: SystemUiOverlayStyle.dark,
//           iconTheme: const IconThemeData(color: kBlackColor),
//           title: const Text('Comment Replies', style: bodyStyle),
//           centerTitle: true,
//           shape: Border(bottom: BorderSide(color: kBaseGrey.withOpacity(0.25))),
//           automaticallyImplyLeading: true,
//           backgroundColor: kTransparentColor,
//           elevation: 0,
//         ),
//         body: Column(children: [
//           Expanded(
//             child: SingleChildScrollView(
//               physics: const BouncingScrollPhysics(),
//               child: Padding(
//                 padding: const EdgeInsets.symmetric(horizontal: distance_20),
//                 child: Column(
//                   children: [
//                     CommentSection(
//                       showDialogBox: () {
//                         ReportController.to.reportAComment(
//                             reportedCommentId: widget.commentId, context: context, postId: widget.postId, content: widget.comment ?? "");
//                       },
//                       userOntap: () {
//                         widget.userUid == FirebaseAuth.instance.currentUser!.uid
//                             ? Navigator.of(context).pushNamed(route.profile)
//                             : Navigator.of(context).pushNamed(route.publicProfile, arguments: {
//                                 'userModel': widget.usermodel,
//                               });
//                       },
//                       nameOnTap: () {
//                         widget.userUid == FirebaseAuth.instance.currentUser!.uid
//                             ? Navigator.of(context).pushNamed(route.profile)
//                             : Navigator.of(context).pushNamed(route.publicProfile, arguments: {
//                                 'userModel': widget.usermodel,
//                               });
//                       },
//                       anonymousPic: widget.anonymous,
//                       userUid: widget.userUid,
//                       uId: widget.anonymousUserUid,
//                       profilepic: widget.commentUserProfile.toString(),
//                       commentConroller: commentConroller,
//                       content: widget.comment.toString(),
//                       name: widget.anonymousUserUid == widget.userUid ? anonymousUser : widget.commentUserName,
//                       time: timeCalculation.convertToAgo(widget.commentDate!),
//                     ),
//                     Padding(
//                       padding: const EdgeInsets.only(left: distance_50),
//                       child: ActionRow(
//                         likeWidget: commentList[0].isLiked == false
//                             ? const Text(
//                                 'Like',
//                                 style: body3MStyle,
//                               )
//                             : Row(
//                                 children: [
//                                   const Text(
//                                     'Like',
//                                     style: body5StylePrimary,
//                                   ),
//                                   const SizedBox(
//                                     width: distance_5,
//                                   ),
//                                   const CircleAvatar(
//                                     radius: 1,
//                                     backgroundColor: kprimaryColor,
//                                   ),
//                                   const SizedBox(
//                                     width: distance_5,
//                                   ),
//                                   SvgPicture.asset(Assets.assets.icons.heartIcon),
//                                 ],
//                               ),
//                         flowerWidget: !commentList[0].isFlower
//                             ? const Text(
//                                 'Give a flower',
//                                 style: body3MStyle,
//                               )
//                             : Row(children: const [
//                                 Text(
//                                   'Give a flower',
//                                   style: yellowebodyStyle,
//                                 ),
//                                 SizedBox(
//                                   width: distance_5,
//                                 ),
//                                 CircleAvatar(
//                                   radius: 1,
//                                   backgroundColor: kprimaryColor,
//                                 ),
//                                 SizedBox(
//                                   width: distance_5,
//                                 ),
//                                 Icon(
//                                   MdiIcons.flowerPoppy,
//                                   color: kYellowColor,
//                                   size: 12,
//                                 ),
//                               ]),
//                         likeOnTap: () {},
//                         flowerOnTap: () {},
//                         replyOnTap: null, //() {},
//                       ),
//                     ),
//                     const SizedBox(
//                       height: distance_10,
//                     ),
//                     Padding(
//                       padding: const EdgeInsets.only(left: distance_50),
//                       child: StreamBuilder(
//                           stream: FirebaseFirestore.instance
//                               .collection('communityposts')
//                               .doc(widget.postId)
//                               .collection('comments')
//                               .doc(widget.commentId)
//                               .collection('replies')
//                               .orderBy('replyTime', descending: true)
//                               .snapshots(),
//                           builder: (context, snapshot) {
//                             if (snapshot.connectionState == ConnectionState.waiting) {
//                               return Container(
//                                 width: double.infinity,
//                                 height: 50,
//                                 color: kBaseGrey,
//                               );
//                             } else if (snapshot.connectionState == ConnectionState.active) {
//                               if (snapshot.hasData) {
//                                 QuerySnapshot repliesData = snapshot.data as QuerySnapshot;
//                                 return ListView.separated(
//                                   itemCount: repliesData.docs.length,
//                                   physics: const NeverScrollableScrollPhysics(),
//                                   shrinkWrap: true,
//                                   itemBuilder: (context, index) {
//                                     RepliesModel _replies = RepliesModel.fromMap(repliesData.docs[index].data() as Map<String, dynamic>);
//                                     return StreamBuilder(
//                                         stream: FirebaseFirestore.instance.collection('users').doc(_replies.userUid).snapshots(),
//                                         builder: (context, Usersnapshot) {
//                                           if (snapshot.connectionState == ConnectionState.waiting) {
//                                           } else if (Usersnapshot.connectionState == ConnectionState.active) {
//                                             if (Usersnapshot.hasData && Usersnapshot.data != null) {
//                                               try {
//                                                 DocumentSnapshot userdata = Usersnapshot.data as DocumentSnapshot;
//                                                 UserModel userModel = UserModel.fromMap(userdata.data() as Map<String, dynamic>);
//                                                 return Column(
//                                                   children: [
//                                                     CommentSection(
//                                                       showDialogBox: () {
//                                                         ReportController.to.reportACommentReply(
//                                                             commentReplyId: _replies.replyId ?? "",
//                                                             content: widget.comment.toString(),
//                                                             commentId: widget.commentId,
//                                                             context: context,
//                                                             postId: widget.postId);
//                                                       },
//                                                       userOntap: () {
//                                                         userModel.uId == FirebaseAuth.instance.currentUser!.uid
//                                                             ? Navigator.of(context).pushNamed(route.profile)
//                                                             : Navigator.of(context).pushNamed(route.publicProfile, arguments: {
//                                                                 "userModel": userModel,
//                                                               });
//                                                       },
//                                                       nameOnTap: () {
//                                                         userModel.uId == FirebaseAuth.instance.currentUser!.uid
//                                                             ? Navigator.of(context).pushNamed(route.profile)
//                                                             : Navigator.of(context).pushNamed(route.publicProfile, arguments: {
//                                                                 "userModel": userModel,
//                                                               });
//                                                       },
//                                                       anonymousPic: widget.anonymous,
//                                                       userUid: userModel.uId,
//                                                       uId: widget.usermodel.uId,
//                                                       profilepic: userModel.profilePicture,
//                                                       commentConroller: commentConroller,
//                                                       content: _replies.reply,
//                                                       name: userModel.name,
//                                                       time: timeCalculation.convertToAgo(_replies.replyTime!),
//                                                     ),
//                                                     Padding(
//                                                       padding: const EdgeInsets.only(left: distance_50),
//                                                       child: ActionRow(
//                                                         likeWidget: const Text(
//                                                           'Like',
//                                                           style: body3MStyle,
//                                                         ),
//                                                         flowerWidget: const Text(
//                                                           'Give a flower',
//                                                           style: body3MStyle,
//                                                         ),
//                                                         likeOnTap: () {},
//                                                         flowerOnTap: () {},
//                                                         replyOnTap: null, // () {},
//                                                       ),
//                                                     ),
//                                                   ],
//                                                 );
//                                               } catch (_) {
//                                                 return Container();
//                                               }
//                                             }
//                                           }
//                                           return const SizedBox();
//                                         });
//                                   },
//                                   separatorBuilder: (context, index) {
//                                     return const SizedBox(
//                                       height: distance_20,
//                                     );
//                                   },
//                                 );
//                               }
//                             }
//
//                             return const Text('No data found');
//                           }),
//                     ),
//                   ],
//                 ),
//               ),
//             ),
//           ),
//           Container(
//             color: kWhiteColor,
//             padding: const EdgeInsets.symmetric(vertical: distance_15),
//             child: Row(
//               children: [
//                 const SizedBox(
//                   width: distance_15,
//                 ),
//                 Expanded(
//                   child: textField2(
//                     fillColor: borderColor.withOpacity(0.50),
//                     isFilled: true,
//                     isPassword: false,
//                     inputType: TextInputType.text,
//                     hintText: "Type your reply",
//                     // controller: commentConroller.replyController,
//                     // hintText: postIsCommentedNotification,
//                     controller: replyController,
//                     borderColor: borderColor,
//                   ),
//                 ),
//                 const SizedBox(
//                   width: distance_10,
//                 ),
//                 TextButton(
//                     onPressed: () async {
//                       if (replyController.text.isNotEmpty) {
//                         commentConroller.setReplies(widget.postId, widget.commentId, replyController.text);
//                         replyController.clear();
//
//                         log('reply sent');
//                       } else {
//                         snackBar(context, 'add a reply', kprimaryColor);
//                       }
//                     },
//                     child: const Text(
//                       'Post',
//                       style: body4StylePrimary,
//                     )),
//                 const SizedBox(
//                   width: distance_10,
//                 ),
//               ],
//             ),
//           ),
//         ]));
//   }
// }
