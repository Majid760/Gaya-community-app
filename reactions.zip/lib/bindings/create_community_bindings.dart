import 'package:get/get.dart';

import '../view/community/create_community/controllers/community_questionnaire_controller.dart';

class CreateCommunityBindings extends Bindings {
  @override
  dependencies() {
    Get.lazyPut(() => QuestionnaireController());
  }
}
