class VideoAssetsUtils {
  VideoAssetsUtils._();

  static const String _parentVideoPath = 'Assets/videos/';
  static const String instaStoryBg = '${_parentVideoPath}insta_story_bg.mp4';
}
