import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../const.dart';

class GayaButtonStyles {
  // comments/ reply
  static final actionRowTextButtonStyle = TextButton.styleFrom(
    tapTargetSize: MaterialTapTargetSize.padded,
    visualDensity: const VisualDensity(horizontal: -4, vertical: -4),
    foregroundColor: kSecondaryColor,
    padding: const EdgeInsets.symmetric(horizontal: 2, vertical: 0).r,
  );
  // home post widget
  static final actionRowTextButtonStyle2 = TextButton.styleFrom(
    tapTargetSize: MaterialTapTargetSize.padded,
    foregroundColor: kSecondaryColor,
    padding: const EdgeInsets.symmetric(horizontal: 2).r,
  );
}
