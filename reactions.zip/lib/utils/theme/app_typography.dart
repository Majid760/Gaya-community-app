/// TO Calculate Line Height Of Text from FIGMA
/// LINE HEIGHT formula  = (line-height/fontSize)
import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gaya/utils/textstyles.dart';

import 'app_colors.dart';

class GayaTypography {
  // headers
  static final h1 = TextStyle(
      fontWeight: FontWeight.w600,
      fontSize: 28.8.sp,
      color: AppColors.black,
      height: 1.5,
      letterSpacing: 0.2,
      fontFamily: GayaFontTheme.primaryFont);
  static final h2 = TextStyle(
      fontWeight: FontWeight.w600,
      fontSize: 25.63.sp,
      color: AppColors.black,
      height: 1.5,
      letterSpacing: 0.4,
      fontFamily: GayaFontTheme.primaryFont);

  static final h3 = TextStyle(
      fontWeight: FontWeight.w600,
      fontSize: 22.78.sp,
      color: AppColors.black,
      height: 1.5,
      letterSpacing: 0.4,
      fontFamily: GayaFontTheme.primaryFont);

  static final h4 = TextStyle(
      fontWeight: FontWeight.w600,
      fontSize: 20.25.sp,
      color: AppColors.black,
      height: 1.2,
      letterSpacing: 0.4,
      fontFamily: GayaFontTheme.primaryFont);

  static final body2 =
      TextStyle(fontWeight: FontWeight.w400, fontSize: 16.sp, color: AppColors.black, height: 1.8, fontFamily: GayaFontTheme.primaryFont);

  // titles
  static final titleMedium = TextStyle(
      fontWeight: FontWeight.w500, fontSize: 16.sp, color: AppColors.black, letterSpacing: 0.2, fontFamily: GayaFontTheme.primaryFont);

  static final title = TextStyle(
    fontWeight: FontWeight.w600,
    fontSize: 16.sp,
    color: AppColors.black,
    letterSpacing: 0.4,
    fontFamily: GayaFontTheme.primaryFont,
  );

  static final titleSemiBold = TextStyle(
      fontWeight: FontWeight.w600,
      fontSize: 16.sp,
      color: AppColors.black,
      height: 1.5,
      letterSpacing: 0.2,
      fontFamily: GayaFontTheme.primaryFont);

  // texts
  static final text = TextStyle(
      fontWeight: FontWeight.w400, fontSize: 16.sp, color: AppColors.black, letterSpacing: 0.2, fontFamily: GayaFontTheme.primaryFont);

  // subtitles
  static final subtitleRegular = TextStyle(
    fontWeight: FontWeight.w400,
    fontSize: 14.22.sp,
    color: AppColors.black,
    letterSpacing: 0.1,
    fontFamily: GayaFontTheme.primaryFont,
  );

  static final subtitleMedium = TextStyle(
      fontWeight: FontWeight.w500, fontSize: 14.22.sp, color: AppColors.black, letterSpacing: 0.1, fontFamily: GayaFontTheme.primaryFont);

  // captions
  static final caption = TextStyle(
    fontWeight: FontWeight.w400,
    fontSize: 12.64.sp,
    color: AppColors.black,
    height: 0.702,
    letterSpacing: 0.3,
    fontFamily: GayaFontTheme.primaryFont,
  );

  static final captionMedium = TextStyle(
      fontWeight: FontWeight.w500, fontSize: 12.sp, color: AppColors.black, letterSpacing: 0.3, fontFamily: GayaFontTheme.primaryFont);

  static final caption2 = TextStyle(
      fontWeight: FontWeight.w400,
      fontSize: 11.24.sp,
      color: AppColors.black,
      height: 0.51,
      letterSpacing: 0.3,
      fontFamily: GayaFontTheme.primaryFont);

  static final caption2Medium = TextStyle(
      fontWeight: FontWeight.w500,
      fontSize: 12.64.sp,
      color: AppColors.black,
      height: 1.424,
      letterSpacing: 0.3,
      fontFamily: GayaFontTheme.primaryFont);
  static final caption4Medium = TextStyle(
      fontWeight: FontWeight.w500,
      fontSize: 18.sp,
      color: AppColors.white,
      height: 1.2,
      letterSpacing: 0.2,
      fontFamily: GayaFontTheme.primaryFont);

  static final caption3 = TextStyle(
      fontWeight: FontWeight.w400,
      fontSize: 10.sp,
      color: AppColors.black,
      height: 2,
      letterSpacing: 0.2,
      fontFamily: GayaFontTheme.primaryFont);

  static final caption3Medium = TextStyle(
      fontWeight: FontWeight.w500,
      fontSize: 10.sp,
      color: AppColors.black,
      height: 0.45,
      letterSpacing: 0.2,
      fontFamily: GayaFontTheme.primaryFont);
}

class CustomTypography {
  CustomTypography();

  static final TextStyle superTitleStyle = TextStyle(
      fontWeight: FontWeight.w700,
      fontSize: 36.sp,
      color: AppColors.black,
      height: 0.84,
      letterSpacing: 0.2,
      fontFamily: GayaFontTheme.primaryFont);

  static final title24W600 = TextStyle(
      fontWeight: FontWeight.w600,
      fontSize: 24.sp,
      color: AppColors.black,
      height: 1.7,
      letterSpacing: 0.2,
      fontFamily: GayaFontTheme.primaryFont);
  static final TextStyle community = TextStyle(
      fontWeight: FontWeight.w500, fontSize: 12.sp, color: AppColors.black, letterSpacing: 0.2, fontFamily: GayaFontTheme.primaryFont);

  static final TextStyle postCaptionStyle = TextStyle(
      fontSize: 14.sp,
      fontFamily: GayaFontTheme.primaryFont,
      fontFamilyFallback: DeviceCheck.isIOS ? [] : [GayaFontTheme.fallBackFont],
      height: 1.5);

  static final TextStyle modalSheetTitleStyle = GayaTypography.text.copyWith(height: 1.13);
}

class DeviceCheck {
  static bool get isIOS {
    if (kIsWeb) {
      return false;
    } else {
      return Platform.isIOS;
    }
  }

  static bool get isAndroid {
    if (kIsWeb) {
      return false;
    } else {
      return Platform.isAndroid;
    }
  }

  static bool get isWeb {
    return kIsWeb;
  }
}