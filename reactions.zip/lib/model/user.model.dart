import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:gaya/model/topic.model.dart';
import 'package:gaya/shared/service/dynamic_link_service/utils/query_param_consts.dart';
import 'package:gaya/utils/logger.dart';
import 'package:get/get.dart';

import '../shared/service/dynamic_link_service/enums/dynamic_link_type.dart';
import '../shared/service/dynamic_link_service/model/dynamic_link_type_string.dart';

class UserModel extends GetxService implements DynamicLinkTypeString {
  static UserModel get to => Get.find();

  update(UserModel? user) {
    if (user == null) return;
    bio = user.bio;
    coverPhoto = user.coverPhoto;
    email = user.email;
    interests = user.interests;
    name = user.name;
    profilePicture = user.profilePicture;
    uId = user.uId ?? FirebaseAuth.instance.currentUser?.uid;
    fm_token = user.fm_token;
    admin = user.admin;
    allowToDm = user.allowToDm;
    phoneNumber = user.phoneNumber;
    createdOn = user.createdOn;
    isActive = user.isActive;
    dob = user.dob;
    gender = user.gender;
    userDailyCrowns = user.userDailyCrowns;
    userTotalCrowns = user.userTotalCrowns;

    debugPrint('UserModel updated ${user.dob}');
  }

  String? bio;
  String? coverPhoto;
  String? email;
  List<TopicsModel>? interests;
  String? name;
  String? profilePicture;
  String? uId;
  String? fm_token;
  bool? admin;
  bool? allowToDm;
  String? phoneNumber;
  DateTime? createdOn;
  DateTime? dob;
  String? gender;
  bool? isActive;

  int? userTotalCrowns;
  int? userDailyCrowns;

  // UserCrownsModel? userCrownsModel;

  UserModel(
      {this.bio,
      this.coverPhoto,
      this.email,
      this.interests = const [],
      this.name,
      this.profilePicture,
      this.uId,
      this.fm_token,
      this.admin,
      this.allowToDm,
      this.phoneNumber,
      this.createdOn,
      this.dob,
      this.gender,
      this.isActive,
      this.userDailyCrowns,
      this.userTotalCrowns});

  // this.userCrownsModel});
//used for public post or any activity
  toPublicJson({bool shouldHaveEmail = true}) {
    Map<String, dynamic> map = {
      'name': name,
      'profilePic': profilePicture,
      'uid': uId ?? FirebaseAuth.instance.currentUser?.uid,
    };
    if (shouldHaveEmail) {
      map.addAll({'email': email});
    }
    return map;
  }

  UserModel.fromMap(Map<String, dynamic> map) {
    bio = map['bio'];
    coverPhoto = map['coverphoto'];
    email = map['email'];
    name = map['name'].toString();
    profilePicture = map['profilePic'];
    fm_token = map['fm_token'];
    uId = map['uid'];
    admin = map['isAdmin'];
    allowToDm = map['allowToDm'] ?? true;
    phoneNumber = map['phoneNumber'];
    isActive = map['isActive'];
    dob = map["dob"] is String
        ? map["dob"].toString().isEmpty
            ? null
            : DateTime.tryParse(map["dob"])
        : map["dob"] is Timestamp
            ? map["dob"].toDate()
            : null;

    gender = map["gender"];
    // createdOn = map['createdOn'];
    userDailyCrowns = map["userDailyCrowns"] ?? 0;
    userTotalCrowns = map["userTotalCrowns"] ?? 0;

    // userCrownsModel = (map['userCrownsModel'] == null) ? null : UserCrownsModel.fromMap(map['userCrownModel'] as Map<String, dynamic>);

    if (map['interests'] != null) {
      interests = <TopicsModel>[];

      List<String> topicNames = map['interests'].map<String>((e) => e["title"].toString().toLowerCase()).toList();

      /// make a new list of topics from the list of topic names
      /// and assign it to the interests list
      /// This case is for the user who has already created an account and they don't have  icon in their interests
      final data = topicsList.where((element) => topicNames.contains(element.title.toLowerCase())).toList();
      interests = data;
    }
  }

  Map<String, dynamic> toMap() {
    return {
      'bio': bio,
      'coverphoto': coverPhoto,
      'email': email,
      'name': name,
      'profilePic': profilePicture,
      'uid': uId,
      'fm_token': fm_token,
      'interests': interests ?? [],
      'admin': admin,
      'allowToDm': allowToDm ?? true,
      'phoneNumber': phoneNumber,
      'isActive': isActive,
      'dob': dob,
      'gender': gender,
      'userTotalCrowns': userTotalCrowns ?? 0,
      'userDailyCrowns': userDailyCrowns ?? 0
      // 'userCrownsModel': (userCrownsModel == null) ? null : userCrownsModel?.toMap()
      // 'userCreatedOn' : createdOn,
    };
  }

  // to copyWith mehto
  UserModel copyWith({
    String? bio,
    String? coverPhoto,
    String? email,
    List<TopicsModel>? interests,
    String? name,
    String? profilePicture,
    String? uId,
    String? gender,
    DateTime? dob,
    String? phoneNumber,
    bool ismoderator = false,
    int? userTotalCrowns,
    int? userDailyCrowns,
    bool? allowToDm,
    // UserCrownsModel? userCrownsModel,
  }) {
    return UserModel(
      bio: bio ?? this.bio,
      coverPhoto: coverPhoto ?? this.coverPhoto,
      interests: interests ?? this.interests ?? [],
      name: name ?? this.name,
      profilePicture: profilePicture ?? this.profilePicture,
      uId: uId ?? this.uId,
      dob: dob ?? this.dob,
      gender: gender ?? this.gender,
      phoneNumber: phoneNumber ?? this.phoneNumber,
      userDailyCrowns: userDailyCrowns,
      userTotalCrowns: userTotalCrowns,
      allowToDm: allowToDm ?? this.allowToDm,
    );

    // userCrownsModel: (userCrownsModel == null)
    //     ? null
    //     : userCrownsModel.copyWith(userDailyCrowns: userCrownsModel.userDailyCrowns, userTotalCrowns: userCrownsModel.userTotalCrowns)
  }

  /// increaments total crowns
  UserModel updateCrown({bool shouldIncreament = false}) {
    MyLoggerServices.to
        .print("should increment $shouldIncreament and ${shouldIncreament ? (userTotalCrowns ?? 0) + 1 : (userTotalCrowns ?? 1) - 1}");
    return copyWith(userTotalCrowns: shouldIncreament ? (userTotalCrowns ?? 0) + 1 : (userTotalCrowns ?? 1) - 1);
  }

  // convert the algolia map to userModel ( we need just id,name,profilePicture)
  UserModel.fromAlgoliaMap(Map<String, dynamic> map) {
    try {
      uId = map['objectID'];
      name = map['name'].toString().capitalizeFirst;
      email = map['email'];
      profilePicture = map['profilePic'];
      coverPhoto = map['coverphoto'];
      phoneNumber = map['phoneNumber'];
      isActive = map['isActive'];
      bio = map['bio'];
    } catch (_) {}
  }

  void logOut() {
    update(UserModel());
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;

    return other is UserModel && other.uId == uId;
  }

  @override
  String get type => DynamicLinkType.userProfile.name;

  @override
  String get queryParams => "?${QueryParamConst.id}=$uId&${QueryParamConst.type}=$type";

  @override
  int get hashCode => uId.hashCode;
}

extension ParsingDateTime on DateTime {
  tryParseDate() {
    try {
      return DateTime.parse(toString());
    } catch (_) {
      return "";
    }
  }
}

class UserScoring {
  int? posts, comments, likes, followers, following, total;
}

extension UserModelExtension on UserModel {
  String dobAndGender() {
    return "${_isValidGender() ? "${gender?.capitalizeFirst ?? ""}," : ""} ${calculateAge != null ? "$calculateAge years old" : ""}";
  }

  bool _isValidGender() {
    return gender?.toLowerCase() == "male" || gender?.toLowerCase() == "female";
  }

  int? get calculateAge {
    if (dob == null) return null;
    final now = DateTime.now();
    final age = now.year - dob!.year;

    if (age > 0) {
      return age;
    }
    return null;
  }
}
