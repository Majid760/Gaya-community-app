class ReactionModel {
  String userId;
  String reaction;

  ReactionModel({
    required this.userId,
    required this.reaction,
  });

  @override
  bool operator ==(other) {
    if (identical(this, other)) return true;
    return other is ReactionModel && userId == other.userId;
  }

  @override
  int get hashCode => userId.hashCode;

  factory ReactionModel.fromMap(Map<String, dynamic> map) {
    return ReactionModel(
      userId: map['userId'],
      reaction: map['reaction'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'userId': userId,
      'reaction': reaction,
    };
  }
}

class PostReactionDataModel {
  int inLove;
  int sad;
  int angry;
  int surprized;
  int funny;

  PostReactionDataModel({
    this.inLove = 0,
    this.sad = 0,
    this.angry = 0,
    this.surprized = 0,
    this.funny = 0,
  });

  @override
  bool operator ==(other) {
    if (identical(this, other)) return true;
    return other is PostReactionDataModel && inLove == other.inLove;
  }

  @override
  int get hashCode => inLove.hashCode;

  factory PostReactionDataModel.fromMap(Map<String, dynamic> map) {
    return PostReactionDataModel(
      inLove: map['inLove'] ?? 0,
      sad: map['sad'] ?? 0,
      angry: map['angry'] ?? 0,
      surprized: map['surprized'] ?? 0,
      funny: map['funny'] ?? 0,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'inLove': inLove,
      'sad': sad,
      'angry': angry,
      'surprized': surprized,
      'funny': funny,
    };
  }
}
