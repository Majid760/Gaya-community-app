// // import 'dart:developer';
// import 'dart:developer';
//
// import 'package:cached_network_image/cached_network_image.dart';
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:firebase_auth/firebase_auth.dart';
// import 'package:firebase_image/firebase_image.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_svg/svg.dart';
// import 'package:gaya/components/profile_image_widget.dart';
// import 'package:gaya/components/skeleton.post.component.dart';
// import 'package:gaya/controller/communities.controller.dart';
// import 'package:gaya/utils/animation.dart';
// import 'package:gaya/utils/methods.dart';
// import 'package:gaya/view/comments/view/comment_with_post_screen.dart';
// import 'package:gaya/widgets/home_view_widgets/home.post.widget.dart';
// import 'package:get/get.dart';
// import 'package:paginate_firestore/paginate_firestore.dart';
// import 'package:provider/provider.dart';
// import '../../components/button.component.dart';
// import '../../components/show.full.picture.dart';
// import '../../components/snackbar.component.dart';
// import '../../controller/app_config_controller.dart';
// import '../../controller/create.post.controller.dart';
// import '../../controller/group.controller.dart';
// import '../../controller/homepage.controller.dart';
// import '../../controller/report_controller.dart';
// import '../../gen/assets.gen.dart';
// import '../../model/community.model.dart';
// import '../../model/create.post.model.dart';
// import '../../model/user.model.dart';
// import '../../routing/getx_route_methods.dart';
// import '../../routing/routes.dart' as route;
// import '../../services/notification/notification_api/notification_api.dart';
// import '../../services/services.dart';
// import '../../utils/const.dart';
// import '../../utils/strings.dart';
// import '../../utils/textstyles.dart';
//
// class UserWithoutommunities extends StatefulWidget {
//   const UserWithoutommunities({super.key});
//
//   @override
//   State<UserWithoutommunities> createState() => _UserWithoutommunitiesState();
// }
//
// class _UserWithoutommunitiesState extends State<UserWithoutommunities> {
//   @override
//   Widget build(BuildContext context) {
//     debugPrint("UserWithoutommunities built");
//     final user = FirebaseAuth.instance.currentUser!.uid;
//     return PaginateFirestore(
//       scrollController: Provider.of<HomePageController>(context, listen: false).homeScrollController,
//       itemBuilder: (context, documentSnapshots, index) {
//         final document = documentSnapshots[index].data() as Map<String, dynamic>;
//         //where old posts are loaded.
//         if (document["postedBy"] == null) {
//           return PostsSkeleton();
//         }
//         CreatePostModel createPostModel = CreatePostModel.fromMap(documentSnapshots[index].data() as Map<String, dynamic>);
//
//         CreateCommunityModel _createCommunityModel = createPostModel.community;
//
//         UserModel _userModel = createPostModel.postedBy;
//         if (AppConfigurationController.to.isUserBlockedAlready(userId: _userModel.uId ?? "")) {
//           print("Blocked User as SizedBox Shrink ${_userModel.uId} (user without communities widget)");
//           return SizedBox.shrink();
//         }
//         return HomePostWidget(
//           onTap: () {
//             Routes.postDetailsScreen(post: createPostModel);
//             // Get.to(() => CommentWithPostScreen(postModel: createPostModel, userModel: _userModel));
//
//             //   Navigator.of(context).pushNamed(route.postWithComments, arguments: {
//             //   'userModel': _userModel,
//             //   'postModel': createPostModel,
//             //   'communityModel': _createCommunityModel,
//             // });
//           },
//           hasVideo: (createPostModel.video == null || createPostModel.video == '') ? false : true,
//           index: index,
//           videoLink: createPostModel.video,
//           crossAxis: createPostModel.multipleImages == null
//               ? 1
//               : createPostModel.multipleImages!.length < 2
//                   ? 1
//                   : 2,
//           postId: createPostModel.postid,
//           onDeleteTap: () async {
//             Navigator.pop(context);
//             try {
//               await context.read<GroupController>().deleteYourPost(createPostModel.postid!, context);
//
//               // homeController.allPostsUserNotLoginList.removeAt(index);
//               // homeController.userDataListNoCommunity.removeAt(index);
//               // homeController.communitiesDataNoCommunity.removeAt(index);
//             } catch (e) {
//               debugPrint(e.toString());
//             }
//
//             // setState(() {
//             //   homeController.allPostsUserNotLoginList;
//             //   homeController.userDataListNoCommunity;
//             //   homeController.communitiesDataNoCommunity;
//             // });
//           },
//           doNotshowBottomrow: false,
//           totalFlowerCounts: createPostModel.flowersBy?.length.toString() ?? "0",
//           totalLikesCount: createPostModel.likedBy?.length.toString() ?? "0",
//           totalCommentsCount: createPostModel.totalCommentsCount ?? "0",
//           flowerIconColor: createPostModel.flowersBy?.contains(UserModel.to.uId) == true ? kYellowColor : kSecondaryColor,
//           likeIconColor: createPostModel.likedBy?.contains(UserModel.to.uId) == true ? kRedColor : kSecondaryColor,
//           report: () {
//             Navigator.pop(context);
//             ReportController.to.reportPost(createPostModel.postid ?? "", context);
//           },
//           overlapImage: GestureDetector(
//             onTap: () {
//               if (createPostModel.isPostedAnonymously == true) {
//               } else if (_userModel.uId == user) {
//                 Navigator.of(context).pushNamed(route.profile);
//               } else {
//                 Navigator.of(context).pushNamed(route.publicProfile, arguments: {
//                   'userModel': _userModel,
//                 });
//               }
//             },
//             child: CircleAvatar(
//               backgroundColor: kWhiteColor,
//               radius: 17,
//               child: (createPostModel.isPostedAnonymously == true)
//                   ? CircleAvatar(radius: distance_15, backgroundImage: AssetImage("Assets/images/anonymous_user.png"))
//                   : _userModel.profilePicture?.trim() == ''
//                       ? CircleAvatar(radius: distance_15, backgroundImage: AssetImage('Assets/images/user.png'))
//                       : CircleAvatar(
//                           //backgroundImage:   CachedNetworkImageProvider(_userModel.profilePicture ??""),
//                           child: ProfileImageWidget(
//                             url: _userModel.profilePicture,
//                             size: Size(distance_30, distance_30),
//                           ),
//
//                           // CachedNetworkImage(
//                           //   memCacheHeight: 50,
//                           //   memCacheWidth: 50,
//                           //   imageUrl: _userModel.profilePicture ?? "",
//                           //   imageBuilder: (context, imageProvider) {
//                           //     return Container(
//                           //       decoration: BoxDecoration(
//                           //         shape: BoxShape.circle,
//                           //         image: DecorationImage(
//                           //           image: imageProvider,
//                           //           fit: BoxFit.cover,
//                           //         ),
//                           //       ),
//                           //     );
//                           //   },
//                           //   fit: BoxFit.cover,
//                           //   errorWidget: (context, url, error) => Container(
//                           //     decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.grey.shade200),
//                           //     child: Center(
//                           //         child: Icon(
//                           //       Icons.error,
//                           //       color: Colors.red,
//                           //     )),
//                           //   ),
//                           //   placeholder: (context, url) => Image.asset(
//                           //     Assets.assets.images.userDefault,
//                           //   ),
//                           // ),
//                           // FirebaseImage(
//                           //     errorAssetImage: 'Assets/images/user.png',
//                           //
//                           //     'gs://gaya-production.appspot.com/users/${_userModel.uId}/avatar.png'),
//                           // backgroundImage: FirebaseImage('gs://gayatest-badar.appspot.com/users/${_userModel.uId}/avatar.png'),
//
//                           radius: distance_15,
//                           backgroundColor: kBaseGrey,
//                         ),
//             ),
//           ),
//           imageTap: () {
//             (createPostModel.multipleImages?.isEmpty ?? true)
//                 ? null
//                 : Navigator.of(context).push(MaterialPageRoute(
//                     builder: (context) => PostImages(
//                       allImages: createPostModel.multipleImages ?? [],
//                     ),
//                   ));
//           },
//
//           //void call back on flower on tap
//           likeOnTap: () async {
//             print("like on tap");
//             if (createPostModel.likedBy?.contains(UserModel.to.uId) == false) {
//               context.read<CreatePostController>().likePost(
//                     createPostModel.postid!,
//                   );
//
//               // log('Post liked ${index}');
//               if (_userModel.uId != user) {
//                 bool isNotificationSet = await NotificationApiHitting()
//                     .callOnFcmApiSendPushNotifications(gaya_message: postIsLikedNotification, fcmToken: _userModel.fm_token);
//                 // if (isNotificationSet) {
//                 //   log("Notification Sent:");
//                 // } else {
//                 //   log("Notification Not Sent:");
//                 // }
//                 DocumentSnapshot? profileUserData = await Services().getUserDetailsServices();
//                 Services().addNotification(
//                     posId: createPostModel.postid,
//                     isRead: false,
//                     message: postIsLikedNotification,
//                     receiverUserID: _userModel.uId!,
//                     senderId: profileUserData!.id,
//                     senderName: profileUserData["name"],
//                     time: DateTime.now().toString(),
//                     type: "postLiked",
//                     userImage: profileUserData["profilePic"]);
//               } else {
//                 // log("Cannot Create Notification on self Post.");
//               }
//             } else {
//               FirebaseFirestore.instance.collection('communityposts').doc(createPostModel.postid).update({
//                 'likedBy': FieldValue.arrayRemove([UserModel.to.uId]),
//               });
//               // .collection('likes')
//               // .where('userUid', isEqualTo: user)
//               // .get()
//               // .then((value) => value.docs.first.reference.delete());
//
//               // log('unliking the post ${index}');
//             }
//           },
//
//           //void call back on like button
//           flowerOnTap: () async {
//             if (createPostModel.flowersBy?.contains(UserModel.to.uId) == false) {
//               context.read<CreatePostController>().flowerPost(
//                     createPostModel.postid!,
//                   );
//
//               // log('Post flower ${index}');
//               if (_userModel.uId != user) {
//                 bool isNotificationSet = await NotificationApiHitting()
//                     .callOnFcmApiSendPushNotifications(gaya_message: flowerGivenNotification, fcmToken: _userModel.fm_token);
//                 if (isNotificationSet) {
//                   // log("Notification Sent:");
//                 } else {
//                   // log("Notification Not Sent:");
//                 }
//                 DocumentSnapshot? profileUserData = await Services().getUserDetailsServices();
//                 Services().addNotification(
//                     posId: createPostModel.postid,
//                     isRead: false,
//                     message: flowerGivenNotification,
//                     receiverUserID: _userModel.uId!,
//                     senderId: profileUserData!.id,
//                     senderName: profileUserData["name"],
//                     time: DateTime.now().toString(),
//                     type: "postFlowered",
//                     userImage: profileUserData["profilePic"]);
//               } else {
//                 // log("Cannot Create Notification on self Post.");
//               }
//             } else {
//               FirebaseFirestore.instance.collection('communityposts').doc(createPostModel.postid).update({
//                 'flowersBy': FieldValue.arrayRemove([UserModel.to.uId]),
//               });
//               // .collection('flowers')
//               // .where('userUid', isEqualTo: user)
//               // .get()
//               // .then((value) => value.docs.first.reference.delete());
//
//               // log('unliking the flower ${index}');
//             }
//           },
//
//           commentOntap: () {
//             Routes.postDetailsScreen(post: createPostModel);
//             // Get.to(() => CommentWithPostScreen(postModel: createPostModel, userModel: _userModel));
//
//             // Navigator.of(context).pushNamed(route.postWithComments, arguments: {
//             //   'userModel': _userModel,
//             //   'postModel': createPostModel,
//             //   'communityModel': _createCommunityModel,
//             // });
//           },
//           save: AppConfigurationController.to.savedPostsID.contains(createPostModel.postid) == true ? "Unsave" : "Save",
//           //savePostQ.docs.length < 1 ? "Save" : "Unsave", todo://almog confirm if still its in use
//           onTapSaved: () async {
//             if (AppConfigurationController.to.savedPostsID.contains(createPostModel.postid) == true) {
//               Navigator.pop(context);
//               AppConfigurationController.to.savedPostsID.remove(createPostModel.postid);
//
//               await context.read<HomePageController>().deleteUserSaveDocFromPostCollection(createPostModel.postid!, context);
//               await context.read<HomePageController>().deletePostFromUserCollection(createPostModel.postid!);
//             } else {
//               Navigator.pop(context);
//               AppConfigurationController.to.savedPostsID.add(createPostModel.postid ?? "");
//               await context.read<CreatePostController>().savePost(
//                     createPostModel.postid!,
//                   );
//
//               await context.read<HomePageController>().setSavePostInUSerCollection(
//                   {'postId': createPostModel.postid, 'communityId': _createCommunityModel.communityId, 'userUid': UserModel.to.uId},
//                   context);
//             }
//           },
//           currentUserPost: createPostModel.memberId == user ? true : false,
//
//           onUserTap: () async {
//             final controller = context.read<GroupController>();
//             try {
//               final result = await Future.wait([
//                 controller.checkJoinOrNot(_createCommunityModel.communityId!),
//                 Services().getCommunityMembersCount(_createCommunityModel.communityId!),
//                 controller.checkWhetherTheCommunityisPrivateorPublic(_createCommunityModel.communityId!),
//               ]);
//               QuerySnapshot<Object?>? data = result.first as QuerySnapshot<Object?>?;
//               int membersCount = result[1] as int;
//               data!.docs.length == 0
//                   ? joinCommunitySheet(_createCommunityModel.communityName!, _createCommunityModel.communityType!, membersCount,
//                       _createCommunityModel.communityDescription!, _createCommunityModel.communityId!, context,
//                       communityModel: _createCommunityModel)
//                   : Navigator.of(context).pushNamed(route.group, arguments: {"communityModel": _createCommunityModel});
//             } catch (_) {}
//           },
//           groupImage: _createCommunityModel.CommunityPic.toString(),
//           groupName: _createCommunityModel.communityName.toString(),
//           postDetailsText: createPostModel.postDescription.toString(),
//           postImage: createPostModel.multipleImages ?? [],
//           dateTime: createPostModel.isPostedAnonymously == true ? anonymousUser : _userModel.name.toString(),
//
//           isPostHasImage: createPostModel.multipleImages == null
//               ? false
//               : createPostModel.multipleImages!.isEmpty == true
//                   ? false
//                   : true,
//           approvalShow: false,
//         );
//       },
//       onEmpty: const Center(
//         child: AnimationLottie(),
//       ),
//       itemsPerPage: 30,
//       onError: (error) => const Center(
//         child: AnimationLottie(),
//       ),
//       bottomLoader: PostsSkeleton(),
//       initialLoader: Column(
//         children: [PostsSkeleton()],
//       ),
//       query: AppConfigurationController.to.publicCommunities.isNotEmpty
//           ? FirebaseFirestore.instance
//               .collection('communityposts')
//               .where("communityId", whereIn: _getPublicCommunitiesIds())
//               .where("approve", isEqualTo: true)
//               .where('isDeleted', isEqualTo: false)
//               .orderBy("createdOn", descending: true)
//           : FirebaseFirestore.instance
//               .collection('communityposts')
//               .where("approve", isEqualTo: true)
//               .where('isDeleted', isEqualTo: false)
//               .orderBy("createdOn", descending: true),
//       itemBuilderType: PaginateBuilderType.listView,
//       isLive: true,
//     );
//   }
//
//   List<String?> _getPublicCommunitiesIds() {
//     List<String?> communityUids = AppConfigurationController.to.publicCommunities.map((e) => e.communityId).toList();
//     if (communityUids.length > 10) {
//       communityUids = communityUids.sublist(0, 10);
//     }
//     return communityUids;
//   }
//
//   joinCommunitySheet(
//       String communityName, String communityType, int totalMembers, String communityDescription, String communityId, BuildContext context,
//       {required CreateCommunityModel communityModel}) {
//     showModalBottomSheet(
//       context: context,
//       builder: (context) => Container(
//         padding: EdgeInsets.all(20),
//         width: MediaQuery.of(context).size.width,
//         decoration: BoxDecoration(
//           color: Colors.white,
//           borderRadius: BorderRadius.only(topLeft: Radius.circular(13.0), topRight: Radius.circular(13.0)),
//         ),
//         child: StatefulBuilder(builder: (context, readMore) {
//             return SingleChildScrollView(
//               physics: ClampingScrollPhysics(),
//               child: Column(
//                 mainAxisSize: MainAxisSize.min,
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                 children: [
//                   Text(
//                     communityName,
//                     style: headingStyle,
//                   ),
//                   SizedBox(
//                     height: 10,
//                   ),
//                   IntrinsicHeight(
//                     child: Row(
//                       children: [
//                         SvgPicture.asset(communityType == "Private" ? "Assets/icons/lock.svg" : "Assets/icons/unlock.svg"),
//                         SizedBox(
//                           width: 10,
//                         ),
//                         Text(
//                           communityType,
//                           style: dark12,
//                         ),
//                         VerticalDivider(
//                           color: kBaseGrey,
//                           thickness: 2,
//                         ),
//                         Text(
//                           "$totalMembers members",
//                           style: dark12,
//                         ),
//                       ],
//                     ),
//                   ),
//                   SizedBox(
//                     height: 20,
//                   ),
//                   Text(
//                     "About",
//                     style: body2StyleWeightBlack,
//                   ),
//                   SizedBox(
//                     height: 20,
//                   ),
//                   Text(
//                     communityDescription,
//                     textDirection: Methods.isRTL(communityModel.communityDescription ?? '') ? TextDirection.rtl : TextDirection.ltr,
//
//                     style: body4StyleLowWeight,
//                     maxLines: context.read<CommunitiesController>().isReadMore == true ? null : 3,
//                     overflow: context.read<CommunitiesController>().isReadMore == false ? TextOverflow.ellipsis : TextOverflow.visible,
//                   ),
//                   SizedBox(height: 10),
//                   button(
//                       onPressed: () {
//                         readMore(() {
//                           context.read<CommunitiesController>().isReadMore = !context.read<CommunitiesController>().isReadMore;
//                         });
//                       },
//                       height: 40,
//                       title:context.read<CommunitiesController>().isReadMore == false ? "Read more" : "Read less",
//                       textStyle: body4Style,
//                       primaryColor: kBaseGrey,
//                       borderColor: const Color.fromRGBO(255, 255, 255, 0.0)),
//                   SizedBox(
//                     height: 10,
//                   ),
//                   Consumer<GroupController>(builder: (context, joinCommunity, _) {
//                     bool isLoading = false;
//                     return StatefulBuilder(
//                       builder: (BuildContext context, update) {
//                         return isLoading == true
//                             ? Center(child: CircularProgressIndicator.adaptive())
//                             : SizedBox(
//                                 width: double.infinity,
//                                 height: 50,
//                                 child: ElevatedButton.icon(
//                                   style: ElevatedButton.styleFrom(backgroundColor: kprimaryColor),
//                                   onPressed: () async {
//                                     try {
//                                       isLoading = true;
//                                       update(() {});
//                                       QuerySnapshot<Object?>? data = await joinCommunity.checkJoinOrNot(communityId);
//
//                                       // log('This is size of data : ${data!.docs.length}');
//                                       if (data?.docs.length == 0) {
//                                         await joinCommunity.checkWhetherTheCommunityisPrivateorPublic(communityId);
//
//                                         if (joinCommunity.communityType == "Public") {
//                                           AppConfigurationController.to.joinPublicCommunity(communityModel);
//
//                                           await joinCommunity.joinThePublicGroup(communityId);
//                                           await joinCommunity.addCommunityToUserList(communityName, communityId);
//
//                                           snackBar(context, "Joined community successfully", kprimaryColor);
//                                         } else {
//                                           AppConfigurationController.to.joinACommunity(communityModel);
//                                           await joinCommunity.joinTheGroup(communityId);
//                                           snackBar(context, "Request sent successfully", kprimaryColor);
//                                         }
//
//                                         // log('User successfully joined the group');
//                                       } else {
//                                         // log('User joined already');
//                                       }
//                                     } catch (e) {
//                                       snackBar(context, "unable to join the community", kRedColor);
//                                     } finally {
//                                       isLoading = false;
//                                       update(() {});
//                                       Navigator.pop(context);
//                                     }
//                                   },
//                                   label: FutureProvider<QuerySnapshot?>(
//                                     initialData: null,
//                                     create: (context) => joinCommunity.checkPending(communityId),
//                                     child: Consumer<QuerySnapshot?>(builder: (context, value, _) {
//                                       return value == null
//                                           ? SizedBox()
//                                           : Text(
//                                               value.docs.length == 0 ? "Join community" : "Waitng for approval",
//                                               style: body4StyleWhite,
//                                             );
//                                     }),
//                                   ),
//                                   icon: SvgPicture.asset(
//                                     Assets.assets.icons.communities,
//                                     color: kWhiteColor,
//                                   ),
//                                 ),
//                               );
//                       },
//                     );
//                   }),
//                 ],
//               ),
//             );
//           }
//         ),
//       ),
//     );
//   }
// }
