// import 'dart:developer';

// import 'package:cached_network_image/cached_network_image.dart';
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:firebase_auth/firebase_auth.dart';
// import 'package:flutter/material.dart';
// import 'package:gaya/widgets/home_view_widgets/home.post.widget.dart';
// import 'package:provider/provider.dart';
// import 'package:gaya/routing/routes.dart'as route;
// import '../../components/skeleton.post.component.dart';
// import '../../controller/homepage.controller.dart';
// import '../../controller/topics.controller.dart';
// import '../../model/community.model.dart';
// import '../../model/create.post.model.dart';
// import '../../model/post.model.dart';
// import '../../model/user.model.dart';
// import '../../utils/animation.dart';
// import '../../utils/const.dart';

// class InterestListEmpty extends StatelessWidget {
//   const InterestListEmpty({Key? key}) : super(key: key);

//   @override
//   Widget build(BuildContext context) {
//     final controller = Provider.of<TopicsController>(context, listen: false);
//     final homepageController =
//         Provider.of<HomePageController>(context, listen: false);

//     User? user = FirebaseAuth.instance.currentUser;
//     controller.getSelectedTitles.clear();
//     for (var i in controller.topics) {
//       controller.getSelectedTitles.add(i.title);
//     }
//     controller.getSelectedTitles.shuffle();
//     homepageController.randomItems =
//         controller.getSelectedTitles.take(3).toList();
//     log(homepageController.randomItems.toString());

//     return SingleChildScrollView(
//       child: Column(
//         children: [
//           FutureBuilder<QuerySnapshot?>(
//               initialData: null,
//               future: homepageController.getRandomCommunities,
//               builder: (context, snapshot) {
//                 if (snapshot.connectionState == ConnectionState.waiting) {
//                   return SingleChildScrollView(
//                     child: Column(
//                         crossAxisAlignment: CrossAxisAlignment.start,
//                         children: List.generate(3, (index) => PostsSkeleton())),
//                   );
//                 } else if (snapshot.connectionState == ConnectionState.done) {
//                   if (snapshot.hasData) {
//                     QuerySnapshot randomCommunitiesSnapShot =
//                         snapshot.data as QuerySnapshot;
//                     homepageController.randomCommunities.clear();
//                     for (var i in randomCommunitiesSnapShot.docs) {
//                       CreateCommunityModel communityModel =
//                           CreateCommunityModel.fromMap(
//                               i.data() as Map<String, dynamic>);
//                       homepageController.randomCommunities
//                           .add(communityModel.communityId!);
//                     }
//                     log(homepageController.randomCommunities.toString());

                  
//                   }

//                   FutureBuilder(
//                     future:
//                         homepageController.getCommunitiesIdWhereTheUserLogin(
//                             homepageController.randomCommunities),
//                     builder: (context, allPostSnapShot) {
//                       if (allPostSnapShot.connectionState ==
//                           ConnectionState.waiting) {
//                         return SingleChildScrollView(
//                           child: Column(
//                               crossAxisAlignment: CrossAxisAlignment.start,
//                               children:
//                                   List.generate(3, (index) => PostsSkeleton())),
//                         );
//                       } else if (allPostSnapShot.connectionState ==
//                           ConnectionState.done) {
//                         if (allPostSnapShot.hasData) {
//                           QuerySnapshot allPosts =
//                               allPostSnapShot.data as QuerySnapshot;

//                           return ListView.builder(
//                               itemCount: allPosts.docs.length,
//                               itemBuilder: (context, index) {
//                                 CreatePostModel postModel =
//                                     CreatePostModel.fromMap(allPosts.docs[index]
//                                         .data() as Map<String, dynamic>);
//                                 return FutureBuilder(
//                                     future:
//                                         homepageController.getPostUserDetails(
//                                             postModel.memberId!),
//                                     builder: (context, userSnapshot) {
//                                       if (userSnapshot.connectionState ==
//                                           ConnectionState.waiting) {
//                                       } else if (userSnapshot.connectionState ==
//                                           ConnectionState.done) {
//                                         if (userSnapshot.hasData) {
//                                           DocumentSnapshot userDetails =
//                                               userSnapshot.data
//                                                   as DocumentSnapshot;
//                                           UserModel userModel =
//                                               UserModel.fromMap(
//                                                   userDetails.data()
//                                                       as Map<String, dynamic>);
//                                           return FutureBuilder(
//                                               future: homepageController
//                                                   .getDetailsOfCommunityForAPost(
//                                                       postModel.communityId!),
//                                               builder:
//                                                   (context, communitySnapshot) {
//                                                 if (communitySnapshot
//                                                         .connectionState ==
//                                                     ConnectionState.waiting) {
//                                                 } else if (communitySnapshot
//                                                         .connectionState ==
//                                                     ConnectionState.done) {
//                                                   if (communitySnapshot
//                                                       .hasData) {
//                                                     DocumentSnapshot
//                                                         communityDetails =
//                                                         communitySnapshot.data
//                                                             as DocumentSnapshot;
//                                                     CreateCommunityModel
//                                                         communityModel =
//                                                         CreateCommunityModel
//                                                             .fromMap(
//                                                                 communityDetails
//                                                                         .data()
//                                                                     as Map<
//                                                                         String,
//                                                                         dynamic>);
//                                                     return FutureBuilder(
//                                                         future: homepageController
//                                                             .getCommentCount(
//                                                                 postModel
//                                                                     .postid!),
//                                                         builder: (context,
//                                                             likeCountsnapshot) {
//                                                           if (likeCountsnapshot
//                                                                   .connectionState ==
//                                                               ConnectionState
//                                                                   .waiting) {
//                                                           } else if (likeCountsnapshot
//                                                                   .connectionState ==
//                                                               ConnectionState
//                                                                   .done) {
//                                                             if (likeCountsnapshot
//                                                                 .hasData) {
//                                                               QuerySnapshot
//                                                                   commentCount =
//                                                                   likeCountsnapshot
//                                                                           .data
//                                                                       as QuerySnapshot;

//                                                               return FutureProvider<
//                                                                   QuerySnapshot?>(
//                                                                 initialData:
//                                                                     null,
//                                                                 create: (context) =>
//                                                                     homepageController
//                                                                         .getFlowersCount(
//                                                                             postModel.postid!),
//                                                                 child: FutureProvider<
//                                                                         QuerySnapshot?>(
//                                                                     initialData:
//                                                                         null,
//                                                                     create: (_) =>
//                                                                         homepageController.getLikesCount(postModel
//                                                                             .postid!),
//                                                                     catchError:
//                                                                         (context,
//                                                                             error) {
//                                                                       return null;
//                                                                     },
//                                                                     lazy: true,
//                                                                     child: Consumer<
//                                                                             QuerySnapshot?>(
//                                                                         builder: (context,
//                                                                             value,
//                                                                             _) {
//                                                                       return value ==
//                                                                               null
//                                                                           ? SizedBox()
//                                                                           : HomePostWidget(
//                                                                               totalFlowerCounts: value.docs.length.toString(),
//                                                                               totalLikesCount: value.docs.length.toString(),
//                                                                               totalCommentsCount: commentCount.docs.length.toString(),
//                                                                               //changing like button icon color
//                                                                               likeIconColor: user == null
//                                                                                   ? kSecondaryColor
//                                                                                   : postList[index].isLiked == false
//                                                                                       ? kSecondaryColor
//                                                                                       : kRedColor,

//                                                                               //changing flower icon color
//                                                                               flowerIconColor: user == null
//                                                                                   ? kSecondaryColor
//                                                                                   : postList[index].isFlower == false
//                                                                                       ? kSecondaryColor
//                                                                                       : kYellowColor,

//                                                                               //changing the save post icon color
//                                                                               savePostColor: user == null
//                                                                                   ? kSecondaryColor
//                                                                                   : postList[index].isSaved == false
//                                                                                       ? kprimaryColor
//                                                                                       : kSecondaryColor,

//                                                                               //void call back function for save on tap
//                                                                               onTapSaved: () {
//                                                                                 user == null ? Navigator.of(context).pushNamed(route.login) : homepageController.savePost(index);
//                                                                               },

//                                                                               //images
//                                                                               overlapImage: CircleAvatar(
//                                                                                 backgroundColor: kWhiteColor,
//                                                                                 radius: 17,
//                                                                                 child: CircleAvatar(
//                                                                                   backgroundImage: CachedNetworkImageProvider(
//                                                                                     userModel.profilePicture.toString(),
//                                                                                   ),
//                                                                                   radius: distance_15,
//                                                                                   backgroundColor: kRedColor,
//                                                                                 ),
//                                                                               ),

//                                                                               // void call back on comment tap
//                                                                               // commentOntap: () {
//                                                                               //  Navigator.of(context)
//                                                                               //   .pushNamed(
//                                                                               //       route
//                                                                               //           .postWithComments,
//                                                                               //       arguments: {
//                                                                               //     'isLiked': likeSnapShot
//                                                                               //             .docs.isEmpty
//                                                                               //         ? kSecondaryColor
//                                                                               //         : kRedColor,
//                                                                               //     'isFlower':
//                                                                               //         flowerSnapshot.docs
//                                                                               //                 .isEmpty
//                                                                               //             ? kSecondaryColor
//                                                                               //             : kYellowColor,
//                                                                               //     'description':
//                                                                               //         postModel
//                                                                               //             .postDescription
//                                                                               //             .toString(),
//                                                                               //     'postImage':
//                                                                               //         postModel
//                                                                               //             .postPicture,
//                                                                               //     'totalComments':
//                                                                               //         commentCount
//                                                                               //             .docs.length
//                                                                               //             .toString(),
//                                                                               //     'totalLikes': totalLikes
//                                                                               //         .docs.length
//                                                                               //         .toString(),
//                                                                               //     'totalFlowers':
//                                                                               //         totalFlowers
//                                                                               //             .docs.length
//                                                                               //             .toString(),
//                                                                               //     'personName':
//                                                                               //         userModel.name
//                                                                               //             .toString(),
//                                                                               //     'memeberImage':
//                                                                               //         userModel
//                                                                               //             .profilePicture
//                                                                               //             .toString(),
//                                                                               //     'groupName': communityModel
//                                                                               //         .communityName,
//                                                                               //     'groupImage':
//                                                                               //         communityModel.CommunityPic,
//                                                                               //     'isSaved': savePost
//                                                                               //             .docs.isEmpty
//                                                                               //         ? kSecondaryColor
//                                                                               //         : kprimaryColor,
//                                                                               //     'postId':
//                                                                               //         postModel.postid,
//                                                                               //   });                                              },

//                                                                               //void call back on flower on tap
//                                                                               flowerOnTap: () {
//                                                                                 // _firebaseAuth
//                                                                                 //             .currentUser ==
//                                                                                 //         null
//                                                                                 //     ? Navigator.of(context).push(
//                                                                                 //         MaterialPageRoute(
//                                                                                 //             builder: (context) =>
//                                                                                 //                 RequireSignRegisterView(
//                                                                                 //                   isflower: false,
//                                                                                 //                 )))
//                                                                                 //     : homeController
//                                                                                 //         .isFlowering(
//                                                                                 //             index);
//                                                                               },

//                                                                               //void call back on like button
//                                                                               likeOnTap: () {
//                                                                                 // _firebaseAuth
//                                                                                 //             .currentUser ==
//                                                                                 //         null
//                                                                                 //     ? Navigator.of(context).push(
//                                                                                 //         MaterialPageRoute(
//                                                                                 //             builder: (context) =>
//                                                                                 //                 RequireSignRegisterView(
//                                                                                 //                   isButtonLiked: false,
//                                                                                 //                 )))
//                                                                                 //     : homeController
//                                                                                 //         .isLiking(
//                                                                                 //             index);
//                                                                               },

//                                                                               onTap: () {
//                                                                                 Navigator.of(context).pushNamed(route.recipedetails, arguments: {
//                                                                                   'directions': postModel.postDirections,
//                                                                                   'ingredients': postModel.ingredients,
//                                                                                   'preparationTime': postModel.preparationTime,
//                                                                                   'recipeName': postModel.recipeName,
//                                                                                   'totalTime': postModel.totaltime,
//                                                                                   'postImage': postModel.postPicture
//                                                                                 });
//                                                                               },
//                                                                               groupImage: communityModel.CommunityPic.toString(),
//                                                                               groupName: communityModel.communityName.toString(),
//                                                                               postDetailsText: postModel.postDescription.toString(),
//                                                                               postImage: postModel.postPicture.toString(),
//                                                                               dateTime: userModel.name.toString(), isPostHasImage: true,
//                                                                             );
//                                                                     })),
//                                                               );
//                                                             }
//                                                           }

//                                                           return SizedBox();
//                                                         });
//                                                   }
//                                                 }
//                                                 return SizedBox();
//                                               });
//                                         }
//                                       }
//                                       return SizedBox();
//                                     });
//                               });
//                         }
//                       }
//                       return AnimationLottie();
//                     },
//                   );
//                 }
//                 return AnimationLottie();
//               })
//         ],
//       ),
//     );
//   }
// }
