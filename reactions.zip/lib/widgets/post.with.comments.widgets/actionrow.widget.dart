import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gaya/utils/language/translation.dart';
import 'package:get/get.dart';

import '../../utils/theme/app_colors.dart';
import '../../utils/theme/app_typography.dart';
import '../../utils/theme/button_styles.dart';

class ActionRow extends StatelessWidget {
  final VoidCallback likeOnTap, flowerOnTap;
  final VoidCallback? replyOnTap;
  final Widget likeWidget, flowerWidget;
  final double? childPadding;

  const ActionRow({
    Key? key,
    required this.likeOnTap,
    required this.flowerOnTap,
    this.replyOnTap,
    required this.likeWidget,
    required this.flowerWidget,
    this.childPadding,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final btnStyle = GayaButtonStyles.actionRowTextButtonStyle;
    return Row(children: [
      SizedBox(width: childPadding ?? 8.w),
      TextButton(style: btnStyle, onPressed: likeOnTap, child: likeWidget),
      SizedBox(width: childPadding ?? 6.w),
      SizedBox(width: childPadding ?? 6.w),
      TextButton(style: btnStyle, onPressed: flowerOnTap, child: flowerWidget),
      SizedBox(width: childPadding ?? 6.w),
      SizedBox(width: childPadding ?? 6.w),
      if (replyOnTap != null)
        TextButton(
            style: btnStyle,
            onPressed: replyOnTap,
            child: Text(GayaStrings.reply_txt.tr, style: GayaTypography.caption.copyWith(color: AppColors.secondary))),
    ]);
  }
}
