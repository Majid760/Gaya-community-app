import 'package:cloud_firestore/cloud_firestore.dart';

class DeleteCommunityServices {
  Future<void> deleteCommunity({String communityId = "44ee8fa0-af21-11ed-b8b7-619c0650c169"}) async {
    final ref = FirebaseFirestore.instance.collection('communities').doc(communityId);
    await _deleteFromMembers(ref, communityId);
    //[lastly called this.]
    ref.delete();
  }

  Future<void> _deleteFromMembers(DocumentReference<Map<String, dynamic>> ref, String communityId) async {
    final totalMembers = (await ref.collection("communityMembers").get()).docs;

    for (var doc in totalMembers) {
      final map = doc.data();
      final userId = map["userUid"];
      final ref = await FirebaseFirestore.instance
          .collection('users')
          .doc(userId)
          .collection('communities')
          .where("communityId", isEqualTo: communityId)
          .get();
      for (var element in ref.docs) {
        try {
          await element.reference.delete();
        } catch (e) {
          print("******* couldn't delete for this user $e      \n ${element.data()}");
        }
      }
    }
  }
}
