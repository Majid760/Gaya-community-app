// class UserScripts {
//   Future<void> getAllUser() async {
//     final users = await FirebaseFirestore.instance.collection('users').where('uid', isNotEqualTo: FirebaseAuth.instance.currentUser?.uid).get();
//
//     if (users.docs.isNotEmpty) {
//       debugPrint("All users that have null: ${users.docs.length}");
//       // final batch = FirebaseFirestore.instance.batch();
//       for (var element in users.docs) {
//         // debugPrint("element: ${element.data()['userTotalCrowns']}");
//         // batch.update(element.reference, {'userTotalCrowns': 11});
//       }
//        // await batch.commit();
//     } else {
//       debugPrint("no users");
//     }
//   }
// }
