// ignore_for_file: use_build_context_synchronously

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:gaya/model/user.model.dart';
import 'package:gaya/services/notification/notification_api/notification_api.dart';
import 'package:gaya/services/services.dart';
import 'package:gaya/utils/language/translation.dart';
import 'package:gaya/utils/logger.dart';
import 'package:get/get.dart';

import '../components/report_dialogue.dart';
import '../components/snackbar.component.dart';
import '../model/user_report.model.dart';
import '../utils/collections.dart';
import '../utils/const.dart';

abstract class ReportServicesImpl {
  Future<void> reportAUser(String reportedPersonUid, {bool isMessageReport = false, String reportMsg});

  Future<void> reportPost(String reportedPostId, String? adminUi, {required String reportMsg, required String communityId});

  Future<void> reportAComment(
      {required String reportedCommentId,
      required BuildContext context,
      required String postId,
      required String content,
      required String reportMsg});

  Future<void> reportACommentReply(
      {required String content,
      required String commentId,
      required String postId,
      required String commentReplyId,
      required String reportMsg,
      required BuildContext context});
}

class ReportServices implements ReportServicesImpl {
  final _commonServices = Services();
  final _notificationApiHitting = NotificationApiHitting();
  //Report A User
  @override
  Future<void> reportAUser(String reportedPersonUid, {bool isMessageReport = false, String reportMsg = ''}) async {
    if (FirebaseAuth.instance.currentUser == null) return;
    try {
      UserReport reportModel = UserReport(
          reportedByUid: FirebaseAuth.instance.currentUser!.uid,
          reportMessage: reportMsg,
          reportedUserUid: reportedPersonUid,
          isMessageReport: isMessageReport);
      await FirebaseFirestore.instance.collection(userReport).doc(reportedPersonUid).set(reportModel.toMap(), SetOptions(merge: true));
    } catch (e) {
      rethrow;
    }
  }

  //Report A Post
  @override
  Future<void> reportPost(String reportedPostId, String? adminUi, {required String reportMsg, required String communityId}) async {
    MyLoggerServices.to.print("reportPost");
    if (FirebaseAuth.instance.currentUser == null) return;
    try {
      PostReport reportModel =
          PostReport(reportedByUid: FirebaseAuth.instance.currentUser!.uid, reportedPostId: reportedPostId, reportedMsg: reportMsg);
      await FirebaseFirestore.instance.collection(postReport).doc().set(reportModel.toMap());
      if (adminUi != null) {
        UserModel? adminData = await _commonServices.getUserById(adminUi, forcefullyServer: true);
        final fcmPostModel = FcmCreatePostModel(
            communityId: communityId,
            postid: reportedPostId,
            messageContent: GayaStrings.post_reported_consider_delete.tr,
            messageTitle: GayaStrings.post_reported.tr,
            receiverFcm: adminData?.fm_token ?? '');
        _notificationApiHitting.callOnFcmApiForPostRelatedNotifications(fcmPostModel
            // gaya_message: "${usermodel.name} sent you a new message.", fcmToken: otherChatParticipantFcmToken
            );
        //add into user's table.
        await _commonServices.addNotification(
          isRead: false,
          posId: reportedPostId,
          body: GayaStrings.post_reported_consider_delete.tr,
          receiverUserID: adminData?.uId ?? '',
          senderId: UserModel.to.uId ?? '',
          title: UserModel.to.name ?? "Gaya User",
          time: DateTime.now().toString(),
          type: "postReported",
          userImage: UserModel.to.profilePicture ?? "",
        );
      }
    } catch (e) {
      MyLoggerServices.to.print(e.toString());
      rethrow;
    }
  }

  //Report A Comment
  @override
  Future<void> reportAComment(
      {required String reportedCommentId,
      required BuildContext context,
      required String postId,
      required String content,
      required String reportMsg}) async {
    if (FirebaseAuth.instance.currentUser == null) return;

    try {
      final String userId = FirebaseAuth.instance.currentUser!.uid;
      CommentReport reportModel = CommentReport(
          content: content, reportMsg: reportMsg, reportedByUid: userId, reportedCommentId: reportedCommentId, reportedPostId: postId);
      final participants = [reportedCommentId, userId]..sort();
      await FirebaseFirestore.instance
          .collection(commentReports)
          .doc(participants.join())
          .set(reportModel.toMap(), SetOptions(merge: true));
      await showDialog(
          context: context,
          builder: (context) {
            return const ReportDialogue();
          });
    } catch (e) {
      snackBar(context, GayaStrings.unable_report_post.tr, kRedColor);
    }
  }

  //Report A Comment Reply
  @override
  Future<void> reportACommentReply(
      {required String content,
      required String commentId,
      required String postId,
      required String commentReplyId,
      required String reportMsg,
      required BuildContext context}) async {
    if (FirebaseAuth.instance.currentUser == null) return;
    try {
      final String userId = FirebaseAuth.instance.currentUser!.uid;

      CommentReplyReport reportModel = CommentReplyReport(
          content: content,
          reportedByUid: userId,
          reportedCommentId: commentId,
          reportedReplyId: commentReplyId,
          reportMsg: reportMsg,
          reportedPostId: postId);
      final participants = [commentReplyId, userId]..sort();
      await FirebaseFirestore.instance
          .collection(commentReports)
          .doc(participants.join())
          .set(reportModel.toMap(), SetOptions(merge: true));
      // ignore: use_build_context_synchronously
      await showDialog(
          context: context,
          builder: (context) {
            return const ReportDialogue();
          });
    } catch (e) {
      snackBar(context, GayaStrings.unable_report_post.tr, kRedColor);
    }
  }
}
