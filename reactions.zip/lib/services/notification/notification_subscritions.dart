import 'package:firebase_messaging/firebase_messaging.dart';

mixin NotificationSubscriptionImpl {
  Future<void> subscribeToCommunitiesNotifications(List<String> subscribedCommunities) async {
    for (var communityId in subscribedCommunities) {
      FirebaseMessaging.instance.subscribeToTopic(communityId);
    }
  }

  Future<void> unsubscribeFromCommunitiesNotifications(List<String> subscribedCommunities) async {
    for (var communityId in subscribedCommunities) {
      FirebaseMessaging.instance.unsubscribeFromTopic(communityId);
    }
  }
}
