import 'dart:convert';

import 'package:awesome_notifications/awesome_notifications.dart';

import 'fcm_helper.dart';

class NotificationApiController {
  /// Use this method to detect when the user taps on a notification or action button
  @pragma("vm:entry-point")
  static Future<void> onActionReceivedMethod(ReceivedAction receivedAction) async {
    print("payload recieved=> ${receivedAction.payload}");
    // Your code goes here
    print("init catched for onActionReceivedMethod.");

    if (receivedAction.payload != null) {
      navigate(receivedAction.payload?["messageType"], receivedAction.payload);
    } else {
      try {
        String messageType = jsonDecode(receivedAction.payload?["messageType"].toString() ?? "");
        final Map<String, String?>? payload = jsonDecode(receivedAction.payload.toString());
        navigate(messageType, payload);
      } catch (_) {}
    }
  }

  static void navigate(String? messageType, Map<String, String?>? payload) {
    if (messageType == 'chatMessage') {
      NotificationNavigationService.navigateToChatroom(payload);
    } else if (messageType == 'post') {
      NotificationNavigationService.navigateToPost(payload);
    } else if (messageType == 'community') {
      NotificationNavigationService.navigateToCommunity(payload);
    } else if (messageType == 'profile') {
      NotificationNavigationService.navigateToProfile(payload);
    }
  }
}
