import 'package:awesome_notifications/awesome_notifications.dart';

import 'notification_routes.dart';

class GayaAwesomeNotification {
  // Private named constructor
  GayaAwesomeNotification._() {
    awesomeNotifications = AwesomeNotifications();
  }

  /// Static FriendshipStatusService instance variable for singleton
  static GayaAwesomeNotification? _awesomeNotification;

  late final AwesomeNotifications awesomeNotifications;

  /// Static getter to get a singleton instance of FriendshipStatusService
  static GayaAwesomeNotification get instance => _awesomeNotification ??= GayaAwesomeNotification._();

  void init() {
    awesomeNotifications.setListeners(onActionReceivedMethod: NotificationApiController.onActionReceivedMethod);
  }
}
