// // ignore_for_file: use_build_context_synchronously

// import 'dart:developer';
// import 'dart:io';

// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:easy_refresh/easy_refresh.dart';
// import 'package:firebase_auth/firebase_auth.dart';
// import 'package:flutter/foundation.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter/services.dart';
// import 'package:gaya/components/snackbar.component.dart';
// import 'package:gaya/controller/app_config_controller.dart';
// import 'package:gaya/model/community.model.dart';
// import 'package:gaya/model/user.model.dart';
// import 'package:gaya/routing/getx_route_methods.dart';
// import 'package:gaya/services/services.dart';
// import 'package:gaya/shared/service/media_service/file_picking_service.dart';
// import 'package:gaya/utils/const.dart';
// import 'package:gaya/utils/helpers.functions.dart';
// import 'package:gaya/utils/logger.dart';
// import 'package:gaya/view/community/controllers/community_feed_controller.dart';
// import 'package:gaya/view/community/controllers/community_profile_controller.dart';
// import 'package:get/get.dart';
// import 'package:get/get_rx/src/rx_workers/utils/debouncer.dart';
// import 'package:image_picker/image_picker.dart';
// import 'package:provider/provider.dart';

// import '../view/community/create_community/models/community_theme_model.dart';
// import '../view/community/services/community_members_services.dart';
// import 'package:gaya/services/media_cropping/service/image_cropping_service.dart';

// enum PhotoType { profile, cover }

// class CommunityEditingController extends ChangeNotifier {
//   final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;
//   CreateCommunityModel? createCommunityModel;
//   List<String> topics = [];
//   Services services = Services();
//   ImageServices imageService = ImageServices();
//   List<UserModel> communityUsers = [];
//   List<UserModel> dummyCommunityModerators = [];
//   List<UserModel> communityModerators = [];
//   TextEditingController searchFieldController = TextEditingController();
//   final MediaService _mediaService = MediaService();
//   XFile? coverPhoto;
//   XFile? profilePhoto;
//   bool isLoading = false;
//   bool isUploadingModerator = false;
//   bool isImageLoading = false;
//   bool isSavedPressed = false;

//   /// togle the isSavedPressed value
//   void setIsSavedPressed(bool value) {
//     isSavedPressed = value;
//   }


//   // Community members for paginated form community members
//   bool isFirstTime = false;
//   List<UserModel> _paginatedCommunityMembers = [];
//   CommunityMembersServices? _communityMembersServices;
//   EasyRefreshController refreshController = EasyRefreshController();

//   bool get isMembersEmpty => _paginatedCommunityMembers.isEmpty;
//   List<UserModel> searchedUsers = [];
//   final Debouncer _debouncer = Debouncer(delay: 1000.milliseconds);

//   List<UserModel> getMembers() => _paginatedCommunityMembers;

//   bool isModeratorExists(UserModel user) => dummyCommunityModerators.isEmpty || !dummyCommunityModerators.contains(user);

//   bool isPosterModerator(UserModel user) =>
//       dummyCommunityModerators.isNotEmpty && dummyCommunityModerators.contains(user) ||
//       createCommunityModel?.moderators?.contains(user.uId ?? "") == true;

//   Future<void> requestMoreData({bool fromInit = false}) async {
//     if (createCommunityModel?.communityId == null) return;
//     // _communityMembersServices = CommunityMembersServices(communityId: createCommunityModel?.communityId ?? '');
//     // to avoid double loading at top andbottom on screen
//     if (fromInit == false) refreshController.callLoad();

//     MyLoggerServices.to.print(" requestMoreData called");
//     if (fromInit) {
//       isLoading = true;
//       // notifyListeners();
//     }
//     isFirstTime = true;
//     final newPosts = await _communityMembersServices!.requestMoreData();
//     MyLoggerServices.to.print("newMembers.length ${newPosts.length}");
//     _paginatedCommunityMembers.addAll(newPosts);
//     isLoading = false;
//     notifyListeners();
//   }

//   initializeCommunityMembersServices() {
//     _communityMembersServices = CommunityMembersServices(communityId: createCommunityModel?.communityId ?? '');
//   }

//   // A dispose method.
//   void resetController({bool isDisposing = false}) async {
//     _paginatedCommunityMembers = [];
//     isFirstTime = false;
//     isLoading = false;
//     searchFieldController.clear();
//     if (_communityMembersServices != null) {
//       _communityMembersServices?.reset();
//     }
//     if (isDisposing) {
//       WidgetsBinding.instance.addPostFrameCallback((_) {
//         notifyListeners();
//       });
//     } else {
//       await requestMoreData(
//         fromInit: true,
//       );
//     }
//     _debouncer.cancel();
//   }

//   void setCreateCommunityModel(CreateCommunityModel communityModel, {bool isFirstTime = false}) async {
//     try {
//       createCommunityModel = communityModel;
//       topics = [];
//       topics.addAll(createCommunityModel?.communityTopicList?.map((e) => e).toList() ?? []);
//       notifyListeners();
//       if (isFirstTime) {
//         await getCommunityMembersProfile();
//       }
//     } catch (_) {}
//   }

//   void fetchCommunityProfile(CreateCommunityModel communityModel, {bool isFirstTime = false}) async {
//     try {
//       final communityDetail = await services.getCommunitiesDetails(communityModel.communityId ?? '');
//       if (communityDetail?.data() != null) {
//         CreateCommunityModel commModel = CreateCommunityModel.fromMap(communityDetail?.data() as Map<String, dynamic>);
//         topics = [];
//         setCreateCommunityModel(commModel, isFirstTime: isFirstTime);
//       } else {}
//     } catch (_) {}
//   }

//   // pick the photo from gallery
//   Future<void> pickImageFromGallery({required BuildContext context, int imageQuality = 50, required PhotoType photoType}) async {
//     try {
//       isImageLoading = true;
//       notifyListeners();
//       List<XFile>? files = await _mediaService.pickImageFromGallery(context: context, imageQuality: imageQuality);
//       if (files != null && files.isNotEmpty) {
//         if (photoType == PhotoType.cover) {
//           coverPhoto = files.last;
//           if (coverPhoto != null) {
//             List<File> files = await Routes.cropPhotoView(imageFile: <File>[File(coverPhoto!.path)]);
//             if (files.isNotEmpty) {
//               coverPhoto = XFile(files.first.path);
//             }
//           }
//         } else if (photoType == PhotoType.profile) {
//           profilePhoto = files.last;
//           if (profilePhoto != null) {
//             List<File> files = await Routes.cropPhotoView(imageFile: <File>[File(profilePhoto!.path)]);
//             if (files.isNotEmpty) {
//               profilePhoto = XFile(files.first.path);
//             }
//           }
//         } else {}
//       }
//       MyLoggerServices.to.print(coverPhoto!.path);
//       isImageLoading = false;
//       notifyListeners();
//     } on PlatformException catch (e) {
//       log(e.toString());
//       isImageLoading = false;
//       notifyListeners();
//     } catch (e) {
//       log(e.toString());
//       isImageLoading = false;
//       notifyListeners();
//     }
//   }

//   // to check that user has changed the desc,profile, or cover phot
//   bool isUserDataChanged({required String description, required String name, required String selectedThemeColor}) {
//     try {
//       return (profilePhoto != null ||
//           coverPhoto != null ||
//           description != createCommunityModel?.communityDescription ||
//           name != createCommunityModel?.communityName || selectedThemeColor != createCommunityModel?.communityThemeModel?.color);
//     } catch (e) {
//       log('error during  changes!${e.toString()}');
//       return false;
//     }
//   }

//   // discard the changes
//   void discardChanges() {
//     try {
//       profilePhoto = null;
//       coverPhoto = null;
//       notifyListeners();
//     } catch (e) {
//       log('error during discard changes!${e.toString()}');
//     }
//   }

//   // update the communities

//   Future<void> updateCommunity(BuildContext context, {required String description, required String name, required String selectedThemeColor}) async {
//     try {
//       isSavedPressed = false;
//       isLoading = true;
//       notifyListeners();
//       final helperController = Provider.of<HelpersFunctions>(context, listen: false);
//       User? user = _firebaseAuth.currentUser;
//       if (user == null) return;
//       String? communityPhoto;
//       String? communityCoverPhoto;
//       if (profilePhoto != null) {
//         await helperController.uploadImage(
//             context, helperController.imageUploadPercentage, File(profilePhoto!.path), helperController.communityImageFolderName);
//         communityPhoto = helperController.communityPictureDownloadUrl;
//       }
//       if (coverPhoto != null) {
//         await helperController.uploadCoverImage(
//             context, helperController.imageUploadPercentageCover, File(coverPhoto!.path), helperController.communityImageFolderNameCover);
//         communityCoverPhoto = helperController.communityPictureDownloadUrlCover;
//       }
//       if (createCommunityModel != null) {
//         createCommunityModel!.CommunityPic = communityPhoto ?? createCommunityModel!.CommunityPic ?? '';
//         createCommunityModel!.coverPicture = communityCoverPhoto ?? createCommunityModel!.coverPicture ?? '';
//         createCommunityModel!.communityThemeModel = CommunityThemeModel(color: selectedThemeColor, isThemeSelected: true);
//         createCommunityModel!.communityDescription = description;
//         createCommunityModel!.communityName =  name;
//         await FirebaseFirestore.instance
//             .collection('communities')
//             .doc(createCommunityModel!.communityId)
//             .set(createCommunityModel!.toMap(), SetOptions(merge: true));
//         coverPhoto = null;
//         profilePhoto = null;
//       }
//       isLoading = false;
//       isSavedPressed = true;
//       notifyListeners();
//       updateGroupViewCommunity(community: createCommunityModel);
//       snackBar(context, 'Community Updated Successfully!', kprimaryColor);
//     } catch (e) {
//       MyLoggerServices.to.print('something went woring during updating community error => ${e.toString()}');
//     }
//   }

//   /// updates group.view object.
//   void updateGroupViewCommunity({required CreateCommunityModel? community}){
//     CommunityProfileController.to.updateGroupViewCommunity(community: community);

//   }

//   addNewCommunityTopic(context, {String topic = ''}) {
//     if (createCommunityModel == null || createCommunityModel?.communityTopicList == null) return;
//     if (topics.contains(topic) == false && topic.trim().isNotEmpty) {
//       topics.add(topic);
//     }
//     notifyListeners();
//   }

//   deleteCommunityTopic(int index) {
//     if (createCommunityModel == null || createCommunityModel?.communityTopicList == null) return;
//     topics.removeAt(index);
//     notifyListeners();
//   }

//   // update the community topics
//   Future<void> updateCommunityTopics(BuildContext context) async {
//     try {
//       if (listEquals(createCommunityModel?.communityTopicList, topics)) return;
//       createCommunityModel?.communityTopicList = [];
//       createCommunityModel?.communityTopicList?.addAll(topics);
//       isLoading = true;
//       notifyListeners();
//       User? user = _firebaseAuth.currentUser;
//       if (user == null) return;
//       if (createCommunityModel != null) {
//         await FirebaseFirestore.instance.collection('communities').doc(createCommunityModel!.communityId).update({
//           'communityTopicList': createCommunityModel?.communityTopicList ?? [],
//         });
//       }
//       isLoading = false;
//       notifyListeners();
//       snackBar(context, 'Community Topics Updated Successfully!', kprimaryColor);
//     } catch (e) {
//       isLoading = false;
//       notifyListeners();
//       MyLoggerServices.to.print('something went woring during updating community topics error => ${e.toString()}');
//     }
//   }

//   // reset tcommunity topics
//   Future<void> resetCommunityTopics() async {
//     topics = [];
//     topics.addAll(createCommunityModel?.communityTopicList?.map((e) => e).toList() ?? []);
//     notifyListeners();
//   }

//   // check topics list equality incase of discard changes while creating new topics
//   Future<bool> areTopicListsEquals() async {
//     if (listEquals(createCommunityModel?.communityTopicList, topics)) return true;
//     return false;
//   }

//   /// converts List<String?> to  List<String>
//   List<String> convertNullableStringList({required List<String?> list}) {
//     List<String> newList = [];
//     for (var element in list) {
//       if (element != null) {
//         newList.add(element);
//       }
//     }
//     return newList;
//   }

//   resetState() {
//     createCommunityModel = null;
//     topics = [];
//     debugPrint('resetting the state of the community provider');
//   }

//   //get the count of the members in the  community
//   Future getCommunityMembersProfile() async {
//     try {
//       if (createCommunityModel?.communityId == null) return;

//       final allMembersAndModerators = await services.getCommunityModerators(createCommunityModel?.communityId ?? '');
//       List<UserModel> _allUsers = allMembersAndModerators["allMembers"] ?? [];
//       List<UserModel> _allModerators = [];
//       for (var user in _allUsers) {
//         if (createCommunityModel?.moderators?.contains(user.uId) ?? false) {
//           _allModerators.add(user);
//         }
//       }

//       if (allMembersAndModerators.isEmpty) {
//         communityUsers = [];
//         communityModerators = [];
//         dummyCommunityModerators = [];
//       } else {
//         communityUsers = [];
//         communityModerators = [];
//         dummyCommunityModerators = [];
//         communityUsers.addAll(_allUsers);
//         communityModerators.addAll(_allModerators);
//         dummyCommunityModerators.addAll(_allModerators);
//       }

//       notifyListeners();
//     } catch (_) {
//       notifyListeners();
//     }
//   }

//   //search the communities
//   searchFeed(String query) {
//     _debouncer.call(() {
//       searchedUsers = [];
//       if (communityUsers.isEmpty) return;
//       final suggestion = communityUsers.where((element) {
//         final userName = element.name?.toLowerCase();
//         return userName?.contains(query.toLowerCase()) ?? false;
//       }).toList();
//       searchedUsers = suggestion;
//       notifyListeners();
//     });
//   }

//   // get color from hex color
//   // Color? getColorFromHexaString() {
//   //   Color? color;
//   //   if (createCommunityModel?.communityThemeModel?.color != null) {
//   //     color = getColorFromHex(createCommunityModel?.communityThemeModel?.color ?? 'F5E5FF');
//   //   }
//   //   return color;
//   // }

//   // //get the count of the members in the  community
//   // Future getCommunityMembersProfile(context) async {
//   //   try {
//   //     if (createCommunityModel?.communityId == null) return;
//   //     final communityMembers = await services.getCommunityModerators(createCommunityModel?.communityId ?? '');
//   //     if (communityMembers.isEmpty) {
//   //       communityUsers = [];
//   //       communityModerators = [];
//   //       dummyCommunityModerators = [];
//   //     } else {
//   //       communityUsers = [];
//   //       communityModerators = [];
//   //       dummyCommunityModerators = [];
//   //       communityUsers.addAll(communityMembers);
//   //       for (var userModel in communityMembers) {
//   //         if (userModel.isModerator) {
//   //           communityModerators.add(userModel);
//   //           dummyCommunityModerators.add(userModel);
//   //         } else {
//   //           print('${userModel.name} is not a moderator');
//   //         }
//   //       }
//   //     }
//   //     notifyListeners();
//   //   } catch (_) {
//   //     notifyListeners();
//   //   }
//   // }

//   // add/remove moderator in the community
//   addRemoveCommumityModerator(context, UserModel userModel, bool value) {
//     if (createCommunityModel == null || communityUsers == []) return;
//     if (value == true) {
//       dummyCommunityModerators.add(userModel);
//       // createCommunityModel?.moderators?.add(userModel.uId!);
//     } else {
//       dummyCommunityModerators.remove(userModel);
//     }
//     notifyListeners();
//   }

//   // update the community moderators in db
//   Future updateCommunityModerators(BuildContext context) async {
//     if (listEquals(createCommunityModel?.moderators, dummyCommunityModerators)) return;
//     try {
//       if (createCommunityModel == null || dummyCommunityModerators.isEmpty) return;
//       isUploadingModerator = true;
//       notifyListeners();
//       // createCommunityModel?.moderators = [];
//       for (var moderator in dummyCommunityModerators) {
//         if (moderator.uId != null) {
//           await FirebaseFirestore.instance.collection('communities').doc(createCommunityModel!.communityId).set({
//             "moderators": FieldValue.arrayUnion([moderator.uId!])
//           }, SetOptions(merge: true));
//           if (createCommunityModel?.moderators != null && !createCommunityModel!.moderators!.contains(moderator.uId!)) {
//             createCommunityModel?.moderators?.add(moderator.uId!);
//           }

//           ///Add locally to controller.
//           AppConfigurationController.to.asModeratorCommunities.add(CreateCommunityModel(communityId: createCommunityModel!.communityId!));
//         }
//       }
//       isUploadingModerator = false;
//       notifyListeners();
//       // to update community feeds with moderator tag
//       final CommunityFeedController communityFeedController = Get.find();
//       communityFeedController.update();

//       // ignore: use_build_context_synchronously
//       snackBar(context, 'Community Moderators Updated Successfully!', kprimaryColor);
//     } on SocketException {
//       isUploadingModerator = false;
//       notifyListeners();
//       snackBar(context, "Please check your internet connection then try again.", Colors.red);
//     } catch (e) {
//       isUploadingModerator = false;
//       notifyListeners();
//     }
//   }

//   // delete the community moderators in db
//   Future deleteCommunityModeratorsInDb(BuildContext context, UserModel userModel) async {
//     try {
//       if (createCommunityModel == null || userModel.uId == null) return;
//       isUploadingModerator = true;
//       notifyListeners();
//       await FirebaseFirestore.instance.collection('communities').doc(createCommunityModel!.communityId).set({
//         "moderators": FieldValue.arrayRemove([userModel.uId!])
//       }, SetOptions(merge: true));

//       ///Remove locally to controller.
//       AppConfigurationController.to.asModeratorCommunities
//           .removeWhere((community) => community.communityId == createCommunityModel!.communityId);
//       if (dummyCommunityModerators.contains(userModel)) {
//         dummyCommunityModerators.remove(userModel);
//         communityModerators.remove(userModel);
//         createCommunityModel?.moderators?.remove(userModel.uId);
//       }
//       isUploadingModerator = false;
//       notifyListeners();
//       // to update community feeds with moderator tag
//       final CommunityFeedController communityFeedController = Get.find();
//       communityFeedController.update();
//       snackBar(context, 'Community Moderators Updated Successfully!', kprimaryColor);
//     } on SocketException {
//       isUploadingModerator = false;
//       notifyListeners();
//       snackBar(context, "Please check your internet connection then try again.", Colors.red);
//     } catch (e) {
//       isUploadingModerator = false;
//       notifyListeners();
//       MyLoggerServices.to.print('something went woring during updating community moderators error => ${e.toString()}');
//     }
//   }

//   handleError() {
//     isUploadingModerator = false;
//     notifyListeners();
//   }

//   // update the community moderators tag data
//   Future<void> updateModeratorsTagData(context, String tagColor, {String moderatorTag = 'Moderator'}) async {
//     if (createCommunityModel == null) return;
//     try {
//       isLoading = true;
//       notifyListeners();
//       Map<String, dynamic>? moderatorTagData = {
//         'moderatorTag': moderatorTag,
//         'tagColor': tagColor,
//       };
//       createCommunityModel?.moderatorTagData = moderatorTagData;
//       User? user = _firebaseAuth.currentUser;
//       if (user == null) return;
//       if (createCommunityModel != null) {
//         await services.updateModeratorsTagData(createCommunityModel?.communityId ?? '', moderatorTagData);
//       }
//       isLoading = false;
//       notifyListeners();
//     } catch (e) {
//       isLoading = false;
//       notifyListeners();
//       MyLoggerServices.to.print('something went woring during updating community topics error => ${e.toString()}');
//     }
//   }

//   // clearing moderators data
//   clearModeratorsData() {
//     communityUsers = [];
//     dummyCommunityModerators = [];
//     communityModerators = [];
//     isLoading = false;
//   }
// }
