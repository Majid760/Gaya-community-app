import 'dart:async';
import 'dart:math' as math;
import 'dart:math';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:gaya/components/snackbar.component.dart';
import 'package:gaya/model/friendship.model.dart';
import 'package:gaya/model/save.post.model.dart';
import 'package:gaya/model/user.model.dart';
import 'package:gaya/model/user.saved.post.model.dart';
import 'package:gaya/services/services.dart';
import 'package:gaya/shared/service/search_service/search_service.dart';
import 'package:gaya/shared/view/widget/gaya_snackbar.dart';
import 'package:gaya/utils/const.dart';
import 'package:gaya/utils/enum.dart';
import 'package:gaya/utils/helper/helper.functions.dart';
import 'package:gaya/utils/language/translation.dart';
import 'package:gaya/utils/logger.dart';
import 'package:gaya/utils/methods.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart' as intl;

// import '../model/community.model.dart';
// import '../model/create.post.model.dart';
// import '../model/user.communities.dart';
// import '../utils/collections.dart';

class HomePageController extends ChangeNotifier {
  HelperFunc helperFunc = HelperFunc();

// Firestore things

  FirebaseAuth firebaseAuth = FirebaseAuth.instance;
  late QuerySnapshot<Map<String, dynamic>> querySnapshot;
  DocumentSnapshot? lastDocument;
  DocumentSnapshot? lastPostNoCommunity;

  QuerySnapshot? postQueryDocs;

  // //for the communities when joined in
  // late QuerySnapshot<Map<String, dynamic>> userDataQuerSnapshot;
  // late QuerySnapshot<Map<String, dynamic>> communitiesDataQuerSnapshot;
  // late QuerySnapshot<Map<String, dynamic>> flowerCountQuersnapShot;
  // late QuerySnapshot<Map<String, dynamic>> likeCountQuersnapShot;
  // late QuerySnapshot<Map<String, dynamic>> commentCountQuersnapShot;
  // late QuerySnapshot<Map<String, dynamic>> allPostsUserNotLoginQuerSnapshot;

  // //for the communities not join in
  // late QuerySnapshot<Map<String, dynamic>> userDataQuerSnapshotNoCommunity;
  // late QuerySnapshot<Map<String, dynamic>>
  //     communitiesDataQuerSnapshotNoCommunity;
  //
  // late QuerySnapshot<Map<String, dynamic>> flowerCountQuersnapShotNoCommunity;
  // late QuerySnapshot<Map<String, dynamic>> likeCountQuersnapShotNoCommunity;
  // late QuerySnapshot<Map<String, dynamic>> commentCountQuersnapShotNoCommunity;

  // // All models , controllers and other objects
  // ScrollController communitiesScroll = ScrollController();
  // ScrollController noCommunitiesScroll = ScrollController();
  // ScrollController noCommunitiesScrollNotLogin = ScrollController();
  TextEditingController searchFriendsController = TextEditingController();

  // final refreshKey = GlobalKey<RefreshIndicatorState>();
  // final refreshKey1 = GlobalKey<RefreshIndicatorState>();

  Services services = Services();
  UserSavedPostsModel? userSavedPostsModel;

  //All bools
  bool loadMoreData = false;
  bool isMoreDataAvailable = true;
  bool isMoreDataAvailableForNoJoinedCommunities = true;
  bool loadMoreDataNoCommunities = false;
  bool isSend = false;
  bool isSearchModeOn = false;

  // // All lists
  // List userCommuniteis = [];
  // List<Map<String, dynamic>> postsList = [];
  // List<Map<String, dynamic>> newPostsList = [];

  List allUsername = [];
  List<String> userCommuniteisWithIdsOnly = [];
  List savePostsIds = [];
  List savePostsCommunityIds = [];
  List<String> savePostsUserIds = [];

  // List communityList = [];
  // List<String> listadd = [];
  // List<String> interest = [];
  // List<Map<String, dynamic>> userDataList = [];
  // List<Map<String, dynamic>> communitiesData = [];
  // List<int> flowerCountList = [];
  // List<int> commentCountList = [];
  // List publicCommunities = [];//
  //  List publicCommunitiesOnly10 = [];
  //  List<String> communitiesIdsList = [];
  List<String> sentMessageUserIds = [];

  // List<int> flowerCountListNoCommunity = [];
  // List<int> commentCountListNoCommunity = [];
  // List<int> likeCountListNoCommunity = [];
  // List<Map<String, dynamic>> allPostsUserNotLoginList = [];

  // List<Map<String, dynamic>> userDataListNoCommunity = [];
  // List<Map<String, dynamic>> communitiesDataNoCommunity = [];

  List<String> senderFriendsUid = [];
  List<String> recieverFriendsUid = [];
  List<String> allFriendsList = [];

  List<UserModel> allFriends = [];
  List<UserModel> searchFriends = [];

  addUserInAllFriends(UserModel user) {
    if (!allFriends.contains(user)) {
      allFriends.add(user);
    }
  }

  // All integers
  // int lastPostListLength = 0;
  // int totalNumberOfPosts = 0;
  // int homepageTotalPosts = 0;
  // int totalHomePosts = 0;
  int totalCommunitiesMembers = 0;
  int flowerSize = 0;

  // int likeSize = 0;
  // int saveSize = 0;

  // int flowerDocCount = 0;
  // int commentDocCount = 0;
  // int likeDocCount = 2;
  //
  // //constructor
  // HomePageController() {
  //   // getUserAllSavedPosts();
  // }

  //switch between the screens
  HomepageSwitch index = HomepageSwitch.home;

  get getView => index;

  //
  // HomepageSwitch setView(HomepageSwitch Setindex) {
  //   index = Setindex;
  //   notifyListeners();
  //   return index;
  // }

  bool isRTL(String text) {
    return intl.Bidi.detectRtlDirectionality(text);
  }

  // //get the communites
  // Future<QuerySnapshot?> getUserCommunities() async {
  //   return await services.getUserCommunities();
  // }

  //get The ucommunities in which the user joined

  // Future<QuerySnapshot?> getCommunitiesIdWhereTheUserLogin() async {
  //   QuerySnapshot getPosts = await FirebaseFirestore.instance
  //       .collection('communityposts')
  //       .where('communityId', whereIn: userCommuniteisWithIdsOnly)
  //       .get()
  //       .then((value) {
  //     totalHomePosts = value.docs.length;
  //     postQueryDocs = value;
  //     return value;
  //   });
  //   return getPosts;
  // }

  // //get the post user detail
  // Future<DocumentSnapshot?> getPostUserDetails(String userId) async {
  //   return services.getPostUserDetails(userId);
  // }

  // //get the community details for the post
  // Future<DocumentSnapshot?> getDetailsOfCommunityForAPost(String docId) async {
  //   return services.getCommunityDetails(docId);
  // }

  // //get the comment count
  // Future<QuerySnapshot?> getCommentCount(String postId) async {
  //   return services.getCommentCount(postId);
  // }

  // Stream<QuerySnapshot?> getCommentCountStream(String postId) async* {
  //   yield* FirebaseFirestore.instance
  //       .collection('communityposts')
  //       .doc(postId)
  //       .collection('comments')
  //       .snapshots();
  // }

// //get the like count homepage
//   Stream<QuerySnapshot?> likecount(String postId) async* {
//     yield* FirebaseFirestore.instance
//         .collection('communityposts')
//         .doc(postId)
//         .collection('likes')
//         .snapshots();
//     // totalLikesSnap.listen((event) {
//     //   totalLikes = event!.docs.length;
//     //   notifyListeners();
//     // });
//   }

  // Stream<QuerySnapshot?> getCommunityMembers(String communityId) async* {
  //   yield* FirebaseFirestore.instance
  //       .collection('communities')
  //       .doc(communityId)
  //       .collection('communityMembers')
  //       .snapshots();
  // }

  // //get the homepage like
  // Stream<QuerySnapshot?> getLikes(String postId) async* {
  //   yield* services.homepageLikeCounts(postId);
  // }

  // //get the homepage flowers counts
  // Stream<QuerySnapshot?> getFlowers(String postId) async* {
  //   yield* services.homepageFlowerCounts(postId);
  // }
  //
  // //get the homepage flowers counts
  // Stream<QuerySnapshot?> getsavePost(String postId) async* {
  //   yield* services.homepageSavePost(postId);
  // }

  // //get the communities from random generated list
  // Future<QuerySnapshot?> getRandomCommunitiesFromTheList(
  //     List<String> randomCommunitiesdata) async {
  //   return services.randomCommunities(randomCommunitiesdata);
  // }

  // //get the communities from random generated list
  // Future<QuerySnapshot?> getUnknownSelectedInterestCommunities(
  //     List<String> communities) async {
  //   return services.randomCommunities(communities);
  // }

  ///

  // //get all the user communnites
  // Future<QuerySnapshot?> getAllUserCommunities() async {
  //   CreateCommunityModel? _communites;
  //   User? user = FirebaseAuth.instance.currentUser;
  //   QuerySnapshot? userAllCommunities = await FirebaseFirestore.instance
  //       .collection(userCollection)
  //       .doc(user!.uid)
  //       .collection(userCommunities)
  //       .get()
  //       .then((snapshot) {
  //     for (var i in snapshot.docs) {
  //       _communites = CreateCommunityModel.fromMap(i.data());
  //
  //       communityList.add(_communites!.communityId);
  //     }
  //
  //     return snapshot;
  //   });
  //
  //   return userAllCommunities;
  // }
  //
  // Future<QuerySnapshot?> homepagePostCommunityDetails() async {
  //   QuerySnapshot homePostDetailsData = await FirebaseFirestore.instance
  //       .collection('communities')
  //       .where("communityId", whereIn: communityList)
  //       .get()
  //       .then((value) {
  //     log(value.docs.length.toString());
  //     userCommuniteis.clear();
  //     userCommuniteisWithIdsOnly.clear();
  //     for (var i in value.docs) {
  //       CreateCommunityModel _userCommunites =
  //           CreateCommunityModel.fromMap(i.data());
  //
  //       // userCommuniteis.add({
  //       //   'communityname': _userCommunites.communityName,
  //       //   'communityId': _userCommunites.communityId
  //       // });
  //
  //       userCommuniteisWithIdsOnly.add(_userCommunites.communityId!);
  //     }
  //
  //     return value;
  //   });
  //   return homePostDetailsData;
  // }
  //
  // Future<QuerySnapshot?> allcommunitiesPosts() async {
  //   QuerySnapshot postsData = await FirebaseFirestore.instance
  //       .collection(communityPosts)
  //       .where("communityId", whereIn: userCommuniteisWithIdsOnly)
  //       .get()
  //       .then((value) {
  //     homepageTotalPosts = value.docs.length;
  //     for (var i in value.docs) {
  //       CreatePostModel createPostModel = CreatePostModel.fromMap(i.data());
  //
  //       log("All the posts are details are ${createPostModel.postDescription}");
  //     }
  //
  //     return value;
  //   });
  //   return postsData;
  // }

  //set the save posts in the user collections
  Future setSavePostInUSerCollection(Map<String, dynamic> setMap, BuildContext context) async {
    User? user = FirebaseAuth.instance.currentUser;
    SavePostModel savePostModel = SavePostModel(saveDocID: setMap["postId"]);

    try {
      await FirebaseFirestore.instance
          .collection('users')
          .doc(user!.uid)
          .collection('saveposts')
          .doc(savePostModel.saveDocID)
          .set(setMap)
          .then((value) {
        GayaSnackBar.show(context: context, type: GayaSnackBarType.save, text: GayaStrings.post_saved.tr);

        return value;
      });
    } catch (e) {
      // log(e.toString());
      snackBar(context, GayaStrings.failed_to_save.tr, kprimaryColor);
    } finally {}
  }

  //delete the user unsave doc from community post save collection
  Future<QuerySnapshot?> deleteUserSaveDocFromPostCollection(String postId, BuildContext context) async {
    User? user = firebaseAuth.currentUser;
    QuerySnapshot? unsavePostQuery;

    try {
      unsavePostQuery = await FirebaseFirestore.instance
          .collection('communityposts')
          .doc(postId)
          .collection('savepost')
          .where('userUid', isEqualTo: user!.uid)
          .get()
          .then((value) {
        value.docs.first.reference.delete();
        return value;
      });
    } catch (e) {
      // log("failed to unsave the post");
      snackBar(context, GayaStrings.failed_to_unsaved.tr, kRedColor);
    } finally {}
    return unsavePostQuery;
  }

  //delete the save post from the user collection
  Future deletePostFromUserCollection(String postId) async {
    User? user = FirebaseAuth.instance.currentUser;
    try {
      await FirebaseFirestore.instance.collection('users').doc(user!.uid).collection('saveposts').doc(postId).delete();
    } catch (_) {}
  }

//********************* */

//Save posts details

  // //get all the user save post from user collection
  // Future<QuerySnapshot?> getUserAllSavedPosts() async {
  //   User? user = FirebaseAuth.instance.currentUser;
  //   QuerySnapshot userSavedPosts = await FirebaseFirestore.instance
  //       .collection('users')
  //       .doc(user!.uid)
  //       .collection('saveposts')
  //       .get()
  //       .then((snapshot) {
  //     totalNumberOfPosts = snapshot.docs.length;
  //     savePostsCommunityIds.clear();
  //     savePostsIds.clear();
  //     savePostsUserIds.clear();
  //     for (var i in snapshot.docs) {
  //       userSavedPostsModel = UserSavedPostsModel.fromMap(i.data());
  //       savePostsCommunityIds.add(userSavedPostsModel!.communityId);
  //       savePostsIds.add(userSavedPostsModel!.postId);
  //       savePostsUserIds.add(userSavedPostsModel!.userUid!);
  //       notifyListeners();
  //       // userSavedPostDetailss();
  //       // savedPostCommunityDetails();
  //       // savedPostDetails();
  //     }
  //     // log("these are the save posts id ${savePostsIds}");
  //     //  log("these are the save posts community id ${savePostsCommunityIds}");
  //     // log("these are the save posts user id ${savePostsUserIds}");
  //     return snapshot;
  //   });
  //   return userSavedPosts;
  // }

  //get the user saved posts details
  // Future<QuerySnapshot?> savedPostDetails() async {
  //   QuerySnapshot userSavedPostDetails = await FirebaseFirestore.instance
  //       .collection('communityposts')
  //       .where('postId', whereIn: savePostsIds)
  //       .get()
  //       .then((snapshot) {
  //     for (var i in snapshot.docs) {
  //       createPostModelsave = CreatePostModel.fromMap(i.data());
  //     }
  //     return snapshot;
  //   });
  //   return userSavedPostDetails;
  // }
  // //get the user saved posts community details
  // Future<QuerySnapshot?> savedPostCommunityDetails() async {
  //   QuerySnapshot userSavedPostDetails = await FirebaseFirestore.instance
  //       .collection('communities')
  //       .where('communityId', whereIn: savePostsCommunityIds)
  //       .get()
  //       .then((snapshot) {
  //     for (var i in snapshot.docs) {
  //       createCommunityModel = CreateCommunityModel.fromMap(i.data());
  //     }
  //     return snapshot;
  //   });
  //   return userSavedPostDetails;
  // }

  // //get the user saved posts user details
  // Future<QuerySnapshot?> userSavedPostDetailss() async {
  //   QuerySnapshot userSavedPostDetails = await FirebaseFirestore.instance
  //       .collection('users')
  //       .where('uid', whereIn: savePostsUserIds)
  //       .get()
  //       .then((snapshot) {
  //     for (var i in snapshot.docs) {
  //       usermodel = UserModel.fromMap(i.data());
  //     }
  //     return snapshot;
  //   });
  //   return userSavedPostDetails;
  // }

  // Save posts end
  //************ */

//*********** */

  //when users communities data is empty then we will show the users insterests data
  // Future<DocumentSnapshot?> userInterestsDataCommunities() async {
  //   User? user = FirebaseAuth.instance.currentUser;
  //   DocumentSnapshot usersData = await FirebaseFirestore.instance
  //       .collection("users")
  //       .doc(user!.uid)
  //       .get()
  //       .then((snapShot) {
  //     UserModel usermodel = UserModel.fromMap(snapShot.data()!);
  //     interest.clear();
  //     for (var i in usermodel.interests!) {
  //       interest.add(i.name!);
  //     }
  //     return snapShot;
  //   });
  //   return usersData;
  // }
  //
  // Future<QuerySnapshot?> getCommunitiesWithUserInterest() async {
  //   QuerySnapshot communitiesIds = await FirebaseFirestore.instance
  //       .collection('communities')
  //       .where('topics.${'topicName'}', whereIn: [
  //         'Food',
  //         'Science',
  //         'Learn something',
  //         'Art',
  //         'Fitness',
  //         'Cooking',
  //         'Makeup'
  //       ])
  //       .where('type', isEqualTo: 'Public')
  //       .get()
  //       .then((value) {
  //         communitiesIdsList.clear();
  //         for (var i in value.docs) {
  //           CreateCommunityModel createCommunityModel =
  //               CreateCommunityModel.fromMap(i.data());
  //           communitiesIdsList.add(createCommunityModel.communityId!);
  //
  //           log(createCommunityModel.communityName.toString());
  //         }
  //         return value;
  //       });
  //
  //   return communitiesIds;
  // }

  //--------

  // Future onRefresh() async {
  //   await Future.delayed(Duration(milliseconds: 1000));
  //   lastDocument = null;
  //   isMoreDataAvailable = true;
  //
  //   notifyListeners();
  //   // await allcommunityPosts();
  // }
  //
  // Future onRefreshWithNoCommunities() async {
  //   await Future.delayed(Duration(milliseconds: 1000));
  //   lastDocument = null;
  //   isMoreDataAvailableForNoJoinedCommunities = true;
  //   allPostsUserNotLoginList.clear();
  //   userDataListNoCommunity.clear();
  //   communitiesDataNoCommunity.clear();
  //   commentCountListNoCommunity.clear();
  //   notifyListeners();
  //   // await getAllDataWhenUserNotJoinAnyCommunity();
  // }
  //
  // Future<QuerySnapshot?> userJoinedGroupsId() async {
  //   User? user = FirebaseAuth.instance.currentUser;
  //
  //   QuerySnapshot getUserCommunities = await FirebaseFirestore.instance
  //       .collection('users')
  //       .doc(user!.uid)
  //       .collection('communities')
  //       .get()
  //       .then((snapshot) async {
  //     for (var i in snapshot.docs) {
  //       UserCommunitiesModel communityModel =
  //           UserCommunitiesModel.fromMap(i.data());
  //       listadd.add(communityModel.communityId!);
  //
  //       notifyListeners();
  //     }
  //
  //     // await allcommunityPosts();
  //
  //     return snapshot;
  //   });
  //   return getUserCommunities;
  // }
  //
  // Future allcommunityPosts() async {
  //   if (isMoreDataAvailable) {
  //     loadMoreData = true;
  //     notifyListeners();
  //
  //     final collection = await FirebaseFirestore.instance
  //         .collection("communityposts")
  //         .where('communityId', whereIn: listadd)
  //         .where("isDeleted", isEqualTo: false)
  //         .where("approve", isEqualTo: true)
  //         .orderBy("createdOn", descending: true);
  //
  //     if (lastDocument == null) {
  //       log("Start of the pagination");
  //       querySnapshot = await collection.limit(10).get().then((value) async {
  //         for (var i in value.docs) {
  //           CreatePostModel createPostModel = CreatePostModel.fromMap(i.data());
  //
  //           // ----------- user data ---------
  //           final collectionUser = FirebaseFirestore.instance
  //               .collection('users')
  //               .where('uid', isEqualTo: createPostModel.memberId);
  //
  //           userDataQuerSnapshot = await collectionUser.get();
  //           userDataList.addAll(userDataQuerSnapshot.docs.map((e) => e.data()));
  //
  //           // ---------- communities data  ---------
  //           final collectionCommunities = FirebaseFirestore.instance
  //               .collection('communities')
  //               .where('communityId', isEqualTo: createPostModel.communityId);
  //           communitiesDataQuerSnapshot = await collectionCommunities.get();
  //
  //           communitiesData
  //               .addAll(communitiesDataQuerSnapshot.docs.map((e) => e.data()));
  //
  //           // ---------- flower count real time  ---------
  //           final flowerCountCollection = FirebaseFirestore.instance
  //               .collection('communityposts')
  //               .doc(createPostModel.postid)
  //               .collection('flowers');
  //           flowerCountQuersnapShot =
  //               await flowerCountCollection.get().then((value) {
  //             flowerCountList.add(value.docs.length);
  //             return value;
  //           });
  //
  //           // ---------- comment count real time  ---------
  //           final commentCountCollection = FirebaseFirestore.instance
  //               .collection('communityposts')
  //               .doc(createPostModel.postid)
  //               .collection('comments');
  //           commentCountQuersnapShot =
  //               await commentCountCollection.get().then((value) {
  //             commentCountList.add(value.docs.length);
  //             return value;
  //           });
  //         }
  //
  //         return value;
  //       });
  //     } else {
  //       log("Getting more and more data");
  //       querySnapshot = await collection
  //           .limit(10)
  //           .startAfterDocument(lastDocument!)
  //           .get()
  //           .then((value) async {
  //         for (var i in value.docs) {
  //           CreatePostModel createPostModel = CreatePostModel.fromMap(i.data());
  //
  //           // ----------- user data ---------
  //           final collectionUser = FirebaseFirestore.instance
  //               .collection('users')
  //               .where('uid', isEqualTo: createPostModel.memberId);
  //           userDataQuerSnapshot = await collectionUser.get();
  //           userDataList.addAll(userDataQuerSnapshot.docs.map((e) => e.data()));
  //           notifyListeners();
  //
  //           // ---------- communities data  ---------
  //           final collectionCommunities = FirebaseFirestore.instance
  //               .collection('communities')
  //               .where('communityId', isEqualTo: createPostModel.communityId);
  //           communitiesDataQuerSnapshot = await collectionCommunities.get();
  //           communitiesData
  //               .addAll(communitiesDataQuerSnapshot.docs.map((e) => e.data()));
  //           notifyListeners();
  //
  //           // ---------- flower count real time  ---------
  //           final flowerCountCollection = FirebaseFirestore.instance
  //               .collection('communityposts')
  //               .doc(createPostModel.postid)
  //               .collection('flowers');
  //           flowerCountQuersnapShot =
  //               await flowerCountCollection.get().then((value) {
  //             flowerCountList.add(value.docs.length);
  //             return value;
  //           });
  //
  //           // ---------- comment count real time  ---------
  //           final commentCountCollection = FirebaseFirestore.instance
  //               .collection('communityposts')
  //               .doc(createPostModel.postid)
  //               .collection('comments');
  //           commentCountQuersnapShot =
  //               await commentCountCollection.get().then((value) {
  //             commentCountList.add(value.docs.length);
  //             return value;
  //           });
  //         }
  //
  //         return value;
  //       });
  //     }
  //
  //     lastDocument = querySnapshot.docs.last;
  //
  //     postsList.addAll(querySnapshot.docs.map((e) => e.data()));
  //     log("postlist length before ${postsList.length}");
  //
  //     //REMOVE THE DUPLICATE POSTS FROM THE LIST OF MAPS
  //     final ids = postsList.map((e) => e['postId']!).toSet();
  //     postsList.retainWhere((Map x) {
  //       return ids.remove(x['postId']);
  //     });
  //     log("last post length ${lastPostListLength}");
  //     int length2 = postsList.length;
  //     log("length2 : $length2");
  //     int length3 = length2 - lastPostListLength;
  //     log("length3 : $length3");
  //     newPostsList = postsList;
  //     log("new post added before  are ${newPostsList.length}");
  //     List<Map<String, dynamic>> newList =
  //         newPostsList.skip(lastPostListLength).toList();
  //     log("new list is ${newList.length}");
  //     log("new post added are ${newPostsList.length}");
  //
  //     // postsList.insertAll(0, newList);
  //     lastPostListLength = postsList.length;
  //     notifyListeners();
  //
  //     log("postlist length after ${postsList.length}");
  //     Future.delayed(Duration(seconds: 1), () {
  //       loadMoreData = false;
  //       notifyListeners();
  //     });
  //
  //     if (querySnapshot.docs.length < 10) {
  //       log("Now it is the last time of pagination , because documents are going to end");
  //       isMoreDataAvailable = false;
  //       notifyListeners();
  //     }
  //   } else {
  //     loadMoreData = false;
  //     // notifyListeners();
  //     log("There is no more data available");
  //
  //     await getAllDataWhenUserNotJoinAnyCommunity();
  //   }
  // }

  // //get the like count homepage
  // int totalFlowerCounts = 0;
  //
  // Stream<QuerySnapshot?> flowercount(String postids) async* {
  //   yield* FirebaseFirestore.instance
  //       .collection('communityposts')
  //       .doc(postids)
  //       .collection('flowers')
  //       .snapshots();
  //
  //   // flowerCount.listen((event) {
  //   //   totalCounts = event!.docs.length;
  //   // });
  // }
  //
  // //get the flowers count in the homepage
  // int fCount = 0;
  //
  // Stream<QuerySnapshot?> homepageFlowerCounts(String postId) async* {
  //   User? user = FirebaseAuth.instance.currentUser;
  //
  //   yield* FirebaseFirestore.instance
  //       .collection('communityposts')
  //       .doc(postId)
  //       .collection('flowers')
  //       .where('userUid', isEqualTo: user!.uid)
  //       .snapshots();
  // }
  //
  // //get the count of the comments on the post in home screen
  // Stream<QuerySnapshot?> getComments(String postId) async* {
  //   yield* await FirebaseFirestore.instance
  //       .collection('communityposts')
  //       .doc(postId)
  //       .collection('comments')
  //       .snapshots();
  // }

  // ------------- when user not login

  //get all the data from the communities

  // Future<QuerySnapshot?> getPublicCommunities() async {
  //   publicCommunities.clear();
  //   publicCommunitiesOnly10.clear();
  //   QuerySnapshot getUserCommunities = await FirebaseFirestore.instance
  //       .collection('communities')
  //       .where("type", isEqualTo: "Public")
  //       .get()
  //       .then((snapshot) async {
  //     for (var i in snapshot.docs) {
  //       CreateCommunityModel communityModel =
  //           CreateCommunityModel.fromMap(i.data());
  //
  //       publicCommunities.add(communityModel.communityId!);
  //
  //       final filterList = publicCommunities.take(10);
  //       publicCommunitiesOnly10 = filterList.toList();
  //
  //       notifyListeners();
  //     }
  //     // log("users have following communities with ids in his list $listadd");
  //
  //     // await getAllDataWhenUserNotJoinAnyCommunity(calledFrom: 'getPublicCommunities');
  //
  //     return snapshot;
  //   });
  //   return getUserCommunities;
  // }

  // Future getAllDataWhenUserNotJoinAnyCommunity() async {
  //   if (isMoreDataAvailableForNoJoinedCommunities) {
  //     loadMoreDataNoCommunities = true;
  //     notifyListeners();
  //
  //     final collection = await FirebaseFirestore.instance
  //         .collection('communityposts')
  //         .where("communityId", whereIn: publicCommunitiesOnly10)
  //         .where("approve", isEqualTo: true)
  //         .where('isDeleted', isEqualTo: false);
  //     if (lastPostNoCommunity == null) {
  //       log("This is out 10 limit");
  //       allPostsUserNotLoginQuerSnapshot =
  //           await collection.limit(10).get().then((value) async {
  //         for (var i in value.docs) {
  //           CreatePostModel createPostModel = CreatePostModel.fromMap(i.data());
  //
  //           // ----------- user data ---------
  //           final collectionUser = FirebaseFirestore.instance
  //               .collection('users')
  //               .where('uid', isEqualTo: createPostModel.memberId);
  //
  //           userDataQuerSnapshotNoCommunity = await collectionUser.get();
  //
  //           userDataListNoCommunity.addAll(
  //               userDataQuerSnapshotNoCommunity.docs.map((e) => e.data()));
  //
  //           // ---------- communities data  ---------
  //           final collectionCommunities = FirebaseFirestore.instance
  //               .collection('communities')
  //               .where('communityId', isEqualTo: createPostModel.communityId);
  //           communitiesDataQuerSnapshotNoCommunity =
  //               await collectionCommunities.get();
  //
  //           communitiesDataNoCommunity.addAll(
  //               communitiesDataQuerSnapshotNoCommunity.docs
  //                   .map((e) => e.data()));
  //
  //           //Communities total members
  //           FirebaseFirestore.instance
  //               .collection('communities')
  //               .doc(createPostModel.communityId)
  //               .collection('communityMembers')
  //               .get()
  //               .then((value) {
  //             totalCommunitiesMembers = value.docs.length;
  //             notifyListeners();
  //             return value;
  //           });
  //
  //           // ---------- flower count real time  ---------
  //           final flowerCountCollection = FirebaseFirestore.instance
  //               .collection('communityposts')
  //               .doc(createPostModel.postid)
  //               .collection('flowers');
  //           flowerCountQuersnapShotNoCommunity =
  //               await flowerCountCollection.get().then((value) {
  //             flowerCountListNoCommunity.add(value.docs.length);
  //             return value;
  //           });
  //
  //           // ---------- likes count real time  ---------
  //           final likeCountCollection = FirebaseFirestore.instance
  //               .collection('communityposts')
  //               .doc(createPostModel.postid)
  //               .collection('likes');
  //           likeCountQuersnapShotNoCommunity =
  //               await likeCountCollection.get().then((event) {
  //             likeCountListNoCommunity.add(event.docs.length);
  //             return event;
  //           });
  //           ;
  //
  //           // ---------- comment count real time  ---------
  //
  //           final commentCountCollection = FirebaseFirestore.instance
  //               .collection('communityposts')
  //               .doc(createPostModel.postid)
  //               .collection('comments');
  //           commentCountQuersnapShotNoCommunity =
  //               await commentCountCollection.get().then((value) {
  //             commentCountListNoCommunity.add(value.docs.length);
  //             return value;
  //           });
  //         }
  //
  //         return value;
  //       });
  //     } else {
  //       allPostsUserNotLoginQuerSnapshot = await collection
  //           .limit(10)
  //           .startAfterDocument(lastPostNoCommunity!)
  //           .get()
  //           .then((value) async {
  //         for (var i in value.docs) {
  //           CreatePostModel createPostModel = CreatePostModel.fromMap(i.data());
  //
  //           // ----------- user data ---------
  //           final collectionUser = FirebaseFirestore.instance
  //               .collection('users')
  //               .where('uid', isEqualTo: createPostModel.memberId);
  //
  //           userDataQuerSnapshotNoCommunity = await collectionUser.get();
  //
  //           userDataListNoCommunity.addAll(
  //               userDataQuerSnapshotNoCommunity.docs.map((e) => e.data()));
  //
  //           // ---------- communities data  ---------
  //           final collectionCommunities = FirebaseFirestore.instance
  //               .collection('communities')
  //               .where('communityId', isEqualTo: createPostModel.communityId);
  //           communitiesDataQuerSnapshotNoCommunity =
  //               await collectionCommunities.get();
  //
  //           communitiesDataNoCommunity.addAll(
  //               communitiesDataQuerSnapshotNoCommunity.docs
  //                   .map((e) => e.data()));
  //
  //           // ---------- flower count real time  ---------
  //           final flowerCountCollection = FirebaseFirestore.instance
  //               .collection('communityposts')
  //               .doc(createPostModel.postid)
  //               .collection('flowers');
  //           flowerCountQuersnapShotNoCommunity =
  //               await flowerCountCollection.get().then((value) {
  //             flowerCountListNoCommunity.add(value.docs.length);
  //             return value;
  //           });
  //
  //           // ---------- likes count real time  ---------
  //           final likeCountCollection = FirebaseFirestore.instance
  //               .collection('communityposts')
  //               .doc(createPostModel.postid)
  //               .collection('likes');
  //           likeCountQuersnapShotNoCommunity =
  //               await likeCountCollection.get().then((event) {
  //             likeCountListNoCommunity.add(event.docs.length);
  //             return event;
  //           });
  //           ;
  //
  //           // ---------- comment count real time  ---------
  //
  //           final commentCountCollection = FirebaseFirestore.instance
  //               .collection('communityposts')
  //               .doc(createPostModel.postid)
  //               .collection('comments');
  //           commentCountQuersnapShotNoCommunity =
  //               await commentCountCollection.get().then((value) {
  //             commentCountListNoCommunity.add(value.docs.length);
  //             return value;
  //           });
  //         }
  //
  //         return value;
  //       });
  //     }
  //
  //     lastPostNoCommunity = allPostsUserNotLoginQuerSnapshot.docs.last;
  //
  //     allPostsUserNotLoginList
  //         .addAll(allPostsUserNotLoginQuerSnapshot.docs.map((e) => e.data()));
  //     loadMoreDataNoCommunities = false;
  //     notifyListeners();
  //
  //     if (allPostsUserNotLoginQuerSnapshot.docs.length < 10) {
  //       log("Now it is the last pagination no communities");
  //       isMoreDataAvailableForNoJoinedCommunities = false;
  //       notifyListeners();
  //     }
  //   } else {
  //     loadMoreDataNoCommunities = false;
  //     notifyListeners();
  //     log("There is no more ");
  //   }
  // }
  //
  // void scrollToTop() {
  //   WidgetsBinding.instance.addPostFrameCallback((_) {
  //     communitiesScroll.animateTo(
  //       communitiesScroll.position.minScrollExtent,
  //       duration: const Duration(milliseconds: 700),
  //       curve: Curves.easeIn,
  //     );
  //   });
  // }
  //
  // void scrollToTopNoCommunityNoLogin() {
  //   WidgetsBinding.instance.addPostFrameCallback((_) {
  //     noCommunitiesScrollNotLogin.animateTo(
  //       noCommunitiesScrollNotLogin.position.minScrollExtent,
  //       duration: const Duration(milliseconds: 700),
  //       curve: Curves.easeIn,
  //     );
  //   });
  // }
  //
  // void scrollToTopNoCommunity() {
  //   WidgetsBinding.instance.addPostFrameCallback((_) {
  //     noCommunitiesScroll.animateTo(
  //       noCommunitiesScroll.position.minScrollExtent,
  //       duration: const Duration(milliseconds: 700),
  //       curve: Curves.easeIn,
  //     );
  //   });
  // }

  //getting all users
  List<UserModel> searchedUser = [];
  AlgoliaService algoliaService = AlgoliaService();
  bool isLoading = false;
  Future<void> fetchUsers(String query) async {
    try {
      notifyListeners();
      if (query.trim().isEmpty) return;
      searchedUser = await algoliaService.getsAllUsers(query);
      isLoading = false;
      notifyListeners();
    } catch (e) {
      MyLoggerServices.to.print('errorororo${e.toString()}');
    }
  }

  //

  Future<List<UserModel>> getMyFriends() async {
    User? user = firebaseAuth.currentUser;

    if (user == null) return [];
    final freindsSnaps = await Future.wait([
      FirebaseFirestore.instance
          .collection("friendship")
          .where("Recieveruid", isEqualTo: user.uid)
          .where("isaccepted", isEqualTo: true)
          .get(),
      FirebaseFirestore.instance.collection("friendship").where("senderUid", isEqualTo: user.uid).where("isaccepted", isEqualTo: true).get()
    ]);

    //senders
    for (var index in freindsSnaps[0].docs) {
      FriendShipModel friendShipModel = FriendShipModel.fromMap(index.data());

      senderFriendsUid.add(friendShipModel.senderUid!);
    }

    // recievers
    for (var index in freindsSnaps[1].docs) {
      FriendShipModel friendShipModel = FriendShipModel.fromMap(index.data());

      recieverFriendsUid.add(friendShipModel.recieverUid!);
    }

    List<String> allFriendsIds = [...senderFriendsUid, ...recieverFriendsUid];

    List<UserModel> allFriendsData = [];
    try {
      /// split the list into chunks of 10
      /// then get the users by ids
      /// then add the users to the list
      /// then return the list
      Methods.generateListOfChunks(allFriendsIds).forEach((element) async {
        await services.getUsersByIds(element).then((userChunk) {
          allFriendsData.addAll(userChunk);
        });
      });
    } catch (e) {
      print(e);
    }
    return allFriendsData;
  }

  //get all the your friends
  Future<QuerySnapshot?> yourFriends() async {
    User? user = firebaseAuth.currentUser;
    if (user == null) return null;
    return await FirebaseFirestore.instance
        .collection("friendship")
        .where("Recieveruid", isEqualTo: user.uid)
        .where("isaccepted", isEqualTo: true)
        .get()
        .then((value) {
      for (var index in value.docs) {
        FriendShipModel friendShipModel = FriendShipModel.fromMap(index.data());

        senderFriendsUid.add(friendShipModel.senderUid!);
      }

      return value;
    }).whenComplete(() async {
      await FirebaseFirestore.instance
          .collection("friendship")
          .where("senderUid", isEqualTo: user.uid)
          .where("isaccepted", isEqualTo: true)
          .get()
          .then((value) {
        for (var index in value.docs) {
          FriendShipModel friendShipModel = FriendShipModel.fromMap(index.data());

          recieverFriendsUid.add(friendShipModel.recieverUid!);
        }
        return value;
      });
    }).whenComplete(() async {
      allFriendsList = [...recieverFriendsUid, ...senderFriendsUid];

      // log("This is our complete list ${allFriendsList}");
      // log("This is reciver list ${recieverFriendsUid}");
      // log("This is sender list ${senderFriendsUid}");
      // log("This is getfirends list list ${_getFriendsList(allFriendsList)}");
    }).then((value) async {
      if (allFriendsList.isEmpty) return null;
      return await FirebaseFirestore.instance
          .collection("users")
          .where("uid", whereIn: _getFriendsList(allFriendsList))
          .get()
          .then((value) {
        return value;
      });
    }).whenComplete(() {
      allFriendsList.clear();
      senderFriendsUid.clear();
      recieverFriendsUid.clear();
    });
  }

  final Random random = Random();

  int generateRand({int? max}) {
    int rand = (random.nextInt(max ?? 10000));
    return rand;
  }

  DateTime generateRandomDateTime() {
    DateTime now = DateTime.now();
    int day = generateRand(max: 30);
    DateTime randomDay = now.subtract(Duration(days: day));
    return randomDay;
  }

  Future<QuerySnapshot?> getUsersOfMyInterest({int? limit}) async {
    if (UserModel.to.interests?.isEmpty ?? true) return null;
    debugPrint("My itnerests :  ${UserModel.to.interests}");
    final myInterest = await FirebaseFirestore.instance
        .collection("users")
        .where("interests", arrayContainsAny: UserModel.to.interests?.map((element) => element.toMap()).toList())
        .limit(limit ?? 10)
        .get();
    return myInterest;
  }

  Future<QuerySnapshot?> randomUsers({int? limit}) async {
    final randomUsers = await FirebaseFirestore.instance
        .collection("users")
        .where('userCreatedOn', isGreaterThanOrEqualTo: generateRandomDateTime())
        .limit(limit ?? 10)
        .get();
    return randomUsers;
  }

  Future<QuerySnapshot?> myFriendsOrInterestBaseOrRandomUsers() async {
    QuerySnapshot? users;

    try {
      /// fetch my friends
      await yourFriends().then((friends) {
        if (friends?.docs.isNotEmpty ?? false) {
          users = friends;
        } else {
          /// if no friends then fetch ppl from my interests
          return getUsersOfMyInterest().then((interests) {
            if (interests?.docs.isNotEmpty ?? false) {
              users = interests;
            } else {
              /// if no interests then fetch random users
              return randomUsers().then((random) {
                if (random?.docs.isNotEmpty ?? false) {
                  users = random;
                }
              });
            }
          });
        }
      });
    } catch (_) {
      debugPrint("Error in getting myFriendsOrInterestBaseOrRandomUsers ${_}");
    }

    return users;
  }

  List<String?> _getFriendsList(List<String?> allFriendsList) {
    List<String?> allfriendsIds = [];
    if (allFriendsList.length < 10) {
      allfriendsIds = allFriendsList;
    } else {
      allfriendsIds = allFriendsList.cutList(allFriendsList, 10);
    }
    return allfriendsIds;
  }

//search the communities
  searchFriendsFunc(String query) {
    if (isSearchModeOn != true) {
      isSearchModeOn = true;
    }
    if (query.trim().isEmpty) {
      isSearchModeOn = false;
    }
    final suggestion = allFriends.where((element) {
      final friendName = element.name!.toLowerCase();
      final input = query.toLowerCase();
      return friendName.contains(input);
    }).toList();
    searchFriends = suggestion;
    notifyListeners();
  }
}

extension CutList<T> on List<T?> {
  List<T?> cutList(List<T?> oldList, int newLength) {
    return List<T?>.filled(newLength, null)..setRange(0, math.min(newLength, oldList.length), oldList);
  }
}
