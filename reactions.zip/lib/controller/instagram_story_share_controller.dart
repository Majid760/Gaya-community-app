// import 'dart:io' show File;
//
// import 'package:flutter/foundation.dart' show debugPrint;
// import 'package:flutter/services.dart' show ByteData, Uint8List, rootBundle;
// import 'package:get/get.dart';
// import 'package:image_picker/image_picker.dart' show ImagePicker, ImageSource;
// import 'package:path_provider/path_provider.dart';
// import 'package:screenshot/screenshot.dart' show ScreenshotController;
// import 'package:social_share/social_share.dart';
//
// import '../utils/asset_video.dart';
//
// class InstagramStoryShareController extends GetxController {
//   /// static getter to get instance of InstagramStoryShareController
//   static InstagramStoryShareController get instance => Get.find();
//
//   /* -------------------------------------------------------------------------- */
//   /*                               STATE VARIABLES                              */
//   /* -------------------------------------------------------------------------- */
//   /// instance of ScreenshotController for taking ss of widgets
//   ScreenshotController screenshotController = ScreenshotController();
//
//   /// callback to execute on share on you story button tap
//   Future<void> sharePost() async {
//     try {
//       // loading video from assets for BG
//       ByteData videoByteData = await rootBundle.load(
//         VideoAssetsUtils.instaStoryBg,
//       );
//       // creating bg vide file from [videoByteData]
//       File videoFile =
//           await File('${(await getTemporaryDirectory()).path}/bg.mp4')
//               .writeAsBytes(
//         videoByteData.buffer.asUint8List(
//           videoByteData.offsetInBytes,
//           videoByteData.lengthInBytes,
//         ),
//       );
//
//       // // getting screen shot image bytes from ssController
//       // Uint8List? imageBytesList = await screenshotController.capture();
//       // // creating ss image file
//       // File ssFile = File('${(await getTemporaryDirectory()).path}/ss.png');
//
//       // loading post image from assets for BG
//       ByteData postByteData = await rootBundle.load(
//         'Assets/images/post_image.jpg',
//       );
//       // creating post file from [postByteData]
//       File postFile =
//           await File('${(await getTemporaryDirectory()).path}/post.jpg')
//               .writeAsBytes(
//         postByteData.buffer.asUint8List(
//           postByteData.offsetInBytes,
//           postByteData.lengthInBytes,
//         ),
//       );
//
//       // sharing post data to instagram story
//       SocialShare.shareInstagramStory(
//         appId: '924808208588215', // mateen
//         // appId: '939959917386507', //gaya
//         imagePath: postFile.path,
//         backgroundResourcePath: videoFile.path,
//       );
//     } catch (e) {
//       debugPrint(e.toString());
//     }
//   }
//
//   /* -------------------------------------------------------------------------- */
//   /*                                HELPER API'S                                */
//   /* -------------------------------------------------------------------------- */
//   /// invoke to pick image form gallery
//   Future<String?> pickImage() async {
//     final file = await ImagePicker().pickImage(
//       source: ImageSource.gallery,
//     );
//
//     return file?.path;
//   }
// }
