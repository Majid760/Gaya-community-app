import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:gaya/components/button.component.dart';
import 'package:gaya/generated/assets.dart';
import 'package:gaya/utils/const.dart';
import 'package:gaya/utils/language/translation.dart';
import 'package:gaya/utils/textstyles.dart';
import 'package:get/get_utils/src/extensions/internacionalization.dart';
import 'package:permission_handler/permission_handler.dart';

class NotificationController extends ChangeNotifier {
  List docId = [];

  final FirebaseAuth _firebaseInstance = FirebaseAuth.instance;
  late ScrollController notificationsScrollController;
  bool isNotificationsLoaded = false;
  PermissionStatus? _permissionStatus;

  changeNotificationsLoadedStatus() {
    if (isNotificationsLoaded) return;
    isNotificationsLoaded = true;
    notifyListeners();
  }

  Future<void> checkPermissionStatus() async {
    final status = await Permission.microphone.status;

    _permissionStatus = status;
    notifyListeners();
  }

  void showBottomSheetIfNeeded(BuildContext context) {
    if (_permissionStatus != PermissionStatus.granted) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _showBottomSheet(context);
      });
    }
  }

  void _showBottomSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.only(topLeft: Radius.circular(13.0), topRight: Radius.circular(13.0))),
      builder: (BuildContext context) {
        return SafeArea(
          child: SizedBox(
            height: MediaQuery.of(context).size.height * 0.75,
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 15.0.r),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  SizedBox(height: 12.h),
                  Container(height: 4.h, width: 40.w, decoration: const BoxDecoration(color: kBaseGrey)),
                  SizedBox(height: 50.h),
                  Expanded(
                      child: Column(
                    children: [
                      SizedBox(
                        height: 120.h,
                        width: 120.w,
                        child: SvgPicture.asset(Assets.bellNotification),
                      ),
                      Text(
                        GayaStrings.enable_notification.tr,
                        textAlign: TextAlign.center,
                        style: TextStyle(fontWeight: FontWeight.w700, fontFamily: GayaFontTheme.primaryFont, fontSize: 28.sp),
                      ),
                      SizedBox(height: 20.h),
                      SizedBox(
                        width: MediaQuery.of(context).size.width * 0.7,
                        child: Center(
                          child: Text(
                            GayaStrings.receive_latest_update.tr,
                            textAlign: TextAlign.center,
                            style: TextStyle(fontWeight: FontWeight.normal, fontFamily: GayaFontTheme.primaryFont, fontSize: 16.sp),
                          ),
                        ),
                      ),
                      SizedBox(height: 50.h),
                      GayaButton(
                          height: 50.h,
                          textStyle: body2Style,
                          borderColor: kTransparentColor,
                          title: GayaStrings.turn_on_notifications.tr,
                          onPressed: () {
                            openAppSettings();
                          },
                          primaryColor: kpurpleColor),
                      SizedBox(height: 20.h),
                      GestureDetector(
                        onTap: () => Navigator.of(context).pop(),
                        child: Text(
                          GayaStrings.skip_for_now.tr,
                          textAlign: TextAlign.center,
                          style: TextStyle(fontWeight: FontWeight.normal, fontFamily: GayaFontTheme.primaryFont, fontSize: 16.sp),
                        ),
                      ),
                    ],
                  ))
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  void scrollToTop() {
    try {
      if (notificationsScrollController.hasClients == false) return;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        notificationsScrollController.animateTo(
          notificationsScrollController.position.minScrollExtent,
          duration: const Duration(milliseconds: 350),
          curve: Curves.bounceIn,
        );
      });
    } catch (_) {}
  }

  Future<void> getNotifications() {
    return Future.delayed(const Duration(milliseconds: 500));
  }

  Stream<QuerySnapshot<Object?>>? friendrequestNotificationsStream() {
    try {
      User? user = _firebaseInstance.currentUser;

      if (user == null) return null;

      return FirebaseFirestore.instance
          .collection('friendship')
          .where('Recieveruid', isEqualTo: user.uid)
          .where('isaccepted', isEqualTo: false)
          .snapshots();
    } catch (e) {
      return null;
    }
  }

  aproveFriendRequest(String docId) async {
    try {
      await FirebaseFirestore.instance.collection('friendship').doc(docId).update({'isaccepted': true});
      notifyListeners();
    } catch (_) {}
  }

  rejectFriendrequest(String docId) async {
    try {
      await FirebaseFirestore.instance.collection('friendship').doc(docId).delete();
      notifyListeners();
    } catch (_) {}
  }
}
