import 'package:cloud_firestore/cloud_firestore.dart';
abstract class IPhoneMessage {
  Future<String> sendSMS({required String phone, required String message});

  Stream<DocumentSnapshot<Map<String, dynamic>>> listenToSentMessage({required String docId});
}

class PhoneMessageServices implements IPhoneMessage {
  final twillioRef = FirebaseFirestore.instance.collection('twillioMessages');

  @override
  Future<String> sendSMS({required String phone, required String message}) async {

    return (await twillioRef.add({'to': phone, 'body': message})).id;
  }

  @override
  Stream<DocumentSnapshot<Map<String, dynamic>>> listenToSentMessage({required String docId}) {
    return twillioRef.doc(docId).snapshots();
  }
}
