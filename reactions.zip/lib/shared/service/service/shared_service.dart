import 'dart:developer';

enum Gender {
  male,
  female,
  nonBinary,
}

class SharedService {
  // gender list
  static List<Gender> genderStringList = [Gender.male, Gender.female, Gender.nonBinary];

  static String genderString(Gender gender) => Gender.nonBinary == gender ? "Non-Binary" : gender.name;

  static int daysInYear = 365;

  //// this function is just for calculating and validating the age of uer entered age
  static bool isEnteredAgeValid(DateTime dateTime, int age) {
    try {
      Duration difference = DateTime.now().difference(dateTime);
      double diffInYear = difference.inDays / daysInYear;
      return (diffInYear >= age);
    } catch (e) {
      log('error caught during age calculating');
      return false;
    }
  }
}
