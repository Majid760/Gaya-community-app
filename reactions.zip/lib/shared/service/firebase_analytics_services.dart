import 'dart:io';

import 'package:firebase_analytics/firebase_analytics.dart';
import 'package:flutter/foundation.dart';
import 'package:gaya/shared/service/service/version_platform_services.dart';

import 'engagement_score_services/engagement_helpers/engagement_enums.dart';

class FirebaseAnalyticsService {
  FirebaseAnalyticsService();

  final FirebaseAnalytics _analytics = FirebaseAnalytics.instance;

  final FirebaseAnalyticsObserver observer =
      FirebaseAnalyticsObserver(analytics: FirebaseAnalytics.instance);

  Future<void> setScreen(String screenName) async {
    try {
      await _analytics.setCurrentScreen(screenName: screenName);
    } catch (_) {}
  }

  Future<void> setUserId(String userId) async {
    await _analytics.setUserId(id: userId);
  }

  Future<void> setUserProperty(String name, String value) async {
    await _analytics.setUserProperty(name: name, value: value);
  }

  Future<void> logLogin() async {
    await _logEvent('login', {});
  }

  Future<void> logSignUp() async {
    await _logEvent('sign_up', {});
  }

  Future<void> logLogout() async {
    await _logEvent('logout', {});
  }

  Future<void> logHomeLogoTapped() async {
    await _logEvent('home_logo_tapped', {});
  }

  Future<void> logChangeName(
      {required String oldName, required String newName}) async {
    await _logEvent('change_name', {'old_name': oldName, 'new_name': newName});
  }

  Future<void> logDeleteAccount({required String id, required Map? metadata}) {
    return _logEvent('delete_account', {'id': id, 'metadata': metadata});
  }

  Future<void> logUserWithOldVersion() async {
    await _logEvent('old_version', {});
  }

  Future<void> logViewPicture({required List<String> urls}) async {
    try {
      await _logEvent('view_picture', {
        'url': urls.toString(),
      });
    } catch (_) {}
  }

  Future<void> logInviteHomeButton({bool isTappedOnly = true}) async {
    return _logEvent(
        'invite_home_button', {'is_tapped_only': isTappedOnly.toString()});
  }

  Future<void> logShare(String contentType, String itemId, String event,
      {bool isCopy = false}) async {
    try {
      await _logEvent(isCopy ? "copy" : 'share', {
        'content_type': contentType,
        'item_id': itemId,
      });
    } on Exception catch (_) {}
  }

  Future<void> deleteComment({
    required String commentId,
    required String postId,
  }) async {
    try {
      await _logEvent('delete_comment', {
        'comment_id': commentId,
        'post_id': postId,
      });
    } catch (_) {}
  }

  Future<void> logCurrentTab(int index) async {
    await _logEvent('current_tab', {
      'index': index,
      'name': index == 0
          ? 'home'
          : index == 1
              ? 'communities'
              : index == 2
                  ? 'topics'
                  : index == 3
                      ? 'notifications'
                      : 'profile'
    });
  }

  Future<void> logViewCrownRemainingSheet() {
    return _logEvent('view_crown_remaining_sheet', {});
  }

  Future<void> logSearch(String contentType, String itemId) async {
    try {
      await _logEvent('search', {
        'content_type': contentType,
        'item_id': itemId,
      });
    } catch (_) {}
  }

  Future<void> logOpenRoom({required String? name, required String? id}) async {
    try {
      await _logEvent('open_room', {
        'name': name,
        'id': id,
      });
    } catch (_) {}
  }

  Future<void> logCreatePost({required String communityId}) async {
    try {
      return _logEvent('create_post', {
        'community_id': communityId,
      });
    } catch (_) {}
  }

  Future<void> logSelectContent(String contentType, String id) async {
    try {
      await _logEvent('select_content', {
        'content_type': contentType,
        'id': id,
      });
    } catch (_) {}
  }

  Future<void> logViewItemList(String contentType) async {
    try {
      await _logEvent('view_item_list', {
        'content_type': contentType,
      });
    } catch (_) {}
  }

  Future<void> logViewSearchResults(String contentType) async {
    try {
      await _logEvent('view_search_results', {
        'content_type': contentType,
      });
    } catch (_) {}
  }

  Future<void> logCheckCrown() {
    return _logEvent('check_crown', {});
  }

  Future<void> logReply(String contentType, String itemId) async {
    try {
      await _logEvent('reply', {
        'content_type': contentType,
        'item_id': itemId,
      });
    } catch (_) {}
  }

  Future<void> logUnlike(String contentType, String itemId) async {
    try {
      await _logEvent('remove_from_like', {
        'content_type': contentType,
        'item_id': itemId,
      });
    } catch (_) {}
  }

  Future<void> logAddToSaveList(String contentType, String itemId) async {
    try {
      await _logEvent('add_to_save', {
        'content_type': contentType,
        'item_id': itemId,
      });
    } catch (_) {}
  }

  Future<void> goToSavedList() async {
    try {
      await _logEvent('go_to_saved_list', {});
    } catch (_) {}
  }

  Future<void> logRemoveFromSaveList(String contentType, String itemId) async {
    try {
      await _logEvent('remove_from_save', {
        'content_type': contentType,
        'item_id': itemId,
      });
    } catch (_) {}
  }

  Future<void> logRreportPost(String contentType, String itemId) async {
    try {
      await _logEvent('report_post', {
        'content_type': contentType,
        'item_id': itemId,
      });
    } catch (_) {}
  }

  Future<void> logReportUser(String contentType, String itemId) async {
    try {
      await _logEvent('report_user', {
        'content_type': contentType,
        'item_id': itemId,
      });
    } catch (_) {}
  }

  Future<void> logReportComment(String contentType, String itemId) async {
    try {
      await _logEvent('report_comment', {
        'content_type': contentType,
        'item_id': itemId,
      });
    } catch (_) {}
  }

  Future<void> logReportReply(String contentType, String itemId) async {
    try {
      await _logEvent('report_reply', {
        'content_type': contentType,
        'item_id': itemId,
      });
    } catch (_) {}
  }

  Future<void> logPickImage() async {
    await _logEvent('pick_image', {});
  }

  Future<void> logPickVideo() async {
    await _logEvent('pick_video', {});
  }

  Future<void> cropImage() async {
    await _logEvent('crop_image', {});
  }

  Future<void> cropVideo() async {
    await _logEvent('crop_image', {});
  }

  Future<void> logSeeAllCommunities(String category, String type) async {
    try {
      await _logEvent('see_all_comment', {
        'category': category,
        'type': type,
      });
    } catch (_) {}
  }

  Future<void> logSeeAll(
    String screen,
  ) async {
    try {
      await _logEvent('see_all', {
        'screen': screen,
      });
    } catch (_) {}
  }

  Future<void> logRefreshUserView() async {
    await _logEvent('refresh_user_view', {});
  }

  Future<void> logViewUser(String userId) async {
    try {
      await _logEvent('view_user', {
        'user_id': userId,
      });
    } catch (_) {}
  }

  Future<void> logViewUserPost(String userId, String postId) async {
    try {
      await _logEvent('view_user_post', {
        'user_id': userId,
        'post_id': postId,
      });
    } catch (_) {}
  }

  Future<void> logViewCommunityModal(String communityId) async {
    try {
      await _logEvent('view_community_modal', {
        'community_id': communityId,
      });
    } catch (_) {}
  }

  Future<void> logViewCommunity(String communityId) async {
    try {
      await _logEvent('view_community', {
        'community_id': communityId,
      });
    } catch (_) {}
  }

  Future<void> logViewMessage(String userId) async {
    try {
      await _logEvent('view_message', {
        'user_id': userId,
      });
    } catch (_) {}
  }

  Future<void> logViewNotification(String notificationId) async {
    try {
      await _logEvent('view_notification', {
        'notification_id': notificationId,
      });
    } catch (_) {}
  }

  Future<void> logViewPost(String postId) async {
    try {
      await _logEvent('view_post', {
        'post_id': postId,
      });
    } catch (_) {}
  }

  Future<void> logScore({required EngagementEvent event}) async {
    try {
      await _logEvent('score', {'event': event.name});
    } catch (_) {}
  }

  /// invoke to log event if a user joins a new community
  Future<void> logUserAddedToCommunity({
    required String communityId,
    required String userId,
  }) async {
    try {
      await _logEvent(
        'user_joined_community',
        {
          'community_id': communityId,
          'user_id': userId,
          'user_added_on': DateTime.now().toIso8601String(),
        },
      );
    } catch (e) {
      debugPrint(e.toString());
    }
  }

  /// invoke to log new post added to community
  Future<void> logCreateNewPost({
    required String communityId,
    required String userId,
  }) async {
    try {
      await _logEvent(
        'create_new_post',
        {
          'community_id': communityId,
          'user_id': userId,
          'post_created_on': DateTime.now().toIso8601String(),
        },
      );
    } catch (e) {
      debugPrint(e.toString());
    }
  }

  /// invoke to log event if a user joins a new community
  Future<void> logCommunityView({
    required String communityId,
    required String userId,
  }) async {
    try {
      await _logEvent(
        'community_view',
        {
          'community_id': communityId,
          'user_id': userId,
          'user_added_on': DateTime.now().toIso8601String(),
        },
      );
    } catch (e) {
      debugPrint(e.toString());
    }
  }

  /// invoke to log like event to post/comment/sub-comments
  Future<void> logAddToLike(
    String contentType,
    String itemId, {
    required String? communityId,
  }) async {
    try {
      await _logEvent(
        'add_to_like',
        {
          'content_type': contentType,
          'item_id': itemId,
          'community_id': communityId,
          'like_dislike_on': DateTime.now().toIso8601String(),
        },
      );
    } catch (e) {
      debugPrint(e.toString());
    }
  }

  /// invoke to log to new comment adding event
  Future<void> logAddNewComment({
    required String commentId,
    String? communityId,
    String? commentContentTypeId, // post or comment
    String? commenterId,
  }) async {
    try {
      await _logEvent(
        'add_new_comment',
        {
          'comment_content_type_id': commentContentTypeId,
          'community_id': communityId,
          'comment_id': commentId,
          'commenter_id': commenterId,
          'comment_added_on': DateTime.now().toIso8601String(),
        },
      );
    } catch (e) {
      debugPrint(e.toString());
    }
  }

  /// invoke to log crown add events
  Future<void> logAddCrown(
    String contentType,
    String itemId, {
    String? crownGiverId,
    String? communityId,
  }) async {
    try {
      await _logEvent('add_crown', {
        'content_type': contentType,
        'item_id': itemId,
        'crown_giver_id': crownGiverId,
        'community_id': communityId,
        'crown_added_on': DateTime.now().toIso8601String(),
      });
    } catch (e) {
      debugPrint(e.toString());
    }
  }

  Future<void> _logEvent(String name, Map<String, dynamic> parameters) async {
    if (kDebugMode) return;
    try {
      parameters['timestamp'] = DateTime.now().millisecondsSinceEpoch;
      parameters['platform'] = Platform.operatingSystem;
      parameters['version'] =
          (await VersionPlatformServices.to.getPlatformInfo())?.version ??
              'unknown';

      await _analytics.logEvent(name: name, parameters: parameters);
      debugPrint('log event $name $parameters');
    } catch (_) {
      debugPrint('log event error $_ $name $parameters');
    }
  }
}
