import 'package:connectycube_sdk/connectycube_sdk.dart' as Connectycube;
// import 'package:connectycube_sdk/connectycube_sdk.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gaya/components/image_swiper.dart';
import 'package:gaya/components/profile_image_widget.dart';
import 'package:gaya/routing/getx_route_methods.dart';
import 'package:gaya/utils/const.dart';
import 'package:gaya/utils/theme/app_colors.dart';
import 'package:gaya/view/chat/components/audio_widget.dart';
import 'package:gaya/view/chat/components/network_pdf_view.dart';
import 'package:gaya/view/chat/components/play_video_widget.dart';
import 'package:gaya/view/chat/components/text_link_widget.dart';
import 'package:gaya/view/chat/helper/helper_functions.dart';
import 'package:gaya/view/messaging/components/load_message_as_communitypreview.dart';
import 'package:gaya/view/messaging/components/load_message_as_postpreview.dart';
import 'package:get/get.dart';
import 'package:get/get_utils/src/get_utils/get_utils.dart';
import 'package:get/utils.dart';

class UserMessageWidget extends StatefulWidget {
  // final Message currentMessage;
  final VoidCallback onLongTap;
  final int index;
  final MessageType messageType;
  final Connectycube.CubeMessage? message;
  final String dialogId;
  String sentTime = '';
  String deliveryStatus = '';

  UserMessageWidget(
      {super.key,
      // required this.currentMessage,
      required this.onLongTap,
      required this.index,
      this.message,
      required this.messageType,
      required this.dialogId,
      required this.sentTime,
      required this.deliveryStatus});

  @override
  State<UserMessageWidget> createState() => _UserMessageWidgetState();
}

class _UserMessageWidgetState extends State<UserMessageWidget> {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onLongPress: widget.onLongTap,
      child: Padding(
        padding: const EdgeInsets.only(top: distance_10, bottom: distance_10),
        child: Align(
          alignment: Alignment.bottomRight,
          child: LayoutBuilder(
            builder: (context, constraints) {
              if ((widget.messageType == MessageType.nullAttachment) && (widget.message!.body == null || widget.message!.body!.isEmpty)) {
                return const SizedBox.shrink();
              } else {
                // returns type of widget whether it's text, image,video...
                if (widget.messageType == MessageType.community) {
                  return widget.message!.attachments != null && !isListEmptyOrNull(widget.message!.attachments)
                      ? LoadCommunityMessageWidget(
                          message: widget.message,
                          sentTime: widget.sentTime,
                          deliveryStatus: widget.deliveryStatus,
                        )
                      : const SizedBox.shrink();
                } else if (widget.messageType == MessageType.post) {
                  return widget.message!.attachments != null && !isListEmptyOrNull(widget.message!.attachments)
                      ? LoadPostMessageWidget(
                          message: widget.message,
                          sentTime: widget.sentTime,
                          deliveryStatus: widget.deliveryStatus,
                        )
                      // LoadPostMessage(postId: widget.message!.attachments!.first.data.toString(), isCurrentUser: false)
                      : const SizedBox.shrink();
                } else if (widget.messageType == MessageType.link) {
                  return widget.message!.attachments != null && !isListEmptyOrNull(widget.message!.attachments)
                      ? TextlinkWidget(
                          isLink: GetUtils.isURL(widget.message!.attachments!.first.data.toString()),
                          text: widget.message!.attachments!.first.data ?? '',
                          currentMessage: widget.message!,
                          mySelf: true,
                          sentTime: widget.sentTime,
                          deliveryStatus: widget.deliveryStatus,
                        )
                      : const SizedBox.shrink();
                } else if (widget.messageType == MessageType.image) {
                  return widget.message!.attachments != null && !isListEmptyOrNull(widget.message!.attachments)
                      ? SizedBox(
                          height: 200.h,
                          width: 150.w,
                          child: GestureDetector(
                            onTap: () {
                              if (widget.message!.attachments!.first.url != null) {
                                List<String> images = [widget.message!.attachments!.first.url!];
                                Routes.openImages(urls: images, index: 0, ctx: context);
                              }
                            },
                            child: Stack(
                              children: [
                                Container(
                                    clipBehavior: Clip.antiAlias,
                                    decoration: BoxDecoration(borderRadius: BorderRadius.circular(12).r),
                                    child: ScrolledHero(
                                        tag: widget.message!.attachments!.first,
                                        transitionOnUserGestures: true,
                                        child: PostImageWidget(url: widget.message!.attachments!.first.url))),
                                Positioned(
                                    bottom: 4.r,
                                    right: 4.r,
                                    child: Row(
                                      children: [
                                        Text(
                                          widget.sentTime,
                                          style: TextStyle(color: AppColors.white, fontSize: 10.0.sp, fontStyle: FontStyle.italic),
                                        ),
                                        Row(
                                          children: [
                                            SizedBox(
                                              width: 4.r,
                                            ),
                                            getReadDeliveredWidget(widget.deliveryStatus),
                                          ],
                                        )
                                      ],
                                    ))
                              ],
                            ),
                          ))
                      : const SizedBox.shrink();
                } else if (widget.messageType == MessageType.video) {
                  return PlayVideoWidget(
                    currentMessage: widget.message!,
                    sentTime: widget.sentTime,
                    deliveryStatus: widget.deliveryStatus,
                    mySelf: true,
                  );
                } else if (widget.messageType == MessageType.audio) {
                  return widget.message!.attachments != null && !isListEmptyOrNull(widget.message!.attachments)
                      ? AudioWidget(
                    isCurrentUser: true,
                          audioPath: widget.message!.attachments!.first.url!,
                          sentTime: widget.sentTime,
                          deliveryStatus: widget.deliveryStatus,
                          duration: widget.message?.properties['duration'],
                        )
                      : const SizedBox.shrink();
                } else if (widget.messageType == MessageType.document) {
                  return widget.message!.attachments != null && !isListEmptyOrNull(widget.message!.attachments)
                      ? NetworkPDFView(
                          path: widget.message!.attachments!.first.url!,
                          filename: widget.message!.attachments!.first.name ?? '',
                          chatDialogId: widget.dialogId,
                          width: 230.w,
                          thumbnailUrl: widget.message!.attachments!.first.data,
                          sentTime: widget.sentTime,
                          deliveryStatus: widget.deliveryStatus,
                          mySelf: true,
                        )
                      : const SizedBox.shrink();
                }
                return widget.message!.body != null && (widget.message!.body?.isNotEmpty ?? false)
                    ? TextlinkWidget(
                        isLink: GetUtils.isURL(widget.message!.body.toString()),
                        text: widget.message!.body ?? '',
                        currentMessage: widget.message!,
                        mySelf: true,
                        sentTime: widget.sentTime,
                        deliveryStatus: widget.deliveryStatus,
                      )
                    : const SizedBox.shrink();
              }
            },
          ),
        ),
      ),
    );
  }
}
