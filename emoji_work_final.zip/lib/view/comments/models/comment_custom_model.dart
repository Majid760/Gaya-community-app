import 'dart:io';

import 'package:gaya/model/reaction_model.dart';
import 'package:gaya/model/user.model.dart';

enum MediaSource { local, network, idle }

class MultiCommentModel {
  CommentCustomModel comment;
  List<CommentCustomModel> replies;

  MultiCommentModel({required this.comment, this.replies = const []});

  void addReply(CommentCustomModel reply) {
    replies.add(reply);
  }
}

class CommentCustomModel {
  final String id;
  final String comment;
  final UserModel user;
  int totalLikes;
  int totalCrowns;
  // int totalFlowers;
  bool isLiked;
  // bool isFlower;
  bool isCrown;
  final DateTime createdAt;
  final String? photoUrl;
  final Map<String, dynamic>? videoUrl;
  final File? photoFile;
  final File? videoFile;
  final MediaSource mediaSource;
  final File? documentFile;
  final List<Map<String, dynamic>>? mentionedUsers;
  final List<Map<String, dynamic>>? pdfFiles;

  // Reaction parameters
  ReactionModel? reactionModel;
  PostReactionDataModel? commentReactionData;

  CommentCustomModel(
      {required this.id,
      required this.comment,
      required this.user,
      required this.createdAt,
      this.totalLikes = 0,
      this.totalCrowns = 0,
      // this.totalFlowers = 0,
      this.isLiked = false,
      this.isCrown = false,
      // this.isFlower = false
      this.photoUrl,
      this.videoUrl,
      this.videoFile,
      this.photoFile,
      this.mediaSource = MediaSource.network,
      this.mentionedUsers,
      this.documentFile,
      this.pdfFiles,
      this.reactionModel,
      this.commentReactionData});

  CommentCustomModel copyWithLike({bool shouldUnlike = false}) {
    return CommentCustomModel(
      id: this.id,
      comment: this.comment,
      user: this.user,
      createdAt: this.createdAt,
      totalLikes: shouldUnlike == false
          ? this.totalLikes + 1
          : this.totalLikes > 0
              ? this.totalLikes - 1
              : this.totalLikes,
      totalCrowns: this.totalCrowns,
      isLiked: !this.isLiked,
      isCrown: this.isCrown,
      photoUrl: photoUrl ?? this.photoUrl,
      videoUrl: videoUrl ?? this.videoUrl,
      photoFile: photoFile ?? this.photoFile,
      videoFile: videoFile ?? this.videoFile,
      mediaSource: mediaSource,
      mentionedUsers: mentionedUsers ?? this.mentionedUsers,
      pdfFiles: pdfFiles,
      documentFile: documentFile,
      // isFlower: this.isFlower,
      reactionModel: reactionModel,
      commentReactionData: commentReactionData,
    );
  }

  CommentCustomModel copyWithFlower({bool shouldUnCrown = false}) {
    return CommentCustomModel(
      id: this.id,
      comment: this.comment,
      user: this.user,
      createdAt: this.createdAt,
      totalLikes: this.totalLikes,
      totalCrowns: shouldUnCrown == false
          ? this.totalCrowns + 1
          : this.totalCrowns > 0
              ? this.totalCrowns - 1
              : this.totalCrowns,
      isLiked: this.isLiked,
      isCrown: !this.isCrown,
      photoUrl: photoUrl ?? this.photoUrl,
      videoUrl: videoUrl ?? this.videoUrl,
      photoFile: photoFile ?? this.photoFile,
      videoFile: videoFile ?? this.videoFile,
      mediaSource: mediaSource,
      mentionedUsers: mentionedUsers ?? this.mentionedUsers,
      pdfFiles: pdfFiles ?? this.pdfFiles,
      documentFile: documentFile,
      reactionModel: reactionModel,
      commentReactionData: commentReactionData,
      // isFlower: !this.isFlower,
    );
  }

  copyWith({
    String? id,
    String? comment,
    UserModel? user,
    int? totalLikes,
    int? totalCrowns,
    // int? totalFlowers,
    bool? isLiked,
    bool? isCrown,
    // bool? isFlower,
    DateTime? createdAt,
    String? photoUrl,
    Map<String, dynamic>? videoUrl,
    File? photoFile,
    File? videoFile,
    File? documentFile,
    MediaSource? mediaSource,
    List<Map<String, dynamic>>? mentionedUsers,
    List<Map<String, dynamic>>? pdfFiles,

    // Reaction parameters
    ReactionModel? reactionModel,
    PostReactionDataModel? commentReactionData,
  }) {
    return CommentCustomModel(
      id: id ?? this.id,
      comment: comment ?? this.comment,
      user: user ?? this.user,
      totalLikes: totalLikes ?? this.totalLikes,
      totalCrowns: totalCrowns ?? this.totalCrowns,
      isLiked: isLiked ?? this.isLiked,
      isCrown: isCrown ?? this.isCrown,
      createdAt: createdAt ?? this.createdAt,
      photoUrl: photoUrl ?? this.photoUrl,
      videoUrl: videoUrl ?? this.videoUrl,
      mediaSource: mediaSource ?? this.mediaSource,
      mentionedUsers: mentionedUsers ?? this.mentionedUsers,
      pdfFiles: pdfFiles ?? this.pdfFiles,
      documentFile: documentFile ?? this.documentFile,

      reactionModel: reactionModel,
      commentReactionData: commentReactionData,
      //
    );
  }
}
