import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_feed_reaction/flutter_feed_reaction.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gaya/controller/firebase_analytics_controller.dart';
import 'package:gaya/controller/report_controller.dart';
import 'package:gaya/model/create.post.model.dart';
import 'package:gaya/model/user.model.dart';
import 'package:gaya/routing/getx_route_methods.dart';
import 'package:gaya/shared/view/widget/gaya_report_dialog.dart';
import 'package:gaya/utils/assets_icons.dart';
import 'package:gaya/utils/const.dart';
import 'package:gaya/utils/language/translation.dart';
import 'package:gaya/utils/methods.dart';
import 'package:gaya/utils/strings.dart';
import 'package:gaya/utils/theme/app_colors.dart';
import 'package:gaya/utils/theme/app_typography.dart';
import 'package:gaya/view/comments/controller/comments_controller.dart';
import 'package:gaya/view/comments/controller/post_with_comment_controller.dart';
import 'package:gaya/view/comments/models/comment_custom_model.dart';
import 'package:gaya/view/comments/view/reply_comment_view.dart';
import 'package:gaya/widgets/post.with.comments.widgets/actionrow.widget.dart';
import 'package:gaya/widgets/post.with.comments.widgets/comments.dart';
import 'package:get/get.dart';
import 'package:jiffy/jiffy.dart';

/// This is the replies listview that is used in the [ParentCommentsListView]
class RepliesListView extends StatelessWidget {
  final String? postId;
  final CommentsController controller;
  final PostWithCommentController postWithCommentController;
  final UserModel replyBy;
  final CommentCustomModel reply;
  final MultiCommentModel comments;
  final int index;
  final Post post;

  const RepliesListView(
      {Key? key,
      required this.controller,
      required this.postWithCommentController,
      this.postId,
      required this.replyBy,
      required this.reply,
      required this.comments,
      required this.index,
      required this.post})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    final bodyReactionStyle = GayaTypography.caption.copyWith(color: AppColors.secondary);
    final primaryReactionStyle = GayaTypography.caption.copyWith(color: AppColors.primary);
    final yellowReactionStyle = GayaTypography.caption.copyWith(color: AppColors.warning);
    return Column(
      children: [
        CommentSection(
          showDialogBox: () {
            debugPrint("called Im");
            String? userUid = FirebaseAuth.instance.currentUser?.uid;
            bool isMyComment = replyBy.uId == userUid || post.community.adminUid == userUid;
            Methods.showModalSheetComment(context, () {
              AnalyticsController.to.instance.logReportComment("parent_comment", reply.id);
              reportTextFieldBottomModal(context, onSubmit: (String reportMsg) async {
                Navigator.pop(context);
                await ReportController.to.reportAComment(
                    content: reply.comment.toString(),
                    reportMsg: reportMsg,
                    reportedCommentId: reply.id,
                    context: context,
                    postId: postWithCommentController.post.postid ?? "");
              });
            }, onCommentDelete: isMyComment ? () => controller.deleteChildComment(comments.comment.id, reply.id) : null);
          },
          nameOnTap: () {
            Routes.viewProfile(uid: replyBy.uId, model: replyBy);
          },
          userOntap: () {
            Routes.viewProfile(uid: replyBy.uId, model: replyBy);
          },
          anonymousPic: postWithCommentController.post.isPostedAnonymously ?? false,
          userUid: replyBy.uId!,
          uId: postWithCommentController.post.postedBy.uId,
          profilepic: replyBy.profilePicture,
          content: reply.comment,
          name: postWithCommentController.post.isPostedAnonymously == true
              ? postWithCommentController.post.postedBy.uId == reply.user.uId
                  ? anonymousUser
                  : reply.user.name
              : reply.user.name,
          time: Jiffy(reply.createdAt).fromNow(),
          videoFile: reply.videoFile,
          photoFile: reply.photoFile,
          videoUrl: reply.videoUrl,
          photoUrl: reply.photoUrl,
          mentionedListUsers: reply.mentionedUsers,
          documentFile: reply.documentFile,
          pdfFiles: reply.pdfFiles,
          postId: post.postid ?? '',
        ),
        Padding(
          padding: const EdgeInsets.only(left: distance_50),
          child: ActionRow(
            childPadding: 0,
            // likeWidget: reply.totalLikes < 1
            //     ? Text(GayaStrings.like_txt.tr, style: bodyReactionStyle)
            //     : Row(
            //         children: [
            //           Text(GayaStrings.like_txt.tr,
            //               style: (reply.isLiked)
            //                   ? primaryReactionStyle
            //                   : bodyReactionStyle),
            //           const SizedBox(width: distance_5),
            //           CircleAvatar(
            //               radius: 1,
            //               backgroundColor:
            //                   (reply.isLiked) ? kprimaryColor : kBaseGrey),
            //           const SizedBox(width: distance_5),
            //           SvgIconWidget.heartFilled(
            //               color: (reply.isLiked) ? kprimaryColor : kBaseGrey,
            //               height: 12.h,
            //               width: 14.h),
            //           // SvgPicture.asset(Assets.assets.icons.heartIcon,
            //           //     // ignore: deprecated_member_use
            //           //     color: (reply.isLiked) ? kprimaryColor : kBaseGrey),
            //           const SizedBox(width: distance_5),
            //           Text(reply.totalLikes.toString(),
            //               style: (reply.isLiked)
            //                   ? primaryReactionStyle
            //                   : bodyReactionStyle),
            //         ],
            //       ),
            likeWidget:
                // reply.totalLikes < 1
                //     ? Text(GayaStrings.like_txt.tr, style: bodyReactionStyle)
                //     :
                Row(
              children: [
                // like reaction button
                Builder(builder: (context) {
                  Widget prefixWidget =
                      Methods.getMyReactionIcon(reply.reactionModel?.reaction, postReactionData: reply.commentReactionData, iconSize: 13.r);
                  Widget suffixWidget = Methods.getMyReactionText(reply.reactionModel?.reaction,
                      postReactionData: reply.commentReactionData, fontSize: 12.5.r);
                  List<int>? reactionsCountList = Methods.getReactionsCountsList(postReactionData: reply.commentReactionData);
                  return FlutterFeedReaction(
                    reactions: Methods.reactions,
                    dragSpace: 30.0.r,
                    dragStart: 150.0.r,
                    reactionsCountList: reactionsCountList,
                    onReactionSelected: (val) {
                      if (reply.reactionModel == null) {
                        likeReactionOnTap(val.name, true);
                      } else if (reply.reactionModel?.reaction == val.name) {
                        likeReactionOnTap(val.name, false);
                      } else {
                        likeReactionOnTap(val.name, true);
                      }
                    },
                    onPressed: () {
                      if (reply.reactionModel == null) {
                        likeReactionOnTap('Love', true);
                      } else {
                        likeReactionOnTap(reply.reactionModel?.reaction, false);
                      }
                    },
                    prefix: prefixWidget,
                    suffix: Padding(padding: const EdgeInsets.only(top: 1).r, child: suffixWidget),
                    containerWidth: 162.0.r,
                    spacing: 6.r,
                  );
                }),
              ],
            ),
            flowerWidget: reply.totalCrowns < 1
                ? Text(GayaStrings.crown_txt.tr, style: bodyReactionStyle)
                : Row(
                    children: [
                      Text(GayaStrings.crown_txt.tr, style: (reply.isCrown) ? yellowReactionStyle : bodyReactionStyle),
                      const SizedBox(width: distance_5),
                      CircleAvatar(radius: 1, backgroundColor: (reply.isCrown) ? kYellowColor : kBaseGrey),
                      const SizedBox(width: distance_5),
                      SvgIconWidget.crownFilledd(color: kYellowColor, height: 12.h, width: 14.h),
                      // SvgPicture.asset('Assets/images/grey_crown.svg',
                      //     color: kYellowColor,
                      //     // color: (reply.isCrown) ? kYellowColor : kBaseGrey,
                      //     height: 8,
                      //     width: 8),
                      const SizedBox(width: distance_5),
                      Text(reply.totalCrowns.toString(), style: (reply.isCrown) ? yellowReactionStyle : bodyReactionStyle),
                    ],
                  ),
            // likeOnTap: () async {
            //   if (reply.isLiked) {
            //     controller.unlikeACommentReply(
            //       commentId: comments.comment.id,
            //       replyId: reply.id,
            //       communityId: postWithCommentController.post.communityId ?? '',
            //     );
            //   } else {
            //     controller.likeACommentReply(
            //       commentId: comments.comment.id,
            //       replyId: reply.id,
            //       communityId: postWithCommentController.post.communityId ?? '',
            //     );
            //   }
            // },
            likeOnTap: () async {},
            flowerOnTap: () async {
              if (reply.isCrown) {
              } else if (reply.user.uId == UserModel.to.uId) {
              } else if (UserModel.to.userDailyCrowns == 0) {
                Methods.showCrownsTotalModalSheet(ctx: Get.context);
              } else {
                controller.crownAReplyComment(
                  commentId: comments.comment.id,
                  replyCommentId: reply.id,
                  receiverUser: reply.user,
                  communityId: postWithCommentController.post.communityId,
                );
              }
            },
            replyOnTap: () {
              Get.to(ReplyCommentView(
                  postModel: postWithCommentController.post, userModel: postWithCommentController.post.postedBy, indexForComment: index));
            },
          ),
        ),
      ],
    );
  }

  likeReactionOnTap(String? reaction, bool isChecked) {
    print('reaction is: $reaction and value is: $isChecked');
    if (reaction != null && isChecked) {
      controller.likeReactionACommentReply(
          commentId: comments.comment.id,
          replyId: reply.id,
          communityId: postWithCommentController.post.communityId ?? '',
          reaction: reaction,
          isChecked: isChecked);
    } else if (isChecked == false) {
      controller.unlikeReactionACommentReply(
          commentId: comments.comment.id,
          replyId: reply.id,
          communityId: postWithCommentController.post.communityId ?? '',
          reaction: reaction,
          isChecked: isChecked);
    } else {
      print('Else case occured while reaction is: $reaction and value is: $isChecked');
    }
  }
}
