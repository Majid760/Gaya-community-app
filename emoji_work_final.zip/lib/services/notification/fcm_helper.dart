import 'dart:convert';

import 'package:awesome_notifications/awesome_notifications.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:connectycube_sdk/connectycube_sdk.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:fluttertoast/fluttertoast.dart';
// import 'package:fluttertoast/fluttertoast.dart';
import 'package:gaya/controller/app_config_controller.dart';
import 'package:gaya/model/community.model.dart';
import 'package:gaya/model/create.post.model.dart';
import 'package:gaya/model/user.model.dart';
import 'package:gaya/routing/getx_route_methods.dart';
import 'package:gaya/services/notification/awesome_notification.dart';
import 'package:gaya/services/services.dart';
import 'package:gaya/utils/flavors/flavors.dart';
import 'package:gaya/utils/logger.dart';
import 'package:gaya/utils/methods.dart';
import 'package:gaya/view/chat/controllers/chat_controller.dart';
import 'package:gaya/view/chat/utils/pref_util.dart';
import 'package:gaya/view/other_user_profile/views/other.user.profile.dart';
import 'package:get/get.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:platform_device_id/platform_device_id.dart';
import 'package:universal_io/io.dart';

class FcmHelper {
  // FCM Messaging
  static late FirebaseMessaging messaging;

  // Notification lib
  static AwesomeNotifications awesomeNotifications = AwesomeNotifications();

  // Awsome notification instance for connectycube notifications
  static AwesomeNotifications connectycubeAwesomeNotifications = AwesomeNotifications();

  /// this function will initialize firebase and fcm instance
  static Future<void> initFcm() async {
    // if (kDebugMode) return;
    try {
      messaging = FirebaseMessaging.instance;

      // initialize notifications channel and libraries
      await _initNotification();

      // notification settings handler
      await _setupFcmNotificationSettings();

      // generate token if it not already generated and store it on shared pref
      await _generateFcmToken();

      // // connectycube initializations
      // try {
      //   await init(config.APP_ID, config.AUTH_KEY, config.AUTH_SECRET, onSessionRestore: () async {
      //     SharedPrefs sharedPrefs = await SharedPrefs.instance.init();
      //     CubeUser? user = sharedPrefs.getUser();
      //     return createSession(user);
      //   });
      //   await initConnectycubeNotifications();
      //   print('here');
      // } catch (_) {
      //   print('here');
      // }
    } catch (error) {
      MyLoggerServices.to.print(error);
    }
  }

  static Future<void> clearFcmToken() async {
    try {
      await _clearFcmTokenToServer();
    } catch (error) {
      MyLoggerServices.to.print(error);
    }
  }

  ///handle fcm notification settings (sound,badge..etc)
  static Future<void> _setupFcmNotificationSettings() async {
    //show notification with sound and badge
    messaging.setForegroundNotificationPresentationOptions(alert: true, sound: true, badge: true);

    //NotificationSettings settings
    await messaging.requestPermission();
  }

  /// generate and save fcm token if its not already generated (generate only for 1 time)
  static Future<void> _generateFcmToken() async {
    try {
      var token = await messaging.getToken();
      if (token != null) {
        MyLoggerServices.to.print(token.toString());
        _sendFcmTokenToServer(token);
      } else {
        // retry generating token
        await Future.delayed(const Duration(seconds: 5));
        _generateFcmToken();
      }
    } catch (error) {
      MyLoggerServices.to.print(error);
    }
  }

  /// this method will be triggered when the app generate fcm
  /// token successfully
  static _sendFcmTokenToServer(String token) async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (FirebaseAuth.instance.currentUser?.uid != null) {
        FirebaseFirestore.instance.collection('users').doc(user?.uid).set({'fm_token': token}, SetOptions(merge: true));
      }
    } catch (error) {
      MyLoggerServices.to.print(error);
    }
  }

  static _clearFcmTokenToServer() async {
    final user = FirebaseAuth.instance.currentUser;
    await messaging.deleteToken();
    if (FirebaseAuth.instance.currentUser?.uid != null) {
      await FirebaseFirestore.instance.collection('users').doc(user?.uid).set({'fm_token': ''}, SetOptions(merge: true));
    }
  }

  // handle fcm notification when app is open

  //display notification for user with sound
  static showNotification(
      {required String? title,
      required String? body,
      required int id,
      String? channelKey,
      String? summary,
      Map<String, String>? payload,
      String? largeIcon}) async {
    awesomeNotifications.isNotificationAllowed().then((isAllowed) {
      if (!isAllowed) {
      } else {
        // u can show notification
        awesomeNotifications.createNotification(
          content: NotificationContent(
            id: id,
            channelKey: channelKey ?? NotificationChannels.generalChannelKey,
            title: title ?? 'Gaya',
            body: body ?? 'Gaya Notification Alert',
            payload: payload,
            summary: summary,
            largeIcon: largeIcon,
          ),
        );
      }
    });
  }

  ///init notifications channels
  static _initNotification() async {
    await awesomeNotifications.initialize(
        "resource://drawable/ic_launcher", // null mean it will show app icon on the notification (status bar)
        [
          NotificationChannel(
              enableLights: true,
              enableVibration: true,
              channelKey: NotificationChannels.generalChannelKey,
              channelName: NotificationChannels.generalChannelName,
              channelDescription: 'Notification channel for general notifications',
              playSound: true,
              importance: NotificationImportance.Max)
        ]);
  }

  //////////////////////// Connectycube notifications methods below ////////////////////////
  static Future<dynamic> Function(String? payload)? onNotificationClicked;

  static Future<void> initConnectycubeNotifications() async {
    // initialize notifications channel and libraries for connectycube
    await _initConnectyCubeNotification();

    String? token;
    if (Platform.isAndroid || kIsWeb) {
      messaging.getToken().then((token) {
        log('[getToken] token: $token');
        subscribe(token);
      }).catchError((onError) {
        log('[getToken] onError: $onError');
      });
    } else if (Platform.isIOS || Platform.isMacOS) {
      token = await messaging.getToken();
      if (!isEmpty(token)) {
        subscribe(token);
      }
      print('here ios token $token');
      // token = await messaging.getToken();
      log('[getAPNSToken] token: $token');
    }

    FirebaseMessaging.onBackgroundMessage(onBackgroundMessage);
  }

  ///init notifications channels
  static _initConnectyCubeNotification() async {
    bool isInitialized = await connectycubeAwesomeNotifications.initialize(
        "resource://drawable/ic_launcher", // null mean it will show app icon on the notification (status bar)
        [
          NotificationChannel(
              enableLights: true,
              enableVibration: true,
              channelKey: NotificationsChannels.GCM,
              channelName: NotificationChannels.generalChannelName,
              channelDescription: 'Notification channel for connectycube notifications',
              playSound: true,
              importance: NotificationImportance.Max)
        ]);
    MyLoggerServices.to.print('_initConnectyCubeNotification $isInitialized done');
  }

  //display notification for user with sound
  static showConnectycubeNotification(
      {required String? title,
      required String? body,
      required int id,
      String? channelKey,
      String? summary,
      Map<String, String>? payload,
      String? largeIcon}) async {
    // MyLoggerServices.to.print("payload showNotification:-> $payload");
    connectycubeAwesomeNotifications.isNotificationAllowed().then((isAllowed) {
      if (!isAllowed) {
      } else {
        // u can show notification
        connectycubeAwesomeNotifications.createNotification(
          content: NotificationContent(
            id: id,
            channelKey: NotificationsChannels.GCM,
            title: title ?? 'Gaya',
            body: body ?? 'Gaya Notification Alert',
            payload: payload,
            summary: summary,
            largeIcon: largeIcon,
          ),
        );
      }
    });
  }

  static subscribe(String? token) async {
    debugPrint('[subscribe] token: $token');

    SharedPrefs sharedPrefs = await SharedPrefs.instance.init();
    // if (sharedPrefs.getSubscriptionToken() == token) {
    //   log('[subscribe] skip subscription for same token');
    //   return;
    // }

    CreateSubscriptionParameters parameters = CreateSubscriptionParameters();
    parameters.pushToken = token;

    bool isProduction = kIsWeb ? true : !F.isDev; // bool.fromEnvironment('dart.vm.product');
    parameters.environment = isProduction ? CubeEnvironment.PRODUCTION : CubeEnvironment.DEVELOPMENT;

    if (Platform.isAndroid || kIsWeb) {
      parameters.channel = NotificationsChannels.GCM;
      parameters.platform = CubePlatform.ANDROID;
    } else if (Platform.isIOS || Platform.isMacOS) {
      parameters.channel = NotificationsChannels.GCM;
      parameters.platform = CubePlatform.ANDROID;
      parameters.pushToken = token;
      parameters.environment = CubeEnvironment.PRODUCTION;
      parameters.bundleIdentifier = 'com.gaya.ios';
    }

    var deviceId = await PlatformDeviceId.getDeviceId;

    if (kIsWeb) {
      parameters.udid = base64Encode(utf8.encode(deviceId ?? ''));
    } else {
      parameters.udid = deviceId;
    }

    var packageInfo = await PackageInfo.fromPlatform();
    parameters.bundleIdentifier = packageInfo.packageName;

    debugPrint('parameters ${parameters.channel}');

    try {
      final cubeSubscription = await createSubscription(parameters.getRequestParameters());
      debugPrint('cubeSubscription $cubeSubscription');
      sharedPrefs.saveSubscriptionToken(token!);
      for (var subscription in cubeSubscription) {
        if (subscription.clientIdentificationSequence == token) {
          debugPrint('subscription.id ${subscription.id}');
          sharedPrefs.saveSubscriptionId(subscription.id!);
        }
      }
    } catch (e) {
      debugPrint('error at createSubscription $e');
    }
  }

  static unsubscribe() {
    SharedPrefs.instance.init().then((sharedPrefs) {
      int subscriptionId = sharedPrefs.getSubscriptionId();
      if (subscriptionId != 0) {
        deleteSubscription(subscriptionId).then((voidResult) {
          FirebaseMessaging.instance.deleteToken();
          sharedPrefs.saveSubscriptionId(0);
        });
      }
    }).catchError((onError) {
      log('[unsubscribe] ERROR: $onError');
    });
  }

  static Future<void> onBackgroundMessage(RemoteMessage message) async {
    // showAlertDialog(Get.context!, 'isFromDeepLink', ChatController.to().currentUser ?? CubeUser(login: '123', password: '123'));
    // Firebase automatically send the fcm so we commented the below line
    bool shouldNotify = true;
    bool isChatMessage = false;
    Map<String, String>? newPayload;
    if (message.data['dialog_id'] != null) {
      newPayload = {
        "user_id": message.data["user_id"] ?? '123',
        "dialog_type": message.data["dialog_type"] ?? 'Private dialog',
        "title": message.data["title"] ?? '',
        "dialog_id": message.data["dialog_id"] ?? '123',
        "message_id": message.data["message_id"] ?? '132',
        "message": message.data["message"] ?? '',
        "messageType": "chatMessage",
      };
      // NotificationApiController.navigate(newPayload["messageType"], newPayload);
      isChatMessage = true;
      if (isChatMessage && Get.currentRoute == "/Conversation") {
        shouldNotify = false;
      }
    }
    if (Platform.isAndroid && shouldNotify) {
      String data = message.data['message'];
      // showConnectycubeNotification(title: data.split(':').first, body: data.split(':').last, id: 1, payload: newPayload);
    }
    // Only after at least the action method is set, the notification events are delivered
    GayaAwesomeNotification.instance.init();
    return Future.value();
  }

  static Future<dynamic> onNotificationSelected(String? payload) {
    try {
      log('[onSelectNotification] payload: $payload');
      // if (context == null) return Future.value();
      log('[onSelectNotification] context != null');
      if (payload != null && jsonDecode(payload)['dialog_id'] != null) {
        return SharedPrefs.instance.init().then((sharedPrefs) async {
          CubeUser? user = sharedPrefs.getUser();

          if (user != null && CubeChatConnection.instance.isAuthenticated()) {
            Map<String, dynamic> payloadObject = jsonDecode(payload);
            String? dialogId = payloadObject['dialog_id'];
            log("getNotificationAppLaunchDetails, dialog_id: $dialogId");
            getDialogs({'id': dialogId}).then((dialogs) async {
              if (dialogs?.items != null && dialogs!.items.isNotEmpty) {
                CubeDialog dialog = dialogs.items.first;
                if (dialogs == null) Future.value();
                await ChatController.to().updateCubeCurrentChat(dialog);
                Get.toNamed(RouteHelper.conversation)?.then((value) => ChatController.to().refreshChatsList());
              } else {
                MyLoggerServices.to.print('...${dialogs?.items} and  ${dialogs?.items.isNotEmpty}');
              }
            });
          } else {
            MyLoggerServices.to.print('.. ${CubeChatConnection.instance.isAuthenticated()}');
          }
        });
      } else {
        return Future.value();
      }
    } catch (_) {
      MyLoggerServices.to.print('error in: onNotificationSelected() method');
      return Future.value();
    }
  }

  ///////////////////////////// Connectycube methods ends here /////////////////////////////
  ///
}

class NotificationChannels {
  // chat channel (for messages only)
  static String get chatChannelKey => "gaya_chat_channel";

  static String get chatChannelName => "Gaya Chat Channel";

  static String get chatChannelDescription => "Notification channel for chat notifications";

  // general channel (for all other notifications)
  static String get generalChannelKey => "high_importance_channel";

  static String get generalChannelName => "Gaya General Channel";

  static String get generalChannelDescription => "Notification channel for general notifications";
}

// class to navigate on notification click action
class NotificationNavigationService {
  static Future<void> navigateToChatroom(Map<String, String?>? payload) async {
    // showAlertDialog(Get.context!, 'isFromDeepLink', ChatController.to().currentUser ?? CubeUser(login: '321', password: '321'));

    // UserModel receiverUserModel = UserModel(
    //   uId: payload?["senderProfileUid"],
    //   profilePicture: payload?["senderProfilePicture"],
    //   name: payload?["senderProfileName"],
    // );
    // final chatRoomId = payload?["chatroomId"];

    // if (receiverUserModel.uId != null && chatRoomId != null) {
    //   Get.to(() => PersonMessageView(
    //         name: receiverUserModel.name ?? "gaya User",
    //         uid: receiverUserModel.uId ?? "",
    //         profilePicture: receiverUserModel.profilePicture ?? "",
    //         chatRoomModel: ChatRoomModel(chatRoomId: chatRoomId),
    //       ));
    // } else {
    //   MyLoggerServices.to.print("navigation failed on chatRoom navigation in NotificationNavigationService class.");
    // }
    // log('called navigateToChatroom function.');

    Map<String, dynamic> params = {};
    params['dialogId'] = payload?['dialog_id'] ?? '123';
    final chats = await getDialogs(params);
    if (chats == null) return;
    final chatModel = chats.items.first;
    print(ChatController.to().currentUser);
    if (ChatController.to().currentUser == null) {
      Fluttertoast.showToast(msg: 'Error ${ChatController.to().currentUser}');
      return;
    }
    Get.toNamed(
      RouteHelper.conversation,
      arguments: {"dialog": chatModel},
    )?.then((value) => ChatController.to().refreshChatsList());
  }

  static final _commonServices = Services();

  static Future<void> navigateToPost(Map<String, String?>? payload) async {
    try {
      UserModel userModel = UserModel(
        uId: payload?["senderProfileUid"],
        profilePicture: payload?["senderProfilePicture"],
        name: payload?["senderProfileName"],
      );
      final postId = payload?["postId"];
      final communityId = payload?["communityId"];
      if (postId != null && postId != '') {
        Community communityModel = Community(communityId: communityId);
        Post postModel = Post(postid: postId, community: communityModel, postedBy: userModel);
        final reactionModel = await _commonServices.getUserReactionOnPost(postModel.postid ?? '');
        postModel.reactionModel = reactionModel;

        Routes.postDetailsScreen(post: postModel, community: communityModel);
      } else {
        MyLoggerServices.to.print("navigation failed on post navigation in NotificationNavigationService class.");
      }
      log('called navigateToPost function.');
    } catch (_) {}
  }

  static Future<void> navigateToCommunity(Map<String, String?>? payload) async {
    try {
      final communityId = payload?["communityId"];

      if (communityId != null && communityId != '') {
        Community communityModel = Community(
          communityId: communityId,
          communityName: payload?["communityName"] ?? '',
          communityDescription: payload?["communityDescription"] ?? '',
          CommunityPic: payload?["CommunityPic"] ?? '',
          adminUid: payload?["adminUid"] ?? '',
          coverPicture: payload?["coverPicture"] ?? '',
        );

        ///Show join community modal if user is not a member of community.
        if (AppConfigurationController.to.isMemberOfCommunity(communityModel.communityId ?? "") == false &&
            Get.context != null &&
            (Get.context?.mounted ?? false)) {
          Methods.showModalSheetToJoinCommunity(communityId: communityModel.communityId ?? "", ctx: Get.context!);
          return;
        }
        Methods.routeToGroup(community: communityModel);

        // Routes.groupView(community: communityModel);
      } else {
        MyLoggerServices.to.print("navigation failed on community navigation in NotificationNavigationService class.");
      }
      log('called navigateToCommunity function.');
    } catch (_) {}
  }

  static Future<void> navigateToProfile(Map<String, String?>? payload) async {
    try {
      final uId = payload?["uId"];

      if (uId != null && uId != '') {
        UserModel userModel = UserModel(
          uId: uId,
          name: payload?["name"] ?? '',
          profilePicture: payload?["profilePicture"] ?? '',
        );

        Get.to(() => PeopleProfileView(
              usermodel: userModel,
            ));
      } else {
        MyLoggerServices.to.print("navigation failed on community navigation in NotificationNavigationService class.");
      }
      log('called navigateToProfile function.');
    } catch (_) {}
  }

  static Map<String, String>? getPayload({payload}) {
    try {
      MyLoggerServices.to.print("payload: $payload");
      payload = jsonDecode(payload);
      if (payload == null) return null;
      Map<String, String>? newPayload;
      if (payload["messageType"].toString() == "chatMessage") {
        log('returned chatmessage Payload from NotificationNavigationService class.');

        newPayload = {
          "senderProfilePicture": payload["senderProfilePicture"] ?? '',
          "senderProfileUid": payload["senderProfileUid"] ?? '',
          "senderProfileName": payload["senderProfileName"] ?? '',
          "chatroomId": payload["chatroomId"] ?? '',
          "messageType": payload["messageType"] ?? 'default'
        };
      } else if (payload["messageType"].toString() == "post") {
        log('returned post Payload from NotificationNavigationService class.');
        newPayload = {
          "senderProfilePicture": payload["senderProfilePicture"] ?? '',
          "senderProfileUid": payload["senderProfileUid"] ?? '',
          "senderProfileName": payload["senderProfileName"] ?? '',
          "postId": payload["postId"] ?? '',
          "communityId": payload["communityId"] ?? '',
          "messageType": payload["messageType"] ?? 'default'
        };
      } else if (payload["messageType"].toString() == "community") {
        log('returned community Payload from NotificationNavigationService class.');
        newPayload = {
          "communityName": payload["communityName"] ?? '',
          "communityDescription": payload["communityDescription"] ?? '',
          "coverPicture": payload["coverPicture"] ?? '',
          "CommunityPic": payload["CommunityPic"] ?? '',
          "adminUid": payload["adminUid"] ?? '',
          "communityId": payload["communityId"] ?? '',
          "messageType": payload["messageType"] ?? 'default'
        };
      } else if (payload["messageType"].toString() == "profile") {
        log('returned community Payload from NotificationNavigationService class.');
        newPayload = {
          "uId": payload["uId"] ?? '',
          "name": payload["name"] ?? '',
          "profilePicture": payload["profilePicture"] ?? '',
          "messageType": payload["messageType"] ?? 'default'
        };
      }
      log('returned else Payload from NotificationNavigationService class.');

      return newPayload;
    } catch (e) {
      log('catch block Payload from NotificationNavigationService class. $e');

      return null;
    }
  }
}
