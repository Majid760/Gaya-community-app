import 'package:connectycube_sdk/connectycube_sdk.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gaya/services/notification/fcm_helper.dart';
import 'package:gaya/shared/service/firebase_performance_services.dart';
import 'package:gaya/utils/flavors/flavors.dart';
import 'package:gaya/utils/logger.dart';
import 'package:gaya/view/chat/utils/pref_util.dart';
import 'package:get_storage/get_storage.dart';
import 'package:gaya/view/chat/utils/configs.dart' as config;
import 'app.dart';

Future<void> main() async {
  F.appFlavor = Flavor.PROD;

  WidgetsFlutterBinding.ensureInitialized();

  if (kIsWeb) {
    await Firebase.initializeApp(
        options: const FirebaseOptions(
            apiKey: "AIzaSyDMUbvC7tODkadWx8k32HT4hPnysjAx80w",
            authDomain: "gaya-5876c.firebaseapp.com",
            databaseURL: "https://gaya-5876c-default-rtdb.europe-west1.firebasedatabase.app",
            projectId: "gaya-5876c",
            storageBucket: "gaya-5876c.appspot.com",
            messagingSenderId: "353177936887",
            appId: "1:353177936887:web:18930368f17435e797c4f2",
            measurementId: "G-GYC29R375X"));
  } else {
    await Firebase.initializeApp();
  }

  getEntry();
  //crashlytics
  InitCrashlytics();
  //register service locators
  serviceLocators();
  // connectycube session creation
  // try {
  //   await init(config.APP_ID, config.AUTH_KEY, config.AUTH_SECRET, onSessionRestore: () async {
  //     SharedPrefs sharedPrefs = await SharedPrefs.instance.init();
  //     CubeUser? user = sharedPrefs.getUser();
  //     return createSession(user);
  //   });
  // } catch (_) {
  //   MyLoggerServices.to.print('_initConnectyCubeNotification done');
  // }

  if (!kIsWeb) {
    await FcmHelper.initFcm();
    SystemChrome.setPreferredOrientations(
      [DeviceOrientation.portraitUp, DeviceOrientation.portraitDown],
    );
    await ScreenUtil.ensureScreenSize();
  }

  PerformanceServices.init();
  await GetStorage.init();

  debugPrint('kIsWeb: $kIsWeb');
  // await UserScripts().getAllUser();
  //  await UserScripts().getAllUser();
/* return runApp( DevicePreview(
    enabled: true,
    builder: (context) => const GayaApp(), // Wrap your app
  ),);*/
  runApp(const GayaApp());
}
