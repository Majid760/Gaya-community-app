// ignore_for_file: use_build_context_synchronously

import 'dart:developer';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:gaya/components/button.component.dart';
import 'package:gaya/components/snackbar.component.dart';
import 'package:gaya/controller/firebase_analytics_controller.dart';
import 'package:gaya/controller/gaya_shared_controller.dart';
import 'package:gaya/controller/profile.controller.dart';
import 'package:gaya/model/chatroom.model.dart';
import 'package:gaya/routing/getx_route_methods.dart';
import 'package:gaya/shared/service/service/shared_service.dart';
import 'package:gaya/shared/view/widget/gaya_report_dialog.dart';
import 'package:gaya/shared/view/widget/gaya_snackbar.dart';
import 'package:gaya/utils/language/translation.dart';
import 'package:gaya/utils/theme/app_spaces.dart';
import 'package:gaya/view/chat/controllers/chat_controller.dart';
import 'package:gaya/view/profile/components/skeletons.dart';
import 'package:gaya/widgets/notification_widgets/nonotification.widget.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';
import 'package:share/share.dart';

import '../components/dialogue.dart';
import '../controller/block_controller.dart';
import '../controller/report_controller.dart';
import '../model/user.model.dart';
import '../services/services.dart';
import '../shared/view/widget/gaya_back_button.dart';
import '../utils/asset_images.dart';
import '../utils/const.dart';
import '../utils/gaya_text_widget.dart';
import '../utils/methods.dart';
import '../utils/textstyles.dart';
import '../utils/theme/app_colors.dart';
import '../utils/theme/app_typography.dart';
import '../widgets/profile.widgets/button.widget.dart';
import '../widgets/profile.widgets/figure.widget.dart';
import '../widgets/profile.widgets/profileimage.widget.dart';
import '../widgets/topic_view_widgets/interest.widget.dart';

class PeopleProfileView extends StatefulWidget {
  PeopleProfileView({Key? key, required this.usermodel}) : super(key: key);

  UserModel usermodel;

  @override
  State<PeopleProfileView> createState() => _PeopleProfileViewState();
}

class _PeopleProfileViewState extends State<PeopleProfileView> {
  DocumentSnapshot? snapshot;
  FirebaseAuth firebaseAuth = FirebaseAuth.instance;

  Map<String, dynamic>? map;
  var profileDetails;
  late Future<UserModel?> futureUserModel;
  var otherProfileDetails;
  bool newChat = false;
  final Services services = Services();

  final performance = PerformanceController.to.instance;

  @override
  void initState() {
    performance.startUserProfileViewLoadTime();
    print("User Id: ${widget.usermodel.uId}");
    futureUserModel = services.getUserById(widget.usermodel.uId);
    profileDetails = getFriend();
    /*
    User? user = firebaseAuth.currentUser;
    user != null ? getName() : null;
    */
    context.read<ProfileController>().getUserDetails();
    otherProfileDetails = context.read<ProfileController>().getOtherUserProfileDetails(widget.usermodel.uId ?? "");
    super.initState();
  }

  final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;

  QuerySnapshot? getFriends;

  Future getFriend() async {
    User? user = _firebaseAuth.currentUser;
    getFriends = await FirebaseFirestore.instance
        .collection('friendship')
        .where("senderUid", isEqualTo: widget.usermodel.uId)
        .where('Recieveruid', isEqualTo: user?.uid)
        .get();

    return getFriends;
  }

/*  Future getName() async {
    User? user = firebaseAuth.currentUser;
    user == null ? '' : snapshot = await FirebaseFirestore.instance.collection('users').doc(user.uid).get();
    // log(snapshot!.data().toString());
    map = snapshot!.data() as Map<String, dynamic>;

    setState(() {});
  }*/

  @override
  Widget build(BuildContext context) {
    User? user = firebaseAuth.currentUser;
    final controller = Provider.of<ProfileController>(context, listen: false);
    return CupertinoPageScaffold(
        navigationBar: CupertinoNavigationBar(
          backgroundColor: Colors.white,
          leading: const GayaBackButton(),
          middle: Text(GayaStrings.profile_txt.tr, style: GayaTypography.titleMedium),
          trailing: Material(
            color: Colors.transparent,
            borderRadius: BorderRadius.circular(20.r),
            child: IconButton(
              tooltip: GayaStrings.more_txt.tr,
              padding: EdgeInsets.zero,
              visualDensity: const VisualDensity(horizontal: -4, vertical: -4),
              splashRadius: 20.r,
              icon: SvgIcons.moreIconBlack,
              onPressed: () {
                user == null
                    ? Routes.loginView()
                    : Methods.showCircularModalSheet(
                        context,
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10).r,
                          width: MediaQuery.of(context).size.width,
                          decoration: const BoxDecoration(color: Colors.white),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              button(
                                  title: GayaStrings.share_profile.tr,
                                  onPressed: () async {
                                    Get.back();

                                    final shareAbleLink = await GayaSharedController.to.createAShareableProfileLink(user: widget.usermodel);
                                    if (shareAbleLink != null) await Share.share(shareAbleLink);
                                  },
                                  borderColor: kTransparentColor,
                                  height: 50.h,
                                  primaryColor: kBaseGrey,
                                  textStyle: GayaTypography.subtitleRegular,
                                  width: MediaQuery.of(context).size.width),
                              const SizedBox(height: 10),
                              button(
                                  title: BlockController.to.isUserBlocked(widget.usermodel.uId ?? "")
                                      ? GayaStrings.user_blocked.tr
                                      : GayaStrings.block_user.tr,
                                  onPressed: () async {
                                    if (widget.usermodel.uId == null) return;
                                    BlockController.to.block(userId: widget.usermodel.uId ?? "", context: context);

                                    Get.back();
                                  },
                                  borderColor: kTransparentColor,
                                  height: 50.h,
                                  primaryColor: kBaseGrey,
                                  textStyle: GayaTypography.subtitleRegular.copyWith(color: AppColors.error),
                                  width: MediaQuery.of(context).size.width),
                              const SizedBox(height: 10),
                              button(
                                  title: GayaStrings.report.tr,
                                  onPressed: () async {
                                    Get.back();

                                    reportTextFieldBottomModal(context, onSubmit: (String reportMsg) async {
                                      bool isExist = await controller.checkCurrentUserReportedThatUserAlready(widget.usermodel.uId!);
                                      if (!isExist) {
                                        await ReportController.to.reportAUser(widget.usermodel.uId!, context, reportMsg: reportMsg);
                                      } else {
                                        snackBar(context, GayaStrings.already_reported.tr, kRedColor);
                                      }
                                    });
                                    // await controller.checkCurrentUserReportedThatUserAlready(widget.usermodel.uId!);
                                    // if (controller.size < 1) {
                                    //   await ReportController.to.reportAUser(widget.usermodel.uId!, context);
                                    // } else {
                                    //   snackBar(context, "You have already reported that user", kRedColor);
                                    //   Navigator.pop(context);
                                    // }
                                  },
                                  borderColor: kTransparentColor,
                                  height: 50.h,
                                  primaryColor: kBaseGrey,
                                  textStyle: GayaTypography.subtitleRegular.copyWith(color: AppColors.error),
                                  width: MediaQuery.of(context).size.width),
                            ],
                          ),
                        ));
              },
            ),
          ),
        ),
        child: SafeArea(
            child: Scaffold(
          backgroundColor: Colors.white,
          body: Padding(
            padding: const EdgeInsets.symmetric(horizontal: distance_20),
            child: SingleChildScrollView(
              child: FutureBuilder<UserModel?>(
                  initialData: widget.usermodel,
                  future: futureUserModel,
                  builder: (context, userSnapshot) {
                    try {
                      print("userSnapshot.data ${userSnapshot.data}");
                      widget.usermodel = userSnapshot.data!;
                    } catch (e) {
                      print(e);
                      return const SizedBox.shrink();
                    }
                    return FutureBuilder(
                        future: profileDetails,
                        builder: (context, snapshot) {
                          if (snapshot.connectionState == ConnectionState.waiting) {
                            return SizedBox(
                              height: MediaQuery.of(context).size.height,
                              child: const SizedBox.shrink(),
                            );
                          } else if (snapshot.connectionState == ConnectionState.active) {
                            if (snapshot.hasData) {
                            } else if (snapshot.hasError) {
                              return Center(
                                child: Text(GayaStrings.some_error_occurred.tr),
                              );
                            }
                          }
                          performance.stopUserProfileViewLoadTime();
                          return Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const SizedBox(height: distance_15),
                              ProfilePicWidget(
                                oncovertap: () => Routes.openImages(urls: [widget.usermodel.coverPhoto ?? ""], index: 0, ctx: context),
                                onproftap: () => Routes.openImages(urls: [widget.usermodel.profilePicture ?? ""], index: 0, ctx: context),
                                coverPhoto: widget.usermodel.coverPhoto,
                                profilePic: widget.usermodel.profilePicture,
                              ),
                              Center(child: Text(widget.usermodel.name.toString(), style: subHeading)),
                              const SizedBox(height: distance_20),
                              Row(
                                children: [
                                  Expanded(
                                    flex: 1,
                                    child: FutureBuilder<int>(
                                        future: context.read<ProfileController>().getOtherUserFriendsCount(widget.usermodel.uId ?? ""),
                                        builder: ((context, snapshot) {
                                          if (snapshot.connectionState == ConnectionState.waiting) {
                                            return const CountSkeletonWidget();
                                          } else if (snapshot.connectionState == ConnectionState.done) {
                                            return FiguresWidget(
                                              number: (snapshot.data ?? 0).toString(),
                                              title: GayaStrings.friends_txt.tr,
                                            );
                                          }
                                          return const SizedBox.shrink();
                                        })),
                                  ),
                                  Expanded(
                                    flex: 1,
                                    child: FutureBuilder<int>(
                                        future: context.read<ProfileController>().getOtherUserCommunityCount(widget.usermodel.uId ?? ""),
                                        builder: (context, communitesCountSnapshot) {
                                          if (communitesCountSnapshot.connectionState == ConnectionState.waiting) {
                                            return const CountSkeletonWidget();
                                          }
                                          return FiguresWidget(
                                              number: (communitesCountSnapshot.data ?? 0).toString(),
                                              title: GayaStrings.communities_txt.tr);
                                        }),
                                  ),
                                  Expanded(
                                    flex: 1,
                                    child: FiguresWidget(
                                      number: (widget.usermodel.userTotalCrowns ?? 0).toString(),
                                      title: GayaStrings.crown_txt.tr,
                                      flower: SvgPicture.asset('Assets/images/filled_crown.svg', height: 10, width: 12),
                                    ),
                                  )
                                ],
                              ),
                              const SizedBox(
                                height: distance_15,
                              ),
                              Center(
                                child: GayaTextWidget(
                                  (widget.usermodel.bio.toString()),
                                  style: body4StyleLowWeight,
                                  trimLines: 20,
                                  shouldIgnoreSelectableText: false,
                                  trimMode: TrimMode.line,
                                  trimCollapsedText: GayaStrings.read_more.tr,
                                  trimExpandedText: GayaStrings.read_less.tr,
                                  colorClickableText: kprimaryColor,
                                ),
                              ),
                              const SizedBox(height: distance_10),
                              user == null
                                  ? Row(
                                      children: [
                                        Expanded(
                                          child: ButtonWidget(
                                            icon: SvgPicture.asset("Assets/icons/Union.svg", color: Colors.white),
                                            onTap: () {
                                              Routes.loginView();
                                            },
                                            buttonColor: kprimaryColor,
                                            color: kBlackColor.withOpacity(0.5),
                                            title: GayaStrings.add_friend.tr,
                                            style: body4StyleWhite,
                                          ),
                                        ),
                                        const SizedBox(
                                          width: distance_5,
                                        ),
                                        Expanded(
                                          child: ButtonWidget(
                                              onTap: () {
                                                Routes.loginView();
                                              },
                                              title: GayaStrings.message_txt.tr,
                                              buttonColor: kBaseGrey,
                                              color: kBlackColor.withOpacity(0.5),
                                              icon: SvgPicture.asset(
                                                "Assets/images/outline_mesage.svg",
                                                color: Colors.black,
                                              ),
                                              style: body2StyleWeightBlack),
                                        ),
                                      ],
                                    )
                                  : StreamBuilder<QuerySnapshot>(
                                      stream: getFriends?.docs.isEmpty ?? true
                                          ? FirebaseFirestore.instance
                                              .collection('friendship')
                                              .where("Recieveruid", isEqualTo: widget.usermodel.uId)
                                              .where('senderUid', isEqualTo: user.uid)
                                              .snapshots()
                                          : FirebaseFirestore.instance
                                              .collection('friendship')
                                              .where("Recieveruid", isEqualTo: user.uid)
                                              .where('senderUid', isEqualTo: widget.usermodel.uId)
                                              .snapshots(),
                                      builder: (context, dataSnapshot) {
                                        if (dataSnapshot.connectionState == ConnectionState.waiting) {
                                          return Row(
                                            children: [
                                              Expanded(
                                                child: Container(
                                                  height: distance_40,
                                                  color: Colors.grey[300],
                                                ),
                                              ),
                                              const SizedBox(width: distance_5),
                                              Expanded(
                                                child: Container(height: distance_40, color: Colors.grey[300]),
                                              ),
                                            ],
                                          );
                                        } else if (dataSnapshot.connectionState == ConnectionState.active ||
                                            dataSnapshot.connectionState == ConnectionState.done) {
                                          if (dataSnapshot.hasError) {
                                            return Center(
                                              child: Text(GayaStrings.error_occurred.tr),
                                            );
                                          } else if (dataSnapshot.hasData) {
                                            return Row(
                                              children: [
                                                Expanded(
                                                  child: Consumer<ProfileController>(builder: (context, profileContrl, __) {
                                                    return ButtonWidget(
                                                      icon: dataSnapshot.data!.docs.isEmpty
                                                          ? profileContrl.isRequestSend
                                                              ? SvgPicture.asset(
                                                                  "Assets/icons/Union.svg",
                                                                  color: Colors.grey,
                                                                )
                                                              : SvgPicture.asset(
                                                                  "Assets/icons/Union.svg",
                                                                  color: Colors.white,
                                                                )
                                                          : (dataSnapshot.data!.docs[0]['Recieveruid'] == widget.usermodel.uId &&
                                                                  dataSnapshot.data!.docs[0]['senderUid'] == user.uid &&
                                                                  dataSnapshot.data!.docs[0]['isaccepted'] == false)
                                                              ? const Text("")
                                                              : SvgPicture.asset(
                                                                  "Assets/icons/Union_del.svg",
                                                                  color: Colors.black,
                                                                ),
                                                      onTap: (dataSnapshot.data == null || dataSnapshot.data!.size == 0)
                                                          ? () async {
                                                              if (dataSnapshot.data!.docs.isEmpty && profileContrl.isRequestSend == false) {
                                                                final userDeatail = profileContrl.userDetails!;
                                                                final userDetailModel = widget.usermodel;
                                                                await profileContrl.createFriendShip(
                                                                    userDetailModel.uId ?? '',
                                                                    userDetailModel.name ?? '',
                                                                    userDeatail['name'] ?? '',
                                                                    userDeatail['profilePic'] ?? '',
                                                                    userDetailModel.fm_token);
                                                              }
                                                            } //'Add Friend'
                                                          : (dataSnapshot.data!.docs[0]['Recieveruid'] == user.uid &&
                                                                  dataSnapshot.data!.docs[0]['senderUid'] == widget.usermodel.uId &&
                                                                  dataSnapshot.data!.docs[0]['isaccepted'] == true)
                                                              ? () {
                                                                  log('unfriend sent.');
                                                                  DialogueC(
                                                                    widget.usermodel.name!,
                                                                    () {
                                                                      Get.back();

                                                                      controller.unFriend(widget.usermodel.uId!);
                                                                    },
                                                                    context,
                                                                  );
                                                                } //'Unfriend'
                                                              : (dataSnapshot.data!.docs[0]['Recieveruid'] == user.uid &&
                                                                      dataSnapshot.data!.docs[0]['senderUid'] == widget.usermodel.uId &&
                                                                      dataSnapshot.data!.docs[0]['isaccepted'] == false)
                                                                  ? () async {
                                                                      await profileContrl
                                                                          .acceptFriendRequest(dataSnapshot.data!.docs[0].id);
                                                                    } //'request recieved'
                                                                  : (dataSnapshot.data!.docs[0]['Recieveruid'] == widget.usermodel.uId &&
                                                                          dataSnapshot.data!.docs[0]['senderUid'] == user.uid &&
                                                                          dataSnapshot.data!.docs[0]['isaccepted'] == false)
                                                                      ? () async {
                                                                          controller.unFriend(widget.usermodel.uId!);
                                                                        } //'Request Sent '
                                                                      : (dataSnapshot.data!.docs[0]['Recieveruid'] ==
                                                                                  widget.usermodel.uId &&
                                                                              dataSnapshot.data!.docs[0]['senderUid'] == user.uid &&
                                                                              dataSnapshot.data!.docs[0]['isaccepted'] == true)
                                                                          ? () {
                                                                              log('unfriend sent.');
                                                                              DialogueC(
                                                                                widget.usermodel.name!,
                                                                                () {
                                                                                  Get.back();

                                                                                  controller.unFriend(widget.usermodel.uId!);
                                                                                },
                                                                                context,
                                                                              );
                                                                            } //'Unfriend'
                                                                          : () {
                                                                              log('else else case.');
                                                                            },
                                                      //'Add friend',
                                                      // profileContrl.isRequestSend
                                                      //     ? () {
                                                      //         log('request sent.');
                                                      //       }
                                                      //     : (dataSnapshot.data != null && dataSnapshot.data!.size > 0)
                                                      //         ? () async {
                                                      //             if (dataSnapshot.data?.docs[0]['Recieveruid'] == user.uid  &&
                                                      //                     dataSnapshot.data?.docs[0]['senderUid'] == widget.usermodel.uId  &&
                                                      //                     dataSnapshot.data?.docs[0]['isaccepted'] == false) {
                                                      //               // if (dataSnapshot.data!.docs) {
                                                      //               await profileContrl.acceptFriendRequest(dataSnapshot.data!.docs[0].id);
                                                      //               //  } else {}
                                                      //             } else {
                                                      //               log('else case data: ${dataSnapshot.data?.docs[0]}');
                                                      //             }
                                                      //           }
                                                      //         : () async {
                                                      //             if (dataSnapshot.data!.docs.isEmpty) {
                                                      //               final userDeatail = profileContrl.userDetails!;
                                                      //               final userDetailModel = widget.usermodel;
                                                      //               await profileContrl.createFriendShip(
                                                      //                   userDetailModel.uId ?? '',
                                                      //                   userDetailModel.name ?? '',
                                                      //                   userDeatail['name'],
                                                      //                   userDeatail['profilePic'],
                                                      //                   userDetailModel.fm_token);
                                                      //             } else {
                                                      //               DialogueC(
                                                      //                 widget.usermodel.name!,
                                                      //                 () {
                                                      //                   Navigator.pop(context);
                                                      //                   controller.unFriend(widget.usermodel.uId!);
                                                      //                 },
                                                      //                 context,
                                                      //               );
                                                      //             }
                                                      //           },
                                                      buttonColor: dataSnapshot.data!.docs.isNotEmpty
                                                          ?
                                                          //...... request reciever after friends button color
                                                          (dataSnapshot.data!.docs[0]['isaccepted'] == true &&
                                                                  dataSnapshot.data!.docs[0]['Recieveruid'] == user.uid &&
                                                                  dataSnapshot.data!.docs[0]['senderUid'] == widget.usermodel.uId)
                                                              ? kBaseGrey
                                                              : (dataSnapshot.data!.docs[0]['isaccepted'] == false &&
                                                                      dataSnapshot.data!.docs[0]['Recieveruid'] == user.uid &&
                                                                      dataSnapshot.data!.docs[0]['senderUid'] == widget.usermodel.uId)
                                                                  ? kprimaryColor
                                                                  : (dataSnapshot.data!.docs[0]['isaccepted'] == false &&
                                                                          dataSnapshot.data!.docs[0]['Recieveruid'] ==
                                                                              widget.usermodel.uId &&
                                                                          dataSnapshot.data!.docs[0]['senderUid'] == user.uid)
                                                                      ? kprimaryColor
                                                                      : kBaseGrey
                                                          : kprimaryColor,
                                                      color: kBlackColor.withOpacity(0.5),
                                                      title:
                                                          //.......
                                                          dataSnapshot.data!.docs.isEmpty
                                                              ? GayaStrings.add_friend.tr
                                                              : isFriend(document: dataSnapshot.data!.docs[0])
                                                                  ? GayaStrings.unfriend.tr
                                                                  : (dataSnapshot.data!.docs[0]['Recieveruid'] == user.uid &&
                                                                          dataSnapshot.data!.docs[0]['senderUid'] == widget.usermodel.uId &&
                                                                          dataSnapshot.data!.docs[0]['isaccepted'] == false)
                                                                      ? GayaStrings.accept_request.tr
                                                                      : (dataSnapshot.data!.docs[0]['Recieveruid'] ==
                                                                                  widget.usermodel.uId &&
                                                                              dataSnapshot.data!.docs[0]['senderUid'] == user.uid &&
                                                                              dataSnapshot.data!.docs[0]['isaccepted'] == false)
                                                                          ? GayaStrings.request_sent.tr
                                                                          : (dataSnapshot.data!.docs[0]['Recieveruid'] ==
                                                                                      widget.usermodel.uId &&
                                                                                  dataSnapshot.data!.docs[0]['senderUid'] == user.uid &&
                                                                                  dataSnapshot.data!.docs[0]['isaccepted'] == true)
                                                                              ? GayaStrings.unfriend.tr
                                                                              : GayaStrings.add_friend.tr,

                                                      //........

                                                      style: dataSnapshot.data!.docs.isNotEmpty
                                                          ?

                                                          //.... text styling of reciever after friends
                                                          (dataSnapshot.data!.docs[0]['isaccepted'] == true &&
                                                                  dataSnapshot.data!.docs[0]['Recieveruid'] == user.uid &&
                                                                  dataSnapshot.data!.docs[0]['senderUid'] == widget.usermodel.uId)
                                                              ? bodyStyle
                                                              : (dataSnapshot.data!.docs[0]['isaccepted'] == true &&
                                                                      dataSnapshot.data!.docs[0]['Recieveruid'] == widget.usermodel.uId &&
                                                                      dataSnapshot.data!.docs[0]['senderUid'] == user.uid)
                                                                  ? bodyStyle
                                                                  : (dataSnapshot.data!.docs[0]['isaccepted'] == false &&
                                                                          dataSnapshot.data!.docs[0]['Recieveruid'] ==
                                                                              widget.usermodel.uId &&
                                                                          dataSnapshot.data!.docs[0]['senderUid'] == user.uid)
                                                                      ? body4StyleWhite
                                                                      : (dataSnapshot.data!.docs[0]['isaccepted'] == false &&
                                                                              dataSnapshot.data!.docs[0]['Recieveruid'] == user.uid &&
                                                                              dataSnapshot.data!.docs[0]['senderUid'] ==
                                                                                  widget.usermodel.uId)
                                                                          ? body4StyleWhite
                                                                          : bodyStyle
                                                          : body4StyleWhite,
                                                    );
                                                  }),
                                                ),
                                                const SizedBox(
                                                  width: distance_5,
                                                ),
                                                Expanded(
                                                  child: newChat == true
                                                      ? ButtonWidget(
                                                          icon: SvgPicture.asset(
                                                            "Assets/images/outline_mesage.svg",
                                                            color: kWhiteColor,
                                                          ),
                                                          title: GayaStrings.message_txt.tr,
                                                          color: kprimaryColor,
                                                          style: body2StyleWeight,
                                                          buttonColor: kprimaryColor,
                                                          onTap: () async {
                                                            if (SharedService.isEnteredAgeValid(
                                                                        widget.usermodel.dob ?? DateTime(2000), 16) ==
                                                                    false &&
                                                                isFriend(
                                                                        document: dataSnapshot.data!.docs.isNotEmpty
                                                                            ? dataSnapshot.data!.docs[0]
                                                                            : null) ==
                                                                    false) {
                                                              GayaSnackBar.show(
                                                                  context: context,
                                                                  type: GayaSnackBarType.problem,
                                                                  text: GayaStrings.not_allowed_users_lower_than_16_years.tr);
                                                            } else {
                                                              if (widget.usermodel.allowToDm == false) {
                                                                GayaSnackBar.show(
                                                                    context: context,
                                                                    type: GayaSnackBarType.problem,
                                                                    text: GayaStrings.cannot_send_message.tr);
                                                              } else {
                                                                if (ChatController.to().currentUser != null) {
                                                                  ChatController.to()
                                                                      .helperFunc
                                                                      .openOrCreateCubeConversation(context, widget.usermodel.uId ?? "");
                                                                }
                                                                // ChatRoomModel? chatRoom = await getchatRoomCUstom();
                                                                // if ((chatRoom != null)) {
                                                                //   EngagementScoreController.to.instance
                                                                //       .onDirectMessage(toUserId: widget.usermodel.uId ?? "");
                                                                //   Routes.personMessages(person: widget.usermodel, chatroom: chatRoom);
                                                                // }
                                                              }
                                                            }
                                                            // if (dataSnapshot.data!.docs[0]['isaccepted'] == true) {
                                                            //   ChatRoomModel? chatRoom = await getchatRoomCUstom(shouldRefresh: false);
                                                            //
                                                            //   if ((chatRoom != null)) {
                                                            //     Routes.personMessages(person: widget.usermodel, chatroom: chatRoom);
                                                            //   }
                                                            // }
                                                          })
                                                      : ButtonWidget(
                                                          onTap: () async {
                                                            if (SharedService.isEnteredAgeValid(
                                                                        widget.usermodel.dob ?? DateTime(2000), 16) ==
                                                                    false &&
                                                                isFriend(
                                                                        document: dataSnapshot.data!.docs.isNotEmpty
                                                                            ? dataSnapshot.data!.docs[0]
                                                                            : null) ==
                                                                    false) {
                                                              GayaSnackBar.show(
                                                                  context: context,
                                                                  type: GayaSnackBarType.problem,
                                                                  text: GayaStrings.not_allowed_users_lower_than_16_years.tr);
                                                            } else {
                                                              if (widget.usermodel.allowToDm == false &&
                                                                  isFriend(
                                                                          document: dataSnapshot.data!.docs.isNotEmpty
                                                                              ? dataSnapshot.data!.docs[0]
                                                                              : null) ==
                                                                      false) {
                                                                GayaSnackBar.show(
                                                                    context: context,
                                                                    type: GayaSnackBarType.problem,
                                                                    text: GayaStrings.cannot_send_message.tr);
                                                              } else {
                                                                if (ChatController.to().currentUser != null) {
                                                                  ChatController.to()
                                                                      .helperFunc
                                                                      .openOrCreateCubeConversation(context, widget.usermodel.uId ?? "");
                                                                }
                                                                // ChatRoomModel? chatRoom = await getchatRoomCUstom();
                                                                // if ((chatRoom != null)) {
                                                                //   EngagementScoreController.to.instance
                                                                //       .onDirectMessage(toUserId: widget.usermodel.uId ?? "");
                                                                //   Routes.personMessages(person: widget.usermodel, chatroom: chatRoom);
                                                                // }
                                                              }
                                                            }
                                                            // print('usermodel is: ${widget.usermodel.allowToDm}');
                                                            // return;

                                                            //////////////////////////////////////////////////////////////////////////////////////////////////
                                                            //                               debugPrint("chat button pressed");
                                                            //                               if (BlockController.to.isUserBlocked(widget.usermodel.uId ?? "")) {
                                                            //                                 snackBar(context, "You can't send a message to a blocked user", kRedColor);
                                                            //                                 return;
                                                            //                               }
                                                            //                               if (dataSnapshot.data?.docs.isEmpty ?? true) {
                                                            //                                 snackBar(context, 'Add ${widget.usermodel.name} as a friend to chat',
                                                            //                                     kprimaryColor);
                                                            //                                 return;
                                                            //                               }
                                                            //
                                                            //                               if (dataSnapshot.data?.docs.isNotEmpty ?? false) {
                                                            //                                 if (dataSnapshot.data!.docs[0]['isaccepted'] == true) {
                                                            //                                   ChatRoomModel? chatRoom = await getchatRoomCUstom();
                                                            //
                                                            //                                   if ((chatRoom != null)) {
                                                            //                                     Routes.personMessages(person: widget.usermodel, chatroom: chatRoom);
                                                            //                                   }
                                                            //                                 } else {
                                                            //                                   snackBar(context, 'Wait for friend request acceptance', kprimaryColor);
                                                            //                                 }
                                                            //                               } else if (dataSnapshot.data!.docs[0]['isaccepted'] == false) {
                                                            //                                 snackBar(context, 'Wait for friend request acceptance', kprimaryColor);
                                                            //                               } else {
                                                            //                                 snackBar(
                                                            //                                     context,
                                                            //                                     'Add ${widget.usermodel.name} in friend list to continue chatting',
                                                            //                                     kprimaryColor);
                                                            //                               }
                                                            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                          },
                                                          title: (GayaStrings.message.tr),
                                                          buttonColor: (SharedService.isEnteredAgeValid(
                                                                          widget.usermodel.dob ?? DateTime(2000), 16) ==
                                                                      true &&
                                                                  widget.usermodel.allowToDm != false)
                                                              ? kprimaryColor
                                                              : kBaseGrey,

                                                          // dataSnapshot.data!.docs.isNotEmpty
                                                          //     ? (dataSnapshot.data!.docs[0]['isaccepted'] == true &&
                                                          //             dataSnapshot.data!.docs[0]['Recieveruid'] == user.uid &&
                                                          //             dataSnapshot.data!.docs[0]['senderUid'] == widget.usermodel.uId)
                                                          //         ? kprimaryColor
                                                          //         : (dataSnapshot.data!.docs[0]['isaccepted'] == true &&
                                                          //                 dataSnapshot.data!.docs[0]['Recieveruid'] ==
                                                          //                     widget.usermodel.uId &&
                                                          //                 dataSnapshot.data!.docs[0]['senderUid'] == user.uid)
                                                          //             ? kprimaryColor
                                                          //             : kBaseGrey
                                                          //     : kBaseGrey,
                                                          color: kBlackColor.withOpacity(0.8),
                                                          icon: SvgPicture.asset(
                                                            "Assets/images/outline_mesage.svg",
                                                            color: (SharedService.isEnteredAgeValid(
                                                                            widget.usermodel.dob ?? DateTime(2000), 16) ==
                                                                        true &&
                                                                    widget.usermodel.allowToDm != false)
                                                                ? Colors.white
                                                                : disableColor,

                                                            // dataSnapshot.data!.docs.isEmpty
                                                            //     ? disableColor //Colors.black
                                                            //     : (dataSnapshot.data!.docs[0]['Recieveruid'] == widget.usermodel.uId &&
                                                            //             dataSnapshot.data!.docs[0]['senderUid'] == user.uid &&
                                                            //             dataSnapshot.data!.docs[0]['isaccepted'] == false)
                                                            //         ? disableColor //Colors.black
                                                            //
                                                            //         : Colors.white,
                                                          ),
                                                          style: (SharedService.isEnteredAgeValid(
                                                                          widget.usermodel.dob ?? DateTime(2000), 16) ==
                                                                      true &&
                                                                  widget.usermodel.allowToDm != false)
                                                              ? body2StyleWeight
                                                              : body2StyleWeighGrey,
                                                          // dataSnapshot.data!.docs.isNotEmpty
                                                          //     ? dataSnapshot.data!.docs[0]['isaccepted'] == true
                                                          //         ? body2StyleWeight
                                                          //         : body2StyleWeighGrey
                                                          //     : body2StyleWeighGrey,
                                                        ),
                                                ),
                                              ],
                                            );
                                          } else {
                                            const NoNotificationWidget();
                                          }
                                        }

                                        return const NoNotificationWidget();
                                      }),
                              const SizedBox(
                                height: distance_12,
                              ),
                              // Text('Interests', style: GayaTypography.subtitleMedium),
                              // const SizedBox(
                              //   height: 4,
                              // ),
                              FutureProvider<DocumentSnapshot?>(
                                initialData: null,
                                create: (context) => otherProfileDetails,
                                child: Consumer<DocumentSnapshot?>(builder: (context, value, _) {
                                  return value == null
                                      ? const SizedBox()
                                      : Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              GayaStrings.interest_txt.tr,
                                              style: GayaTypography.subtitleMedium,
                                            ),
                                            const SizedBox(
                                              height: 4,
                                            ),
                                            Builder(
                                              builder: (context) {
                                                var data = value.data() as Map<String, dynamic>;
                                                UserModel userDetailsModel = UserModel.fromMap(data);
                                                return Wrap(
                                                  direction: Axis.horizontal,
                                                  runAlignment: WrapAlignment.start,
                                                  // runSpacing: distance_10,
                                                  spacing: distance_10,
                                                  children: List.generate(userDetailsModel.interests?.length ?? 0, (index) {
                                                    return InterestWidget(
                                                      color: kBaseGrey,
                                                      horizontalDistance: distance_40,
                                                      image: userDetailsModel.interests?[index].image ?? '',
                                                      title: userDetailsModel.interests?[index].title ?? '',
                                                      onTap: () {},
                                                    );
                                                  }),
                                                );
                                              },
                                            ),
                                          ],
                                        );
                                }),
                              ),

                              ///space
                              MySpaces.bottom
                            ],
                          );
                        });
                  }),
            ),
          ),
        )));
  }

  bool isFriend({required QueryDocumentSnapshot<Object?>? document}) {
    if (document == null) return false;
    final otherUserId = widget.usermodel.uId;
    if (document['isaccepted'] == true) {
      if (document['Recieveruid'] == UserModel.to.uId && document['senderUid'] == otherUserId ||
          document['Recieveruid'] == otherUserId && document['senderUid'] == UserModel.to.uId) {
        return true;
      }
    }
    return false;
    return (document['Recieveruid'] == UserModel.to.uId || document['senderUid'] == widget.usermodel.uId && document['isaccepted'] == true);
  }

  //Function to check whether the chatroom between the current user and reciver is created or not
  Future<ChatRoomModel?> getchatRoomCUstom({bool shouldRefresh = true}) async {
    newChat = true;
    if (shouldRefresh) setState(() {});
    ChatRoomModel chatRoom = ChatRoomModel();
    User? myUser = firebaseAuth.currentUser;
    if (myUser == null) {
      return null;
    }
    final participants = [myUser.uid, widget.usermodel.uId ?? ""]..sort();
    QuerySnapshot querySnapshot = await FirebaseFirestore.instance.collection('chatrooms').where("userIds", isEqualTo: participants).get();
    if (querySnapshot.docs.isNotEmpty) {
      chatRoom = ChatRoomModel.fromMap(querySnapshot.docs[0].data() as Map<String, dynamic>);
    } else {
      //create room if dont exist
      ChatRoomModel newChatRoom = ChatRoomModel(
          chatRoomId: participants.join(),
          typing: [],
          participants: participants,
          isReadSender: true,
          isReadReceiver: false,
          lastMessage: '',
          lastMesgUserId: myUser.uid);

      final UserModel? participant1 = await Services().getUserById(FirebaseAuth.instance.currentUser!.uid);
      final UserModel? participant2 = await Services().getUserById(widget.usermodel.uId);
      if (participant1 == null || participant2 == null) return null;
      await FirebaseFirestore.instance
          .collection('chatrooms')
          .doc(participants.join())
          .set(newChatRoom.toMapForCreateRoom(participant1: participant1!, participant2: participant2!));
      chatRoom = newChatRoom;
    }

    return chatRoom;
  }
}
