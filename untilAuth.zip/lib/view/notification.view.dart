import 'dart:developer';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gaya/model/community.model.dart';
import 'package:gaya/model/create.post.model.dart';
import 'package:gaya/model/notifications.model.dart';
import 'package:gaya/model/user.model.dart';
import 'package:gaya/routing/getx_route_methods.dart';
import 'package:gaya/utils/animation.dart';
import 'package:gaya/utils/assets_icons.dart';
import 'package:gaya/utils/collections.dart';
import 'package:gaya/utils/language/translation.dart';
import 'package:gaya/utils/methods.dart';
import 'package:gaya/utils/theme/app_colors.dart';
import 'package:gaya/view/messaging/components/messages_skeleton_widget.dart';
import 'package:get/get.dart';
import 'package:jiffy/jiffy.dart';
import 'package:paginate_firestore/paginate_firestore.dart';
import 'package:provider/provider.dart';

import '../controller/notification.controller.dart';
import '../services/services.dart';
import '../utils/const.dart';
import '../utils/textstyles.dart';
import '../widgets/notification_widgets/nonotification.widget.dart';
import '../widgets/notification_widgets/notification.whole.widget.dart';

class NotificationView extends StatefulWidget {
  const NotificationView({Key? key}) : super(key: key);

  @override
  State<NotificationView> createState() => _NotificationViewState();
}

class _NotificationViewState extends State<NotificationView> {
  Stream<QuerySnapshot>? snapShotData;

  List docId = [];

  var getFriendRequests;

  late NotificationController _notificationsController;

  @override
  void initState() {
    // Services().readAllNotifications(userId: FirebaseAuth.instance.currentUser!.uid);
    _notificationsController = context.read<NotificationController>();
    // _notificationsController.notificationsScrollController = ScrollController();
    super.initState();
  }

  @override
  void dispose() {
    // _notificationsController.notificationsScrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    log("Inside Notification View:");
    User? user = FirebaseAuth.instance.currentUser;
    final notificationController = Provider.of<NotificationController>(context, listen: false);
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        systemOverlayStyle: SystemUiOverlayStyle.dark,
        shape: Border(
            bottom: BorderSide(
          color: kBaseGrey.withOpacity(0.5),
        )),
        automaticallyImplyLeading: false,
        title: Text(GayaStrings.notifications_txt.tr, style: bodyStyle),
        centerTitle: true,
        backgroundColor: kTransparentColor,
        elevation: 0,
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 12.0),
            child: StreamProvider<QuerySnapshot?>(
              initialData: null,
              create: (context) => FirebaseAuth.instance.currentUser?.uid == null
                  ? const Stream.empty()
                  : FirebaseFirestore.instance
                      .collection('users')
                      .doc(FirebaseAuth.instance.currentUser!.uid)
                      .collection('notifications')
                      .where("isRead", isEqualTo: true)
                      .snapshots(),
              child: Consumer<QuerySnapshot?>(builder: (context, isReadAll, child) {
                return isReadAll == null
                    ? const SizedBox.shrink()
                    : TextButton(
                        onPressed: isReadAll.docs.isNotEmpty
                            ? () {
                                Services().readAllNotifications(userId: FirebaseAuth.instance.currentUser!.uid);
                              }
                            : null,
                        child: Text(
                          GayaStrings.mark_as_read.tr,
                          style: TextStyle(
                              color: (docId.isEmpty && isReadAll.docs.isEmpty) ? kSecondaryColor : kprimaryColor,
                              fontWeight: FontWeight.w600,
                              fontFamily: GayaFontTheme.primaryFont,
                              fontSize: 14.sp),
                        ));
              }),
            ),
          ),
          // const SizedBox(width: 20)
        ],
      ),
      body: SizedBox(
        height: MediaQuery.of(context).size.height - (kBottomNavigationBarHeight + kToolbarHeight),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (user != null)
              StreamBuilder<QuerySnapshot>(
                  stream: notificationController.friendrequestNotificationsStream(),
                  builder: (context, dataSnapshot) {
                    if (dataSnapshot.connectionState == ConnectionState.waiting &&
                        Provider.of<NotificationController>(context, listen: true).isNotificationsLoaded == false) {
                      return const SizedBox.shrink();
                    }
                    if (dataSnapshot.connectionState == ConnectionState.active || dataSnapshot.connectionState == ConnectionState.done) {
                      if (dataSnapshot.hasData) {
                        if (docId.isEmpty) {
                        } else if (docId.isNotEmpty) {
                          docId.clear();
                        }
                        for (var i = 0; i < dataSnapshot.data!.docs.length; i++) {
                          docId.add(dataSnapshot.data!.docs[i].id);
                          // log(docId[i].toString());
                        }
                        if (docId.isEmpty || docId.length == 1) {}
                        return SizedBox(
                          // height: MediaQuery.of(context).size.height * 0.79,
                          width: MediaQuery.of(context).size.width,
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              docId.isNotEmpty
                                  ? ListView.builder(
                                      // controller: notificationController.notificationsScrollController,
                                      physics: const NeverScrollableScrollPhysics(),
                                      shrinkWrap: true,
                                      itemCount: (dataSnapshot.data!.docs.isNotEmpty && dataSnapshot.data!.docs.length > 2)
                                          ? 2
                                          : dataSnapshot.data!.docs.length,
                                      itemBuilder: (context, index) {
                                        Timestamp timestamp = dataSnapshot.data?.docs[index]['createdOn'];
                                        DateTime dateTime = timestamp.toDate();
                                        return Column(
                                          children: [
                                            RequestNotificationWidget(
                                                senderId: dataSnapshot.data?.docs[index]['senderUid'],
                                                profileImg: dataSnapshot.data?.docs[index]['senderProfile'],
                                                color: Colors.blue,
                                                text: dataSnapshot.data?.docs[index]['senderName'],
                                                postedTime: Jiffy(dateTime).fromNow(),
                                                pic: SvgIconWidget.userFilled(color: AppColors.white, height: 16.h, width: 16.w),
                                                // pic: const Icon(Icons.person, color: kWhiteColor, size: 16),
                                                widget1: GestureDetector(
                                                  onTap: () async {
                                                    notificationController.aproveFriendRequest(docId[index]);
                                                  },
                                                  child: Container(
                                                    alignment: Alignment.center,
                                                    // height: 32,
                                                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                                                    decoration: BoxDecoration(
                                                      color: kprimaryColor,
                                                      borderRadius: BorderRadius.circular(borderRadius_4),
                                                    ),
                                                    child: Center(
                                                      child: Text(GayaStrings.add_friend.tr, style: titleStyleWhite),
                                                    ),
                                                  ),
                                                ),
                                                widget2: GestureDetector(
                                                  onTap: () async {
                                                    notificationController.rejectFriendrequest(docId[index]);
                                                  },
                                                  child: Container(
                                                    alignment: Alignment.center,
                                                    // height: distance_40,
                                                    padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
                                                    decoration: BoxDecoration(
                                                      color: kBaseGrey,
                                                      borderRadius: BorderRadius.circular(borderRadius_4),
                                                    ),
                                                    child: Text(
                                                      GayaStrings.remove_txt.tr,
                                                      style: dark12,
                                                    ),
                                                  ),
                                                )),
                                          ],
                                        );
                                      })
                                  : const SizedBox.shrink(),
                              if (dataSnapshot.data!.docs.isNotEmpty && dataSnapshot.data!.docs.length > 2)
                                Padding(
                                  padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.end,
                                    children: [
                                      GestureDetector(
                                          onTap: () {
                                            Routes.openSeeAllFriendRequests();
                                          },
                                          child: Text(GayaStrings.see_all.tr, style: secondaryFontStyle)),
                                    ],
                                  ),
                                )
                            ],
                          ),
                        );
                      }
                    }
                    return const SizedBox.shrink();
                  }),
            if (user != null)
              Expanded(
                child: PaginateFirestore(
                  itemBuilder: (context, documentSnapshots, index) {
                    NotificationModel notificationModel =
                        NotificationModel.fromMap(documentSnapshots[index].data() as Map<String, dynamic>);

                    return (documentSnapshots.isEmpty)
                        ? docId.isEmpty
                            ? const Center(child: NoNotificationWidget())
                            : const SizedBox.shrink()
                        : (Provider.of<NotificationController>(context, listen: true).isNotificationsLoaded == false)
                            ? Padding(
                                padding: const EdgeInsets.only(top: distance_16),
                                child: MessagesSkeletonWidget(),
                              )
                            : (notificationModel.postId != null)
                                ? NotificationItemWithPost(notification: notificationModel, snapshot: documentSnapshots[index])
                                : (notificationModel.communityId != null)
                                    ?
                                    ////// community related notifications ///////
                                    CommunityNotificationItem(
                                        notification: notificationModel,
                                        snapshot: documentSnapshots[index],
                                      )
                                    : Column(
                                        children: [
                                          OtherNotificationWidget(
                                            unreadMessageColor: notificationModel.isRead == false ? kprimaryColorLight : kTransparentColor,
                                            notificationId: documentSnapshots[index].id,
                                            receiverUserId: isCrownAirdrppNotification(documentSnapshots[index])
                                                ? ""
                                                : documentSnapshots[index]["receiverUserID"],
                                            profileImg: isCrownAirdrppNotification(documentSnapshots[index])
                                                ? null
                                                : documentSnapshots[index]['userImage'],
                                            color: (documentSnapshots[index]['type'] == 'postCommented')
                                                ? Colors.green
                                                : (documentSnapshots[index]['type'] == 'postLiked')
                                                    ? Colors.red
                                                    : (documentSnapshots[index]['type'] == 'postCrowned' ||
                                                            documentSnapshots[index]['type'] == 'crownAirdrop')
                                                        ? kYellowColor
                                                        : (documentSnapshots[index]['type'] == 'communityJoiningApproved' ||
                                                                documentSnapshots[index]['type'] == 'communityJoiningRejected' ||
                                                                documentSnapshots[index]['type'] == 'communityPostApproved' ||
                                                                documentSnapshots[index]['type'] == 'communityPostRejected'
                                                            // ||
                                                            // documentSnapshots[index]['type'] == 'communityJoiningrequest'
                                                            )
                                                            ? kPrimaryBackgroundBtnColor //Colors.blue
                                                            : (documentSnapshots[index]['type'] == 'friendRequest')
                                                                ? Colors.blue
                                                                : (documentSnapshots[index]['type'] == 'communityPostRequest' ||
                                                                        documentSnapshots[index]['type'] == 'postReported' ||
                                                                        documentSnapshots[index]['type'] == 'communityJoiningrequest')
                                                                    ? kTransparentColor
                                                                    : Colors.pinkAccent,

                                            text: documentSnapshots[index]['sender_name'],
                                            postedTime: getJiffyDateTimeFromString(documentSnapshots[index]),
                                            // '${dateTime.isAfter(DateTime.now().subtract(Duration(days: 1))) ? 'today' : DateFormat.yMd().format(dateTime)} at $time',
                                            pic: (documentSnapshots[index]['type'] == 'postCommented')
                                                ? SvgIconWidget.commentOutline(color: AppColors.white)
                                                : (documentSnapshots[index]['type'] == 'postLiked')
                                                    ? SvgIconWidget.like()
                                                    : (documentSnapshots[index]['type'] == 'postCrowned')
                                                        ? SvgIconWidget.flower()
                                                        : (documentSnapshots[index]['type'] == 'crownAirdrop')
                                                            ? SvgIconWidget.flower()
                                                            : (documentSnapshots[index]['type'] == 'communityJoiningApproved' ||
                                                                    documentSnapshots[index]['type'] == 'communityJoiningRejected' ||
                                                                    documentSnapshots[index]['type'] == 'communityPostApproved' ||
                                                                    documentSnapshots[index]['type'] == 'communityPostRejected')
                                                                ? SvgIconWidget.community()
                                                                // Image.asset('Assets/images/community_logo.png',
                                                                //                         color: Colors.white, height: 15, width: 15)
                                                                : (documentSnapshots[index]['type'] == 'friendRequest')
                                                                    ? SvgIconWidget.userFilled(
                                                                        color: AppColors.white, height: 16.h, width: 16.w)
                                                                    : (documentSnapshots[index]['type'] == 'communityPostRequest' ||
                                                                            documentSnapshots[index]['type'] == 'postReported' ||
                                                                            documentSnapshots[index]['type'] == 'communityJoiningrequest')
                                                                        ? const SizedBox.shrink()
                                                                        : SvgIconWidget.like(),
                                            // SvgPicture.asset('Assets/images/like_notification.svg'),
                                            message: documentSnapshots[index]['message'],
                                            onTapNotification: () {
                                              if (documentSnapshots[index]["type"] == "friendRequest") {
                                                final user = UserModel(uId: documentSnapshots[index]["sender_user_id"]);
                                                Routes.viewProfile(uid: user.uId, model: user);
                                              }

                                              if (documentSnapshots[index]["isRead"] == true) {
                                                //already read. no need to run below.
                                                return;
                                              }
                                              Services().readNotification(
                                                receiverUserID: (isCrownAirdrppNotification(documentSnapshots[index]))
                                                    ? UserModel.to.uId
                                                    : documentSnapshots[index]["receiverUserID"],
                                                notificationId: documentSnapshots[index].id,
                                              );
                                            },
                                          ),
                                        ],
                                      );
                  },
                  itemsPerPage: 10,
                  onEmpty: const Center(child: NoNotificationWidget()),
                  onError: (error) => const Center(child: AnimationLottie()),
                  onLoaded: (p0) {
                    SchedulerBinding.instance.addPostFrameCallback((_) {
                      Provider.of<NotificationController>(context, listen: false).changeNotificationsLoadedStatus();
                    });
                  },
                  initialLoader: Align(
                      alignment: Alignment.topCenter,
                      child: Padding(padding: const EdgeInsets.only(top: distance_16), child: MessagesSkeletonWidget())),
                  query: FirebaseFirestore.instance
                      .collection('users')
                      .doc(user.uid)
                      .collection("notifications")
                      .orderBy("time", descending: true),
                  itemBuilderType: PaginateBuilderType.listView,
                  isLive: true,
                ),
              )
          ],
        ),
      ),
    );
  }

  /// data is snapshot of notification
  String getJiffyDateTimeFromString(DocumentSnapshot<Object?> data) {
    try {
      final String dateTime = data['time'].toString();
      if (isCrownAirdrppNotification(data) && isInt(dateTime)) {
        int time = int.parse(dateTime);
        return Jiffy(DateTime.fromMillisecondsSinceEpoch(time).toLocal()).fromNow();
      }

      return Jiffy(dateTime).fromNow();
    } catch (e) {}
    return "";
  }

  bool isInt(String s) {
    return int.tryParse(s) != null;
  }

  bool isCrownAirdrppNotification(DocumentSnapshot<Object?> data) {
    return data['type'] == 'crownAirdrop';
  }
}

class NotificationItemWithPost extends StatefulWidget {
  final NotificationModel notification;
  final snapshot;

  const NotificationItemWithPost({Key? key, required this.notification, required this.snapshot}) : super(key: key);

  @override
  State<NotificationItemWithPost> createState() => _NotificationItemWithPostState();
}

class _NotificationItemWithPostState extends State<NotificationItemWithPost> with AutomaticKeepAliveClientMixin {
  @override
  Widget build(BuildContext context) {
    super.build(context);
    final NotificationModel notificationModel = widget.notification;
    final DocumentSnapshot notificationSnapshot = widget.snapshot;
    return FutureBuilder<DocumentSnapshot?>(
        future: FirebaseFirestore.instance.collection(communityPosts).doc(notificationModel.postId).get(),
        builder: (context, postSnapshot) {
          DocumentSnapshot? postQuery = postSnapshot.data;
          if (!postSnapshot.hasData || postSnapshot.hasError || postSnapshot.data?.data() == null || postQuery?.data() == null) {
            return const SizedBox.shrink();
          }
          Post createPostModel = Post.fromMap(postQuery?.data() as Map<String, dynamic>);
          return Column(
            children: [
              OtherNotificationWidget(
                unreadMessageColor: notificationModel.isRead == false ? kprimaryColorLight : kTransparentColor,
                notificationId: notificationSnapshot.id,
                receiverUserId:
                    NotificationItemUtils.isCrownAirdrppNotification(notificationSnapshot) ? "" : notificationSnapshot["receiverUserID"],
                profileImg:
                    NotificationItemUtils.isCrownAirdrppNotification(notificationSnapshot) ? null : notificationSnapshot['userImage'],
                color: (notificationSnapshot['type'] == 'postCommented')
                    ? Colors.green
                    : (notificationSnapshot == 'postLiked')
                        ? Colors.red
                        : (notificationSnapshot == 'postCrowned' || notificationSnapshot['type'] == 'crownAirdrop')
                            ? kYellowColor
                            : (notificationSnapshot['type'] == 'communityJoiningApproved' ||
                                    notificationSnapshot['type'] == 'communityJoiningRejected' ||
                                    notificationSnapshot['type'] == 'communityPostApproved' ||
                                    notificationSnapshot['type'] == 'communityPostRejected')
                                ? kPrimaryBackgroundBtnColor
                                : (notificationSnapshot['type'] == 'friendRequest')
                                    ? Colors.blue
                                    : (notificationSnapshot['type'] == 'communityPostRequest' ||
                                            notificationSnapshot['type'] == 'postReported' ||
                                            notificationSnapshot['type'] == 'communityJoiningrequest')
                                        ? kTransparentColor
                                        : Colors.pinkAccent,
                text: notificationSnapshot['sender_name'],
                postedTime: NotificationItemUtils.getJiffyDateTimeFromString(notificationSnapshot),
                // '${dateTime.isAfter(DateTime.now().subtract(Duration(days: 1))) ? 'today' : DateFormat.yMd().format(dateTime)} at $time',
                pic: (notificationSnapshot['type'] == 'postCommented')
                    ? SvgIconWidget.comment()
                    // SvgPicture.asset("Assets/icons/comments.svg", color: Colors.white)
                    : (notificationSnapshot['type'] == 'postLiked')
                        ? SvgIconWidget.like()
                        // SvgPicture.asset('Assets/images/like_notification.svg')
                        : (notificationSnapshot['type'] == 'postCrowned')
                            ? SvgIconWidget.flower()
                            // SvgPicture.asset('Assets/images/filled_crown.svg', color: kWhiteColor, height: 10, width: 12)
                            : (notificationSnapshot['type'] == 'crownAirdrop')
                                ? Container(color: kprimaryColor)
                                : (notificationSnapshot['type'] == 'communityJoiningApproved' ||
                                        notificationSnapshot['type'] == 'communityJoiningRejected' ||
                                        notificationSnapshot['type'] == 'communityPostApproved' ||
                                        notificationSnapshot['type'] == 'communityPostRejected')
                                    ? SvgIconWidget.community()
                                    // Image.asset('Assets/images/community_logo.png', color: Colors.white, height: 16, width: 16)
                                    : (notificationSnapshot['type'] == 'friendRequest')
                                        ? SvgIconWidget.userFilled(color: AppColors.white, height: 16.h, width: 16.w)
                                        // const Icon(Icons.person, color: kWhiteColor, size: 16)
                                        : (notificationSnapshot['type'] == 'communityPostRequest' ||
                                                notificationSnapshot['type'] == 'postReported' ||
                                                notificationSnapshot['type'] == 'communityJoiningrequest')
                                            ? const SizedBox.shrink()
                                            : SvgIconWidget.like(),
                // SvgPicture.asset('Assets/images/like_notification.svg'),
                message: notificationSnapshot['message'],
                onTapNotification: () {
                  // Get.to(() => CommentWithPostScreen(postModel: createPostModel, userModel: userModel));
                  if (createPostModel.communityId != null) {
                    // Get.lazyPut<EditCommunityController>(() => EditCommunityController());
                    // EditCommunityController.to
                    //     .fetchCommunityProfile(CreateCommunityModel(communityId: createPostModel.communityId));
                  }
                  Routes.postDetailsScreen(post: createPostModel, community: Community(communityId: createPostModel.communityId));

                  if (notificationSnapshot["isRead"] == true) {
                    //already read. no need to run below.
                    return;
                  }
                  Services().readNotification(
                    receiverUserID: NotificationItemUtils.isCrownAirdrppNotification(notificationSnapshot)
                        ? ""
                        : notificationSnapshot["receiverUserID"],
                    notificationId: notificationSnapshot.id,
                  );
                },
              ),
            ],
          );
        });
  }

  @override
  bool get wantKeepAlive => true;
}

class CommunityNotificationItem extends StatefulWidget {
  final NotificationModel notification;
  final snapshot;

  const CommunityNotificationItem({Key? key, required this.notification, required this.snapshot}) : super(key: key);

  @override
  State<CommunityNotificationItem> createState() => _CommunityNotificationItemState();
}

class _CommunityNotificationItemState extends State<CommunityNotificationItem> with AutomaticKeepAliveClientMixin {
  @override
  Widget build(BuildContext context) {
    super.build(context);
    final NotificationModel notificationModel = widget.notification;
    final DocumentSnapshot documentSnapshots = widget.snapshot;
    return FutureBuilder<DocumentSnapshot?>(
        future: FirebaseFirestore.instance.collection(communities).doc(notificationModel.communityId).get(),
        builder: (context, postSnapshot) {
          DocumentSnapshot? postQuery = postSnapshot.data;
          if (!postSnapshot.hasData || postSnapshot.hasError || postSnapshot.data?.data() == null || postQuery?.data() == null) {
            return const SizedBox.shrink();
          }

          Community createCommunityModel = Community.fromMap(postQuery?.data() as Map<String, dynamic>);

          return Column(
            children: [
              OtherNotificationWidget(
                unreadMessageColor: notificationModel.isRead == false ? kprimaryColorLight : kTransparentColor,
                notificationId: documentSnapshots.id,
                receiverUserId:
                    NotificationItemUtils.isCrownAirdrppNotification(documentSnapshots) ? "" : documentSnapshots["receiverUserID"],
                profileImg: NotificationItemUtils.isCrownAirdrppNotification(documentSnapshots) ? null : documentSnapshots['userImage'],
                color: (documentSnapshots['type'] == 'postCommented')
                    ? Colors.green
                    : (documentSnapshots['type'] == 'postLiked')
                        ? Colors.red
                        : (documentSnapshots['type'] == 'postCrowned' || documentSnapshots['type'] == 'crownAirdrop')
                            ? kYellowColor
                            : (documentSnapshots['type'] == 'communityJoiningApproved' ||
                                    documentSnapshots['type'] == 'communityJoiningRejected' ||
                                    documentSnapshots['type'] == 'communityPostApproved' ||
                                    documentSnapshots['type'] == 'communityPostRejected')
                                ? kPrimaryBackgroundBtnColor
                                : (documentSnapshots['type'] == 'friendRequest')
                                    ? Colors.blue
                                    : (documentSnapshots['type'] == 'communityPostRequest' ||
                                            documentSnapshots['type'] == 'postReported' ||
                                            documentSnapshots['type'] == 'communityJoiningrequest')
                                        ? kTransparentColor
                                        : Colors.pinkAccent,
                text: documentSnapshots['sender_name'],
                postedTime: NotificationItemUtils.getJiffyDateTimeFromString(documentSnapshots),
                // '${dateTime.isAfter(DateTime.now().subtract(Duration(days: 1))) ? 'today' : DateFormat.yMd().format(dateTime)} at $time',
                pic: (documentSnapshots['type'] == 'postCommented')
                    ? SvgIconWidget.comment()
                    // SvgPicture.asset("Assets/icons/comments.svg", color: Colors.white)
                    : (documentSnapshots['type'] == 'postLiked')
                        ? SvgIconWidget.like()
                        // ? SvgPicture.asset('Assets/images/like_notification.svg')
                        : (documentSnapshots['type'] == 'postCrowned')
                            ? SvgIconWidget.flower()
                            // ? SvgPicture.asset('Assets/images/filled_crown.svg', height: 10, width: 12, color: kWhiteColor)
                            : (documentSnapshots['type'] == 'crownAirdrop')
                                ? Container(color: kprimaryColor)
                                : (documentSnapshots['type'] == 'communityJoiningApproved' ||
                                        documentSnapshots['type'] == 'communityJoiningRejected' ||
                                        documentSnapshots['type'] == 'communityPostApproved' ||
                                        documentSnapshots['type'] == 'communityPostRejected')
                                    ? SvgIconWidget.community(height: 16, width: 16)
                                    // Image.asset('Assets/images/community_logo.png', color: Colors.white, height: 16, width: 16)
                                    : (documentSnapshots['type'] == 'communityPostRequest')
                                        ? const SizedBox.shrink()
                                        : (documentSnapshots['type'] == 'friendRequest')
                                            ? SvgIconWidget.userFilled(color: AppColors.white, height: 16.h, width: 16.w)
                                            // const Icon(Icons.person, color: kWhiteColor, size: 16)
                                            : (documentSnapshots['type'] == 'postReported' ||
                                                    documentSnapshots['type'] == 'communityJoiningrequest')
                                                ? const SizedBox.shrink()
                                                : SvgIconWidget.like(),
                // SvgPicture.asset('Assets/images/like_notification.svg'),
                message: documentSnapshots['message'],
                onTapNotification: () {
                  if (createCommunityModel.communityId != null && createCommunityModel.communityId != '') {
                    SchedulerBinding.instance.addPostFrameCallback((_) {
                      Methods.routeToGroup(community: createCommunityModel);
                      // Routes.groupView(community: createCommunityModel);
                    });
                  }
                  if (documentSnapshots["isRead"] == true) {
                    //already read. no need to run below.
                    return;
                  }
                  Services().readNotification(
                    receiverUserID:
                        NotificationItemUtils.isCrownAirdrppNotification(documentSnapshots) ? "" : documentSnapshots["receiverUserID"],
                    notificationId: documentSnapshots.id,
                  );
                },
              ),
            ],
          );
        });
  }

  @override
  bool get wantKeepAlive => true;
}

class NotificationItemUtils {
  static bool isInt(String s) {
    return int.tryParse(s) != null;
  }

  static bool isCrownAirdrppNotification(DocumentSnapshot<Object?> data) {
    return data['type'] == 'crownAirdrop';
  }

  /// data is snapshot of notification
  static String getJiffyDateTimeFromString(DocumentSnapshot<Object?> data) {
    try {
      final String dateTime = data['time'].toString();
      if (isCrownAirdrppNotification(data) && isInt(dateTime)) {
        int time = int.parse(dateTime);
        return Jiffy(DateTime.fromMillisecondsSinceEpoch(time).toLocal()).fromNow();
      }

      return Jiffy(dateTime).fromNow();
    } catch (e) {}
    return "";
  }
}
