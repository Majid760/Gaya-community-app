import 'dart:developer';
import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:easy_refresh/easy_refresh.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/services.dart';
import 'package:gaya/components/check_for_app_update.dart';
import 'package:gaya/controller/cache_controller.dart';
import 'package:gaya/controller/crowns_controller.dart';
import 'package:gaya/model/create.post.model.dart';
import 'package:gaya/model/user.model.dart';
import 'package:gaya/routing/getx_route_methods.dart';
import 'package:gaya/services/services.dart';
import 'package:gaya/shared/service/cache_service/cache_services.dart';
import 'package:gaya/shared/service/crown_service/crown_services.dart';
import 'package:gaya/shared/service/media_service/file_picking_service.dart';
import 'package:gaya/utils/extension.dart';
import 'package:gaya/utils/logger.dart';
import 'package:gaya/utils/strings.dart';
import 'package:gaya/view/comments/controller/post_with_comment_controller.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';

import '../../../app.dart';
import '../../../controller/firebase_analytics_controller.dart';
import '../../../model/comment.model.dart';
import '../../../model/like.comment.model.dart';
import '../../../model/local/crown_payload.dart';
import '../../../model/replies.model.dart';
import '../../../services/notification/notification_api/notification_api.dart';
import '../../../utils/asset_images.dart';
import '../models/comment_custom_model.dart';
import '../services/comment_services.dart';

class CommentsController extends GetxController {
  final Post post;

  CommentsController({required this.post});

  final CommentsServices service = CommentsServices();
  final Services _commonService = Services();
  final NotificationApiHitting _notificationApiHitting = NotificationApiHitting();
  final User? user = FirebaseAuth.instance.currentUser;
  EasyRefreshController refreshController = EasyRefreshController();

  UserModel get myAppUser => UserModel.to;

  // done by mak
  File? commentsMedia;
  bool isVideo = false;

  // for pdf files
  TextEditingController documentTextField = TextEditingController();
  List<File> pdfFiles = [];
  Uint8List? pdfThumbnail;
  bool isPdf = false;

  /// this button is for AB testing we can handle to hide the
  /// visibility of post DM

  bool isPostDMEnabled = false;
  @override
  void onInit() {
    super.onInit();
    fetchComments();
    //Fetching from the Remote config
    isPostDMEnabled = GayaRemoteConfig.to.isPostDMEnabled;
  }

  @override
  void dispose() {
    //clear all comments in case (rare case) if cache left.
    allComments.clear();
    service.reset();
    super.dispose();
  }

  List<MultiCommentModel> allComments = [];

  /// returns true if comments fetched
  Future<bool> requestMoreComments() async {
    List<MultiCommentModel> comments = await service.loadPostsComments(post.postid ?? "");
    if (comments.isNotEmpty) {
      allComments.addAll(comments);
      allComments.distinctBy((element) => element.comment.id);
      update();
      return true;
    } else {
      return false;
    }
  }

  void fetchComments() async {
    PerformanceController.to.instance.startLoadCommentsTime();
    //clear all comments in case (rare case) if cache left.
    allComments.clear();
    setLoading(true);
    List<MultiCommentModel> comments = await service.loadPostsComments(post.postid ?? "");
    allComments = comments;
    PerformanceController.to.instance.stopLoadCommentsTime();
    setLoading(false);
  }

  bool documentUploadStatus = false;

  updateDocumentUploadStatus() {
    documentUploadStatus = true;
    update();
  }

  void postNewComment(
      {required String myNewComment, List<Map<String, dynamic>>? mentionedUser, List<Map<String, dynamic>>? documentFiles}) async {
    try {
      final isAnonymous = isPostedAnonymously(post);
      final newCommentId = uuid.v1();

      /// score
      EngagementScoreController.to.instance.onComment(communityId: post.communityId ?? "", postId: post.postid ?? "");

      // log new comment added analytics event
      AnalyticsController.to.instance.logAddNewComment(
        communityId: post.communityId,
        commentId: newCommentId,
        commentContentTypeId: post.postid ?? '',
        commenterId: UserModel.to.uId ?? '',
      );

      /// if image/video attached, call [postNewCommentWithMedia]
      if (commentsMedia != null || pdfFiles.isNotEmpty) {
        return postNewCommentWithMedia(
          newCommentId: newCommentId,
          myNewComment: myNewComment,
          mentionedUsers: mentionedUser,
        );
      }

      // if photo is not attached, post comment directly

      /// empty comment not allowed
      if (myNewComment.isBlank == true) return;
      //make model for local.
      final newComment = CommentCustomModel(
          id: newCommentId, mentionedUsers: mentionedUser?.toList(), comment: myNewComment, user: UserModel.to, createdAt: DateTime.now());
      //add locally.
      if (service.hasMoreComments == false) {
        allComments.add(MultiCommentModel(comment: newComment, replies: []));
      }
      // allComments.insert(0, MultiCommentModel(comment: newComment, replies: []));
      update();
      UserModel? userData = await _commonService.getUserById(post.postedBy.uId, forcefullyServer: true);
      if (post.postedBy.uId != myAppUser.uId) {
        final fcmPostModel = FcmCreatePostModel(
          postid: post.postid ?? '',
          communityId: post.communityId ?? '',
          messageContent: "${isAnonymous ? anonymousUser : myAppUser.name} has commented on your post.",
          messageTitle: 'You have a new comment',
          receiverFcm: userData?.fm_token ?? '',
        );
        _notificationApiHitting.callOnFcmApiForPostRelatedNotifications(fcmPostModel);
        _commonService.addNotification(
            posId: post.postid ?? '',
            isRead: false,
            message: "${isAnonymous ? anonymousUser : myAppUser.name} has commented on your post.",
            receiverUserID: post.postedBy.uId ?? '',
            senderId: myAppUser.uId ?? '',
            senderName: isAnonymous ? anonymousUser : myAppUser.name ?? "Gaya User",
            time: DateTime.now().toString(),
            type: "postCommented",
            userImage: isAnonymous ? ImageAssetsUtils.anonymousUserNetworkUrl : myAppUser.profilePicture ?? "");
      }

      //send to firebase
      CommentsModel commentsModel = CommentsModel(
          userId: myAppUser.uId,
          comment: newComment.comment,
          mentionedUsers: newComment.mentionedUsers,
          commentId: newComment.id,
          commentTime: newComment.createdAt);
      _commonService.postComment(post.postid ?? "", commentsModel.commentId!, commentsModel.toMap());
      notificationSendToMentioedUser(mentionedUser: mentionedUser);
    } catch (e) {
      MyLoggerServices.to.print(e.toString());
    }
  }

  void notificationSendToMentioedUser({List<Map<String, dynamic>>? mentionedUser}) {
    // mentioned user functionality
    List<String> mentionedUsersUids = [];
    if (mentionedUser != null && mentionedUser.isNotEmpty) {
      mentionedUser = mentionedUser.where((item) {
        return (item['isCommunity'] == null || item['isCommunity'] != true);
      }).toList();
      MyLoggerServices.to.print('notifired user ids:${mentionedUser.toString()}');
      mentionedUsersUids = mentionedUser.map<String>((user) {
        return user['senderUid'];
      }).toList();
    }
    if (mentionedUsersUids.isNotEmpty) {
      final PostWithCommentController postController = PostWithCommentController.to(tag: post.postid);
      postController.mentionedUsersOnPost(mentionedUsers: mentionedUsersUids.toSet().toList());
    }
  }

  //deletion of parent comment
  void deleteComment(String commentId) async {
    //delete locally.
    final comment = allComments.firstWhereOrNull((element) => element.comment.id == commentId);
    if (comment == null) return; //comment does not exist for some reason

    int totalCommentsCount = 1 + comment.replies.length;

    //update locally total comments count.
    PostWithCommentController.to(tag: post.postid).updateTotalComments(totalCommentsCount);

    //removing locally
    allComments.removeWhere((element) => element.comment.id == commentId);
    //removing from db
    _commonService.deleteComment(postId: post.postid ?? "", commentId: commentId, totalCommentsCount: totalCommentsCount);
    AnalyticsController.to.instance.deleteComment(commentId: "commentId:$commentId  ", postId: post.postid ?? "");

    update();
  }

  void deleteChildComment(String commentId, String childCommentId) async {
    //delete locally.
    final comment = allComments.firstWhereOrNull((element) => element.comment.id == commentId);
    if (comment == null || comment.replies.isEmpty) {
      return; //comment does not exist for some reason
    }

    int parentCommentIndex = allComments.indexOf(comment);
    if (parentCommentIndex == -1) return;

    //update locally total comments count.
    PostWithCommentController.to(tag: post.postid).updateTotalComments(1);

    //removing reply comment locally.
    allComments[parentCommentIndex].replies.removeWhere((reply) => reply.id == childCommentId);
    //removing comment from db
    _commonService.deleteChildComment(postId: post.postid ?? "", commentId: commentId, childCommentId: childCommentId);
    AnalyticsController.to.instance.deleteComment(commentId: "commentId:$commentId childId: $childCommentId", postId: post.postid ?? "");
    update();
  }

  void postNewReply({
    required String myNewComment,
    required int commentIndex,
    required Post postModel,
    List<Map<String, dynamic>>? mentionedUser,
  }) async {
    final bool isAnonymously = isPostedAnonymously(postModel);
    final newCommentId = uuid.v1();
    try {
      String parentCommentId = allComments[commentIndex].comment.id;
      final newReplyComment = CommentCustomModel(
        id: newCommentId,
        comment: myNewComment,
        user: UserModel.to,
        createdAt: DateTime.now(),
        mentionedUsers: mentionedUser,
      );

      /// score
      EngagementScoreController.to.instance
          .onComment(communityId: post.communityId ?? "", postId: post.postid ?? "", commentId: parentCommentId);

      // log new comment added analytics event
      AnalyticsController.to.instance.logAddNewComment(
        communityId: post.communityId,
        commentId: newCommentId,
        commentContentTypeId: parentCommentId,
        commenterId: UserModel.to.uId ?? '',
      );

      if (commentsMedia != null || pdfFiles.isNotEmpty) {
        return postNewCommentReplyWithMedia(
            myNewComment: myNewComment,
            commentIndex: commentIndex,
            postModel: postModel,
            newCommentId: newCommentId,
            parentCommentId: parentCommentId,
            mentionedUsers: mentionedUser);
      }

      //add locally
      allComments[commentIndex].addReply(newReplyComment);
      update();
      //for firestore
      RepliesModel repliesModel = RepliesModel(
          userUid: newReplyComment.user.uId,
          replyId: newReplyComment.id,
          replyTime: newReplyComment.createdAt,
          reply: newReplyComment.comment,
          mentionedUsers: mentionedUser);
      _commonService.setReply(post.postid ?? "", parentCommentId, repliesModel.replyId!, repliesModel.toMap());
      UserModel? userData = await _commonService.getUserById(post.postedBy.uId, forcefullyServer: true);
      AnalyticsController.to.instance.logReply(
          "postNewReply", "postId: ${post.postid ?? ""} , commentId: $parentCommentId , replyId: ${repliesModel.replyId ?? ""} ,   ");
      if (post.postedBy.uId != myAppUser.uId && post.postedBy.uId != allComments[commentIndex].comment.user.uId) {
        final fcmPostModel = FcmCreatePostModel(
          postid: post.postid ?? '',
          communityId: post.communityId ?? '',
          messageContent: "${isAnonymously ? anonymousUser : newReplyComment.user.name} has commented on your post.",
          messageTitle: 'You have a new comment',
          receiverFcm: userData?.fm_token ?? '',
        );
       _notificationApiHitting.callOnFcmApiForPostRelatedNotifications(fcmPostModel);
        _commonService.addNotification(
            posId: post.postid ?? '',
            isRead: false,
            message: "${isAnonymously ? anonymousUser : newReplyComment.user.name} has commented on your post.",
            receiverUserID: post.postedBy.uId ?? '',
            senderId: myAppUser.uId ?? '',
            senderName: isAnonymously ? anonymousUser : (myAppUser.name ?? "Gaya User"),
            time: DateTime.now().toString(),
            type: "postCommented",
            userImage: isAnonymously ? ImageAssetsUtils.anonymousUserNetworkUrl : myAppUser.profilePicture ?? "");
      }

      if (allComments[commentIndex].comment.user.uId != myAppUser.uId && allComments[commentIndex].comment.user.fm_token != null) {
        final fcmPostModel = FcmCreatePostModel(
          postid: post.postid ?? '',
          communityId: post.communityId ?? '',
          messageContent: isAnonymously ? "Anonymous user has replied to your comment." : "${myAppUser.name} has replied to your comment.",
          messageTitle: 'You have a new reply on comment',
          receiverFcm: allComments[commentIndex].comment.user.fm_token ?? '',
        );
        _notificationApiHitting.callOnFcmApiForPostRelatedNotifications(fcmPostModel);
        log('new comment added successfully.');
        _commonService.addNotification(
            posId: post.postid ?? '',
            isRead: false,
            message: isAnonymously ? "Anonymous user has replied to your comment." : "${myAppUser.name} has replied to your comment.",
            receiverUserID: allComments[commentIndex].comment.user.uId ?? '',
            senderId: myAppUser.uId ?? '',
            senderName: isAnonymously ? anonymousUser : (myAppUser.name ?? "Gaya User"),
            time: DateTime.now().toString(),
            type: "postCommented",
            userImage: isAnonymously ? ImageAssetsUtils.anonymousUserNetworkUrl : myAppUser.profilePicture ?? "");
      }
      // mentioned user functionality
      notificationSendToMentioedUser(mentionedUser: mentionedUser);
    } catch (_) {}
  }

  Future<void> likeAComment({
    required String commentId,
    required String communityId,
  }) async {
    int index = allComments.indexWhere((element) => element.comment.id == commentId);
    if (index == -1) return;
    allComments[index].comment = allComments[index].comment.copyWithLike();
    // print("likeAComment ${allComments[index].comment.totalLikes}");
    update();
    LikeCommentModel likeCommentModel = LikeCommentModel(userUid: myAppUser.uId, likeCommentId: myAppUser.uId);
    AnalyticsController.to.instance.logAddToLike(
      "likeAComment",
      "commentId: $commentId ",
      communityId: commentId,
    );

    /// score
    EngagementScoreController.to.instance.onLike(communityId: post.communityId ?? "", postId: post.postid ?? "", commentId: commentId);
    await FirebaseFirestore.instance
        .collection('communityposts')
        .doc(post.postid)
        .collection('comments')
        .doc(commentId)
        .collection('likeOnComment')
        .doc(myAppUser.uId)
        .set(likeCommentModel.toMap());
  }

  Future<void> unlikeAComment({required String commentId}) async {
    int index = allComments.indexWhere((element) => element.comment.id == commentId);
    if (index == -1) return;
    allComments[index].comment = allComments[index].comment.copyWithLike(shouldUnlike: true);
    // print("unlikeAComment ${allComments[index].comment.totalLikes}");
    update();
    AnalyticsController.to.instance.logUnlike("unlikeAComment", "commentId: $commentId ");
    EngagementScoreController.to.instance.onDislike(communityId: post.communityId ?? "", postId: post.postid ?? "", commentId: commentId);
    await FirebaseFirestore.instance
        .collection('communityposts')
        .doc(post.postid)
        .collection('comments')
        .doc(commentId)
        .collection('likeOnComment')
        .doc(myAppUser.uId)
        .delete();
    // print("unlike comment done");
  }

  /// Crown A Comment with Notification
  Future<void> crownAComment({
    required String commentId,
    UserModel? receiverUser,
    String? communityId,
  }) async {
    final isAnonymous = isPostedAnonymously(post);
    if (post.postid == null || receiverUser?.uId == null || myAppUser.uId == null || receiverUser?.uId == myAppUser.uId) return;
    int index = allComments.indexWhere((element) => element.comment.id == commentId);
    if (index == -1) return;
    final comment = allComments[index].comment;
    allComments[index].comment = allComments[index].comment.copyWithFlower();
    // update user daily crowns
    final tempCrownCount = myAppUser.userDailyCrowns;

    myAppUser.userDailyCrowns = (myAppUser.userDailyCrowns != null) ? myAppUser.userDailyCrowns! - 1 : myAppUser.userDailyCrowns;
    CacheController.to.updateUser(userModel);
    update();

    // log crown comment analytics event
    AnalyticsController.to.instance.logAddCrown(
      "crownAComment",
      "commentId: $commentId ",
      crownGiverId: UserModel.to.uId ?? '',
      communityId: communityId,
    );

    final isCrownedSuccesfully = await crownACommentCloudFunction(
      postId: post.postid!,
      commentId: commentId,
      receiverId: receiverUser!.uId!,
      currentUserId: myAppUser.uId!,
      communityId: communityId,
    );

    if (isCrownedSuccesfully) {
      _updateHomeWidgetTotalCount();

      /// score
      EngagementScoreController.to.instance.onCrown(communityId: post.communityId ?? "", postId: post.postid ?? "", commentId: commentId);
      //send notification
      if (comment.user.uId != userModel.uId) {
        UserModel? userData = await _commonService.getUserById(comment.user.uId, forcefullyServer: true);

        //fcm
        log('comment crowned: ${comment.user.uId}');
        final fcmPostModel = FcmCreatePostModel(
          postid: post.postid ?? '',
          communityId: post.communityId ?? '',
          messageContent: "${isAnonymous ? anonymousUser : myAppUser.name} crowned your comment.",
          messageTitle: postIsCrownedNotification,
          receiverFcm: userData?.fm_token ?? '',
        );

        _notificationApiHitting.callOnFcmApiForPostRelatedNotifications(fcmPostModel);

        //store notification
        _commonService.addNotification(
            posId: post.postid,
            isRead: false,
            message: "Your comment is crowned by ${(isAnonymous ? anonymousUser : myAppUser.name) ?? "Gaya User"}",
            receiverUserID: comment.user.uId!,
            senderId: UserModel.to.uId!,
            senderName: (isAnonymous ? anonymousUser : myAppUser.name) ?? "Gaya User",
            time: DateTime.now().toString(),
            type: "postCrowned",
            userImage: UserModel.to.profilePicture ?? "");
      }
    } else {
      // update user daily crowns
      myAppUser.userDailyCrowns = tempCrownCount;
      CacheController.to.updateUser(userModel);
      allComments[index].comment = allComments[index].comment.copyWithFlower(shouldUnCrown: true);
      update();
    }
  }

  _updateHomeWidgetTotalCount() {
    final CrownsController crownsController = Get.find();

    if (myAppUser.userDailyCrowns == 0) {
      crownsController.getCrownServerTimeStamp();
    } else {
      crownsController.updateCurrentUser();
    }
  }

  /// Crown A Comment Reply with Notification
  Future<void> crownAReplyComment({
    required String commentId,
    required String replyCommentId,
    UserModel? receiverUser,
    String? communityId,
  }) async {
    final isAnonymous = isPostedAnonymously(post);
    if (post.postid == null || receiverUser?.uId == null || myAppUser.uId == null || receiverUser?.uId == myAppUser.uId) return;
    // find parent comment Id index
    int index = allComments.indexWhere((element) => element.comment.id == commentId);
    if (index == -1) return;
    final replies = allComments[index].replies;
    // find reply comment index
    final replyCommentIndex = replies.indexWhere((element) => element.id == replyCommentId);
    allComments[index].replies[replyCommentIndex] = allComments[index].replies[replyCommentIndex].copyWithFlower();
    final reply = allComments[index].replies[replyCommentIndex];
    final tempCrownCount = myAppUser.userDailyCrowns;

    myAppUser.userDailyCrowns = (myAppUser.userDailyCrowns != null) ? myAppUser.userDailyCrowns! - 1 : myAppUser.userDailyCrowns;
    CacheController.to.updateUser(userModel);

    update();

    // log crown comment reply analytics event
    AnalyticsController.to.instance.logAddCrown(
      "crownAReplyComment",
      "commentId: $commentId replyCommentId: $replyCommentId",
      crownGiverId: UserModel.to.uId ?? '',
      communityId: communityId,
    );

    final isCrownedSuccesfully = await crownAReplyCommentCloudFunction(
      postId: post.postid!,
      commentId: commentId,
      receiverId: receiverUser!.uId!,
      currentUserId: myAppUser.uId!,
      replyId: replyCommentId,
      communityId: communityId,
    );

    if (isCrownedSuccesfully) {
      /// score
      EngagementScoreController.to.instance
          .onCrown(communityId: post.communityId ?? "", postId: post.postid ?? "", commentId: commentId, replyId: replyCommentId);
      _updateHomeWidgetTotalCount();
      //send notification
      if (reply.user.uId != userModel.uId) {
        UserModel? userData = await _commonService.getUserById(reply.user.uId, forcefullyServer: true);

        //fcm
        log('comment crowned: ${reply.user.uId}');
        final fcmPostModel = FcmCreatePostModel(
          postid: post.postid ?? '',
          communityId: post.communityId ?? '',
          messageContent: "${isAnonymous ? anonymousUser : myAppUser.name} crowned your comment.",
          messageTitle: postIsCrownedNotification,
          receiverFcm: userData?.fm_token ?? '',
        );

        _notificationApiHitting.callOnFcmApiForPostRelatedNotifications(fcmPostModel);

        //store notification
        _commonService.addNotification(
            posId: post.postid,
            isRead: false,
            message: "Your comment is crowned by ${(isAnonymous ? anonymousUser : myAppUser.name) ?? "Gaya User"}",
            receiverUserID: reply.user.uId!,
            senderId: UserModel.to.uId!,
            senderName: (isAnonymous ? anonymousUser : myAppUser.name) ?? "Gaya User",
            time: DateTime.now().toString(),
            type: "postCrowned",
            userImage: UserModel.to.profilePicture ?? "");
      }
    } else {
      // update user daily crowns
      myAppUser.userDailyCrowns = tempCrownCount;
      CacheController.to.updateUser(userModel);
      allComments[index].replies[replyCommentIndex] = allComments[index].replies[replyCommentIndex].copyWithFlower(shouldUnCrown: true);
      update();
    }
  }

  UserModel userModel = UserModel.to;
  CrownServices crownServices = CrownServices();

  /// this function is used to crown on comment on cloud
  Future<bool> crownACommentCloudFunction({
    required String postId,
    required String commentId,
    required String receiverId,
    required String currentUserId,
    String? communityId,
  }) async {
    final commentCrownPayload = CrownPayload(postId: postId, commentId: commentId, senderId: currentUserId, receiverId: receiverId);

    // log crown a comment analytics event
    AnalyticsController.to.instance.logAddCrown(
      "crownAComment",
      "commentId: $commentId currentUserId: $currentUserId receiverId: $receiverId  ",
      crownGiverId: UserModel.to.uId ?? '',
      communityId: communityId,
    );

    return await crownServices.crownOnComment(payload: commentCrownPayload);
  }

  /// this function is used to crown on comment on cloud
  Future<bool> crownAReplyCommentCloudFunction({
    required String postId,
    required String commentId,
    required String receiverId,
    required String currentUserId,
    required String replyId,
    String? communityId,
  }) async {
    final commentCrownPayload =
        CrownPayload(postId: postId, commentId: commentId, senderId: currentUserId, receiverId: receiverId, replyId: replyId);

    // log crown a comment analytics event
    AnalyticsController.to.instance.logAddCrown(
      "crownAReplyComment",
      "commentId: $commentId currentUserId: $currentUserId receiverId: $receiverId replyId:$replyId",
      crownGiverId: UserModel.to.uId ?? '',
      communityId: communityId,
    );

    return await crownServices.crownOnCommentReply(payload: commentCrownPayload);
  }

  Future<void> likeACommentReply({
    required String commentId,
    required String replyId,
    required String? communityId,
  }) async {
    // print("postId ${this.post.postid}");
    int index = allComments.indexWhere((element) => element.comment.id == commentId);
    if (index == -1) return;
    int replyIndex = allComments[index].replies.indexWhere((element) => element.id == replyId);
    if (replyIndex == -1) return;
    allComments[index].replies[replyIndex] = allComments[index].replies[replyIndex].copyWithLike();
    // print("likeACommentReply ${allComments[index].replies[replyIndex].totalLikes}");
    update();
    AnalyticsController.to.instance.logAddToLike(
      "likeACommentReply",
      "commentId: $commentId, replyId: $replyId",
      communityId: communityId,
    );
    LikeCommentModel likeCommentModel = LikeCommentModel(userUid: myAppUser.uId, likeCommentId: myAppUser.uId);

    /// score
    EngagementScoreController.to.instance
        .onLike(communityId: post.communityId ?? "", postId: post.postid ?? "", commentId: commentId, replyId: replyId);

    await FirebaseFirestore.instance
        .collection('communityposts')
        .doc(post.postid)
        .collection('comments')
        .doc(commentId)
        .collection('replies')
        .doc(replyId)
        .collection('likeOnComment')
        .doc(myAppUser.uId)
        .set(likeCommentModel.toMap());
    // print("likeACommentReply done");
  }

  Future<void> unlikeACommentReply({
    required String commentId,
    required String replyId,
    required String communityId,
  }) async {
    int index = allComments.indexWhere((element) => element.comment.id == commentId);
    if (index == -1) return;
    int replyIndex = allComments[index].replies.indexWhere((element) => element.id == replyId);
    if (replyIndex == -1) return;
    allComments[index].replies[replyIndex] = allComments[index].replies[replyIndex].copyWithLike(shouldUnlike: true);

    update();
    AnalyticsController.to.instance.logAddToLike(
      "commentReply",
      "commentId: $commentId, replyId: $replyId",
      communityId: communityId,
    );

    /// score
    EngagementScoreController.to.instance
        .onDislike(communityId: post.communityId ?? "", postId: post.postid ?? "", commentId: commentId, replyId: replyId);
    await FirebaseFirestore.instance
        .collection('communityposts')
        .doc(post.postid)
        .collection('comments')
        .doc(commentId)
        .collection('replies')
        .doc(replyId)
        .collection('likeOnComment')
        .doc(myAppUser.uId)
        .delete();
    // print("unlike comment done");
  }

  bool isPostedAnonymously(Post postModel) {
    return (postModel.isPostedAnonymously == true && postModel.postedBy.uId == myAppUser.uId);
  }

  bool _isLoading = false;

  bool get isLoading => _isLoading;

  void setLoading(bool value) {
    _isLoading = value;
    update();
  }

  Future<void> postNewCommentWithMedia(
      {required String newCommentId, required String myNewComment, List<Map<String, dynamic>>? mentionedUsers}) async {
    CommentCustomModel newComment = CommentCustomModel(
        id: newCommentId,
        comment: myNewComment,
        user: UserModel.to,
        createdAt: DateTime.now(),
        videoFile: isVideo ? commentsMedia : null,
        photoFile: isVideo
            ? null
            : isPdf
                ? null
                : commentsMedia,
        mediaSource: commentsMedia != null ? MediaSource.local : MediaSource.idle,
        mentionedUsers: mentionedUsers,
        documentFile: pdfFiles.isNotEmpty ? pdfFiles.first : null,
        pdfFiles: []);

    if (isVideo) {
      String? thumbnailUrl;
      service.uploadVideo(file: commentsMedia!).then((url) async {
        if (url == null) return;

        /// once media is uploaded, update the comment with real url
        File? thumbnailFile = await service.getThumbnailFromVideoUrl(videoUrl: url);
        if (thumbnailFile != null) {
          thumbnailUrl = await service.uploadPhoto(file: thumbnailFile);
        }
        Map<String, dynamic>? videoData = {};
        videoData['thumbnailUrl'] = thumbnailUrl;
        videoData['videoUrl'] = url;
        _updateNewCommentLocally(videoData: videoData, commentId: newCommentId, isVideo: true, mentionedUsers: mentionedUsers);
        newComment.copyWith(videoUrl: videoData);
        sendCommentToFirebase(newComment: newComment, videoUrl: videoData);
      });
      // video thumbnail
    } else if (isPdf && pdfFiles.isNotEmpty) {
      String? thumbnailUrl;
      service.uploadDocument(file: pdfFiles.first).then((url) async {
        if (url == null) return;

        File? thumbnailFile = await generateThumbnailFile(url: pdfFiles.first.path);
        if (thumbnailFile != null) {
          // ignore: use_build_context_synchronously
          thumbnailUrl = await service.uploadDocumentThumbnail(file: thumbnailFile);
        }

        List<Map<String, dynamic>> documentFiles = [];
        if (thumbnailUrl != null) {
          documentFiles = [];
          documentFiles.add({
            'title': documentTextField.text.isEmpty ? '' : documentTextField.text.trim(),
            'fileUrl': url,
            'fileName': pdfFiles.first.path.split("/").last,
            'thumbnail': thumbnailUrl
          });
        }
        MyLoggerServices.to.print('allcommentslength is: ${allComments.length}');
        _updateNewCommentLocally(
            videoData: {},
            commentId: newCommentId,
            isVideo: false,
            isPdf: true,
            mentionedUsers: mentionedUsers,
            documentFiles: documentFiles);
        newComment = newComment.copyWith(pdfFiles: documentFiles, documentFile: null);
        sendCommentToFirebase(newComment: newComment, documentFiles: documentFiles);
        pdfFiles = [];
        documentFiles = [];
      });
    } else {
      service.uploadPhoto(file: commentsMedia!).then((url) {
        if (url == null) return;

        /// once media is uploaded, update the comment with real url
        _updateNewCommentLocally(videoData: {}, commentId: newCommentId, isVideo: false, photoUrl: url, mentionedUsers: mentionedUsers);
        sendCommentToFirebase(newComment: newComment, photoUrl: url);
      });
    }
    // allComments.insert(0, MultiCommentModel(comment: newComment, replies: []));
    if (service.hasMoreComments == false) {
      allComments.add(MultiCommentModel(comment: newComment, replies: []));
    }
    MyLoggerServices.to.print('allcommentslength is after: ${allComments.length}');

    notificationSendToMentioedUser(mentionedUser: mentionedUsers);
    commentsMedia = null;
    isPdf = false;
    pdfThumbnail = null;
    // pdfFiles = [];
    isVideo = false;
    setLoading(false);
  }

  Future<File?> generateThumbnailFile({required String url}) async {
    CacheServices cacheService = CacheServices();
    return await cacheService.generateThumbnailFile(url: url);
  }

  Future<void> generateLocalPdfThumbnail({required String url}) async {
    CacheServices cacheService = CacheServices();
    pdfThumbnail = await cacheService.generatelocalPdfThumbnail(url: url);
    setLoading(false);
  }

  Future<String> downloadAndCachePdf({required String url}) async {
    CacheServices cacheService = CacheServices();

    return await cacheService.downloadAndCachePdf(url: url);
  }

  //UPLOAD THE Document TO FIREBASESTORAGE
  // uploadDocumentToFirebase(BuildContext context, File? file) async {
  //   try {
  //     if (file == null) {
  //       // log("There is no video to upload");
  //     } else {
  //       UploadTask uploadTask = FirebaseStorage.instance.ref().child('post documents').child(uuid.v1()).putFile(file);
  //       StreamSubscription listenEvent = uploadTask.snapshotEvents.listen((data) {
  //         videoUploadingPercentage = (data.bytesTransferred / data.totalBytes);
  //         notifyListeners();
  //         if (data.state == TaskState.success) {
  //           videoUploadingPercentage = null;
  //           // log('Our video uploading done');
  //         }
  //         // log('This is our uploading video task : ${videoUploadingPercentage.toString()}');
  //       });
  //       TaskSnapshot taskSnapshot = await uploadTask;
  //       pdfDocumentDownloadLink = await taskSnapshot.ref.getDownloadURL();
  //       listenEvent.cancel();
  //       // log(downloadUrl!);
  //     }
  //   } catch (e) {
  //     // log(e.toString());
  //     snackBar(context, "Uploading of video failed!", kRedColor);
  //   }
  // }

  _updateNewCommentLocally({
    required Map<String, dynamic> videoData,
    required String commentId,
    bool isVideo = false,
    bool isPdf = false,
    String? replyId,
    String? photoUrl,
    List<Map<String, dynamic>>? mentionedUsers,
    List<Map<String, dynamic>>? documentFiles,
  }) {
    /// if replyId is not null, then it is a reply
    if (replyId != null) {
      final commentIndex = allComments.indexWhere((element) => element.comment.id == commentId);
      if (commentIndex == -1) {
        return;
      }
      final replyIndex = allComments[commentIndex].replies.indexWhere((element) => element.id == replyId);
      if (replyIndex == -1) {
        //reply does not exist for some reason
        debugPrint("reply[commentIndex] comment doesnt exist....");
        return;
      }
      debugPrint("dataasdasd: $photoUrl");
      if (isVideo) {
        allComments[commentIndex].replies[replyIndex] = allComments[commentIndex]
            .replies[replyIndex]
            .copyWith(videoUrl: videoData, mediaSource: MediaSource.network, mentionedUsers: mentionedUsers);
      } else if (isPdf) {
        try {
          allComments[commentIndex].replies[replyIndex] = allComments[commentIndex]
              .replies[replyIndex]
              .copyWith(pdfFiles: documentFiles, mediaSource: MediaSource.network, mentionedUsers: mentionedUsers);
          debugPrint(
              "pdf files length in func: (_updateNewCommentLocally) : ${allComments[commentIndex].replies[replyIndex].pdfFiles?.length}");
        } catch (_) {
          debugPrint("_ $_");
        }
      } else {
        try {
          allComments[commentIndex].replies[replyIndex] = allComments[commentIndex]
              .replies[replyIndex]
              .copyWith(photoUrl: photoUrl, mediaSource: MediaSource.network, mentionedUsers: mentionedUsers);
          debugPrint("daadada : ${allComments[commentIndex].replies[replyIndex].photoUrl}");
        } catch (_) {
          debugPrint("_ $_");
        }
      }
      update();
      return;
    }

    /// if [replyId] is null, then it is a parent comment
    MyLoggerServices.to.print('commentId is: $commentId');
    final comment = allComments.firstWhereOrNull((element) => element.comment.id == commentId);
    if (comment == null) return; //comment does not exist for some reason
    if (isVideo) {
      comment.comment = comment.comment.copyWith(videoUrl: videoData, mediaSource: MediaSource.network);
    } else if (isPdf) {
      comment.comment = comment.comment.copyWith(pdfFiles: documentFiles, mediaSource: MediaSource.network);
    } else {
      comment.comment = comment.comment.copyWith(photoUrl: photoUrl, mediaSource: MediaSource.network);
    }
    update();
  }

  /// Post new comment [Firebase Firestore]
  Future<void> sendCommentToFirebase(
      {required CommentCustomModel newComment,
      Map<String, dynamic>? videoUrl,
      String? photoUrl,
      List<Map<String, dynamic>>? documentFiles}) async {
    final isAnonymous = isPostedAnonymously(post);
    UserModel? userData = await _commonService.getUserById(post.postedBy.uId, forcefullyServer: true);
    if (post.postedBy.uId != myAppUser.uId) {
      final fcmPostModel = FcmCreatePostModel(
        postid: post.postid ?? '',
        communityId: post.communityId ?? '',
        messageContent: "${isAnonymous ? anonymousUser : myAppUser.name} has commented on your post.",
        messageTitle: 'You have a new comment',
        receiverFcm: userData?.fm_token ?? '',
      );
      _notificationApiHitting.callOnFcmApiForPostRelatedNotifications(fcmPostModel);
      _commonService.addNotification(
          posId: post.postid ?? '',
          isRead: false,
          message: "${isAnonymous ? anonymousUser : myAppUser.name} has commented on your post.",
          receiverUserID: post.postedBy.uId ?? '',
          senderId: myAppUser.uId ?? '',
          senderName: isAnonymous ? anonymousUser : myAppUser.name ?? "Gaya User",
          time: DateTime.now().toString(),
          type: "postCommented",
          userImage: isAnonymous ? ImageAssetsUtils.anonymousUserNetworkUrl : myAppUser.profilePicture ?? "");
    }

    CommentsModel commentsModel = CommentsModel(
        userId: myAppUser.uId,
        photoUrl: photoUrl,
        videoUrl: videoUrl,
        comment: newComment.comment,
        commentId: newComment.id,
        mentionedUsers: newComment.mentionedUsers,
        commentTime: newComment.createdAt,
        pdfFiles: documentFiles);
    _commonService.postComment(post.postid ?? "", commentsModel.commentId!, commentsModel.toMap());
  }

  Future<void> sendCommentReplyToFirebase(
      {required CommentCustomModel newReplyComment,
      Map<String, dynamic>? videoUrl,
      String? photoUrl,
      required String parentCommentId,
      required int commentIndex,
      List<Map<String, dynamic>>? documentFiles}) async {
    final isAnonymously = isPostedAnonymously(post);
    //for firestore
    RepliesModel repliesModel = RepliesModel(
        userUid: newReplyComment.user.uId,
        replyId: newReplyComment.id,
        replyTime: newReplyComment.createdAt,
        photoUrl: photoUrl,
        videoUrl: videoUrl,
        mentionedUsers: newReplyComment.mentionedUsers,
        reply: newReplyComment.comment,
        pdfFiles: documentFiles);
    _commonService.setReply(
      post.postid ?? "",
      parentCommentId,
      repliesModel.replyId!,
      repliesModel.toMap(),
    );
    UserModel? userData = await _commonService.getUserById(post.postedBy.uId, forcefullyServer: true);

    if (post.postedBy.uId != myAppUser.uId && post.postedBy.uId != allComments[commentIndex].comment.user.uId) {
      final fcmPostModel = FcmCreatePostModel(
        postid: post.postid ?? '',
        communityId: post.communityId ?? '',
        messageContent: "${isAnonymously ? anonymousUser : newReplyComment.user.name} has commented on your post.",
        messageTitle: 'You have a new comment',
        receiverFcm: userData?.fm_token ?? '',
      );
      _notificationApiHitting.callOnFcmApiForPostRelatedNotifications(fcmPostModel);

      _commonService.addNotification(
          posId: post.postid ?? '',
          isRead: false,
          message: "${myAppUser.name} has commented on your post.",
          receiverUserID: post.postedBy.uId ?? '',
          senderId: myAppUser.uId ?? '',
          senderName: isAnonymously ? anonymousUser : (myAppUser.name ?? "Gaya User"),
          time: DateTime.now().toString(),
          type: "postCommented",
          userImage: isAnonymously ? ImageAssetsUtils.anonymousUserNetworkUrl : myAppUser.profilePicture ?? "");
    }

    if (allComments[commentIndex].comment.user.uId != myAppUser.uId && allComments[commentIndex].comment.user.fm_token != null) {
      final fcmPostModel = FcmCreatePostModel(
        postid: post.postid ?? '',
        communityId: post.communityId ?? '',
        messageContent: isAnonymously ? "Anonymous user has replied to your comment." : "${myAppUser.name} has replied to your comment.",
        messageTitle: 'You have a new reply on comment',
        receiverFcm: allComments[commentIndex].comment.user.fm_token ?? '',
      );

      _notificationApiHitting.callOnFcmApiForPostRelatedNotifications(fcmPostModel);
      log('new comment added successfully.');

      _commonService.addNotification(
          posId: post.postid ?? '',
          isRead: false,
          message: isAnonymously ? "Anonymous user has replied to your comment." : "${myAppUser.name} has replied to your comment.",
          receiverUserID: allComments[commentIndex].comment.user.uId ?? '',
          senderId: myAppUser.uId ?? '',
          senderName: isAnonymously ? anonymousUser : (myAppUser.name ?? "Gaya User"),
          time: DateTime.now().toString(),
          type: "postCommented",
          userImage: isAnonymously ? ImageAssetsUtils.anonymousUserNetworkUrl : myAppUser.profilePicture ?? "");
    }
  }

  Future<void> postNewCommentReplyWithMedia(
      {required String myNewComment,
      required int commentIndex,
      required Post postModel,
      required String newCommentId,
      required String parentCommentId,
      List<Map<String, dynamic>>? mentionedUsers}) async {
    CommentCustomModel newReplyComment = CommentCustomModel(
        id: newCommentId,
        comment: myNewComment,
        user: UserModel.to,
        createdAt: DateTime.now(),
        videoFile: isVideo ? commentsMedia : null,
        // photoFile: !isVideo ? commentsMedia : null,
        photoFile: isVideo
            ? null
            : isPdf
                ? null
                : commentsMedia,
        mediaSource: commentsMedia != null ? MediaSource.local : MediaSource.idle,
        mentionedUsers: mentionedUsers,
        documentFile: pdfFiles.isNotEmpty ? pdfFiles.first : null,
        pdfFiles: []);

    String? thumbnailUrl;
    Map<String, dynamic>? videoData = {};
    if (commentsMedia != null || pdfFiles.isNotEmpty) {
      if (isVideo) {
        service.uploadVideo(file: commentsMedia!).then((videoUrl) async {
          if (videoUrl != null) {
            File? thumbnailFile = await service.getThumbnailFromVideoUrl(videoUrl: videoUrl);
            if (thumbnailFile != null) {
              thumbnailUrl = await service.uploadVideo(file: thumbnailFile);
            }
            videoData['videoUrl'] = videoUrl;
            videoData['thumbnailUrl'] = thumbnailUrl;
            _updateNewCommentLocally(
                videoData: videoData,
                commentId: parentCommentId,
                isVideo: true,
                photoUrl: null,
                replyId: newCommentId,
                mentionedUsers: mentionedUsers);
            newReplyComment.copyWith(videoUrl: videoData, photoUrl: null);
            sendCommentReplyToFirebase(
                newReplyComment: newReplyComment, parentCommentId: parentCommentId, commentIndex: commentIndex, videoUrl: videoData);
            setLoading(false);
          }
        });
      } else if (isPdf && pdfFiles.isNotEmpty) {
        String? thumbnailUrl;
        service.uploadDocument(file: pdfFiles.first).then((url) async {
          if (url == null) return;

          File? thumbnailFile = await generateThumbnailFile(url: pdfFiles.first.path);
          if (thumbnailFile != null) {
            // ignore: use_build_context_synchronously
            thumbnailUrl = await service.uploadDocumentThumbnail(file: thumbnailFile);
          }

          List<Map<String, dynamic>> documentFiles = [];
          if (thumbnailUrl != null) {
            documentFiles = [];
            documentFiles.add({
              'title': documentTextField.text.isEmpty ? '' : documentTextField.text.trim(),
              'fileUrl': url,
              'fileName': pdfFiles.first.path.split("/").last,
              'thumbnail': thumbnailUrl
            });
          }
          MyLoggerServices.to.print('allcommentslength is: ${allComments.length}');
          newReplyComment = newReplyComment.copyWith(pdfFiles: documentFiles, documentFile: null);

          _updateNewCommentLocally(
              videoData: {},
              commentId: parentCommentId,
              isVideo: false,
              isPdf: true,
              photoUrl: url,
              replyId: newCommentId,
              mentionedUsers: mentionedUsers,
              documentFiles: documentFiles);

          sendCommentReplyToFirebase(
              newReplyComment: newReplyComment, parentCommentId: parentCommentId, commentIndex: commentIndex, documentFiles: documentFiles);

          // _updateNewCommentLocally(
          //     videoData: {},
          //     commentId: newCommentId,
          //     isVideo: false,
          //     isPdf: true,
          //     mentionedUsers: mentionedUsers,
          //     documentFiles: documentFiles);
          // newReplyComment = newReplyComment.copyWith(pdfFiles: documentFiles, documentFile: null);
          // sendCommentReplyToFirebase(newComment: newReplyComment, documentFiles: documentFiles);
          pdfFiles = [];
          documentFiles = [];
        });
      } else {
        service.uploadPhoto(file: commentsMedia!).then((url) {
          newReplyComment.copyWith(videoUrl: null, photoUrl: url);
          _updateNewCommentLocally(
              videoData: {},
              commentId: parentCommentId,
              isVideo: false,
              photoUrl: url,
              replyId: newCommentId,
              mentionedUsers: mentionedUsers);

          sendCommentReplyToFirebase(
              newReplyComment: newReplyComment, parentCommentId: parentCommentId, commentIndex: commentIndex, photoUrl: url);
        });
      }
    }
    allComments[commentIndex].addReply(newReplyComment);
    notificationSendToMentioedUser(mentionedUser: mentionedUsers);
    commentsMedia = null;
    isPdf = false;
    pdfThumbnail = null;
    setLoading(false);
  }

  // done by mak

  // by mak => picking image from gallerey with proper permission handling etc
  final MediaService _mediaService = MediaService();

  Future<void> pickPhoto({required BuildContext context, int imageQuality = 50}) async {
    try {
      isVideo = false;
      List<XFile>? file = await _mediaService.pickImageFromGallery(context: context, imageQuality: imageQuality);
      if (file != null && file.isNotEmpty) {
        commentsMedia = File(file.last.path);
        List<File> files = await Routes.cropPhotoView(imageFile: <File>[commentsMedia!]);
        if (files.isNotEmpty) {
          commentsMedia = files.first;
        }
      }
      update();
    } on PlatformException catch (e) {
      log(e.toString());
    } catch (e) {
      log(e.toString());
    }
  }

  // by mak => picking video from gallerey with proper permission handling etc
  Future<void> pickVideo({required BuildContext context, int imageQuality = 50}) async {
    try {
      isVideo = true;
      XFile? file = await _mediaService.pickVideoFromGallery(context: context);
      if (file != null) {
        commentsMedia = File(file.path);
        commentsMedia = await Routes.cropVideoView(video: commentsMedia!);
      }
      update();
    } on PlatformException catch (e) {
      log(e.toString());
    } catch (e) {
      log(e.toString());
    }
  }

  final MediaService filePickerService = MediaService();

  //GET THE Document FROM STORAGE
  Future getPdfDocument(BuildContext context) async {
    try {
      documentTextField.clear();
      pdfFiles = [];
      commentsMedia = null;

      isPdf = true;
      final File? document = await filePickerService.pickFile(context: context);
      if (document != null) {
        pdfFiles.add(document);
      } else {
        MyLoggerServices.to.print('No Document picked');
      }
      update();
    } catch (e) {
      debugPrint('error during document picking!: ${e.toString()}');
    }
  }

  void removeSelectedCommentsMedia() {
    try {
      documentTextField.clear();
      commentsMedia = null;
      pdfFiles = [];
      pdfThumbnail = null;
      isPdf = false;

      update();
    } catch (e) {
      log(e.toString());
    }
  }
}
