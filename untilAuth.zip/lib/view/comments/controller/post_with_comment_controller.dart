import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:gaya/controller/cache_controller.dart';
import 'package:gaya/controller/crowns_controller.dart';
import 'package:gaya/controller/firebase_analytics_controller.dart';
import 'package:gaya/model/create.post.model.dart';
import 'package:gaya/shared/service/crown_service/crown_services.dart';
import 'package:gaya/utils/logger.dart';
import 'package:gaya/view/community/controllers/community_feed_controller.dart';
import 'package:gaya/view/feed/controller/post_controller.dart';
import 'package:get/get.dart';

import '../../../controller/app_config_controller.dart';
import '../../../model/local/crown_payload.dart';
import '../../../model/user.model.dart';
import '../../../services/notification/notification_api/notification_api.dart';
import '../../../services/services.dart';
import '../../../utils/strings.dart';
import '../../feed/controller/base/base_feed_impl.dart';
import '../../feed/controller/for_you_controller.dart';

class PostWithCommentController extends GetxController {
  Post post;

  static PostWithCommentController to({required String? tag}) => Get.find<PostWithCommentController>(tag: tag);

  PostWithCommentController({required this.post});

  final User? _user = FirebaseAuth.instance.currentUser;
  final Services _commonService = Services();
  final NotificationApiHitting _notificationApiHitting = NotificationApiHitting();

  UserModel get myAppUser => UserModel.to;

  String get communityId => post.communityId ?? "-1";

  /// returns true if user is member of existing community
  bool get isMember => AppConfigurationController.to.isMemberOfCommunity(communityId, includesAll: true);

  /// returns true if community is public
  bool get isCommunityPublic => post.isCommunityPublic;

  @override
  void onInit() {
    super.onInit();
    fetchPost();
  }

  void fetchPost() async {
    setLoading(true);
    PerformanceController.to.instance.startLoadPostTime();
    final loadedPost = await _commonService.getPostDetailsSnapshot(post.postid ?? "");
    PerformanceController.to.instance.stopLoadPostTime();
    if (loadedPost != null) {
      post = loadedPost;
    }
    setLoading(false);
  }

  Future<void> updatePostTopicsFirebase(Post post) async {
    await _commonService.updatePostTopics(post);
    _updateHomeFeedPost();
  }

  Future<void> likePost() async {
    if (_user == null) return;
    post.likedBy?.insert(0, _user?.uid ?? "");
    _commonService.likeOnPost(post.postid ?? "", communityId);
    update();
    _updateHomeFeedPost();
    if (post.postedBy.uId != UserModel.to.uId) {
      UserModel? userData = await _commonService.getUserById(post.postedBy.uId, forcefullyServer: true);
      if (userData?.uId == null) return;
      //fcm
      final fcmPostModel = FcmCreatePostModel(
        postid: post.postid ?? '',
        communityId: post.communityId ?? '',
        messageContent: "${myAppUser.name} liked your post.",
        messageTitle: postIsLikedNotification,
        receiverFcm: userData?.fm_token ?? '',
      );

      _notificationApiHitting.callOnFcmApiForPostRelatedNotifications(fcmPostModel);

      if (UserModel.to.uId != null && post.postedBy.uId != null) {
        //store notification
        _commonService.addNotification(
            posId: post.postid,
            isRead: false,
            message: "Your Post is Liked.",
            receiverUserID: post.postedBy.uId!,
            senderId: UserModel.to.uId!,
            senderName: UserModel.to.name ?? "Gaya User",
            time: DateTime.now().toString(),
            type: "postLiked",
            userImage: UserModel.to.profilePicture ?? "");
      }

      ///score
      EngagementScoreController.to.instance.onLike(communityId: post.communityId ?? "", postId: post.postid ?? "");
    }
  }

  bool isPostedAnonymously(Post postModel) {
    return (postModel.isPostedAnonymously == true && postModel.postedBy.uId == myAppUser.uId);
  }

  // mentioned users in comments
  Future<void> mentionedUsersOnPost({List<String> mentionedUsers = const []}) async {
    try {
      bool isAnonymous = isPostedAnonymously(post);
      if (_user == null) return;
      // if (post.postedBy.uId != UserModel.to.uId) {
      // UserModel? postUserData = await _commonService.getUserById(post.postedBy.uId);
      List<UserModel> notifyUsers = [];
      for (var user in mentionedUsers) {
        UserModel? userData = await _commonService.getUserById(user, forcefullyServer: true);
        if (userData != null) {
          notifyUsers.add(userData);
        }
      }
      //fcm
      for (var notifyUser in notifyUsers) {
        final fcmPostModel = FcmCreatePostModel(
          postid: post.postid ?? '',
          communityId: post.communityId ?? '',
          messageContent: "${isAnonymous ? anonymousUser : myAppUser.name} has mentioned you in a comment.",
          messageTitle: youMentionedNotification,
          receiverFcm: notifyUser.fm_token ?? '',
        );
        _notificationApiHitting.callOnFcmApiForPostRelatedNotifications(fcmPostModel);

        //store notification
        _commonService.addNotification(
            posId: post.postid,
            isRead: false,
            message: "You have mentioned in a Comment.",
            receiverUserID: notifyUser.uId!,
            senderId: UserModel.to.uId!,
            senderName: "${isAnonymous ? anonymousUser : myAppUser.name}",
            time: DateTime.now().toString(),
            type: "postCommented",
            userImage: UserModel.to.profilePicture ?? "");
      }
      // }
    } catch (e) {
      MyLoggerServices.to.print('error thrown during notification sending!');
    }
  }

  UserModel userModel = UserModel.to;
  CrownServices crownServices = CrownServices();

  Future<PostReaction> crownPost(String? postId, {UserModel? receiverUser}) async {
    String currentUserId = FirebaseAuth.instance.currentUser?.uid ?? "";
    PostReaction operationPerformed = PostReaction.idle;
    if (postId == null) return operationPerformed;
    //checking if the post is already flowered by the user
    bool? isCrowned = post.crownsBy?.contains(FirebaseAuth.instance.currentUser?.uid ?? "");
    if (isCrowned == true) {
      print('Post already crowned');
    } else if (isCrowned == false) {
      post.crownsBy ??= [];
      //locally
      post.crownsBy?.add(currentUserId);
      post.postedBy = post.postedBy.updateCrown(shouldIncreament: true);
      // cache author update
      CacheController.to.updateUser(post.postedBy);
      final tempCrown = userModel.userDailyCrowns;

      userModel.userDailyCrowns = (userModel.userDailyCrowns != null) ? userModel.userDailyCrowns! - 1 : userModel.userDailyCrowns;
      // cache update
      CacheController.to.updateUser(userModel);
      update();
      //db operation
      bool isSuccess = await crownAPostCloudFunction(postId, receiverUser?.uId ?? '', currentUserId);
      if (isSuccess == false) {
        post.crownsBy?.remove(currentUserId);
        post.postedBy.updateCrown(shouldIncreament: false);
        // cache author update
        CacheController.to.updateUser(post.postedBy);
        userModel.userDailyCrowns = tempCrown;
        // userModel.userDailyCrowns = (userModel.userDailyCrowns != null) ? userModel.userDailyCrowns! + 1 : userModel.userDailyCrowns;
        // cache update
        CacheController.to.updateUser(userModel);
      } else {
        EngagementScoreController.to.instance.onCrown(postId: postId, communityId: post.communityId ?? '');
        final CrownsController crownsController = Get.find();
        if (userModel.userDailyCrowns == 0) {
          crownsController.getCrownServerTimeStamp();
        } else {
          crownsController.updateCurrentUser();
        }
      }
      //send notification
      if (post.postedBy.uId != userModel.uId) {
        UserModel? userData = await _commonService.getUserById(post.postedBy.uId, forcefullyServer: true);
        //fcm
        final fcmPostModel = FcmCreatePostModel(
          postid: post.postid ?? '',
          communityId: post.communityId ?? '',
          messageContent: "${myAppUser.name} crowned on your post.",
          messageTitle: postIsCrownedNotification,
          receiverFcm: userData?.fm_token ?? '',
        );

        _notificationApiHitting.callOnFcmApiForPostRelatedNotifications(fcmPostModel);
        //store notification
        _commonService.addNotification(
            posId: post.postid,
            isRead: false,
            message: "Your Post is Crowned.",
            receiverUserID: post.postedBy.uId!,
            senderId: UserModel.to.uId!,
            senderName: UserModel.to.name ?? "Gaya User",
            time: DateTime.now().toString(),
            type: "postCrowned",
            userImage: UserModel.to.profilePicture ?? "");
      }
      operationPerformed = PostReaction.crown;
    } else {
      MyLoggerServices.to.print("nothing performed on post");
    }
    _updateHomeFeedPost();
    update();

    return operationPerformed;
  }

  /// this function is used to crown a post on cloud
  Future<bool> crownAPostCloudFunction(String postId, String receiverId, String currentUserId) async {
    final payload = CrownPayload(postId: postId, senderId: currentUserId, receiverId: receiverId);
    return await crownServices.crownOnPost(payload: payload);
  }

  void unlikePost() {
    if (_user == null) return;
    post.likedBy?.remove(_user?.uid ?? "");
    FirebaseFirestore.instance.collection('communityposts').doc(post.postid).update({
      'likedBy': FieldValue.arrayRemove([UserModel.to.uId]),
    });
    EngagementScoreController.to.instance.onDislike(communityId: post.communityId ?? "", postId: post.postid ?? "");
    update();
    _updateHomeFeedPost();
  }

  void incrementCommentCount() {
    if (_user == null) return;
    post.totalCommentsCount ??= "0";
    int totalCommentCount = int.tryParse(post.totalCommentsCount ?? "0") ?? 0;
    post.totalCommentsCount = (totalCommentCount + 1).toString();
    update();
    _updateHomeFeedPost();
  }

  void _updateHomeFeedPost() {
    try {
      //update post at home feed
      FeedControllerUtils.updatePostLocally(post);
    } catch (_) {
      MyLoggerServices.to.print("error at updating postwithcontroller to homefed");
    }
  }

  //update posts comment (locally)
  void updateTotalComments(int deletedCommentCount) {
    try {
      int totalComments = int.parse(post.totalCommentsCount ?? "");
      int updatedCommentCount = totalComments - deletedCommentCount;
      if (updatedCommentCount > 0) {
        post.totalCommentsCount = updatedCommentCount.toString();
      }
    } catch (_) {
    } finally {
      update();
    }
  }

  /// delete posts from all feeds (community, forYou, myCommunities )
  void deletePostFromFeeds({required Post post}) {
    try {
      /// delete
      CommunityFeedController.to(tag: post.communityId).deletePostLocally(post);

      /// delete from [Home] feed
      ForYouFeedController.to.updatePostLocally(post, shouldDelete: true);

      /// delete from [My Communities] [feed]
      FeedPostsController.to.updatePostLocally(post, shouldDelete: true);
    } catch (_, s) {
      CrashlyticsController.to.instance.recordError(_, stackTrace: s, reason: 'deletePostFromFeeds at $runtimeType');
    }
  }

  bool _isLoading = false;

  bool get isLoading => _isLoading;

  void setLoading(bool value) {
    _isLoading = value;
    update();
  }

  addRemovePostTopic(String topic) {
    if (post.postTopicList == null) {
      post.postTopicList = [topic];
    } else {
      if (post.postTopicList!.contains(topic)) {
        post.postTopicList!.remove(topic);
      } else {
        post.postTopicList!.add(topic);
      }
    }
    update();
  }

  updatePostTopics(context, Post post) async {
    await _commonService.updatePostTopics(post);
    update();
  }
}

class NotificationReaction {}
