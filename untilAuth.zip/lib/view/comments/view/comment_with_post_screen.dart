// ignore_for_file: use_build_context_synchronously

import 'package:easy_refresh/easy_refresh.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:flutter_mentions/flutter_mentions.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gaya/components/button.component.dart';
import 'package:gaya/components/profile_image_widget.dart';
import 'package:gaya/controller/firebase_analytics_controller.dart';
import 'package:gaya/controller/report_controller.dart';
import 'package:gaya/model/create.post.model.dart';
import 'package:gaya/model/user.model.dart';
import 'package:gaya/routing/getx_route_methods.dart';
import 'package:gaya/shared/controller/mentioned_user_controller.dart';
import 'package:gaya/shared/view/widget/gaya_back_button.dart';
import 'package:gaya/shared/view/widget/gaya_upload_document_madalsheet.dart';
import 'package:gaya/shared/view/widget/mentions_user_field_view.dart';
import 'package:gaya/shared/view/widget/pdf_view_widget.dart';
import 'package:gaya/utils/const.dart';
import 'package:gaya/utils/language/translation.dart';
import 'package:gaya/utils/methods.dart';
import 'package:gaya/utils/strings.dart';
import 'package:gaya/utils/textstyles.dart';
import 'package:gaya/utils/theme/app_spaces.dart';
import 'package:gaya/view/chat/controllers/chat_controller.dart';
import 'package:gaya/view/comments/controller/comments_controller.dart';
import 'package:gaya/view/comments/controller/post_with_comment_controller.dart';
import 'package:gaya/view/comments/models/comment_custom_model.dart';
import 'package:gaya/view/community/controllers/community_editing_controller.dart';
import 'package:gaya/view/not_found_view.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

import '../../../components/skeleton.post.component.dart';
import '../../../controller/app_config_controller.dart';
import '../../../controller/create.post.controller.dart';
import '../../../controller/group.controller.dart';
import '../../../controller/homepage.controller.dart';
import '../../../model/community.model.dart';
import '../../../utils/refresh_builder_utils.dart';
import '../../../utils/theme/app_typography.dart';
import '../../../widgets/home_view_widgets/home.post.widget.dart';
import '../components/comments_listview.dart';
import '../components/speed_dial_button.dart';
import 'comment_with_mediaview.dart';

/// IOS Screen
/// getting get arguments for postID
class CommentWithPostIOSScreen extends StatefulWidget {
  const CommentWithPostIOSScreen({Key? key}) : super(key: key);

  @override
  State<CommentWithPostIOSScreen> createState() => _CommentWithPostIOSScreenState();
}

class _CommentWithPostIOSScreenState extends State<CommentWithPostIOSScreen> {
  final TextEditingController _commentC = TextEditingController();
  late ScrollController _scrollController;
  bool showProgressindicator = false;

  bool toggleDM = false;

  // late ScrollController _commentsParentScrollController;
  GlobalKey<FlutterMentionsState> textFormFieldKey = GlobalKey<FlutterMentionsState>();

  /// getting postID from get arguments
  /// this is the postID of the post that is being commented on
  final postId = (Get.arguments["post"] as Post).postid;

  @override
  void dispose() {
    super.dispose();
    _commentC.dispose();
    _scrollController.removeListener(() {});
    _scrollController.dispose();
    // _commentsParentScrollController.removeListener(() {});
    // _commentsParentScrollController.dispose();
    textFormFieldKey.currentState?.controller?.dispose();
  }

  @override
  void initState() {
    _scrollController = ScrollController();
    // _commentsParentScrollController = ScrollController();
    _scrollController.addListener(() {
      //if dragging up, close keyboard
      if (_scrollController.position.userScrollDirection == ScrollDirection.forward) {
        closeKeyboard();
      }
    });
    super.initState();
  }

  void scrollToBottom() {
    _scrollController.animateTo(
      _scrollController.position.maxScrollExtent,
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeOut,
    );
  }

  void closeKeyboard() => FocusScope.of(context).unfocus();

  Future<bool> _onBackPressed() {
    try {
      final postWithCommentController = PostWithCommentController.to(tag: postId);
      Get.back(result: postWithCommentController.post);
    } catch (_) {
      Get.back();
    }
    return Future.value(true);
  }

  @override
  Widget build(BuildContext context) {
    final PostWithCommentController postWithCommentController = PostWithCommentController.to(tag: postId);
    final CommentsController commentsController = Get.find<CommentsController>(tag: postId);

    return Scaffold(
      bottomNavigationBar: GetBuilder<PostWithCommentController>(
          autoRemove: false,
          tag: postId,
          init: postWithCommentController,
          builder: (postWithCommentController) {
            if (postWithCommentController.isLoading) {
              return const SizedBox.shrink();
            }

            // if post is null or user is not a member of the community
            if (postWithCommentController.post.postid == null) {
              return const NotFoundView();
            }

            /// if user is not member of community then show no found view.
            /// if community is not public then show this no found view aswell.
            else if (!postWithCommentController.isMember && !postWithCommentController.isCommunityPublic) {
              /// Register crashlytics error for page not found error
              /// this error is thrown when the post is null or user is not a member of the community
              CrashlyticsController.to.instance.setCustomKey("page_not_found", {
                "post_id": postId,
                "post": postWithCommentController.post.communityId ?? "",
                "userId": UserModel.to.uId ?? "",
                "reason": "post is null or user is not a member of the community"
              });
              return const NotFoundView();
            }

            final double totalCommentsCount = double.parse(postWithCommentController.post.totalCommentsCount ?? "0");
            if (totalCommentsCount == 0) {
              return const SizedBox.shrink();
            }
            return Container(
              // here multiple comments
              color: kWhiteColor,
              padding: EdgeInsets.only(
                  top: 10,
                  left: distance_10,
                  bottom: postWithCommentController.post.isPostedAnonymously!
                      ? MediaQuery.of(context).viewInsets.bottom + 20
                      : MediaQuery.of(context).viewInsets.bottom),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // image and video showing area
                  GetBuilder<CommentsController>(
                      autoRemove: false,
                      tag: postId,
                      init: commentsController,
                      builder: (CommentsController controller) {
                        if (controller.commentsMedia != null) {
                          return ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child: CommentMediaView(
                              mediaFile: controller.commentsMedia!,
                              isVideo: controller.isVideo,
                              tapOnImageRemove: () {
                                controller.removeSelectedCommentsMedia();
                              },
                            ),
                          );
                        } else if (controller.isPdf && controller.pdfFiles.isNotEmpty) {
                          return ClipRRect(
                              borderRadius: BorderRadius.circular(8),
                              child: Padding(
                                padding: const EdgeInsets.only(left: 20, right: 20, bottom: 8).r,
                                child: LocalCommentPdfviewWidget(
                                  path: controller.pdfFiles.first.path,
                                  postId: postId ?? '',
                                  tapOnImageRemove: () {
                                    controller.removeSelectedCommentsMedia();
                                  },
                                ),
                              ));
                        }
                        return const SizedBox.shrink();
                      }),

                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SpeedDialView(
                        tapOnPhoto: () async {
                          final commentController = Get.find<CommentsController>(tag: postId);
                          await commentController.pickPhoto(context: context);
                        },
                        tapOnVideo: () async {
                          final commentController = Get.find<CommentsController>(tag: postId);
                          await commentController.pickVideo(context: context);
                        },
                        tapOnDocument: () async {
                          final commentController = Get.find<CommentsController>(tag: postId);
                          await commentController.getPdfDocument(context);
                          // ignore: use_build_context_synchronously
                          uploadDocumentModelSheet(context, isPost: false, postId: postId ?? '', onSubmit: (String msg) async {
                            // Navigator.pop(context);
                          });
                        },
                      ),
                      const SizedBox(width: distance_5),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Expanded(
                                  child: GayaMentionedField(
                                      autoFocus: true,
                                      textFormFieldKey: textFormFieldKey,
                                      fillColor: borderColor.withOpacity(0.50),
                                      isFilled: true,
                                      isPassword: false,
                                      inputType: TextInputType.multiline,
                                      hintText: GayaStrings.type_comment.tr,
                                      borderColor: borderColor),
                                ),
                                const SizedBox(width: distance_10),
                                TextButton(
                                    onPressed: toggleDM
                                        ? () async {
                                            if (textFormFieldKey.currentState!.controller!.text.isEmpty) {
                                              return;
                                            }

                                            final mentionedCntrl = Get.find<MentionedUserController>();
                                            setState(() {
                                              showProgressindicator = true;
                                              String type = 'post';
                                              ChatController.to().helperFunc.createNewChatAndSendMessage(
                                                  context,
                                                  postWithCommentController.post.postedBy.uId ?? '',
                                                  postWithCommentController.post.postid ?? '',
                                                  type,
                                                  attachmentData: postWithCommentController.post.postid ?? '',
                                                  post: postWithCommentController.post,
                                                  simplePostTextMessage: textFormFieldKey.currentState!.controller!.text
                                                  );
                                            });
                                            Future.delayed(const Duration(seconds: 2)).then((value) => setState(() {
                                                  showProgressindicator = false;
                                                  toggleDM = false;
                                                  textFormFieldKey.currentState!.controller!.clear();
                                                  mentionedCntrl.resetMentionedUser();
                                                  _commentC.clear();
                                                }));
                                          }
                                        : () async {
                                            final commentController = Get.find<CommentsController>(tag: postId);
                                            final mentionedCntrl = Get.find<MentionedUserController>();
                                            //increament the post

                                            if (textFormFieldKey.currentState!.controller!.text.trim().isNotEmpty ||
                                                commentController.commentsMedia != null ||
                                                commentController.pdfFiles.isNotEmpty) {
                                              await mentionedCntrl.getMentionedUserAndCommunity().then((value) {
                                                PostWithCommentController.to(tag: postId).incrementCommentCount();
                                                commentController.postNewComment(
                                                    myNewComment: mentionedCntrl.commentData,
                                                    // myNewComment: textFormFieldKey.currentState!.controller!.text,
                                                    mentionedUser: mentionedCntrl.mentionedUsers);
                                                textFormFieldKey.currentState!.controller!.clear();
                                                mentionedCntrl.resetMentionedUser();
                                                _commentC.clear();
                                              });
                                              FocusScope.of(context).unfocus();
                                              // _commentsParentScrollController.animateTo(
                                              //   _commentsParentScrollController.position.maxScrollExtent,
                                              //   duration: const Duration(milliseconds: 500),
                                              //   curve: Curves.easeOut,
                                              // );
                                            }
                                            // Function Ended
                                          },
                                    child: showProgressindicator
                                        ? const CircularProgressIndicator()
                                        : Text(toggleDM ? GayaStrings.send_txt.tr : GayaStrings.post_txt.tr, style: body4StylePrimary)),
                              ],
                            ),
                            Visibility(
                              visible: commentsController.isPostDMEnabled && !postWithCommentController.post.isPostedAnonymously!,
                              child: Padding(
                                padding: EdgeInsets.only(left: 5.w),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      GayaStrings.send_msg_dm.tr,
                                      style: TextStyle(fontSize: 14.sp, fontFamily: GayaFontTheme.primaryFont, fontWeight: FontWeight.w600),
                                    ),
                                    Switch.adaptive(
                                        activeColor: kprimaryColor,
                                        value: toggleDM,
                                        onChanged: (value) {
                                          setState(() {
                                            toggleDM = value;
                                          });
                                        })
                                  ],
                                ),
                              ),
                            )
                          ],
                        ),
                      )
                    ],
                  ),
                ],
              ),
            );
          }),
      appBar: AppBar(
          systemOverlayStyle: SystemUiOverlayStyle.dark,
          iconTheme: const IconThemeData(color: kBlackColor),
          shape: Border(bottom: BorderSide(color: kBaseGrey.withOpacity(0.25))),
          automaticallyImplyLeading: false,
          leading: GayaBackButton(onPop: _onBackPressed),
          backgroundColor: kTransparentColor,
          elevation: 0),
      body: GetBuilder<PostWithCommentController>(
          tag: postId,
          autoRemove: false,
          builder: (controller) {
            if (controller.isLoading) {
              return const Padding(padding: EdgeInsets.symmetric(horizontal: distance_20), child: PostsSkeleton());
            }
            // if post is null or user is not a member of the community
            Post createPostModel = controller.post;
            Community createCommunityModel = createPostModel.community;
            UserModel userModel = createPostModel.postedBy;
            double totalCommentsCount = double.parse(createPostModel.totalCommentsCount ?? "0");

            return totalCommentsCount == 0
                ? PostWithNoCommentsWidget(
                    post: createPostModel,
                    commentC: _commentC,
                    postController: controller,
                    toggleDM: toggleDM,
                    commentsController: commentsController,
                  )
                : NestedScrollView(
                    controller: _scrollController,
                    physics: totalCommentsCount > 2 ? null : const NeverScrollableScrollPhysics(),
                    headerSliverBuilder: (_, __) {
                      return [
                        SliverToBoxAdapter(
                          child: AppConfigurationController.to.isUserBlockedAlready(userId: userModel.uId ?? "")
                              ? const SizedBox.shrink()
                              : Column(
                                  children: [
                                    HomePostWidget(
                                      // isModerator:
                                      //     AppConfigurationController.to.isAdminOrModerator(communityId: createPostModel.communityId),
                                      pdfFiles: createPostModel.pdfFiles,
                                      onDeleteTap: () async {
                                        Navigator.pop(context);
                                        await context.read<GroupController>().deleteYourPost(createPostModel.postid!, context);
                                        controller.deletePostFromFeeds(post: createPostModel);
                                        Navigator.pop(context);
                                      },
                                      postModel: createPostModel,
                                      createdAt: createPostModel.approvedAt,
                                      anonymousPost: createPostModel.isPostedAnonymously,
                                      currentUserPost: createPostModel.memberId == FirebaseAuth.instance.currentUser?.uid ? true : false,
                                      hasVideo: (createPostModel.video == null || createPostModel.video == '') ? false : true,
                                      videoLink: createPostModel.video,
                                      onTap: null,
                                      crossAxis: createPostModel.multipleImages == null
                                          ? 1
                                          : createPostModel.multipleImages!.length < 2
                                              ? 1
                                              : 2,
                                      imageTap: (createPostModel.multipleImages?.isEmpty ?? true)
                                          ? null
                                          : () {
                                              Routes.openMultipleImages(urls: createPostModel.multipleImages ?? []);
                                            },
                                      onUserTap: () {
                                        Methods.showModalSheetToJoinCommunity(
                                            communityModel: createCommunityModel,
                                            communityId: createCommunityModel.communityId,
                                            ctx: context);
                                      },
                                      //=> Methods.routeToGroup(community: createCommunityModel),
                                      // Routes.groupView(community: createCommunityModel),
                                      approvalShow: false,
                                      doNotshowBottomrow: false,
                                      isPostHasImage: createPostModel.multipleImages == null
                                          ? false
                                          : createPostModel.multipleImages!.isEmpty == true
                                              ? false
                                              : true,
                                      savePostColor: kSecondaryColor,
                                      totalLikesCount: createPostModel.likedBy?.length.toString() ?? "0",
                                      totalCommentsCount: createPostModel.totalCommentsCount ?? "0",
                                      overlapImage: GestureDetector(
                                        onTap: () {
                                          if (createPostModel.isPostedAnonymously == true) {
                                          } else {
                                            Routes.viewProfile(uid: userModel.uId ?? "", model: userModel);
                                          }
                                        },
                                        child: createPostModel.isPostedAnonymously == true
                                            ? CircleAvatar(
                                                radius: 17.r,
                                                backgroundImage: const AssetImage('Assets/images/anonymous_user.png'),
                                                backgroundColor: kBaseGrey)
                                            : userModel.profilePicture == ''
                                                ? CircleAvatar(
                                                    radius: 17.r,
                                                    backgroundColor: kBaseGrey,
                                                    backgroundImage: const AssetImage('Assets/images/user.png'))
                                                : CircleAvatar(
                                                    backgroundColor: kWhiteColor,
                                                    radius: 17.r,
                                                    child: ProfileImageWidget(url: userModel.profilePicture, size: const Size(48, 48))),
                                      ),
                                      postId: createPostModel.postid,
                                      likeIconColor:
                                          createPostModel.likedBy?.contains(UserModel.to.uId) == true ? kRedColor : kSecondaryColor,

                                      groupImage: createCommunityModel.CommunityPic.toString(),
                                      title: createCommunityModel.communityName.toString(),
                                      content: createPostModel.postDescription.toString(),
                                      postImage: createPostModel.multipleImages ?? [],
                                      subtitle: createPostModel.isPostedAnonymously == true ? anonymousUser : userModel.name.toString(),
                                      profileImage: userModel.profilePicture,
                                      commentOntap: null,
                                      report: () {
                                        if (createPostModel.postid == null) return;
                                        Navigator.of(context).pop();
                                        ReportController.to.reportPost(
                                            createPostModel.postid ?? "", context, createPostModel.community.adminUid,
                                            communityId: createPostModel.community.communityId ?? "");
                                      },
                                      onTapSaved: () async {
                                        if (AppConfigurationController.to.savedPostsID.contains(createPostModel.postid) == true) {
                                          Navigator.pop(context);
                                          AppConfigurationController.to.savedPostsID.remove(createPostModel.postid);
                                          await context
                                              .read<HomePageController>()
                                              .deleteUserSaveDocFromPostCollection(createPostModel.postid!, context);
                                          await context.read<HomePageController>().deletePostFromUserCollection(createPostModel.postid!);
                                        } else {
                                          Navigator.pop(context);
                                          AppConfigurationController.to.savedPostsID.add(createPostModel.postid ?? "");
                                          await context.read<CreatePostController>().savePost(createPostModel.postid!);
                                          await context.read<HomePageController>().setSavePostInUSerCollection({
                                            'postId': createPostModel.postid,
                                            'communityId': createCommunityModel.communityId,
                                            'userUid': UserModel.to.uId
                                          }, context);
                                        }
                                      },

                                      //void call back on flower on tap
                                      likeOnTap: () async {
                                        if (createPostModel.likedBy?.contains(UserModel.to.uId) == false) {
                                          controller.likePost();
                                        } else {
                                          controller.unlikePost();
                                        }
                                      },
                                      totalCrownsCount: createPostModel.crownsBy?.length.toString() ?? "0",
                                      posterCrownsCount: userModel.userTotalCrowns?.toString() ?? "0",

                                      isCrowned: createPostModel.crownsBy?.contains(UserModel.to.uId) == true ? true : false,
                                      //void call back on crown on tap
                                      crownOnTap: () async {
                                        if (UserModel.to.userDailyCrowns == null &&
                                                createPostModel.crownsBy?.contains(UserModel.to.uId) == false &&
                                                userModel.uId != UserModel.to.uId ||
                                            UserModel.to.userDailyCrowns == 0 &&
                                                createPostModel.crownsBy?.contains(UserModel.to.uId) == false &&
                                                userModel.uId != UserModel.to.uId) {
                                          Methods.showCrownsTotalModalSheet(ctx: Get.context);
                                          return;
                                        }
                                        if (createPostModel.crownsBy == null && userModel.uId != UserModel.to.uId) {
                                          final PostWithCommentController postController =
                                              PostWithCommentController.to(tag: createPostModel.postid);
                                          postController.crownPost(createPostModel.postid, receiverUser: createPostModel.postedBy);
                                        } else if (createPostModel.crownsBy!.contains(UserModel.to.uId) ||
                                            userModel.uId == UserModel.to.uId) {
                                        } else {
                                          final PostWithCommentController postController =
                                              PostWithCommentController.to(tag: createPostModel.postid);
                                          postController.crownPost(createPostModel.postid, receiverUser: createPostModel.postedBy);
                                        }
                                      },
                                      onManageTopics: () {
                                        Navigator.pop(context);
                                        Methods.showTopicPostUpdateModalSheet(
                                            community: createCommunityModel,
                                            post: createPostModel,
                                            context: context,
                                            onDoneButtonPressed: (updatedPost) =>
                                                postWithCommentController.updatePostTopicsFirebase(updatedPost));
                                      },
                                    ),
                                    const Divider(color: kSecondaryLightColor, thickness: 1.0, height: 1),
                                    const SizedBox(height: MySpaces.gap3),
                                  ],
                                ),
                        )
                      ];
                    },
                    body: GetBuilder<CommentsController>(
                        tag: postId,
                        autoRemove: false,
                        init: commentsController,
                        builder: (controller) {
                          if (controller.isLoading == true) {
                            return const CommentsSkeleton();
                          }

                          return Column(
                            children: [
                              Expanded(
                                child: EasyRefresh.builder(
                                  simultaneously: true,
                                  // noMoreLoad: false,
                                  controller: controller.refreshController,
                                  header: RefreshBuilderUtils.headerAbove,
                                  footer: RefreshBuilderUtils.footerAbove,
                                  onLoad: () async {
                                    final isCommentsFetched = await controller.requestMoreComments();
                                    if (isCommentsFetched == false) {
                                      return IndicatorResult.noMore;
                                    }
                                  },
                                  childBuilder: (context, physics) {
                                    return controller.allComments.isEmpty
                                        ? const SizedBox.shrink()
                                        : ListView.separated(
                                            physics: totalCommentsCount > 2 ? physics : const NeverScrollableScrollPhysics(),
                                            itemCount: controller.allComments.length,
                                            padding: const EdgeInsets.symmetric(horizontal: distance_20).r,
                                            itemBuilder: (context, index) {
                                              MultiCommentModel comments = controller.allComments[index];
                                              UserModel commentBy = comments.comment.user;
                                              //replies
                                              List<CommentCustomModel> allReplies = comments.replies;
                                              return ParentCommentsListView(
                                                comments: comments,
                                                commentBy: commentBy,
                                                allReplies: allReplies,
                                                index: index,

                                                /// as a tag
                                                postId: postId,
                                                post: createPostModel,
                                              );
                                            },
                                            separatorBuilder: (context, index) => const SizedBox(height: distance_5),
                                          );
                                  },
                                ),
                              ),
                            ],
                          );
                        }));
          }),
    );
  }
}

/// LIST TILE
class PostWithNoCommentsWidget extends StatelessWidget {
  final Post post;
  final PostWithCommentController postController;
  final CommentsController commentsController;
  final TextEditingController commentC;
  bool toggleDM;

  PostWithNoCommentsWidget({
    Key? key,
    required this.post,
    required this.commentC,
    required this.postController,
    required this.toggleDM,
    required this.commentsController,
  }) : super(key: key);

  GlobalKey<FlutterMentionsState> textFormFieldKey = GlobalKey<FlutterMentionsState>();
  bool showProgressindicator = false;
  @override
  Widget build(BuildContext context) {
    Post createPostModel = post;
    Community createCommunityModel = createPostModel.community;
    UserModel userModel = createPostModel.postedBy;
    return LayoutBuilder(
      builder: (_, constraints) {
        return SingleChildScrollView(
          child: ConstrainedBox(
            constraints: BoxConstraints(
              minHeight: constraints.maxHeight,
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                HomePostWidget(
                  pdfFiles: createPostModel.pdfFiles,
                  createdAt: createPostModel.approvedAt,
                  anonymousPost: createPostModel.isPostedAnonymously,
                  currentUserPost: createPostModel.memberId == FirebaseAuth.instance.currentUser?.uid ? true : false,
                  hasVideo: (createPostModel.video == null || createPostModel.video == '') ? false : true,
                  videoLink: createPostModel.video,
                  onTap: null,

                  crossAxis: createPostModel.multipleImages == null
                      ? 1
                      : createPostModel.multipleImages!.length < 2
                          ? 1
                          : 2,
                  imageTap: (createPostModel.multipleImages?.isEmpty ?? true)
                      ? null
                      : () {
                          Routes.openMultipleImages(urls: createPostModel.multipleImages ?? []);
                        },
                  onUserTap: () => Methods.routeToGroup(community: createCommunityModel),
                  // Routes.groupView(community: createCommunityModel),
                  approvalShow: false,
                  doNotshowBottomrow: false,
                  isPostHasImage: createPostModel.multipleImages == null
                      ? false
                      : createPostModel.multipleImages!.isEmpty == true
                          ? false
                          : true,
                  savePostColor: kSecondaryColor,
                  totalLikesCount: createPostModel.likedBy?.length.toString() ?? "0",
                  totalCommentsCount: createPostModel.totalCommentsCount ?? "0",
                  overlapImage: GestureDetector(
                    onTap: () {
                      if (createPostModel.isPostedAnonymously == true) {
                      } else {
                        Routes.viewProfile(model: userModel, uid: userModel.uId);
                      }
                    },
                    child: createPostModel.isPostedAnonymously == true
                        ? const CircleAvatar(
                            radius: 17, backgroundImage: AssetImage('Assets/images/anonymous_user.png'), backgroundColor: kBaseGrey)
                        : userModel.profilePicture == ''
                            ? const CircleAvatar(
                                radius: 17, backgroundColor: kBaseGrey, backgroundImage: AssetImage('Assets/images/user.png'))
                            : CircleAvatar(
                                backgroundColor: kWhiteColor,
                                radius: 17,
                                child: ProfileImageWidget(url: userModel.profilePicture, size: const Size(distance_30, distance_30))),
                  ),
                  postId: createPostModel.postid,
                  likeIconColor: createPostModel.likedBy?.contains(UserModel.to.uId) == true ? kRedColor : kSecondaryColor,
                  groupImage: createCommunityModel.CommunityPic.toString(),
                  title: createCommunityModel.communityName.toString(),
                  content: createPostModel.postDescription.toString(),
                  postImage: createPostModel.multipleImages ?? [],
                  subtitle: createPostModel.isPostedAnonymously == true ? anonymousUser : userModel.name.toString(),
                  profileImage: userModel.profilePicture,
                  commentOntap: null,
                  report: () {
                    if (createPostModel.postid == null) return;
                    Navigator.of(context).pop();
                    ReportController.to.reportPost(createPostModel.postid ?? "", context, createPostModel.community.adminUid,
                        communityId: createPostModel.community.communityId ?? "");
                  },
                  onTapSaved: () async {
                    if (AppConfigurationController.to.savedPostsID.contains(createPostModel.postid) == true) {
                      Navigator.pop(context);
                      AppConfigurationController.to.savedPostsID.remove(createPostModel.postid);

                      await context.read<HomePageController>().deleteUserSaveDocFromPostCollection(createPostModel.postid!, context);
                      await context.read<HomePageController>().deletePostFromUserCollection(createPostModel.postid!);
                    } else {
                      Navigator.pop(context);
                      AppConfigurationController.to.savedPostsID.add(createPostModel.postid ?? "");
                      await context.read<CreatePostController>().savePost(createPostModel.postid!);

                      // ignore: use_build_context_synchronously
                      await context.read<HomePageController>().setSavePostInUSerCollection(
                          {'postId': createPostModel.postid, 'communityId': createCommunityModel.communityId, 'userUid': UserModel.to.uId},
                          context);
                    }
                  },

                  //void call back on flower on tap
                  likeOnTap: () async {
                    final PostWithCommentController postWithCommentController = PostWithCommentController.to(tag: createPostModel.postid);
                    if (createPostModel.likedBy?.contains(UserModel.to.uId) == false) {
                      postController.likePost();
                    } else {
                      postController.unlikePost();
                    }
                  },

                  //void call back on like button
                  // flowerOnTap: () async {
                  //   if (createPostModel.flowersBy?.contains(UserModel.to.uId) == false) {
                  //     controller.flowerPost();
                  //   } else {
                  //     controller.unflowerPost();
                  //   }
                  // },
                  totalCrownsCount: createPostModel.crownsBy?.length.toString() ?? "0",
                  posterCrownsCount: userModel.userTotalCrowns?.toString() ?? "0",

                  isCrowned: createPostModel.crownsBy?.contains(UserModel.to.uId) == true ? true : false,
                  //void call back on crown on tap
                  crownOnTap: () async {
                    if (UserModel.to.userDailyCrowns == null &&
                            createPostModel.crownsBy?.contains(UserModel.to.uId) == false &&
                            userModel.uId != UserModel.to.uId ||
                        UserModel.to.userDailyCrowns == 0 &&
                            createPostModel.crownsBy?.contains(UserModel.to.uId) == false &&
                            userModel.uId != UserModel.to.uId) {
                      Methods.showCrownsTotalModalSheet(ctx: Get.context);
                      return;
                    }
                    if (createPostModel.crownsBy == null && userModel.uId != UserModel.to.uId) {
                      final PostWithCommentController postController = PostWithCommentController.to(tag: post.postid);
                      postController.crownPost(post.postid, receiverUser: post.postedBy);
                    } else if (createPostModel.crownsBy!.contains(UserModel.to.uId) || userModel.uId == UserModel.to.uId) {
                    } else {
                      final PostWithCommentController postController = PostWithCommentController.to(tag: post.postid);
                      postController.crownPost(post.postid, receiverUser: post.postedBy);
                    }
                  },
                  onManageTopics: () {
                    final PostWithCommentController postController = PostWithCommentController.to(tag: post.postid);
                    Navigator.pop(context);
                    Methods.showTopicPostUpdateModalSheet(
                        community: createCommunityModel,
                        post: createPostModel,
                        context: context,
                        onDoneButtonPressed: (updatedPost) => postController.updatePostTopicsFirebase(updatedPost));
                  },
                ),
                // const Divider(color: kSecondaryLightColor, thickness: 1.0, height: 1),
                //comment section
                StatefulBuilder(builder: (BuildContext context, StateSetter setState) {
                  return Container(
                    color: kWhiteColor,
                    padding: post.isPostedAnonymously!
                        ? const EdgeInsets.symmetric(vertical: distance_15)
                        : EdgeInsets.only(top: 7.h, bottom: post.isPostedAnonymously! ? distance_15 : 0.0),
                    child: Column(
                      children: [
                        // image and video showing area
                        GetBuilder<CommentsController>(
                            autoRemove: false,
                            tag: createPostModel.postid,
                            init: Get.find<CommentsController>(tag: post.postid),
                            builder: (CommentsController controller) {
                              if (controller.commentsMedia != null) {
                                return ClipRRect(
                                  borderRadius: BorderRadius.circular(8),
                                  child: CommentMediaView(
                                    mediaFile: controller.commentsMedia!,
                                    isVideo: controller.isVideo,
                                    tapOnImageRemove: () {
                                      controller.removeSelectedCommentsMedia();
                                    },
                                  ),
                                );
                              } else if (controller.isPdf && controller.pdfFiles.isNotEmpty) {
                                return ClipRRect(
                                    borderRadius: BorderRadius.circular(8),
                                    child: Padding(
                                      padding: const EdgeInsets.only(left: 20, right: 20, bottom: 8).r,
                                      child: LocalCommentPdfviewWidget(
                                        path: controller.pdfFiles.first.path,
                                        postId: createPostModel.postid ?? '',
                                        tapOnImageRemove: () {
                                          controller.removeSelectedCommentsMedia();
                                        },
                                      ),
                                    ));
                              }
                              return const SizedBox.shrink();
                            }),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const SizedBox(width: distance_5),
                            SpeedDialView(
                              tapOnPhoto: () async {
                                final commentController = Get.find<CommentsController>(tag: post.postid);
                                await commentController.pickPhoto(context: context);
                              },
                              tapOnVideo: () async {
                                final commentController = Get.find<CommentsController>(tag: post.postid);
                                await commentController.pickVideo(context: context);
                              },
                              tapOnDocument: () async {
                                final commentController = Get.find<CommentsController>(tag: post.postid);
                                await commentController.getPdfDocument(context);
                                // ignore: use_build_context_synchronously
                                uploadDocumentModelSheet(context, isPost: false, postId: post.postid ?? '', onSubmit: (String msg) async {
                                  // Navigator.pop(context);
                                });
                              },
                            ),
                            const SizedBox(width: distance_10),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      Expanded(
                                        child: GayaMentionedField(
                                            autoFocus: true,
                                            textFormFieldKey: textFormFieldKey,
                                            fillColor: borderColor.withOpacity(0.50),
                                            isFilled: true,
                                            isPassword: false,
                                            inputType: TextInputType.multiline,
                                            hintText: GayaStrings.type_comment.tr,
                                            borderColor: borderColor),
                                      ),
                                      const SizedBox(width: distance_10),
                                      TextButton(
                                          onPressed: toggleDM
                                              ? () async {
                                                  if (textFormFieldKey.currentState!.controller!.text.isEmpty) {
                                                    return;
                                                  }
                                                  final mentionedCntrl = Get.find<MentionedUserController>();
                                                  setState(() {
                                                    showProgressindicator = true;
                                                    String type = 'post';
                                                    ChatController.to().helperFunc.createNewChatAndSendMessage(
                                                        context, userModel.uId ?? '', post.postid ?? '', type,
                                                        attachmentData: post.postid ?? '', post: post, simplePostTextMessage: textFormFieldKey.currentState!.controller!.text);
                                                  });
                                                  Future.delayed(const Duration(seconds: 2)).then((value) => setState(() {
                                                        showProgressindicator = false;
                                                        commentC.clear();
                                                        toggleDM = false;
                                                        mentionedCntrl.resetMentionedUser();
                                                        textFormFieldKey.currentState!.controller!.clear();
                                                        FocusScope.of(context).unfocus();
                                                      }));
                                                }
                                              : () async {
                                                  final commentController = Get.find<CommentsController>(tag: post.postid);
                                                  final mentionedCntrl = Get.find<MentionedUserController>();
                                                  //increament the post
                                                  if (textFormFieldKey.currentState!.controller!.text.trim().isNotEmpty ||
                                                      commentController.commentsMedia != null) {
                                                    PostWithCommentController.to(tag: post.postid).incrementCommentCount();

                                                    commentController.postNewComment(
                                                        myNewComment: textFormFieldKey.currentState!.controller!.text,
                                                        mentionedUser: mentionedCntrl.mentionedUsers);
                                                    textFormFieldKey.currentState!.controller!.clear();
                                                    commentC.clear();
                                                    mentionedCntrl.resetMentionedUser();
                                                    FocusScope.of(context).unfocus();
                                                  }
                                                  // Function Ended
                                                },
                                          child: showProgressindicator
                                              ? const CircularProgressIndicator()
                                              : Text(toggleDM ? GayaStrings.send_txt.tr : GayaStrings.post_txt.tr,
                                                  style: body4StylePrimary)),
                                    ],
                                  ),
                                  Visibility(
                                    visible: commentsController.isPostDMEnabled && !post.isPostedAnonymously!,
                                    child: Padding(
                                      padding: EdgeInsets.only(left: 5.w),
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          Text(
                                            GayaStrings.send_msg_dm.tr,
                                            style: TextStyle(
                                                fontSize: 14.sp, fontFamily: GayaFontTheme.primaryFont, fontWeight: FontWeight.w600),
                                          ),
                                          Switch.adaptive(
                                              activeColor: kprimaryColor,
                                              value: toggleDM,
                                              onChanged: (value) {
                                                setState(() {
                                                  toggleDM = value;
                                                });
                                              })
                                        ],
                                      ),
                                    ),
                                  )
                                ],
                              ),
                            )
                          ],
                        ),
                      ],
                    ),
                  );
                }),
              ],
            ),
          ),
        );
      },
    );
  }
}

void showModalSheetManageTopicCommentWithPostScreen(BuildContext context, {required PostWithCommentController postWithCommentController}) {
  showModalBottomSheet(
    context: context,
    clipBehavior: Clip.antiAlias,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.only(topLeft: Radius.circular(13.0), topRight: Radius.circular(13.0)),
    ),
    builder: (modalContext) => GetBuilder<EditCommunityController>(
        autoRemove: false,
        init: EditCommunityController.to(tag: postWithCommentController.post.communityId),
        builder: (communityEditingController) {
          return Container(
            padding: const EdgeInsets.all(20),
            width: MediaQuery.of(context).size.width,
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(topLeft: Radius.circular(13.0), topRight: Radius.circular(13.0)),
            ),
            child: GetBuilder<PostWithCommentController>(
                autoRemove: false,
                tag: postWithCommentController.post.postid,
                init: postWithCommentController,
                builder: (postController) {
                  return Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Container(
                        height: 5,
                        width: 40,
                        decoration: const ShapeDecoration(color: borderColor, shape: StadiumBorder()),
                      ),
                      const SizedBox(height: distance_10),
                      Text(GayaStrings.post_topic.tr, style: bodyStyle),
                      const SizedBox(height: distance_15),
                      (communityEditingController.createCommunityModel == null ||
                              communityEditingController.createCommunityModel!.communityTopicList == null)
                          ? SizedBox(
                              height: MediaQuery.of(context).size.height * 0.1,
                              child: Center(
                                child: Text(GayaStrings.no_topic_found.tr, style: bodyStyle),
                              ),
                            )
                          : (communityEditingController.createCommunityModel!.communityTopicList!.isEmpty)
                              ? SizedBox(
                                  height: MediaQuery.of(context).size.height * 0.1,
                                  child: Center(
                                    child: Text(GayaStrings.no_topic_found_community.tr, style: bodyStyle),
                                  ),
                                )
                              : SizedBox(
                                  height: MediaQuery.of(context).size.height * 0.3,
                                  child: ListView.builder(
                                      itemCount: communityEditingController.createCommunityModel?.communityTopicList?.length ?? 0,
                                      // padding: const EdgeInsets.symmetric(horizontal: distance_15, vertical: distance_10),
                                      itemBuilder: (context, index) {
                                        String singleTopic =
                                            communityEditingController.createCommunityModel?.communityTopicList?[index] ?? '';

                                        return CheckboxListTile(
                                            checkColor: kWhiteColor,
                                            activeColor: kprimaryColor,
                                            controlAffinity: ListTileControlAffinity.leading,
                                            contentPadding: const EdgeInsets.symmetric(horizontal: 0),
                                            value: (postController.post.postTopicList == null ||
                                                    !postController.post.postTopicList!.contains(singleTopic))
                                                ? false
                                                : true,
                                            title: Text(singleTopic, style: body2StyleWeightBlack),
                                            onChanged: (newValue) {
                                              postController.addRemovePostTopic(singleTopic);
                                            });
                                      }),
                                ),
                      const SizedBox(height: distance_15),
                      button(
                          title: GayaStrings.done.tr,
                          onPressed: () async {
                            if (communityEditingController.createCommunityModel?.communityTopicList == null &&
                                postController.post.postTopicList == null) {
                              Navigator.pop(modalContext);
                            }
                            postController.updatePostTopics(context, postController.post);
                            Navigator.pop(modalContext);
                            // save topics locally in post lists to do
                          },
                          borderColor: kTransparentColor,
                          height: 48,
                          primaryColor: kprimaryColor,
                          textStyle: const TextStyle(color: kWhiteColor, fontWeight: FontWeight.w500, fontSize: 14),
                          width: MediaQuery.of(context).size.width),
                      const SizedBox(height: distance_15),
                    ],
                  );
                }),
          );
        }),

    // Consumer<CommunityEditingController>(builder: (_, communityEditingController, __) {
    //   return Container(
    //     padding: const EdgeInsets.all(20),
    //     width: MediaQuery.of(context).size.width,
    //     decoration: const BoxDecoration(
    //       color: Colors.white,
    //       borderRadius: BorderRadius.only(topLeft: Radius.circular(13.0), topRight: Radius.circular(13.0)),
    //     ),
    //     child: GetBuilder<PostWithCommentController>(
    //         init: postWithCommentController,
    //         builder: (postController) {
    //           return Column(
    //             mainAxisSize: MainAxisSize.min,
    //             crossAxisAlignment: CrossAxisAlignment.center,
    //             mainAxisAlignment: MainAxisAlignment.spaceEvenly,
    //             children: [
    //               Container(
    //                 height: 5,
    //                 width: 40,
    //                 decoration: const ShapeDecoration(color: borderColor, shape: StadiumBorder()),
    //               ),
    //               const SizedBox(height: distance_10),
    //               Text("Post Topic", style: bodyStyle),
    //               const SizedBox(height: distance_15),
    //               (communityEditingController.createCommunityModel == null ||
    //                       communityEditingController.createCommunityModel!.communityTopicList == null)
    //                   ? SizedBox(
    //                       height: MediaQuery.of(context).size.height * 0.1,
    //                       child: Center(
    //                         child: Text('No Topics Found', style: bodyStyle),
    //                       ),
    //                     )
    //                   : (communityEditingController.createCommunityModel!.communityTopicList!.isEmpty)
    //                       ? SizedBox(
    //                           height: MediaQuery.of(context).size.height * 0.1,
    //                           child: Center(
    //                             child: Text('No Topics Found in Community', style: bodyStyle),
    //                           ),
    //                         )
    //                       : SizedBox(
    //                           height: MediaQuery.of(context).size.height * 0.3,
    //                           child: ListView.builder(
    //                               itemCount: communityEditingController.createCommunityModel?.communityTopicList?.length ?? 0,
    //                               // padding: const EdgeInsets.symmetric(horizontal: distance_15, vertical: distance_10),
    //                               itemBuilder: (context, index) {
    //                                 String singleTopic = communityEditingController.createCommunityModel?.communityTopicList?[index] ?? '';
    //                                 return CheckboxListTile(
    //                                     checkColor: kWhiteColor,
    //                                     activeColor: kprimaryColor,
    //                                     controlAffinity: ListTileControlAffinity.leading,
    //                                     contentPadding: const EdgeInsets.symmetric(horizontal: 0),
    //                                     value: (postController.post.postTopicList == null ||
    //                                             !postController.post.postTopicList!.contains(singleTopic))
    //                                         ? false
    //                                         : true,
    //                                     title: Text(singleTopic, style: body2StyleWeightBlack),
    //                                     onChanged: (newValue) {
    //                                       postController.addRemovePostTopic(singleTopic);
    //                                     });
    //                               }),
    //                         ),
    //               const SizedBox(height: distance_15),
    //               button(
    //                   title: "Done",
    //                   onPressed: () async {
    //                     if (communityEditingController.createCommunityModel?.communityTopicList == null &&
    //                         postController.post.postTopicList == null) {
    //                       Navigator.pop(modalContext);
    //                     }
    //                     postController.updatePostTopics(context, postController.post);
    //                     Navigator.pop(modalContext);
    //                     // save topics locally in post lists to do
    //                   },
    //                   borderColor: kTransparentColor,
    //                   height: 48,
    //                   primaryColor: kprimaryColor,
    //                   textStyle: const TextStyle(color: kWhiteColor, fontWeight: FontWeight.w500, fontSize: 14),
    //                   width: MediaQuery.of(context).size.width),
    //               const SizedBox(height: distance_15),
    //             ],
    //           );
    //         }),
    //   );
    // }),
  );
}
