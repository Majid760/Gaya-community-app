import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gaya/components/check_for_app_update.dart';
import 'package:gaya/controller/app_config_controller.dart';
import 'package:gaya/controller/crowns_controller.dart';
import 'package:gaya/controller/firebase_analytics_controller.dart';
import 'package:gaya/controller/topics.controller.dart';
import 'package:gaya/model/user.model.dart';
import 'package:gaya/routing/getx_route_methods.dart';
import 'package:gaya/shared/view/widget/gaya_floating_action_button.dart';
import 'package:gaya/utils/assets_icons.dart';
import 'package:gaya/utils/const.dart';
import 'package:gaya/utils/language/translation.dart';
import 'package:gaya/utils/local.storage.dart';
import 'package:gaya/utils/logger.dart';
import 'package:gaya/utils/methods.dart';
import 'package:gaya/utils/theme/app_typography.dart';
import 'package:gaya/view/topics.view.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';
import 'package:share/share.dart';

import '../gen/assets.gen.dart';
import '../shared/view/screen/gaya_search_screens/feed_search_screen.dart';
import '../utils/strings.dart';
import '../utils/textstyles.dart';
import 'Auth/controller/require.sigin.register.dart';
import 'feed/view/guest/guest_user_feed_view.dart';
import 'feed/view/private/feeds_View.dart';

class HomeView extends StatefulWidget {
  const HomeView({Key? key}) : super(key: key);

  @override
  State<HomeView> createState() => _HomeViewState();
}

class _HomeViewState extends State<HomeView> {
  late GetInterestStorageController getStorage;

  Future<void> areTopicSelected(TopicsController topicCntrl) async {
    try {
      if (getStorage.getInterestList() == null) {
        WidgetsBinding.instance.addPostFrameCallback((_) async {
          await topicsBottomSheet(context);
        });
      }
    } catch (e) {
      MyLoggerServices.to.print('error thrown during showing bottom_sheet${e.toString()}');
    }
  }

  @override
  void initState() {
    super.initState();
    getStorage = Get.find<GetInterestStorageController>();
    final topicController = Provider.of<TopicsController>(context, listen: false);
    areTopicSelected(topicController);
  }

  UserModel userModel = UserModel.to;
  final isShowInviteHome = GayaRemoteConfig.to.isShowInviteHome;

  @override
  Widget build(BuildContext context) {
    final User? user = FirebaseAuth.instance.currentUser;
    return ScaffoldMessenger(
      key: Get.find<AppConfigurationController>().getScaffoldKey,
      child: Scaffold(
        appBar: AppBar(
          systemOverlayStyle: SystemUiOverlayStyle.dark,
          backgroundColor: kTransparentColor,
          elevation: 0,
          title: GestureDetector(
              onTap: () {
                AnalyticsController.to.instance.logHomeLogoTapped();
              },
              child: Text(GayaStrings.gaya.tr, style: headingStyle)),
          leading: Padding(
            padding: const EdgeInsets.only(left: distance_20),
            child: Image.asset(Assets.assets.images.gayaLogo.path, cacheHeight: 200, cacheWidth: 280),
          ),
          centerTitle: false,
          actions: [
            // Invite Friends
            Visibility(
              visible: isShowInviteHome,
              child: IconButton(
                  tooltip: GayaStrings.invite_friends.tr,
                  splashRadius: 25.r,
                  padding: EdgeInsets.zero,
                  onPressed: () {
                    AnalyticsController.to.instance.logInviteHomeButton();
                    if (user == null) {
                      Get.to(const RequireSignRegisterView(userNotSigin: true), transition: Transition.cupertinoDialog);
                      return;
                    }
                    if (DeviceCheck.isIOS) {
                      Share.share(appStoreLink);
                      AnalyticsController.to.instance.logInviteHomeButton(isTappedOnly: false);
                    } else {
                      Share.share(playstoreLink);
                      AnalyticsController.to.instance.logInviteHomeButton(isTappedOnly: false);
                    }
                  },
                  icon: SvgIconWidget.userPlusOutline()),
            ),
            IconButton(
                tooltip: GayaStrings.search_txt.tr,
                splashRadius: 25.r,
                padding: EdgeInsets.zero,
                onPressed: () {
                  if (user == null) {
                    Get.to(const RequireSignRegisterView(userNotSigin: true), transition: Transition.cupertinoDialog);
                  } else {
                    showCupertinoDialog(context: context, builder: (_) => const FeedSearchScreen());
                  }
                },
                icon: SvgIconWidget.searchLgOutline()),
            const SizedBox(width: distance_10),
          ],
        ),
        floatingActionButtonLocation: FloatingActionButtonLocation.endDocked,
        floatingActionButton: user == null
            ? const SizedBox.shrink()
            : GayaFloatingActionButton(
                onPressed: () => Routes.createPost(isFromHome: true, community: null), svgIconPath: IconsAssetsPathUtils.editOutline),
        body: user == null ? const GuestUserFeed() : const FeedsView(),
      ),
    );
  }

  Future<dynamic> topicsBottomSheet(BuildContext context) async {
    return await Methods.showCircularModalSheet(context, const TopicsView());
  }
}

class CrownTweenTimer extends StatelessWidget {
  final bool showSeconds;

  const CrownTweenTimer({super.key, this.showSeconds = false});

  @override
  Widget build(BuildContext context) {
    final crownRemainingTime = AppConfigurationController.to.getCrownRemainingTimeDuration();
    return GetBuilder<CrownsController>(
      init: CrownsController.to,
      builder: (crownsController) {
        return TweenAnimationBuilder<Duration>(
            tween: Tween(begin: crownRemainingTime, end: const Duration(seconds: 0)),
            duration: crownRemainingTime,
            onEnd: () => crownsController.checkUpdatedCrownsInDb(),
            builder: (BuildContext context, Duration value, Widget? child) {
              // final days = value.inDays;
              final hours = value.inHours % 24;
              final minutes = value.inMinutes % 60;
              final seconds = value.inSeconds % 60;
              return (hours == 0 && minutes == 0 && seconds == 0)
                  ? Text(
                      '${crownsController.myAppUser.userDailyCrowns ?? 0}/3 ${GayaStrings.left.tr}',
                      style: GayaTypography.titleSemiBold,
                    )
                  : Text(
                      showSeconds
                          ? '${GayaStrings.renew_in.tr} ${hours.toString().padLeft(2, "0")}:${minutes.toString().padLeft(2, "0")}:${seconds.toString().padLeft(2, "0")}'
                          : '${GayaStrings.renew_in.tr} ${hours.toString().padLeft(2, "0")}:${minutes.toString().padLeft(2, "0")} ',
                      style: body2StyleWeightBlack,
                    );
            });
      },
    );
  }
}
