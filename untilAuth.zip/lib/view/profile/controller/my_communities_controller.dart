import 'package:firebase_auth/firebase_auth.dart';
import 'package:gaya/model/community.model.dart';
import 'package:gaya/services/services.dart';
import 'package:get/get.dart';

class MyCommunitiesController extends GetxController {
  final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;
  User? get user => _firebaseAuth.currentUser;
  Services services = Services();
  @override
  void onInit() {
    super.onInit();
  }

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
  }

  Future<Map<String, dynamic>> getJoinedCommunities() async {
    if (user == null) return {};
    return services.getJoinedCommunities();
  }

  //search user specific  communities
  // user specific communities
  List<Community> userSpecificCommunties = [];
  List<Community> userSpecificSearchedCommunities = [];
  void userSpecificCommunitiesSearch(String query) {
    // print("query is this $query ${allCommunties.length}");
    if (userSpecificCommunties.isEmpty) return;
    final suggestion = userSpecificCommunties.where((element) => element.communityType != 'Secret').where((element) {
      final communities = element.communityName?.toLowerCase();
      return communities?.contains(query.toLowerCase()) ?? false;
    }).toList();

    // final nameSuggestion = allUsers.where((element) {
    //   final usersNames = element.name?.toLowerCase();
    //   return usersNames?.contains(query.toLowerCase()) ?? false;
    // }).toList();

    // print("suggestion is this $suggestion");
    // print("nameSuggestion is this $nameSuggestion");
    userSpecificSearchedCommunities = suggestion;
    userSpecificCommunties.clear();

    // searchUsers = nameSuggestion;
    // searchUsers.clear();
    update();
  }
}
