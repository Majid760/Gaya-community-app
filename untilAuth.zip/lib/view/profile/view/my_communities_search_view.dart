import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gaya/components/textfield.component.dart';
import 'package:gaya/controller/communities.controller.dart';
import 'package:gaya/gen/assets.gen.dart';
import 'package:gaya/utils/app_data.dart';
import 'package:gaya/utils/const.dart';
import 'package:gaya/utils/language/translation.dart';
import 'package:gaya/utils/methods.dart';
import 'package:gaya/utils/textstyles.dart';
import 'package:gaya/utils/theme/app_colors.dart';
import 'package:gaya/utils/theme/app_typography.dart';
import 'package:gaya/utils/theme/button_styles.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class MyCommunitiesViewSearch extends StatefulWidget {
  const MyCommunitiesViewSearch({super.key, this.isCommunityUsersSearch = false, this.communityId = ''});

  final bool isCommunityUsersSearch;
  final String communityId;

  @override
  State<MyCommunitiesViewSearch> createState() => _MyCommunitiesViewSearchState();
}

class _MyCommunitiesViewSearchState extends State<MyCommunitiesViewSearch> {
  var joinedCommunities;
  late TextEditingController _searchController;
  List<dynamic>? recentSearchList = [];
  // GetCommunityStorageController getStorage = Get.find<GetCommunityStorageController>();
  // GetCommunityUsersStorageController getUserStorage = Get.find<GetCommunityUsersStorageController>();
  final maxItems = 10;

  @override
  void initState() {
    joinedCommunities = context.read<CommunitiesController>().getJoinedCommunities();

    // context.read<CommunitiesController>().searchController.clear();
    _searchController = TextEditingController();
    // if (widget.isCommunityUsersSearch) {
    //   recentSearchList = getUserStorage.getRecentSearchedList();
    //   recentSearchList ??= [];
    // } else {
    //   recentSearchList = getStorage.getRecentSearchedList();
    //   recentSearchList ??= [];
    // }
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
    _searchController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final communitiesController = Provider.of<CommunitiesController>(context, listen: false);
    final searchListLength = (recentSearchList?.length ?? 0) > maxItems ? maxItems : recentSearchList?.length;
    return Scaffold(
      backgroundColor: AppColors.white,
      appBar: AppBar(
        systemOverlayStyle: SystemUiOverlayStyle.dark,
        shape: Border(bottom: BorderSide(color: kBaseGrey.withOpacity(0.5))),
        backgroundColor: kTransparentColor,
        elevation: 0,
        automaticallyImplyLeading: false,
        title: Container(
            padding: const EdgeInsets.symmetric(vertical: distance_15).r,
            child: Row(
              children: [
                Expanded(
                    child: GayaSearchTextField(
                  hintText: widget.isCommunityUsersSearch ? GayaStrings.search_user.tr : GayaStrings.search_communities.tr,
                  autofocus: true,
                  controller: _searchController,
                  onChanged: (query) {
                    setState(() {});
                    communitiesController.userSpecificCommunitiesSearch(query);
                  },
                )),
                SizedBox(width: 10.w),
                TextButton(
                  style: GayaButtonStyles.actionRowTextButtonStyle2.copyWith(
                      tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                      padding: MaterialStateProperty.all(EdgeInsets.zero),
                      visualDensity: VisualDensity.compact),
                  onPressed: () => Navigator.pop(context),
                  child: Text(GayaStrings.cancel_txt.tr, style: body2EnableStyle1),
                ),
              ],
            )),
      ),
      body: Consumer<CommunitiesController>(
        builder: ((context, value, child) {
          return FutureProvider<Map<String, dynamic>>(
            initialData: const {},
            create: (context) => joinedCommunities,
            child: Consumer<Map<String, dynamic>>(builder: (context, value, _) {
              return ( value['communities'] == null)
                  ? const SizedBox()
                  : value['communities'].isEmpty
                      ? SizedBox(
                          height: MediaQuery.of(context).size.height * 0.4,
                          child: Center(child: Text(GayaStrings.no_community_found.tr, style: body2DisableStyle)),
                        )
                      : Builder(builder: (context) {
                          communitiesController.userSpecificCommunties.clear();
                          for (var communityModel in value['communities']) {
                            communitiesController.userSpecificCommunties.add(communityModel);
                          }
                          return ListView.builder(
                              prototypeItem: SizedBox(height: 70.h),
                              physics: const ClampingScrollPhysics(),
                              itemCount: communitiesController.userSpecificSearchedCommunities.length,
                              itemBuilder: (context, index) {
                                final searchCommunities = communitiesController.userSpecificSearchedCommunities[index];
                                final totalMembersCount = searchCommunities.communityMembers ?? 0;
                                return ListTile(
                                  splashColor: kTransparentColor,
                                  selectedColor: kTransparentColor,
                                  selectedTileColor: kTransparentColor,
                                  focusColor: kTransparentColor,
                                  hoverColor: kTransparentColor,
                                  onTap: searchCommunities.communityId == null
                                      ? null
                                      : () async {
                                    FocusScope.of(context).unfocus();
                                    if (searchCommunities.communityId == null) return;
                                    Methods.showModalSheetToJoinCommunity(
                                        communityId: searchCommunities.communityId, ctx: context);
                                    if (!(recentSearchList!.contains(searchCommunities.communityName!))) {
                                      recentSearchList!.add(searchCommunities.communityName!);
                                      // getStorage.storeRecentCommunitySearchedList(recentSearches: recentSearchList!);
                                    }
                                  },
                                  leading: CircleAvatar(
                                      radius: 24.r,
                                      backgroundColor: kBaseGrey,
                                      child: CachedNetworkImage(
                                        memCacheHeight: 50,
                                        memCacheWidth: 50,
                                        imageUrl: searchCommunities.CommunityPic ?? '',
                                        imageBuilder: (context, imageProvider) {
                                          return Container(
                                            decoration: BoxDecoration(
                                              shape: BoxShape.circle,
                                              image: DecorationImage(image: imageProvider, fit: BoxFit.cover),
                                            ),
                                          );
                                        },
                                        fit: BoxFit.cover,
                                        errorWidget: (context, url, error) => AppData.defaultGreyCircleImage,
                                        placeholder: (context, url) => CircleAvatar(
                                          backgroundImage: AssetImage(Assets.assets.images.communityLogo),
                                          backgroundColor: kSecondaryColor,
                                          radius: 40.r,
                                        ),
                                        // placeholder: (context, url) =>
                                        //     Image.asset(Assets.assets.images.communityLogo, cacheHeight: 50, cacheWidth: 50),
                                      )),
                                  title: Text(
                                    searchCommunities.communityName.toString(),
                                    style: GayaTypography.titleMedium,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                  subtitle: Text(
                                    totalMembersCount > 1 ? "$totalMembersCount ${GayaStrings.members_txt.tr}" : "$totalMembersCount ${GayaStrings.members_txt.tr}",
                                    style: GayaTypography.caption,
                                  ),
                                  trailing: Container(
                                    width: 20.w,
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      border: Border.all(color: kBlackColor),
                                    ),
                                    child: Icon(
                                      Icons.keyboard_arrow_right_outlined,
                                      size: 16.r,
                                    ),
                                  ),
                                );
                              });
                        });
            }),
          );
        }),
      ),
    );
  }
}
