import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gaya/components/button.component.dart';
import 'package:gaya/components/gaya_alert_dialogs.dart';
import 'package:gaya/components/textfield.component.dart';
import 'package:gaya/routing/getx_route_methods.dart';
import 'package:gaya/shared/service/service/shared_service.dart';
import 'package:gaya/shared/view/widget/gaya_cupertino_datetime_modal_view.dart';
import 'package:gaya/utils/const.dart';
import 'package:gaya/utils/language/translation.dart';
import 'package:gaya/utils/textstyles.dart';
import 'package:gaya/utils/vallidation.dart';
import 'package:gaya/view/Auth/constants/auth_constants.dart';
import 'package:gaya/view/Auth/service/authentication_services.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

import '../../../shared/view/widget/gaya_back_button.dart';

class DateAndGenderFormView extends StatefulWidget {
  const DateAndGenderFormView({Key? key, this.email}) : super(key: key);
  final String? email;
  @override
  State<DateAndGenderFormView> createState() => _DateAndGenderFormViewState();
}

class _DateAndGenderFormViewState extends State<DateAndGenderFormView> {
  late DateTime _chosenDateTime;
  final TextEditingController _dateController = TextEditingController();
  FocusNode myFocusNode = FocusNode();
  final GlobalKey<FormState> _dobGnderformKey = GlobalKey<FormState>();
  FormValidation formValidation = FormValidation();
  String gender = 'male';
  bool isEnteredAgeValid = true;

  @override
  void initState() {
    super.initState();
    _chosenDateTime = DateTime.now().subtract(const Duration(days: 13 * 365));
    _dateController.text = DateFormat('MMM d, yyyy').format(_chosenDateTime);
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      gayaCupertinoDateTimeModal(context, _dateController, onDateTimeChanged: (dateTime) {
        SharedService.isEnteredAgeValid(dateTime, 13)
            ? setState(() {
                _chosenDateTime = dateTime;
                isEnteredAgeValid = true;
              })
            : setState(() {
                _chosenDateTime = dateTime;
                isEnteredAgeValid = false;
              });
        _dateController.text = DateFormat('MMM d, yyyy').format(_chosenDateTime);
      });
    });
  }

  @override
  void dispose() {
    super.dispose();
    _dateController.dispose();
    myFocusNode.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          systemOverlayStyle: SystemUiOverlayStyle.dark,
          iconTheme: const IconThemeData(color: kBlackColor),
          shape: const Border(bottom: BorderSide(color: kBaseGrey)),
          automaticallyImplyLeading: false,
          leading: const GayaBackButton(),
          title: Text(GayaStrings.sign_up.tr, style: bodyStyle),
          centerTitle: true,
          backgroundColor: kTransparentColor,
          elevation: 0),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24),
        child: Form(
          key: _dobGnderformKey,
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                // dob work
                const SizedBox(height: distance_20),
                Text(GayaStrings.dob.tr,
                    style: TextStyle(
                      fontSize: 16.sp,
                      fontWeight: FontWeight.w500,
                      fontFamily: GayaFontTheme.primaryFont,
                    )),
                const SizedBox(height: distance_20),
                Text(GayaStrings.dob_date.tr,
                    style: TextStyle(
                      fontSize: 14.sp,
                      fontWeight: FontWeight.w400,
                      fontFamily: GayaFontTheme.primaryFont,
                    )),
                const SizedBox(height: distance_10),
                InkWell(
                  onTap: () {
                    gayaCupertinoDateTimeModal(context, _dateController, onDateTimeChanged: (dateTime) {
                      SharedService.isEnteredAgeValid(dateTime, 13)
                          ? setState(() {
                              _chosenDateTime = dateTime;
                              isEnteredAgeValid = true;
                            })
                          : setState(() {
                              _chosenDateTime = dateTime;
                              isEnteredAgeValid = false;
                            });
                      _dateController.text = DateFormat('MMM d, yyyy').format(dateTime);
                    });
                  },
                  child: IgnorePointer(
                      child: textField(
                          focusNode: myFocusNode,
                          controller: _dateController,
                          autoFocus: true,
                          maxlines: 1,
                          borderColor: myFocusNode.hasFocus ? kprimaryColor : borderColor,
                          isPassword: false,
                          autovalidateModel: AutovalidateMode.onUserInteraction,
                          inputType: TextInputType.datetime,
                          validation: formValidation.verifyDob,
                          onChanged: (value) {},
                          hintText: GayaStrings.dob_hint.tr)),
                ),
                (!isEnteredAgeValid)
                    ? Column(
                        children: [
                          const SizedBox(height: distance_3),
                          Text(GayaStrings.valid_dob.tr,
                              style: TextStyle(
                                  fontSize: 14.sp, fontFamily: GayaFontTheme.primaryFont, fontWeight: FontWeight.w400, color: Colors.red)),
                        ],
                      )
                    : const SizedBox.shrink(),
                const SizedBox(height: distance_15),
                Text(GayaStrings.gender.tr,
                    style: TextStyle(
                      fontSize: 16.sp,
                      fontWeight: FontWeight.w500,
                      fontFamily: GayaFontTheme.primaryFont,
                    )),
                SizedBox(
                  height: 40.h,
                  child: ListTile(
                    contentPadding: EdgeInsets.zero,
                    trailing: Padding(
                      padding: EdgeInsets.zero,
                      child: Radio<String>(
                        autofocus: true,
                        fillColor: MaterialStateColor.resolveWith((states) => kprimaryColor),
                        value: "male",
                        groupValue: gender,
                        onChanged: (value) {
                          setState(() {
                            gender = value.toString();
                          });
                        },
                      ),
                    ),
                    leading: Text(GayaStrings.male.tr,
                        style: TextStyle(
                          fontWeight: FontWeight.w400,
                          fontSize: 16.sp,
                          fontFamily: GayaFontTheme.primaryFont,
                        )),
                  ),
                ),
                SizedBox(
                  height: 40.h,
                  child: ListTile(
                    contentPadding: EdgeInsets.zero,
                    trailing: Radio<String>(
                      fillColor: MaterialStateColor.resolveWith((states) => kprimaryColor),
                      value: "female",
                      groupValue: gender,
                      onChanged: (value) {
                        setState(() {
                          gender = value.toString();
                        });
                      },
                    ),
                    leading: Text(GayaStrings.female.tr,
                        style: TextStyle(
                          fontWeight: FontWeight.w400,
                          fontSize: 16.sp,
                          fontFamily: GayaFontTheme.primaryFont,
                        )),
                  ),
                ),
                SizedBox(
                  height: 40.h,
                  child: ListTile(
                    contentPadding: EdgeInsets.zero,
                    enabled: true,
                    trailing: Radio<String>(
                      fillColor: MaterialStateColor.resolveWith((states) => kprimaryColor),
                      value: "other",
                      groupValue: gender,
                      onChanged: (value) {
                        setState(() {
                          gender = value.toString();
                        });
                      },
                    ),
                    leading: Text(GayaStrings.other.tr,
                        style: TextStyle(
                          fontWeight: FontWeight.w400,
                          fontSize: 16.sp,
                          fontFamily: GayaFontTheme.primaryFont,
                        )),
                  ),
                ),
                const SizedBox(height: distance_15),
                button(
                    height: 50.h,
                    borderColor: kTransparentColor,
                    // textStyle: loginController.styleEmail,
                    textStyle: body2EnableStyle,
                    title: GayaStrings.continue_txt.tr,
                    onPressed: () async {
                      if (isEnteredAgeValid == false) {
                        return GayaAlertDialogs.showAlertPopNotEligibleDOB(ctx: context);
                      }
                      if (isEnteredAgeValid && _dobGnderformKey.currentState!.validate() && widget.email != null) {
                        Routes.register(gender: gender, dob: _chosenDateTime, email: widget.email);
                      } else {
                        final authService = AuthenticationServices();
                        Map<String, dynamic> updatedData = {"dob": _chosenDateTime, "gender": gender};
                        if (authService.authUser != null) {
                          await authService.updateUser(userId: authService.authUser!.uid, updatedData: updatedData);
                          Routes.switchView();
                        }
                      }
                    },
                    primaryColor: kprimaryColor)
              ],
            ),
          ),
        ),
      ),
    );
  }
}
