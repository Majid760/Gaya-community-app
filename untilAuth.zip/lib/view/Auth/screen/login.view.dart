import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gaya/gen/assets.gen.dart';
import 'package:gaya/routing/getx_route_methods.dart';
import 'package:gaya/utils/assets_icons.dart';
import 'package:gaya/utils/language/translation.dart';
import 'package:gaya/utils/textstyles.dart';
import 'package:gaya/utils/theme/app_colors.dart';
import 'package:gaya/utils/theme/app_typography.dart';
import 'package:gaya/utils/theme/button_styles.dart';
import 'package:gaya/view/Auth/constants/auth_constants.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

import '../../../components/button.component.dart';
import '../../../components/textfield.component.dart';
import '../../../utils/const.dart';
import '../../../utils/vallidation.dart';
import '../controller/login.controller.dart';

class LoginView extends StatefulWidget {
  const LoginView({Key? key}) : super(key: key);

  @override
  State<LoginView> createState() => _LoginViewState();
}

class _LoginViewState extends State<LoginView> {
  final validation = FormValidation();

  @override
  Widget build(BuildContext context) {
    return Scaffold(body: SafeArea(child: getBody(validation, context)));
  }
}

Widget getBody(FormValidation validation, BuildContext context) {
  final GlobalKey<FormState> loginFormKey = GlobalKey<FormState>();

  final loginController = Provider.of<LoginController>(context, listen: true);

  return Padding(
    padding: const EdgeInsets.symmetric(horizontal: distance_20),
    child: Form(
      key: loginFormKey,
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                SizedBox(height: 54, width: 38, child: Image.asset(Assets.assets.images.gayaLogoPng.path)),
                const SizedBox(width: distance_10),
                Text(AuthString.gaya, style: headingStyle)
              ],
            ),
            const SizedBox(height: distance_10),
            Padding(padding: const EdgeInsets.only(right: distance_40), child: Text(GayaStrings.createCommunityDesc.tr, style: body1Style)),
            const SizedBox(height: distance_30),
            Text(GayaStrings.email.tr, style: secondaryFontStyle),
            const SizedBox(height: distance_10),
            textField(
                maxlines: 1,
                borderColor: borderColor,
                isPassword: false,
                inputType: TextInputType.emailAddress,
                validation: validation.loginEmailValidation,
                controller: loginController.email,
                hintText: GayaStrings.enter_email_hint.tr),
            const SizedBox(height: distance_10),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(GayaStrings.password.tr, style: secondaryFontStyle),
                TextButton(
                  style: GayaButtonStyles.actionRowTextButtonStyle2,
                  child: Text(GayaStrings.forgot_password.tr, style: secondaryFontStyle),
                  onPressed: ()   => Routes.resetPasswordView(),
                ),
              ],
            ),
            textField(
                maxlines: 1,
                borderColor: borderColor,
                isPassword: !loginController.isPasswordVisible,
                inputType: TextInputType.text,
                validation: validation.loginPasswordValidation,
                controller: loginController.password,
                hintText: GayaStrings.type_password_hint.tr,
                suffixIcon: loginController.isPasswordVisible == true
                    ? Consumer<LoginController>(builder: (context, passwordVisible, child) {
                        return IconButton(
                            onPressed: () {
                              passwordVisible.passwordVisibility();
                            },
                            icon: SvgIconWidget.eyeFilled()
                            // icon: (const Icon(Icons.visibility, color: kBlackColor))
                        );
                      })
                    : Consumer<LoginController>(builder: (context, passwordVisibleOff, child) {
                        return IconButton(
                          onPressed: () {
                            passwordVisibleOff.passwordVisibility();
                          },
                            icon: SvgIconWidget.eyeOffFilled()
                          // icon: const Icon(Icons.visibility_off, color: kBlackColor),
                        );
                      })),
            Consumer<LoginController>(builder: (context, logInCtrl, child) {
              return logInCtrl.signInErrorMsg == null || logInCtrl.signInErrorMsg!.isEmpty
                  ? const SizedBox.shrink()
                  : Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          SizedBox(height: distance_30.h),
                          Center(child: Text(logInCtrl.signInErrorMsg ?? '', style: body3Style.copyWith(color: kRedColor))),
                        ],
                      ),
                    );
            }),
            const SizedBox(height: distance_15),
            button(
                height: 50,
                isLoading: loginController.isLoginButtonLoading,
                borderColor: const Color.fromRGBO(255, 255, 255, 0.0),
                textStyle: body2EnableStyle,
                title: GayaStrings.logIn.tr,
                onPressed: () {
                  if (loginFormKey.currentState?.validate() ?? false) {
                    loginController.loginWithEmailAndPassword(context: context);
                  }
                },
                primaryColor: kprimaryColor),
            SizedBox(height: distance_30.h),
            loginController.isLoading
                ? const SizedBox.shrink()
                : Center(
                    child: TextButton(
                        style: GayaButtonStyles.actionRowTextButtonStyle2,
                        onPressed: () => Routes.registerEmailView(),
                        child: Text(GayaStrings.sign_up.tr, style: bodyStyle))),

            SizedBox(height: 20.h),
            Row(
              children: [
                const Expanded(child: Divider(thickness: 2, color: kBaseGrey)),
                const SizedBox(width: 10),
                Text(GayaStrings.or.tr,
                    style: GayaTypography.h2
                        .copyWith(fontSize: 16.sp, color: AppColors.secondary, letterSpacing: 0, fontWeight: FontWeight.w400)),
                const SizedBox(width: 10),
                const Expanded(child: Divider(thickness: 2, color: kBaseGrey)),
              ],
            ),
            SizedBox(height: 20.h),
            Consumer<LoginController>(builder: ((context, loginController, child) {
              return loginController.isLoading
                  ? Column(
                      mainAxisSize: MainAxisSize.min,
                      children:  [Center(child: CircularProgressIndicator.adaptive(backgroundColor: AppColors.primary)),const SizedBox(height: distance_10)])
                  : Column(
                      children: [
                        loginController.socialSignInError == null || loginController.socialSignInError!.isEmpty
                            ? const SizedBox.shrink()
                            : Center(
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    SizedBox(height: distance_20.h),
                                    Center(
                                        child: Text(loginController.socialSignInError ?? '', style: body3Style.copyWith(color: kRedColor))),
                                    SizedBox(height: distance_20.h),
                                  ],
                                ),
                              ),
                        SocialMediaButtons(
                            borderColor: AppColors.secondary,
                            textStyle: GayaTypography.h2.copyWith(fontSize: 16.sp, color: kprimaryColor, letterSpacing: 0),
                            backgroundColor: kWhiteColor,
                            onPressFunction: () => loginController.logInWithGoogle(context: context),
                            text: GayaStrings.continue_with_google.tr,
                            imageAsset: 'Assets/icons/google.png'),
                        const SizedBox(height: distance_10),
                        Visibility(
                          visible: DeviceCheck.isIOS,
                          child: SocialMediaButtons(
                              textStyle: GayaTypography.h2.copyWith(fontSize: 16.sp, color: kWhiteColor, letterSpacing: 0),
                              backgroundColor: kBlackColor,
                              onPressFunction: () async {
                                final userModel = await loginController.signInWithAppleFirebase(context);
                                if (userModel != null) {
                                  if (userModel.dob == null ||
                                      userModel.phoneNumber == null ||
                                      userModel.phoneNumber == '' ||
                                      userModel.name == null ||
                                      userModel.name?.trim() == '') {
                                    // go to splash screen only if we have name, phonenumber and dob
                                    Routes.askNameFieldView();
                                  } else {
                                    Routes.splash();
                                  }
                                }
                              },
                              text: GayaStrings.continue_with_apple.tr,
                              imageAsset: 'Assets/images/apple_logo.png'),
                        ),
                      ],
                    );
            })),
            SizedBox(height: 20.h),
            Center(
              child: RichText(
                  text: TextSpan(
                style: Theme.of(context).textTheme.bodyText1,
                children: [
                   TextSpan(text: GayaStrings.dont_have_account.tr, style: const TextStyle(color: Colors.grey)),
                  TextSpan(
                    text: GayaStrings.continue_as_guest.tr,
                    style: const TextStyle(color: kprimaryColor, fontWeight: FontWeight.bold),
                    recognizer: TapGestureRecognizer()..onTap = () {
                      FirebaseAuth.instance.signOut();
                      Routes.switchView();
                    },
                  ),
                ],
              )),
            ),
          ],
        ),
      ),
    ),
  );
}
