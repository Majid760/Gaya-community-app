import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'package:gaya/view/Auth/service/common_service.dart';
import 'package:gaya/view/chat/controllers/chat_controller.dart';
import 'package:gaya/view/chat/utils/configs.dart' as config;
import 'package:connectycube_sdk/connectycube_chat.dart';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:crypto/crypto.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:gaya/controller/app_config_controller.dart';
import 'package:gaya/controller/firebase_analytics_controller.dart';
import 'package:gaya/routing/getx_route_methods.dart';
import 'package:gaya/services/notification/fcm_helper.dart';
import 'package:gaya/shared/view/widget/gaya_snackbar.dart';
import 'package:gaya/utils/language/translation.dart';
import 'package:gaya/utils/local.storage.dart';
import 'package:get/get.dart';
import 'package:gaya/utils/logger.dart';
import 'package:gaya/view/chat/services/push_notifications_manager.dart';
import 'package:gaya/view/chat/utils/pref_util.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:sign_in_with_apple/sign_in_with_apple.dart';

import '../../../model/user.model.dart';
import '../../../services/services.dart';
import '../../../utils/exception_handler/exception_handler_string.dart';
import '../../../utils/strings.dart';
import '../service/authentication_services.dart';

enum FromPage { login, resetPassword }

class LoginController extends ChangeNotifier {
  final TextEditingController email = TextEditingController();
  final TextEditingController password = TextEditingController();

  final GlobalKey<FormState> resetPasswordFormKey = GlobalKey<FormState>();

  final GlobalKey<FormState> resetPasswordFormKeyPhone = GlobalKey<FormState>();
  final GlobalKey<FormState> resetPasswordFormKeyEmail = GlobalKey<FormState>();
  final GlobalKey<FormState> createPasswordKey = GlobalKey<FormState>();

  final TextEditingController verifyPassword = TextEditingController();
  final TextEditingController otpController = TextEditingController();
  final TextEditingController phoneNumberController = TextEditingController();
  final TextEditingController passController = TextEditingController();
  final TextEditingController confirmPassController = TextEditingController();

  final commonService = Services();
  final crashlytics = CrashlyticsController.to;
  final performance = PerformanceController.to.instance;

  // style
  TextStyle? verifyPasswordStyle;
  Color? buttonBackgroundColorVerifyPassword;
  VoidCallback? onPressedverifyPassword;
  bool isActive = false;
  bool isLoading = false;
  bool isLoginButtonLoading = false;
  var isCodeEntered = false;
  var isResetLoading = false;
  var isEmailSent = false;
  bool isloadingReset = false;
  bool isPasswordVisible = false;
  String? signInErrorMsg;
  String? signUpErrorMsg;
  String? socialSignInError;
  String? resetPasswordErrorMsg;

  // done by mak
  FirebaseAuth get auth => FirebaseAuth.instance;
  final FirebaseMessaging _firebaseMessaging = FirebaseMessaging.instance;

  User? get authUser => auth.currentUser;
  final GoogleSignIn googleSignIn = GoogleSignIn();
  final AuthenticationServices authServices = AuthenticationServices();
  GoogleSignInAccount? _googleSignInAccount;

  GoogleSignInAccount? get googleSignInAccount => _googleSignInAccount;
  String phoneCode = '\+972';

  Stream<User?> get authChanges => auth.authStateChanges();

  // sign up page (dob  and gender part here)
  DateTime? dateOfBirth;
  String? gender;

  @override
  void dispose() {
    email.dispose();
    password.dispose();
    verifyPassword.dispose();
    // done by mak
    otpController.dispose();
    phoneNumberController.dispose();
    passController.dispose();
    confirmPassController.dispose();
    signInErrorMsg = null;
    signUpErrorMsg = null;
    socialSignInError = null;
    resetPasswordErrorMsg = null;
    super.dispose();
  }

  // link with phone
  // link phone with email
  Future<bool> linkPhoneWithEmail({required BuildContext context, required Map<String, dynamic> data}) async {
    bool isLinkedSuccessfully = false;
    try {
      isLoading = true;
      notifyListeners();
      await isUserAlreadyExists(data['email']);
      final credential = EmailAuthProvider.credential(email: data['email'], password: data['password']);
      UserCredential userCredentials = await auth.currentUser!.linkWithCredential(credential);
      if (userCredentials.user != null) {
        final user = userCredentials.user;
        Map<String, dynamic> userData = {
          'name': data['name'],
          'email': data['email'],
          'dob': data['dob'],
          'gender': data['gender'],
          'bio': '',
          'profilePic': '',
          'coverphoto': '',
          'interests': [],
          'uid': user!.uid,
          'admin': false,
          'phoneNumber': data['phone'],
          'createdAt': FieldValue.serverTimestamp(),
          'fm_token': '',
          'isActive': true
        };
        await authServices.addUser(userData);
        UserModel.to.update(UserModel.fromMap(userData));
        // connectycube login
        final cubeUser = await connectyCubeLogin(
            context ?? Get.context!,
            CubeUser(
              login: FirebaseAuth.instance.currentUser?.uid,
              password: FirebaseAuth.instance.currentUser?.uid,
            ),
            saveUser: true);
        await userCredentials.user?.updateDisplayName(data['name']);
        isLoading = false;
        signInErrorMsg = null;
        signUpErrorMsg = null;
        socialSignInError = null;
        resetPasswordErrorMsg = null;
        isLinkedSuccessfully = true;
        notifyListeners();
      }
    } on FirebaseAuthException catch (error) {
      isLoading = false;
      signInErrorMsg = ExceptionHandler.getMsgAuthException(error.code);
      notifyListeners();
      // gayaAlertDialog(context: context, title: "Login Failed", content: ExceptionHandler.getMsgAuthException(error.code));
    } on FirebaseException catch (error) {
      crashlytics.instance.recordError(e, reason: "FirebaseException linkPhoneWithEmail: ${error.message}");
      isLoading = false;
      signInErrorMsg = ExceptionHandler.getMsgFirebaseException(error.code);
      notifyListeners();
      // gayaAlertDialog(context: context, title: "Login Failed", content: ExceptionHandler.getMsgFirebaseException(error.code));
    } catch (e, s) {
      isLoading = false;
      signInErrorMsg = somethingWrong;
      crashlytics.instance.recordError(e, reason: "linkPhoneWithEmail ", stackTrace: s);

      notifyListeners();
    }
    return isLinkedSuccessfully;
  }

  Future<bool> isUserAlreadyExists(String email) async {
    final isUserExist = await authServices.isUserExistsByEmail(email);
    if (isUserExist == false) {
      return isUserExist;
    }
    //user already exists exception
    throw FirebaseAuthException(code: 'email-already-in-use', message: 'The email address is already in use by another account.');
  }

  // register user
  Future<void> register({required BuildContext context, required Map<String, dynamic> data}) async {
    try {
      performance.startRegisterLoadTime();
      // required String userEmail, required String userPassword, String? fullName, String? phone
      isLoading = true;
      // just used for resend email
      email.text = data['email'];
      debugPrint('yes set email${email.text}');
      notifyListeners();
      UserCredential _userCredentials = await auth.createUserWithEmailAndPassword(email: data['email'], password: data['password']);
      if (_userCredentials.user != null) {
        final _user = _userCredentials.user;
        Map<String, dynamic> userData = {
          'name': data['fullName'],
          'email': data['email'],
          'dob': data['dob'],
          'gender': data['gender'],
          // 'password': EncryptData.encryptData(password: password.value.text),
          'bio': '',
          'profilePic': '',
          'coverphoto': '',
          'interests': [],
          'uid': _user!.uid,
          'admin': false,
          'phoneNumber': data['phone'],
          'createdAt': DateTime.now(),
          'fm_token': '',
          'isActive': false
        };
        await authServices.addUser(userData);
        UserModel.to.update(UserModel.fromMap(userData));
        // connectycube login
        final cubeUser = await connectyCubeLogin(
            context ?? Get.context!,
            CubeUser(
              login: FirebaseAuth.instance.currentUser?.uid,
              password: FirebaseAuth.instance.currentUser?.uid,
            ),
            saveUser: true);
        await _userCredentials.user?.updateDisplayName(data['fullName']);
        isLoading = false;
        signUpErrorMsg = null;
        notifyListeners();
        if (_user.emailVerified == true) {
          Routes.switchView();
          // Navigator.popUntil(context, (route) => route.isFirst);
          // Navigator.pushReplacementNamed(context, route.switchView);
        } else if (_user.emailVerified == false) {
          await sendVerificationEmailAndLogout();
          Routes.emailSentView(fromPage: FromPage.login);
          // Navigator.of(context).pushReplacementNamed(route.emailSent, arguments: {"page": FromPage.login});
        }
        // just for asking interest when user signup
        GetInterestStorageController getStorage = Get.find<GetInterestStorageController>();
        await getStorage.removeGetStorage();
      }

      // UserCredential user =
      //     await FirebaseAuth.instance.createUserWithEmailAndPassword(email: email.text.trim(), password: password.text.trim());
      // Get.toNamed(route.emailSent, arguments: {
      //   'userCredentials': user,
      //   'isFromLogn': false,
      // });
      // await addUserdetails();
      // email.clear();
      // password.clear();
      signInErrorMsg = null;
      signUpErrorMsg = null;
      socialSignInError = null;
      resetPasswordErrorMsg = null;
      notifyListeners();
      performance.stopRegisterLoadTime();
    } on FirebaseAuthException catch (error) {
      crashlytics.instance.recordError(e, reason: "register ${error.message}");
      isLoading = false;
      signUpErrorMsg = ExceptionHandler.getMsgAuthException(error.code);
      notifyListeners();
      // gayaAlertDialog(context: context, title: "Registration Failed", content: ExceptionHandler.getMsgAuthException(error.code));
    } on FirebaseException catch (error) {
      crashlytics.instance.recordError(e, reason: "register ${error.message}");
      isLoading = false;
      signUpErrorMsg = ExceptionHandler.getMsgFirebaseException(error.code);
      notifyListeners();
      // gayaAlertDialog(context: context, title: "Registration Failed", content: ExceptionHandler.getMsgFirebaseException(error.code));
    } catch (error, s) {
      crashlytics.instance.recordError(e, reason: "register ", stackTrace: s);

      isLoading = false;
      signUpErrorMsg = somethingWrong;
      notifyListeners();
      email.clear();
      password.clear();
      // gayaAlertDialog(context: context, title: "Registration Failed", content: somethingWrong);
    }
  }

  // get user map data

  // signin with and email and password
  Future<void> loginWithEmailAndPassword({required BuildContext context}) async {
    try {
      performance.startLoginLoadTime();
      isLoginButtonLoading = true;
      notifyListeners();
      UserCredential _userCredentials = await auth.signInWithEmailAndPassword(email: email.text.trim(), password: password.text);
      if (_userCredentials.user != null) {
        final _user = _userCredentials.user;
        //getting myappuser and setting for global singleton
        UserModel? myAppuser = await authServices.getUserById(_user?.uid);

        if (myAppuser == null || myAppuser.uId == null) {
          await authServices.addUserUIDOnly();
        }
        UserModel.to.update(myAppuser);
        // connectycube login
        final cubeUser = await connectyCubeLogin(
            context ?? Get.context!,
            CubeUser(
              login: FirebaseAuth.instance.currentUser?.uid,
              password: FirebaseAuth.instance.currentUser?.uid,
            ),
            saveUser: true);

        //fcm token
        String? fcmToken = await _firebaseMessaging.getToken();
        Map<String, dynamic> updatedData = {'fm_token': fcmToken ?? ''};
        await authServices.updateUser(userId: _user!.uid, updatedData: updatedData);

        if (auth.currentUser?.emailVerified == true) {
          Routes.splash();
          email.clear();
          password.clear();
        } else if (auth.currentUser?.emailVerified == false) {
          await sendVerificationEmailAndLogout();
          Routes.emailSentView(fromPage: FromPage.login);
        } else {
          Routes.splash();
        }
      }
      email.clear();
      password.clear();
      password.clear();
      isLoading = false;
      isLoginButtonLoading = false;
      signInErrorMsg = null;
      signUpErrorMsg = null;
      socialSignInError = null;
      resetPasswordErrorMsg = null;
      notifyListeners();
      performance.stopLoginLoadTime();
    } on FirebaseAuthException catch (error) {
      crashlytics.instance.recordError(error, reason: "login:${email.text}, ${error.message} ");

      isLoading = false;
      isLoginButtonLoading = false;
      signInErrorMsg = ExceptionHandler.getMsgAuthException(error.code);
      notifyListeners();
      // gayaAlertDialog(context: context, title: "Login Failed", content: ExceptionHandler.getMsgAuthException(error.code));
    } on FirebaseException catch (error) {
      crashlytics.instance.recordError(error, reason: "login:${email.text}, ${error.message} ");
      isLoading = false;
      isLoginButtonLoading = false;
      signInErrorMsg = ExceptionHandler.getMsgFirebaseException(error.code);
      notifyListeners();
      // gayaAlertDialog(context: context, title: "Login Failed", content: ExceptionHandler.getMsgFirebaseException(error.code));
    } catch (error, s) {
      debugPrint("err $error");
      isLoading = false;
      isLoginButtonLoading = false;
      signInErrorMsg = somethingWrong;
      notifyListeners();
      crashlytics.instance.recordError(e, reason: "login:${email.text} ", stackTrace: s);
      // gayaAlertDialog(context: context, title: "Login Failed", content: somethingWrong);
    }
  }

  Completer<void>? _taskCompleter;
  Future<void>? _currentTask;
  bool _isTaskRunning = false;

  // Future<void> performConnectyCubeLogin(BuildContext context, CubeUser user, {bool saveUser = false, dynamic isFromDeepLink}) async {
  //   // Simulate an async task that takes some time
  //   if (isFromDeepLink != null && ChatController.to().currentUser == null) {
  //     await Future.delayed(const Duration(seconds: 4));
  //   }
  //   await loginToCC(context, user, saveUser: saveUser, isFromDeepLink: isFromDeepLink);
  //   await Future.delayed(const Duration(seconds: 1));
  // }

  Future<CubeUser?> connectyCubeLogin(BuildContext context, CubeUser user, {bool saveUser = false, dynamic isFromDeepLink}) async {
    if (_currentTask != null) {
      _cancelTask();
    }
    _taskCompleter = Completer<void>();
    _currentTask = await Future.sync(() {
      return loginToCC(context, user, saveUser: saveUser, isFromDeepLink: isFromDeepLink);
    }).then((_) {}).catchError((error) {}).whenComplete(() {
      _taskCompleter = null;
      _currentTask = null;
    });
    return ChatController.to().currentUser;
  }

  void _cancelTask() {
    if (_isTaskRunning && _taskCompleter?.isCompleted == false) {
      _taskCompleter?.completeError('Canceled');
    }
  }

  // login to connectycube
  Future<void> loginToCC(BuildContext context, CubeUser user, {bool saveUser = false, dynamic isFromDeepLink}) async {
    if (isFromDeepLink != null && ChatController.to().currentUser == null) {
      await Future.delayed(const Duration(seconds: 4));
    }
    init(config.APP_ID, config.AUTH_KEY, config.AUTH_SECRET);
    await createSession(user).then((cubeSession) async {
      var tempUser = user;
      user = cubeSession.user!..password = tempUser.login; //tempUser.password;
      if (saveUser) {
        SharedPrefs.instance.init().then((sharedPrefs) {
          sharedPrefs.saveNewUser(user);
        });
      }
      await _loginToCubeChat(context, user, isFromDeepLink);
    }).catchError((error) {});
    // }
  }

  Future<void> _loginToCubeChat(BuildContext context, CubeUser user, dynamic isFromDeepLink) async {
    try {
      CubeChatConnectionSettings.instance.totalReconnections = 5;
      if (!CubeChatConnection.instance.isAuthenticated()) {
        await CubeChatConnection.instance.login(user).then((cubeUser) async {
          await ChatController.to().getAllChatListAndUpdateCurrentUser(cubeUser);
          // PushNotificationsManager.instance.init();
          // FcmHelper.initConnectycubeNotifications();
          if (isFromDeepLink != null && isFromDeepLink != '') {
            // showAlertDialog(context, 'isFromDeepLink', user);
            subscribeToDialog(isFromDeepLink).then((value) async {
              Routes.openConversationAndRemovePreviousConversationRouteIfOpen(value, shouldReplace: true);
            }).catchError((error) {
              log("error is: $error");
            });
          }
        }).catchError((error) {
          log("error is: $error");
        });
      } else {
        await ChatController.to().getAllChatListAndUpdateCurrentUser(user);
        // PushNotificationsManager.instance.init();
        // FcmHelper.initConnectycubeNotifications();

        if (isFromDeepLink != null && isFromDeepLink != '') {
          subscribeToDialog(isFromDeepLink).then((value) async {
            Routes.openConversationAndRemovePreviousConversationRouteIfOpen(value, shouldReplace: true);
          }).catchError((error) {
            log("error is: $error");
          });
        }
      }
    } catch (_) {
      log("error is: $_");
    }
  }

  // send the email for verification and logout
  Future<void> sendVerificationEmailAndLogout() async {
    await auth.currentUser?.sendEmailVerification();
    // auth.signOut();
  }

  Future<OAuthCredential?> reAuthenticateGoogle() async {
    try {
      final googleSignInAccount = await googleSignIn.signIn();
      final googleSignInAuthentication = await googleSignInAccount!.authentication;
      final credential = GoogleAuthProvider.credential(
        accessToken: googleSignInAuthentication.accessToken,
        idToken: googleSignInAuthentication.idToken,
      );
      return credential;
    } catch (_) {}
  }

  Future<OAuthCredential?> reAuthenticateApple() async {
    try {
      final rawNonce = generateNonce();
      final nonce = sha256ofString(rawNonce);
      // Request credential for the currently signed in Apple account.
      final appleSignInAccount = await SignInWithApple.getAppleIDCredential(scopes: [AppleIDAuthorizationScopes.email], nonce: nonce);
      final credential = OAuthProvider('apple.com')
          .credential(idToken: appleSignInAccount.identityToken, accessToken: appleSignInAccount.authorizationCode, rawNonce: rawNonce);
      return credential;
    } catch (_) {}
  }

  // login with Google
  Future<void> logInWithGoogle({required BuildContext context}) async {
    try {
      performance.startLoginLoadTime();
      isLoading = true;
      notifyListeners();
      _googleSignInAccount = await googleSignIn.signIn();
      if (_googleSignInAccount != null) {
        final googleAuth = await _googleSignInAccount!.authentication;

        final _credentials = GoogleAuthProvider.credential(accessToken: googleAuth.accessToken, idToken: googleAuth.idToken);
        final _userCredential = await auth.signInWithCredential(_credentials);

        final User? user = _userCredential.user;
        if (user != null) {
          await authServices.addUserdetails(user);
          final UserModel? userModel = await authServices.getUserById(user.uid);
          UserModel.to.update(userModel);
          // connectycube login
          final cubeUser = await connectyCubeLogin(
              context ?? Get.context!,
              CubeUser(
                login: FirebaseAuth.instance.currentUser?.uid,
                password: FirebaseAuth.instance.currentUser?.uid,
              ),
              saveUser: true);

          // go to splash screen only if we have name and dob
          if (userModel?.dob == null ||
              userModel?.phoneNumber == null ||
              userModel?.phoneNumber!.trim() == '' ||
              userModel?.name == null ||
              userModel?.name?.trim().isEmpty == true) {
            Routes.askNameFieldView();
          } else {
            Routes.splash();
          }
        }
        isLoading = false;
        signInErrorMsg = null;
        signUpErrorMsg = null;
        socialSignInError = null;
        resetPasswordErrorMsg = null;
        notifyListeners();
      } else {
        debugPrint("Inside If Statement: ");
        debugPrint("No Account Selected: ");
        isLoading = false;
        notifyListeners();
      }
      performance.stopLoginLoadTime();
    } on PlatformException catch (e) {
      crashlytics.instance.recordError(e, reason: "login:${email.text}, ");

      debugPrint('platform exceptin occured during google login with this error code: ${e.code}');
      isLoading = false;
      socialSignInError = somethingWrong;
      notifyListeners();
      // await gayaAlertDialog(context: context, title: "Login Failed", content: '${e.code}\n${e.message!}');
    } on FirebaseAuthException catch (error) {
      isLoading = false;
      socialSignInError = ExceptionHandler.getMsgAuthException(error.code);
      notifyListeners();
      // gayaAlertDialog(context: context, title: "Login Failed", content: ExceptionHandler.getMsgAuthException(error.code));
    } on FirebaseException catch (error) {
      isLoading = false;
      socialSignInError = ExceptionHandler.getMsgFirebaseException(error.code);
      notifyListeners();
      // gayaAlertDialog(context: context, title: "Login Failed", content: ExceptionHandler.getMsgFirebaseException(error.code));
    } catch (error) {
      isLoading = false;
      socialSignInError = error.toString();
      notifyListeners();
      email.clear();
      password.clear();
      gayaAlertDialog(context: context, title: GayaStrings.login_failed.tr, content: error.toString());
    }
  }

  // login with app
  Future<UserModel?> signInWithAppleFirebase(BuildContext context) async {
    isLoading = true;
    notifyListeners();
    performance.startLoginLoadTime();
    try {
      final rawNonce = generateNonce();
      final nonce = sha256ofString(rawNonce);
      // Request credential for the currently signed in Apple account.
      final appleCredential = await SignInWithApple.getAppleIDCredential(
          scopes: [AppleIDAuthorizationScopes.email, AppleIDAuthorizationScopes.fullName], nonce: nonce);
      final oauthCredential = OAuthProvider("apple.com").credential(idToken: appleCredential.identityToken, rawNonce: rawNonce);
      final authResult = await auth.signInWithCredential(oauthCredential);
      final user = authResult.user;
      UserModel? myAppUser;

      if (user != null) {
        myAppUser = await authServices.getUserById(user.uid);

        final firstLastName = appleCredential.givenName != null && appleCredential.familyName != null
            ? '${appleCredential.givenName} ${appleCredential.familyName}'
            : appleCredential.givenName;
        await authServices.addUserdetails(user, name: firstLastName);
        myAppUser = await authServices.getUserById(user.uid);
        UserModel.to.update(myAppUser);
        // connectycube login
        final cubeUser = await connectyCubeLogin(
            context ?? Get.context!,
            CubeUser(
              login: FirebaseAuth.instance.currentUser?.uid,
              password: FirebaseAuth.instance.currentUser?.uid,
            ),
            saveUser: true);
      }
      isLoading = false;
      signInErrorMsg = null;
      signUpErrorMsg = null;
      socialSignInError = null;
      resetPasswordErrorMsg = null;
      notifyListeners();
      performance.stopLoginLoadTime();
      debugPrint("apple login successfull ${myAppUser?.toMap()}}");
      return myAppUser;
    } on SignInWithAppleAuthorizationException catch (error) {
      crashlytics.instance.recordError(error, reason: "signInWithAppleFirebase ");

      isLoading = false;
      socialSignInError = ExceptionHandler.getMsgAuthException(error.code.name);
      notifyListeners();
    } on SignInWithAppleNotSupportedException catch (error) {
      crashlytics.instance.recordError(error, reason: "signInWithAppleFirebase ");

      isLoading = false;
      socialSignInError = error.message;
      notifyListeners();
    } on PlatformException catch (e) {
      crashlytics.instance.recordError(e, reason: "signInWithAppleFirebase");

      debugPrint('platform exceptin occured during apple login with this error code: ${e.code}');
      isLoading = false;
      socialSignInError = somethingWrong;
      notifyListeners();
    } on FirebaseAuthException catch (error) {
      crashlytics.instance.recordError(error, reason: "signInWithAppleFirebase ${error.code}", stackTrace: error.stackTrace);
      isLoading = false;
      socialSignInError = ExceptionHandler.getMsgAuthException(error.code);
      notifyListeners();
    } on FirebaseException catch (error) {
      crashlytics.instance.recordError(error, reason: "signInWithAppleFirebase ${error.code}", stackTrace: error.stackTrace);

      isLoading = false;
      socialSignInError = ExceptionHandler.getMsgFirebaseException(error.code);
      notifyListeners();
    } catch (error, s) {
      crashlytics.instance.recordError(error, reason: "signInWithAppleFirebase ", stackTrace: s);

      debugPrint("err $error");
      isLoading = false;
      socialSignInError = somethingWrong;
      notifyListeners();
      email.clear();
      password.clear();
    }
    return null;
  }

  String sha256ofString(String input) {
    final bytes = utf8.encode(input);
    final digest = sha256.convert(bytes);
    return digest.toString();
  }

  String generateNonce([int length = 32]) {
    const charset = '0123456789ABCDEFGHIJKLMNOPQRSTUVXYZabcdefghijklmnopqrstuvwxyz-._';
    final Random random = Random.secure();
    return List.generate(length, (index) {
      charset[random.nextInt(charset.length)];
    }).join();
  }

  Future<bool?> sendVerificationEmail({required BuildContext context, UserCredential? user}) async {
    final myUser = user?.user ?? authUser;
    bool isSent = false;
    try {
      await myUser?.sendEmailVerification();
      isSent = true;
      GayaSnackBar.show(context: context, type: GayaSnackBarType.other, text: 'Email verification resent successfully!');
    } catch (_) {
      isSent = true;
    }
    return isSent;
  }

  // reset password function
  Future<bool?> resetPassword({required BuildContext context, bool isResend = false}) async {
    try {
      isResetLoading = true;
      notifyListeners();
      await auth.sendPasswordResetEmail(email: email.value.text);
      // snackBar(context, "Your Account not found", Colors.deepOrange);
      isResetLoading = false;
      notifyListeners();
      if (isResend) {
        GayaSnackBar.show(context: context, type: GayaSnackBarType.other, text: 'Email resent successfully!');
      }
      resetPasswordErrorMsg = null;
      notifyListeners();
      return true;
    } on FirebaseAuthException catch (error) {
      isResetLoading = false;
      resetPasswordErrorMsg = ExceptionHandler.getMsgAuthException(error.code);
      notifyListeners();
      // gayaAlertDialog(context: context, title: "Login Failed", content: ExceptionHandler.getMsgAuthException(error.code));
    } catch (error, s) {
      isResetLoading = false;
      resetPasswordErrorMsg = somethingWrong;

      crashlytics.instance.recordError(error, reason: "Reset password ", stackTrace: s);

      notifyListeners();
      // gayaAlertDialog(context: context, title: "Login Failed", content: somethingWrong);
    }
  }

  // reset the isEmailSent after a successful message is shown and moved to the back
  void resetIsEmailField() {
    email.clear();
    notifyListeners();
  }

  // logout
  Future<void> logout(BuildContext context) async {
    try {
      if (auth.currentUser != null) {
        await FcmHelper.clearFcmToken();
        UserModel.to.update(UserModel());
        final _providerData = auth.currentUser!.providerData;
        if (_providerData.isNotEmpty) {
          switch (_providerData.first.providerId) {
            case 'google.com':
              await auth.signOut();

              await googleSignIn.signOut();

              break;
            case 'apple.com':
              await auth.signOut();
              break;
            default:
              await auth.signOut();
          }
        }
        // // just to show the interest screen when user login again
        // SharedPreferences preferences = await SharedPreferences.getInstance();
        // UserModel userModel = UserModel.to;
        // if (userModel.interests == null || userModel.interests!.isEmpty) {
        //   preferences.setInt('initScreen', 0);
        // }
        await googleSignIn.signOut();
        await auth.signOut();
        AppConfigurationController.to.resetOnLogInOrOut(); // delete RAM data
        // signout from connectioncube, destroy session and clear shared preferences
        signOut().then(
          (voidValue) {
            MyLoggerServices.to.print('successfully signout from connection cube.');
          },
        ).catchError(
          (onError) {
            MyLoggerServices.to.print('error while signout from connection cube.');
          },
        ).whenComplete(() {
          try {
            // CubeSessionManager.instance.deleteActiveSession();
            CubeChatConnection.instance.destroy();
            // CubeChatConnection.instance.logout();
            // PushNotificationsManager.instance.unsubscribe();
            // FcmHelper.unsubscribe();

            SharedPrefs.instance.deleteUser();
            MyLoggerServices.to.print('all done on signout from connection cube.');
            ChatController.to().clearAllChatList();
          } catch (e) {}
        });
        Routes.loginView(clearPreviousRoutes: true);
      } else {
        Routes.loginView(clearPreviousRoutes: true);
      }
    } catch (error, s) {
      debugPrint("err $error");
      Routes.loginView(clearPreviousRoutes: true);
    }
  }

  Future<dynamic> gayaAlertDialog({required BuildContext context, required String title, String? content}) {
    return showDialog(context: context, builder: (builder) => AlertDialog(title: Text(title), content: Text(content ?? '')));
  }

  //is password visible
  bool passwordVisibility() {
    isPasswordVisible = !isPasswordVisible;
    notifyListeners();
    return isPasswordVisible;
  }

  // validation phone and email
  // to check that entered phone number is valid
  bool isPhoneNumberValid = true;

  void changePhoneValidation(bool flag) {
    isPhoneNumberValid = flag;
    notifyListeners();
  }
}

// showAlertDialog(BuildContext context, String name, CubeUser user) {
//   // set up the buttons
//   Widget cancelButton = TextButton(
//     child: Text("Cancel"),
//     onPressed: () {
//       Navigator.pop(context);
//     },
//   );
//   Widget continueButton = TextButton(
//     child: Text("Continue"),
//     onPressed: () {
//       Navigator.pop(context);
//     },
//   );

//   // set up the AlertDialog
//   AlertDialog alert = AlertDialog(
//     title: Text(name),
//     content: Text("credencials are: ${user.login}, ${user.password}"),
//     actions: [
//       cancelButton,
//       continueButton,
//     ],
//   );

//   // show the dialog
//   showDialog(
//     context: context,
//     builder: (BuildContext context) {
//       return alert;
//     },
//   );
// }
