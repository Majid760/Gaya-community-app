import 'package:easy_refresh/easy_refresh.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gaya/components/skeleton.post.component.dart';
import 'package:gaya/model/community.model.dart';
import 'package:gaya/model/create.post.model.dart';
import 'package:gaya/utils/refresh_builder_utils.dart';
import 'package:gaya/view/community/components/community_feed_post_tile.dart';
import 'package:gaya/view/community/components/no_posts.dart';
import 'package:get/get.dart';

import '../../../utils/theme/app_colors.dart';
import '../controllers/community_feed_controller.dart';

/// [Replacement of group discussion widget]
class CommunityFeedView extends StatelessWidget {
  final Community communityModel;

  const CommunityFeedView({Key? key, required this.communityModel}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final controller = CommunityFeedController.to(tag: communityModel.communityId);
    return SizedBox(
      width: MediaQuery.of(context).size.width,
      height: MediaQuery.of(context).size.height,
      child: GetBuilder<CommunityFeedController>(
          init: controller,
          autoRemove: false,
          builder: (controller) {
            return EasyRefresh.builder(
              simultaneously: true,
              // noMoreLoad: false,
              controller: controller.refreshController,
              // header: const MaterialHeader(backgroundColor: Colors.white, color: Colors.black),
              // footer: const ClassicFooter(
              //     processedText: "",
              //     succeededIcon: Icon(Icons.check, color: Color.fromRGBO(255, 255, 255, 0.0)),
              //     showMessage: false,
              //     triggerWhenReach: true,
              //     noMoreText: "There are no more posts"),
              header: const CupertinoHeader(
                position: IndicatorPosition.above,
                userWaterDrop: false,
                safeArea: true,
                triggerOffset: 40,
                hapticFeedback: true,
                emptyWidget: SizedBox(),
              ),
              footer: RefreshBuilderUtils.footerAbove,
              onRefresh: () async => controller.resetController(context: context, communityModel: communityModel),
              onLoad: controller.isFeedEmpty
                  ? () {
                      return IndicatorResult.noMore;
                    }
                  : () async {
                      final isFetched = await controller.requestMoreData(topic: controller.selectedTopic);
                      if (!isFetched) {
                        return IndicatorResult.noMore;
                      }
                    },
              childBuilder: (context, physics) {
                if (controller.isLoading) {
                  return Padding(
                    padding: const EdgeInsets.all(20.0).r,
                    child: ListView(physics: const NeverScrollableScrollPhysics(), children: const [
                      PostsSkeleton(showTopDivider: false),
                      PostsSkeleton(),
                      PostsSkeleton(),
                    ]),
                  );
                }
                if (controller.isFeedEmpty) {
                  return Padding(
                    padding: const EdgeInsets.all(20.0).r,
                    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                      (controller.selectedTopic == null || controller.selectedTopic == '')
                          ? const NoPostsWidget()
                          : const NoPostsWidget(isFeedWidget: true),
                    ]),
                  );
                }

                return ListView.separated(
                    separatorBuilder: (ctx, index) => Container(color: AppColors.divider, height: 6.h),
                    itemCount: controller.posts.length,
                    physics: physics,
                    itemBuilder: (ctx, index) {
                      Post postModel = controller.posts[index];
                      postModel.community = communityModel;

                      return CommunityFeedPostTile(postModel: postModel, controller: controller);
                    });
              },
            );
          }),
    );
  }
}


