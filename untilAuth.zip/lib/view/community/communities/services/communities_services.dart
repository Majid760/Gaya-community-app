import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:gaya/controller/app_config_controller.dart';
import 'package:get/get.dart';

import '../../../../model/community.model.dart';
import '../../../../utils/logger.dart';
import '../models/topic_communties.dart';

abstract class ICommunitiesServices {
  Future<TopicCommunities?> getCommunityByTopic({required String topic});
}

class CommunitiesServices implements ICommunitiesServices {
  final ref = FirebaseFirestore.instance.collection("communities");
  final _logger = MyLoggerServices.to;

  Query<Map<String, dynamic>> getHotCommunitiesQuery() {
    return ref
        .where(Filter.or(
          Filter('type', isEqualTo: 'Public'),
          Filter('type', isEqualTo: 'Private'),
        ))
        .orderBy('totalmembers', descending: true)
        .limit(8);
  }

  Query<Map<String, dynamic>> getNewCommunitiesQuery(){
    return ref
        .where(Filter.or(
          Filter('type', isEqualTo: 'Public'),
          Filter('type', isEqualTo: 'Private'),
        ))
        .orderBy('createdOn', descending: true)
        .limit(8);
  }

  Future<List<Community>> getHotCommunities() async {
    List<Community> communities = [];
    try {
      final query = getHotCommunitiesQuery();

      final communitiesSnap = await query.get();

      for (var element in communitiesSnap.docs) {
        /// if community is hidden, then skip it
        if (AppConfigurationController.to.isHiddenCommunity(communityId: element.id)) {
          continue;
        }
        try {
          communities.add(Community.fromMap(element.data()));
        } catch (e) {
          _logger.print("Error in makingModel: $e");
        }
      }

      communities.sort((a, b) => b.communityMembers!.compareTo(a.communityMembers!));

      return communities;
    } catch (_) {
      _logger.print("Error in getHotCommunities(): $_");
    }
    return communities;
  }

  Future<List<Community>> getNewCommunities() async {
    List<Community> communities = [];
    try {
      final query = getNewCommunitiesQuery();

      final communitiesSnap = await query.get();

      for (var element in communitiesSnap.docs) {
        /// if community is hidden, then skip it
        if (AppConfigurationController.to.isHiddenCommunity(communityId: element.id)) {
          continue;
        }
        try {
          communities.add(Community.fromMap(element.data()));
        } catch (e) {
          _logger.print("Error in makingModel: $e");
        }
      }

      communities.sort((a, b) => b.communityMembers!.compareTo(a.communityMembers!));

      return communities;
    } catch (_) {
      _logger.print("Error in getHotCommunities(): $_");
    }
    return communities;
  }

  @override
  Future<TopicCommunities?> getCommunityByTopic({required String? topic, int? limit}) async {
    if (topic.isBlank == true || topic == null) return null;
    try {
      List<Community> communities = [];

      /// make a query to get communities with that topic
      final query = ref
          .where('type', isNotEqualTo: 'Secret')
          .where('topics.topicName', isEqualTo: topic)
          .orderBy('type', descending: false)
          .orderBy('totalmembers', descending: true);

      /// If limit is not null, then limit the query
      if (limit != null) query.limit(limit);

      /// Get the snapshot of the query
      final communitiesSnap = await query.get();

      communitiesSnap.docs.removeWhere((element) => AppConfigurationController.to.isHiddenCommunity(communityId: element.id));

      /// iterate over the snapshot and make a model for each community
      for (var element in communitiesSnap.docs) {
        try {
          communities.add(Community.fromMap(element.data()));
        } catch (e) {
          _logger.print("Error in makingModel: $e");
        }
      }

      /// The most popular community will be on top
      /// `!` because in model default value is 0 for communityMembers
      communities.sort((a, b) => b.communityMembers!.compareTo(a.communityMembers!));

      return TopicCommunities(topicName: topic, communities: communities);
    } catch (_) {
      _logger.print("Error in getCommunityByTopic(): $_");
    }
    return null;
  }
}
