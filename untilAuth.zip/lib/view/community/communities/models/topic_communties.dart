import '../../../../model/community.model.dart';

/// This class contains communities with topic name
/// A local model to store communities with topic name
 class TopicCommunities {
  final String topicName;
  final List<Community> communities;

  TopicCommunities({required this.topicName, required this.communities});
 }