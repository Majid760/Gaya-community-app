import 'package:easy_refresh/easy_refresh.dart';
import 'package:gaya/model/create.post.model.dart';
import 'package:gaya/shared/service/base/easy_refresh_impl.dart';
import 'package:gaya/utils/logger.dart';
import 'package:gaya/view/community/controllers/base_controller.dart';
import 'package:get/get.dart' show Get, Inst;
import 'package:helpers/helpers.dart';

import '../../../feed/services/post_isolations.dart';
import '../services/post_approval_services.dart';

class PostApprovalController extends BaseController implements EasyRefreshImpl {
  static PostApprovalController to({required String tag}) => Get.find(tag: tag);
  final String communityId;

  PostApprovalController({required this.communityId});

  late final _postApprovalServices = PostApprovalServices(communityId: communityId);
  final _logger = MyLoggerServices.to;

  bool get isFeedEmpty => _posts.isEmpty;

  bool isFirstTime = false;

  List<Post> _posts = [];

  List<Post> get posts => _posts;

  @override
  void onInit() {
    super.onInit();
    getApprovalPosts(isInitial: true);
  }

  @override
  Future<void> onPullRefresh() async {
    _posts = [];
    isFirstTime = false;

    /// set isLoading false - no need to notify because we already have a setLoadingTrue in [getApprovalPosts]
    setLoading(false, notify: false);

    /// reset service to initial state
    _postApprovalServices.reset();

    /// get posts as initial
    await getApprovalPosts(isInitial: true);
  }

  @override
  Future<int> onLoadMore() async {
    return await getApprovalPosts();
  }

  @override
  EasyRefreshController refreshController = EasyRefreshController(
    controlFinishLoad: true,
  );

  /// Get Approval Posts - Adds the Approval posts to the list and returns the length of the new posts
  Future<int> getApprovalPosts({bool isInitial = false}) async {
    try {
      MyLoggerServices.to.print(" requestMoreData called");
      if (isInitial) setLoading(true);
      isFirstTime = true;
      final newPosts = await _postApprovalServices.requestMoreData();
      MyLoggerServices.to.print("newPosts.length ${newPosts.length}");
      _posts.addAll(newPosts);

      //sort posts in thread
      _posts = await CustomIsolatePost.sortPostInThread(_posts);

      setLoading(false);
      return newPosts.length;
    } catch (_) {
      _logger.printError(_, info: "getApprovalPosts");
      setLoading(false);
    }
    return 0;
  }

  /// To Approve Post both locally and in the DB
  Future<bool> approvePost(
      {required String userId, required String postId, required String communityId, required String communityName}) async {
    bool isSuccessful = false;
    int? removedIndex = _posts.removeFirstWhere((element) => element.postid == postId);

    /// if removedIndex is not null, that means its successfully approved so removed the post from the list.
    /// This will remove the post from the DB.
    if (removedIndex != null) {
      isSuccessful =
          await _postApprovalServices.approvePost(userId: userId, postId: postId, communityId: communityId, communityName: communityName);
    }
    update();
    return isSuccessful;
  }

  Future<bool> rejectPost(
      {required String userId, required String postId, required String communityId, required String communityName}) async {
    bool isSuccessful = false;
    int? removedIndex = _posts.removeFirstWhere((element) => element.postid == postId);

    /// if removedIndex is not null, that means its successfully approved so removed the post from the list.
    /// This will remove the post from the DB.
    if (removedIndex != null) {
      isSuccessful =
          await _postApprovalServices.rejectPost(userId: userId, postId: postId, communityId: communityId, communityName: communityName);
    }
    update();
    return isSuccessful;
  }
}
