import 'package:flutter/material.dart';
import 'package:gaya/model/community.model.dart';
import 'package:gaya/model/user.model.dart';
import 'package:gaya/services/services.dart';
import 'package:gaya/utils/const.dart';
import 'package:gaya/view/community/controllers/base_controller.dart';
import 'package:get/get.dart';

import '../../feed/controller/base/base_feed_impl.dart';

class CommunityProfileController extends BaseController {
  static CommunityProfileController to({required String? tag}) => Get.find(tag: tag);
  final String communityId;
  Community? communityModel;

  CommunityProfileController({required this.communityId, this.communityModel});

  late Services _commonService;

  UserModel userModel = UserModel.to;

  @override
  onInit() {
    super.onInit();
    _commonService = Services();
    fetchCommunityProfile();
  }

  void fetchCommunityProfile() async {
    setLoading(true);
    final communityProfile = await _commonService.getCommunityDetailsModel(communityId);
    if (communityProfile != null) {
      communityModel = communityProfile;
    }
    setLoading(false);
  }

  /// Update the community locally
  /// This is used when the community is updated from the community settings page
  void updateGroupViewCommunity({required Community? community}) {
    if (community == null) return;
    communityModel = community;
    // // update community feed with updated community
    // CommunityFeedController.to._updateAllPostsCommunityLocally(community);
    //update home feed with updated community
    FeedControllerUtils.updateAllOfTheCommunitieslocally(community);
    setLoading(false);
  }

  // get color from hex color
  Color? getColorFromHexaString() {
    Color? color;
    if (communityModel?.communityThemeModel?.color != null) {
      color = getColorFromHex(communityModel?.communityThemeModel?.color ?? 'FFD28AFF');
    }
    return color;
  }

  Community? getPosts() => communityModel;

  // A dispose method.
  void resetController() async {
    communityModel = null;
    setLoading(false, notify: false);
  }
}
