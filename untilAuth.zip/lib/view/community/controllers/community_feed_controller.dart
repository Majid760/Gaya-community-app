import 'package:easy_refresh/easy_refresh.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:gaya/controller/crowns_controller.dart';
import 'package:gaya/model/community.model.dart';
import 'package:gaya/services/notification/notification_api/notification_api.dart';
import 'package:gaya/services/services.dart';
import 'package:gaya/utils/extension.dart';
import 'package:gaya/utils/strings.dart';
import 'package:gaya/view/community/controllers/community_editing_controller.dart';
import 'package:gaya/view/community/controllers/community_profile_controller.dart';
import 'package:get/get.dart';
import 'package:helpers/helpers.dart';

import '../../../controller/cache_controller.dart';
import '../../../controller/firebase_analytics_controller.dart';
import '../../../model/create.post.model.dart';
import '../../../model/user.model.dart';
import '../../../utils/logger.dart';
import '../../feed/controller/base/base_feed_impl.dart';
import '../../feed/controller/post_controller.dart';
import '../../feed/services/base/post_db_operations.dart';
import '../../feed/services/base/post_notification_operations.dart';
import '../services/communityFeedServices.dart';

class CommunityFeedController extends GetxController with PostDbOperationsImpl, PostNotificationImpl {
  final String communityId;
  Community? community;
  final String? hashTagTopic;

  CommunityFeedController({required this.communityId, this.community, this.hashTagTopic});

  static CommunityFeedController to({required String? tag}) => Get.find(tag: tag);

  List<Post> _posts = [];
  List<Post> _pinnedPosts = [];

  late CommunityFeedServices postServices;
  late Services _commonService;
  UserModel userModel = UserModel.to;

  List<Post> get posts => _posts.distinctBy((e) => e.postid ?? "").toList();

  bool get isFeedEmpty => _posts.isEmpty;
  bool isFirstTime = false;
  bool isLoading = false;
  String? selectedTopic;

  @override
  onInit() {
    super.onInit();
    postServices = CommunityFeedServices(communityId: communityId);
    _commonService = Services();
    requestMoreData(fromInit: true, topic: hashTagTopic);
  }

  void setState(bool value) {
    isLoading = value;
    update();
  }

  /// select topic and fetch the post.
  void setSelectedTopic(String? topic) {
    if (selectedTopic == topic) return;
    selectedTopic = topic;
    //fetch posts according to selected topic.
    resetController();
  }

  /// manage topics of post.
  /// firebase update + home feed update if exists in viewport.
  Future<void> updatePostTopicsFirebase(Post post) async {
    await _commonService.updatePostTopics(post);
    _updateHomeFeedPost(post);
  }

  List<Post> getPosts() => _posts;

  //call when new post is posted
  void addAPostLocally(Post post) {
    _posts.insert(0, post);
    update();
  }

//delete post from home feed + community feed
  void deletePostLocally(Post post) {
    _posts.removeWhere((element) => element.postid == post.postid);
    _updateHomeFeedPost(post, shouldDelete: true);
    update();
  }

  //call when any post is updated somewhere else.
  void updatePostLocally(Post post) {
    final index = _posts.indexWhere((element) => element.postid == post.postid);
    if (index != -1) {
      final shouldUpdate = _shouldUpdateAllPostAuthorCrowns(newPost: post, oldPost: _posts[index]);
      if (shouldUpdate) {
        _updateAllOfThePostAuthorsCrownslocally(post);
      }
      _posts[index] = post;
    }
    update();
  }

  PostReaction likePost(String? postId, {UserModel? receiverUser}) {
    PostReaction operationPerformed = PostReaction.idle;
    if (postId == null) return operationPerformed;
    var post = _posts.firstWhereOrNull((element) => element.postid == postId);
    //checking if the post is already flowered by the user
    bool? isLiked = post?.likedBy?.contains(FirebaseAuth.instance.currentUser?.uid ?? "");

    if (isLiked == true) {
      EngagementScoreController.to.instance.onDislike(communityId: communityId, postId: postId);
      post?.likedBy?.remove(FirebaseAuth.instance.currentUser?.uid ?? "");
      unlikeAPost(postId, communityId);
      operationPerformed = PostReaction.unlike;
    } else if (isLiked == false) {
      //locally
      post?.likedBy?.add(FirebaseAuth.instance.currentUser?.uid ?? "");
      //db operation
      likeAPost(postId, communityId);
      //score
      EngagementScoreController.to.instance.onLike(communityId: communityId, postId: postId);
      //send notification
      if (receiverUser != null) sendLikeNotification(postId: postId, user: receiverUser, communityId: communityId);
      operationPerformed = PostReaction.like;
    } else {
      MyLoggerServices.to.print("nothing performed on post");
    }
    update();
    _updateHomeFeedPost(post);
    return operationPerformed;
  }

/*  PostReaction flowerPost(String? postId, {UserModel? receiverUser}) {
    PostReaction operationPerformed = PostReaction.idle;
    try {
      if (postId == null) return operationPerformed;
      var post = _posts.firstWhereOrNull((element) => element.postid == postId);

      //checking if the post is already flowered by the user

      if (isFlower == true) {
        //locally remove
        //db operation
        unFlowerAPost(postId);
        operationPerformed = PostReaction.unflower;
      } else if (isFlower == false) {
        //locally add.
        //db operation
        flowerAPost(postId);
        //send notification
        if (receiverUser != null) sendFlowerNotification(postId: postId, user: receiverUser);
        operationPerformed = PostReaction.flower;
      } else {
        MyLoggerServices.to.print("nothing performed on post");
      }
      update();
      _updateHomeFeedPost(post);
    } catch (_) {
      MyLoggerServices.to.print("flowerPostLocally error $_");
    }

    MyLoggerServices.to.print("action performed ${operationPerformed.name}");
    return operationPerformed;
  }*/

  final _notificationApiHitting = NotificationApiHitting();

  Future<PostReaction> crownPost(String? postId, {UserModel? receiverUser}) async {
    String currentUserId = FirebaseAuth.instance.currentUser?.uid ?? "";
    PostReaction operationPerformed = PostReaction.idle;
    if (postId == null) return operationPerformed;
    var post = _posts.firstWhereOrNull((element) => element.postid == postId);
    if (post?.postedBy == null) return operationPerformed;
    //checking if the post is already flowered by the user
    bool? isCrowned = post?.crownsBy?.contains(FirebaseAuth.instance.currentUser?.uid ?? "");
    if (isCrowned == true) {
    } else if (isCrowned == false) {
      post?.crownsBy ??= [];
      post!.postedBy = post.postedBy.updateCrown(shouldIncreament: true);
      // cache author update
      CacheController.to.updateUser(post.postedBy);
      //locally
      post.crownsBy?.add(currentUserId);
      final tempCrown = userModel.userDailyCrowns;

      userModel.userDailyCrowns = (userModel.userDailyCrowns != null) ? userModel.userDailyCrowns! - 1 : userModel.userDailyCrowns;
      // cache current user update
      CacheController.to.updateUser(userModel);
      update();
      //db operation
      bool isSuccess = await crownAPost(postId, receiverUser?.uId ?? '', currentUserId);
      if (!isSuccess) {
        post.crownsBy?.remove(currentUserId);
        post.postedBy = post.postedBy.updateCrown(shouldIncreament: false);
        // cache author update
        CacheController.to.updateUser(post.postedBy);
        userModel.userDailyCrowns = tempCrown;
        // userModel.userDailyCrowns = (userModel.userDailyCrowns != null) ? userModel.userDailyCrowns! + 1 : userModel.userDailyCrowns;
        // cache current user update
        CacheController.to.updateUser(userModel);
      } else {
        EngagementScoreController.to.instance.onCrown(postId: postId, communityId: post.communityId ?? '');
        final CrownsController crownsController = Get.find();

        if (userModel.userDailyCrowns == 0) {
          crownsController.getCrownServerTimeStamp();
        } else {
          crownsController.updateCurrentUser();
        }
      }
      _updateAllOfThePostAuthorsCrownslocally(post);
      //send notification
      if (receiverUser != null) sendCrownNotification(postId: postId, user: receiverUser);
      operationPerformed = PostReaction.like;
    } else {
      MyLoggerServices.to.print("nothing performed on post");
    }
    update();
    _updateHomeFeedPost(post);
    return operationPerformed;
  }

  Future<void> sendCrownNotification({required String postId, required UserModel user}) async {
    //don't send notification if the user is the same.
    if (userModel.uId == user.uId) return;

    //send fcm notification
    // await _notificationApiHitting.callOnFcmApiSendPushNotifications(gaya_message: postIsLikedNotification, fcmToken: user.fm_token);

    UserModel? userData = await _commonService.getUserById(user.uId, forcefullyServer: true);

    final fcmPostModel = FcmCreatePostModel(
      postid: postId,
      communityId: communityId,
      messageContent: "${userModel.name} crowned on your post.",
      messageTitle: postIsCrownedNotification,
      receiverFcm: userData?.fm_token ?? '',
    );

    _notificationApiHitting.callOnFcmApiForPostRelatedNotifications(fcmPostModel
        // gaya_message: "${usermodel.name} sent you a new message.", fcmToken: otherChatParticipantFcmToken
        );

    //store notification
    _commonService.addNotification(
        posId: postId,
        isRead: false,
        message: "Your Post is Crowned.",
        receiverUserID: user.uId ?? '',
        senderId: UserModel.to.uId!,
        senderName: UserModel.to.name ?? "Gaya User",
        time: DateTime.now().toString(),
        type: "postCrowned",
        userImage: UserModel.to.profilePicture ?? "");
  }

  void _updateAllOfThePostAuthorsCrownslocally(Post post) {
    for (int i = 0; i < _posts.length; i++) {
      if (posts[i].memberId == post.memberId) {
        posts[i].postedBy = post.postedBy;
      }
    }
  }

  /// adds the post to the top of the list
  void addPostToTop(Post post) {
    _posts.removeFirstWhere((element) => element.postid == post.postid);

    _posts.insert(0, post);
  }

  /// returns [true] if the post is pinned
  /// returns [false] if the post is not pinned
  bool togglePinPost(Community communityModel, Post postModel) {
    /// if post was not pinned and it pinned successfully
    bool isPinnedSuccess = false;
    if (postModel.postid == null) return false;
    bool isPinned = postModel.community.pinnedPostList?.contains(postModel.postid ?? '') ?? false;
    MyLoggerServices.to.print('post is pinned or not? : $isPinned');
    if (isPinned == true) {
      postModel.community.pinnedPostList = [];

      unpinAPost(communityModel.communityId ?? '', postModel.postid ?? '');
    } else if (isPinned == false) {
      //locally
      postModel.community.pinnedPostList = [postModel.postid ?? ''];
      //db operation
      pinAPost(communityModel.communityId ?? '', postModel.postid ?? '');
      isPinnedSuccess = true;

      /// Add post to top of the list
      addPostToTop(postModel);
    } else {
      MyLoggerServices.to.print("nothing performed on post");
    }
    update();
    MyLoggerServices.to.print("post comunity is: ${postModel.community.pinnedPostList}");
    updatePostLocally(postModel);
    _updateHomeFeedPost(postModel);
    addPostToTop(postModel);
    return isPinnedSuccess;
  }

/*  /// update community locally
  void _updateAllPostsCommunityLocally(CreateCommunityModel? community){
    if(community == null) return;
    for(int i = 0; i < _posts.length; i++){
      if(posts[i].communityId == community.communityId){
        posts[i].community = community;
      }
    }

  }*/

  bool _shouldUpdateAllPostAuthorCrowns({required Post oldPost, required Post newPost}) =>
      oldPost.postedBy.userTotalCrowns != newPost.postedBy.userTotalCrowns;

  Future<bool> requestMoreData({bool fromInit = false, String? topic}) async {
    debugPrint("selected TOPIC IS: $topic");
    // to avoid double loading at top andbottom on screen
    if (fromInit == false) refreshController.callLoad();

    ///////// waqar work //////////
    String? topicc;
    if (topic != null) {
      topicc = await getTopicFromcommunityTopicsList(topic: topic);
      debugPrint("topicc: ${topicc.toString()} ");
    }
    MyLoggerServices.to.print(" requestMoreData called");
    if (fromInit) setState(true);
    await requestPinnedPosts(topic: topicc);

    isFirstTime = true;
    final newPosts = await postServices.requestMoreData(topic: topicc);
    if (_posts.isEmpty && _pinnedPosts.isNotEmpty) {
      _posts.addAll(_pinnedPosts);
    }
    print("new posts length: ${newPosts.length}");

    _posts.addAll(newPosts);

    _posts = _posts.distinctBy((e) => e.postid ?? "").toList();
    setState(false);
    return newPosts.isNotEmpty;
  }

  // requesting for pinned posts in a community
  Future<void> requestPinnedPosts({String? topic}) async {
    _pinnedPosts = [];
    if (topic == null) {
      final pinnedPosts = await postServices.requestPinnedPosts(topic: topic);
      _pinnedPosts.addAll(pinnedPosts);
    }
  }

///////// waqar work //////////
  Future<String?> getTopicFromcommunityTopicsList({String? topic}) async {
    final communityProfileController = CommunityProfileController.to(tag: communityId);
    final communitymodel = communityProfileController.communityModel;
    String? topicc;
    print('topics is in feed controller is: ${communitymodel?.communityTopicList?.length}');
    if (topic != null && communitymodel?.communityTopicList != null) {
      int index = communitymodel!.communityTopicList!.indexWhere((element) => element.toLowerCase().contains(topic.toLowerCase()));
      if (index != -1) {
        selectedTopic = communitymodel.communityTopicList?[index];
        topicc = selectedTopic;
      } else {
        selectedTopic = null;
        topicc = null;
      }
    } else {}

    return topicc;
  }

  ///////// waqar work ended //////////

  void setNoMorePosts() {
    refreshController.finishLoad(IndicatorResult.noMore);
  }

  EasyRefreshController refreshController = EasyRefreshController();

  void _updateHomeFeedPost(Post? post, {bool shouldDelete = false}) {
    try {
      if (post == null) return;
      //update post at home feed
      FeedControllerUtils.updatePostLocally(post, shouldDelete: shouldDelete);
    } catch (_) {}
  }

  // A dispose method.
  Future<void> resetController({BuildContext? context, Community? communityModel}) async {
    _posts = [];

    isFirstTime = false;
    isLoading = false;
    postServices.reset();
    if (context != null && communityModel != null) {
      await loadCommunityProfile(context, communityModel);
    }
    await refreshController.callLoad();
    await requestMoreData(fromInit: true, topic: selectedTopic);
  }

  // fetch and store community profile in community editing controller
  Future<void> loadCommunityProfile(context, Community communityModel) async {
    EditCommunityController.to(tag: communityModel.communityId).fetchCommunityProfile(communityModel, isFirstTime: true);
    CommunityProfileController.to(tag: communityModel.communityId).fetchCommunityProfile();
    if (CommunityProfileController.to(tag: communityModel.communityId).communityModel != null) {
      community = CommunityProfileController.to(tag: communityModel.communityId).communityModel;
    }
  }

  // setCommunityModel
  void setCommunityModel(Community? communityModel) {
    if (communityModel != null) {
      community = communityModel;
      CommunityProfileController.to(tag: communityModel.communityId ?? "").updateGroupViewCommunity(community: communityModel);
    }
  }
}
