import 'package:easy_refresh/easy_refresh.dart';
import 'package:gaya/model/user.model.dart';
import 'package:gaya/shared/service/base/easy_refresh_impl.dart';
import 'package:gaya/utils/logger.dart';
import 'package:gaya/view/community/controllers/base_controller.dart';
import 'package:get/get.dart' show Get, Inst;
import 'package:helpers/helpers.dart';

import '../services/membership_approval_services.dart';

class MembershipApprovalController extends BaseController implements EasyRefreshImpl {
  static MembershipApprovalController to({required String tag}) => Get.find(tag: tag);
  final String communityId;

  MembershipApprovalController({required this.communityId});

  late final _membershipApprovalServices = MembershipApprovalServices(communityId: communityId);
  final _logger = MyLoggerServices.to;

  bool get isApprovalsEmpty => _members.isEmpty;

  bool isFirstTime = false;

  List<UserModel> _members = [];

  List<UserModel> get members => _members;

  @override
  void onInit() {
    super.onInit();
    getApprovalMembers(isInitial: true);
  }

  @override
  Future<void> onPullRefresh() async {
    _members = [];
    isFirstTime = false;

    /// set isLoading false - no need to notify because we already have a setLoadingTrue in [getApprovalPosts]
    setLoading(false, notify: false);

    /// reset service to initial state
    _membershipApprovalServices.reset();

    /// get posts as initial
    await getApprovalMembers(isInitial: true);
  }

  @override
  Future<int> onLoadMore() async {
    return await getApprovalMembers();
  }

  @override
  EasyRefreshController refreshController = EasyRefreshController(
    controlFinishLoad: true,
  );

  /// Get Approval Posts - Adds the Approval posts to the list and returns the length of the new posts
  Future<int> getApprovalMembers({bool isInitial = false}) async {
    try {
      MyLoggerServices.to.print(" requestMoreData called");
      if (isInitial) setLoading(true);
      isFirstTime = true;
      final newPosts = await _membershipApprovalServices.requestMoreData();
      _members.addAll(newPosts);
      setLoading(false);
      return newPosts.length;
    } catch (_) {
      _logger.printError(_, info: "getApprovalMembers");
      setLoading(false);
    }
    return 0;
  }

  /// To Approve Post both locally and in the DB
  Future<bool> approveUser({required UserModel user, required String communityId, required String communityName}) async {
    bool isSuccessful = false;
    int? removedIndex = _members.removeFirstWhere((element) => element.uId == user.uId);

    /// if removedIndex is not null, that means its successfully approved so removed the post from the list.
    /// This will remove the post from the DB.
    if (removedIndex != null) {
      isSuccessful = await _membershipApprovalServices.approveUser(user: user, communityId: communityId, communityName: communityName);
    }
    update();
    return isSuccessful;
  }

  Future<bool> rejectUser({required UserModel user, required String communityId, required String communityName}) async {
    bool isSuccessful = false;
    int? removedIndex = _members.removeFirstWhere((element) => element.uId == user.uId);

    /// if removedIndex is not null, that means its successfully approved so removed the post from the list.
    /// This will remove the post from the DB.
    if (removedIndex != null) {
      isSuccessful = await _membershipApprovalServices.rejectUser(user: user, communityId: communityId, communityName: communityName);
    }
    update();
    return isSuccessful;
  }
}
