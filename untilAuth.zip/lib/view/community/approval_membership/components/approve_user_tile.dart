import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gaya/model/user.model.dart';
import 'package:gaya/utils/extension.dart';
import 'package:gaya/utils/theme/app_spaces.dart';
import 'package:get/get.dart';

import '../../../../components/button.component.dart';
import '../../../../components/profile_image_widget.dart';
import '../../../../gen/assets.gen.dart';
import '../../../../routing/getx_route_methods.dart';
import '../../../../utils/const.dart';
import '../../../../utils/language/translation.dart';
import '../../../../utils/theme/app_colors.dart';
import '../../../../utils/theme/app_typography.dart';

class ApproveUserTile extends StatelessWidget {
  final UserModel user;
  final DateTime? joinedAt;
  final VoidCallback onAccept;
  final VoidCallback onReject;

  const ApproveUserTile({Key? key, required this.user, required this.joinedAt, required this.onAccept, required this.onReject})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    final defaultWidth = MediaQuery.of(context).size.width * 0.3;
    return Column(
      children: [
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            InkWell(
              onTap: () => Routes.viewProfile(uid: user.uId, model: user),
              child: user.profilePicture == ''
                  ? CircleAvatar(
                      radius: 24.r,
                      backgroundColor: kBaseGrey,
                      child: Image.asset(Assets.assets.images.userDefault, cacheHeight: 48),
                    )
                  : CircleAvatar(radius: 24.r, backgroundColor: kBaseGrey, child: ProfileImageWidget(url: user.profilePicture)),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.only(left: MySpaces.gap3).r,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    GestureDetector(
                      onTap: () => Routes.viewProfile(uid: user.uId, model: user),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(user.name ?? "", style: GayaTypography.subtitleMedium),
                              Text(user.dobAndGender(), style: GayaTypography.subtitleRegular.copyWith(color: AppColors.secondary)),
                            ],
                          ),
                          const Spacer(),
                          Text(
                            joinedAt?.toNow() ?? "",
                            style: GayaTypography.caption.copyWith(color: AppColors.secondary, fontSize: 12.64.sp),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: MySpaces.gap2.h),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        button(
                            onPressed: onAccept,
                            /*     onPressed: () async {
                              // await widget.communityPendingPostsAndUsersController.acceptJoiningRequest(
                              //     user,
                              //     Provider.of<GroupController>(
                              //       context,
                              //       listen: false,
                              //     ));
                            },*/
                            width: defaultWidth,
                            height: 30.h,
                            textStyle: GayaTypography.subtitleMedium.copyWith(color: AppColors.white),
                            title: GayaStrings.approve_txt.tr,
                            primaryColor: kprimaryColor,
                            borderColor: kTransparentColor),
                        SizedBox(width: MySpaces.gap3.w),
                        button(
                            onPressed: onReject,
                            /* onPressed: () async {
                              // await widget.communityPendingPostsAndUsersController.rejectJoiningRequest(
                              //     user,
                              //     Provider.of<GroupController>(
                              //       context,
                              //       listen: false,
                              //     ));
                            },*/
                            width: defaultWidth,
                            height: 30.h,
                            title: GayaStrings.decline_txt.tr,
                            primaryColor: kBaseGrey,
                            textStyle: GayaTypography.subtitleMedium,
                            borderColor: kTransparentColor)
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }
}
