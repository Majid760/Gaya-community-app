import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:gaya/model/user.model.dart';
import 'package:gaya/services/notification/notification_api/notification_api.dart';
import 'package:gaya/utils/logger.dart';
import 'package:get/get.dart';

import '../../../../controller/firebase_analytics_controller.dart';
import '../../../../model/user.communities.dart';
import '../../../../services/services.dart';
import '../../../../utils/strings.dart';

class MembershipApprovalServices with PaginationImpl, ApprovalImpl {
  final String communityId;

  MembershipApprovalServices({required this.communityId});

  /// Get posts from the database
  Future<List<UserModel>> requestMoreData() async => await _requestUsers(communityId);

  /// resets pagination
  void reset() => _reset();
}

/// Database Crud operations for approval
abstract class ApprovalImpl {
  final _commonServices = Services.to;
  final _notificationApiHitting = NotificationApiHitting();

  /// Approve user - returns true if successfully approved.
  ///* userId = Receiver (Post Author)
  Future<bool> approveUser({required UserModel user, required String communityId, required String communityName}) async {
    try {
      /// Check if post id is null
      if (user.uId.isBlank == true) {
        throw Exception("userId is null");
      }

      /// Update membership
      await FirebaseFirestore.instance
          .collection("communities")
          .doc(communityId)
          .collection("communityMembers")
          .doc(user.uId!)
          .update({"isMember": true, "isPending": false});

      //add into usercollectiion
      UserCommunitiesModel userCommunities = UserCommunitiesModel(communityName: communityName, communityId: communityId);

      _commonServices.addCommunityToTheAcceptedUsers(userCommunities.toMap(), user.uId!);

      final community = await _commonServices.getCommunityDetailsModel(communityId);
      if (community?.communityId != null) {
        // logging member community joined log
        AnalyticsController.to.instance.logUserAddedToCommunity(communityId: community?.communityId ?? '', userId: user.uId!);

        final fcmJoinedCommunity = FcmCreateCommunityModel(
          communityId: community?.communityId,
          communityName: community?.communityName,
          communityDescription: community!.communityDescription ?? '',
          CommunityPic: community.CommunityPic ?? '',
          coverPicture: community.coverPicture ?? '',
          adminUid: community.adminUid ?? '',
          messageContent: 'Welcome to ${community.communityName}. $entryApplicationApproved2',
          messageTitle: community.communityName ?? "Gaya Community",
          receiverFcm: user.fm_token ?? '',
        );

        await Future.wait([
          _notificationApiHitting.callOnFcmApiForCommunityNotifications(fcmJoinedCommunity),
          _commonServices.addNotification(
              isRead: false,
              communityId: community.communityId,
              message: 'Welcome to ${community.communityName}. $entryApplicationApproved2',
              receiverUserID: user.uId ?? '',
              senderId: UserModel.to.uId ?? "",
              senderName: UserModel.to.name ?? "Gaya User",
              time: DateTime.now().toString(),
              type: "communityJoiningApproved",
              userImage: UserModel.to.profilePicture ?? "")
        ]);
      }

      return true;
    } catch (_) {
      CrashlyticsController.to.instance.recordError(_, reason: 'ApprovalImplementation.approvePost()');
    }
    return false;
  }

  /// Reject user - returns true if successfully rejected.
  /// * userId = Receiver ( Author)
  Future<bool> rejectUser({required UserModel user, required String communityId, required String communityName}) async {
    try {
      /// Check if post id is null
      if (user.uId.isBlank == true) {
        throw Exception("PostId is null");
      }

      if (user.uId != null) {
        /// Send Notification
        await Future.wait(
          [
            FirebaseFirestore.instance.collection("communities").doc(communityId).collection("communityMembers").doc(user.uId!).delete(),
            _notificationApiHitting.callOnFcmApiSendPushNotifications(
                gaya_message: 'Your entry request to $communityName $entryApplicationRejected2', fcmToken: user.fm_token ?? ''),
            _commonServices.addNotification(
                isRead: false,
                // posId: postId,
                message: 'Your entry request to $communityName $entryApplicationRejected2',
                receiverUserID: user.uId ?? '',
                senderId: UserModel.to.uId ?? "",
                senderName: UserModel.to.name ?? "Gaya User",
                time: DateTime.now().toString(),
                type: "communityJoiningRejected",
                userImage: UserModel.to.profilePicture ?? ""),
          ],
        );
      }
      return true;
    } catch (_) {
      CrashlyticsController.to.instance.recordError(_, reason: 'ApprovalImplementation.rejectPost()');
    }
    return false;
  }
}

/// Pagination operations
abstract class PaginationImpl {
  int postLimitSize = 15;
  DocumentSnapshot? _lastDocument;
  bool _hasMorePosts = true;

  void _reset() {
    _lastDocument = null;
    _hasMorePosts = true;
  }

  Future<List<UserModel>> _requestUsers(String communityId) async {
    List<UserModel> newPosts = [];
    try {
      print(communityId);
      var userMembershipSnap = FirebaseFirestore.instance
          .collection("communities")
          .doc(communityId)
          .collection('communityMembers')
          .orderBy('createdOn', descending: true)
          .limit(postLimitSize);

      // #5: If we have a document start the query after it
      if (_lastDocument != null) {
        userMembershipSnap = userMembershipSnap.startAfterDocument(_lastDocument!);
      }

      if (_hasMorePosts == false) {
        return [];
      }

      List<UserModel> posts = [];
      final postsSnapshot = await userMembershipSnap.get();
      MyLoggerServices.to.print("_requestUsers data length: ${postsSnapshot.docs.length}");
      if (postsSnapshot.docs.isNotEmpty) {
        _lastDocument = postsSnapshot.docs.last;
      } else {
        _hasMorePosts = false;
        return _requestUsers(communityId);
      }

      List<UserModel> localPosts = await parse(postsSnapshot);
      for (var element in localPosts) {
        posts.add(element);
      }

      newPosts = posts;
      MyLoggerServices.to.print("_requestUsers length servies d: ${newPosts.length}");

      // #14: Determine if there's more posts to request
      _hasMorePosts = posts.length == postLimitSize;
    } catch (_) {
      CrashlyticsController.to.instance.recordError(_, reason: '_requestUsers._requestPosts()');
    }
    return newPosts;
  }

  Future<List<UserModel>> parse(QuerySnapshot<Map<String, dynamic>> users) async {
    List<UserModel> allUsers = [];
    final members = users.docs;

    if (members.isNotEmpty) {
      List<UserModel?> users = await _getUserInBulk(userIds: members.map((e) => e.id).toList());

      // make map of users for faster access
      Map<String?, UserModel?> usersMap = {};
      Map<String?, DateTime?> memberJoinedMap = {};
      for (var user in users) {
        usersMap[user?.uId] = user;
      }
      for (var member in members) {
        memberJoinedMap[member.id] = member.data()['createdOn']?.toDate();
      }

      /// (O(m + n)) :: n = posts.length, m = users.length
      /// update user in post
      for (var user in usersMap.values) {
        final UserModel? fetchedUser = usersMap[user?.uId];
        if (fetchedUser != null && fetchedUser.uId != null) {
          fetchedUser.createdOn = memberJoinedMap[fetchedUser.uId];
          allUsers.add(fetchedUser);
        }
      }
    }

    allUsers.sort((a, b) => b.createdOn?.compareTo(a.createdOn ?? DateTime(2017)) ?? 0);

    return allUsers;
  }

  final _commonServices = Services.to;

  Future<List<UserModel?>> _getUserInBulk({required List<String?> userIds}) async {
    List<UserModel?> users = [];
    users = await _commonServices.getUserByIdsWithCompound(userIds);
    return users;
  }
}
