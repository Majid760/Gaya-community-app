import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gaya/utils/const.dart';
import 'package:gaya/utils/language/translation.dart';
import 'package:gaya/utils/textstyles.dart';
import 'package:gaya/view/community/create_community/controllers/create_community_controller.dart';
import 'package:get/get.dart';



class CommunityView4 extends StatelessWidget {
  const CommunityView4({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetBuilder<CreateCommunityController>(builder: (controller) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(GayaStrings.community_settings.tr, style: bodyStyle),
          const SizedBox(height: distance_12),
          Text(GayaStrings.setup_community_settings.tr, style: secondaryFontStyleWeight),
          const SizedBox(height: distance_25),
          Text(GayaStrings.community_theme.tr, style: bodyStyle),
          const SizedBox(height: distance_12),
          Text(
            GayaStrings.choose_color_fit_community.tr,
            style: secondaryFontStyleWeight,
          ),
           SizedBox(height: distance_12.r),
          Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            // mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(GayaStrings.post_approval.tr, style: bodyStyle),
                  Switch.adaptive(
                      activeColor: kprimaryColor,
                      value: controller.isPostApprovalNeeded,
                      onChanged: (newValue) async {
                        controller.setPostApprovalStatus(newValue);
                      })
                ],
              ),
              // const SizedBox(height: 8.0),
              Text(
                GayaStrings.post_community_must_approve.tr,
                style: secondaryFontStyleWeight,
                maxLines: 2,
              ),
            ],
          ),
           SizedBox(height: distance_12.r),
          ///entry form widget

          // GayaSwitchButtonListTile(
          //     title: GayaStrings.post_approvals,
          //     subtitle: GayaStrings.post_approval_des_while_create_community,
          //     value: controller.isPostApprovalNeeded,
          //     onChanged: (value) {
          //       controller.setPostApprovalStatus(value);
          //     }),


          /*   ListTile(
            contentPadding: EdgeInsets.zero,
            horizontalTitleGap: 0,
            leading: Checkbox(
              visualDensity: const VisualDensity(horizontal: -4, vertical: -4),
              materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
              checkColor: kWhiteColor,goto
              activeColor: kprimaryColor,
              value: !controller.isCustomThemeSelected,
              onChanged: (isEnabled) async {
                controller.toggleCommunityTheme();
              },
            ),
            title: Container(
              alignment: Alignment.topLeft,
              child: Text("Auto Select (using cover photo colors)", style: body4StyleLowWeight),
            ),
          ),*/
          if (controller.isCustomThemeSelected) ...[
            const SizedBox(height: distance_12),
            Text(GayaStrings.change_theme.tr, style: bodyStyle),
            const SizedBox(height: distance_12),
            SizedBox(
              height: 50,
              width: double.infinity,
              child: ListView.separated(
                separatorBuilder: (context, index) {
                  return Padding(padding: const EdgeInsets.only(right: 8).r);
                },
                itemCount: moderatortagColors.length,
                scrollDirection: Axis.horizontal,
                itemBuilder: (context, index) {
                  Color? retrieveColor = getColorFromHex(moderatortagColors[index]);
                  return GestureDetector(
                    onTap: () {
                      controller.setCommunityThemeModel(moderatortagColors[index]);
                    },
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        SizedBox(
                            height: 60,
                            width: 60,
                            child: CircleAvatar(
                              backgroundColor: retrieveColor ?? kBaseGrey,
                            )),
                        if (controller.communityThemeModel != null && controller.communityThemeModel?.color == moderatortagColors[index])
                          const Positioned(left: 0, right: 0, top: 0, bottom: 0, child: Icon(Icons.check, color: kBlackColor))
                      ],
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: distance_25),
          ],
        ],
      );
    });
  }
}
