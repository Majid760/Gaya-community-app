import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:gaya/model/create.post.model.dart';
import 'package:gaya/model/user.model.dart';
import 'package:gaya/services/services.dart';
import 'package:gaya/utils/logger.dart';

import '../../../controller/app_config_controller.dart';
import '../../../controller/firebase_analytics_controller.dart';

class CommunityFeedServices {
  String communityId;

  CommunityFeedServices({required this.communityId});

  final _commonServices = Services();

  int PostsLimit = kDebugMode ? 5 : 15;
  bool isPublicPosts = false;
  DocumentSnapshot? _lastDocument;
  bool _hasMorePosts = true;

  void reset() {
    _lastDocument = null;
    _hasMorePosts = true;
    isPublicPosts = false;
  }

  final performance = PerformanceController.to.instance;

// #1: Move the request posts into it's own function
  Future<List<Post>> _requestPosts(String? topic) async {
    List<Post> newPosts = [];
    try {
      performance.startCommunitiesViewLoadTime();
      var pagePostsQuery = topic == null
          ? FirebaseFirestore.instance
              .collection('communityposts')
              .where('communityId', isEqualTo: communityId)
              .where('approve', isEqualTo: true)
              .where("isDeleted", isEqualTo: false)
              .orderBy('createdOn', descending: true)
              .limit(PostsLimit)
          : FirebaseFirestore.instance
              .collection('communityposts')
              .where('communityId', isEqualTo: communityId)
              .where('approve', isEqualTo: true)
              .where("isDeleted", isEqualTo: false)
              .where("postTopicList", arrayContains: topic)
              .orderBy('createdOn', descending: true)
              .limit(PostsLimit);
      // #5: If we have a document start the query after it
      if (_lastDocument != null) {
        pagePostsQuery = pagePostsQuery.startAfterDocument(_lastDocument!);
      }

      if (!_hasMorePosts) {
        if (isPublicPosts == false) {
          isPublicPosts = true;
          _hasMorePosts = true;
          _lastDocument = null;
          MyLoggerServices.to.print("public loading");
          performance.stopCommunitiesViewLoadTime();
          _requestPosts(topic);
        }
        MyLoggerServices.to.print("no more posts from PostServices");
        performance.stopCommunitiesViewLoadTime();
        return [];
      }

      List<Post> posts = [];
      final postsSnapshot = await pagePostsQuery.get();
      MyLoggerServices.to.print("postSnapshot data length: ${postsSnapshot.docs.length}");
      if (postsSnapshot.docs.isNotEmpty) {
        _lastDocument = postsSnapshot.docs.last;
      } else {
        _hasMorePosts = true;
      }

      List<Post?> localPosts = [];
      for (var rawPost in postsSnapshot.docs) {
        try {
          final post = Post.fromMap(rawPost.data());
          if (post.postCreatedOn == null) continue;
          if (AppConfigurationController.to.isUserBlockedAlready(userId: post.postedBy.uId ?? "") == false) {
            ///TODO:  get from local cache instead of getting it again and again...
            UserModel? userModel = await _commonServices.getUserById(post.postedBy.uId);
            if (userModel != null) {
              post.postedBy = userModel;
            }
            localPosts.add(post);
          }
        } catch (_) {}
      }

      localPosts.removeWhere((element) => element == null);
      for (var element in localPosts) {
        posts.add(element!);
      }

      newPosts = posts;
      MyLoggerServices.to.print("newPosts length servies: ${newPosts.length}");

      // #14: Determine if there's more posts to request
      _hasMorePosts = posts.length == PostsLimit;
      performance.stopCommunitiesViewLoadTime();
    } catch (_, s) {
      CrashlyticsController.to.instance.recordError(_, stackTrace: s);
      performance.stopCommunitiesViewLoadTime();
    }
    return newPosts;
  }

  // #2: request pinnedPosts
  Future<List<Post>> _requestPinnedPosts(String? topic) async {
    List<Post> newPosts = [];
    try {
      final postsSnapshot = await FirebaseFirestore.instance
          .collection('communityposts')
          .where('communityId', isEqualTo: communityId)
          .where('isPinned', isEqualTo: true)
          .where('approve', isEqualTo: true)
          .where("isDeleted", isEqualTo: false)
          .orderBy('createdOn', descending: true)
          .get();
      for (var rawPost in postsSnapshot.docs) {
        try {
          final post = Post.fromMap(rawPost.data());
          if (post.postCreatedOn == null) continue;
          if (AppConfigurationController.to.isUserBlockedAlready(userId: post.postedBy.uId ?? "") == false) {
            UserModel? userModel = await _commonServices.getUserById(post.postedBy.uId);
            if (userModel != null) {
              post.postedBy = userModel;
            }
            newPosts.add(post);
          }
        } catch (_) {}
      }
      return newPosts;
    } catch (_) {
      return newPosts;
    }
  }

  Future<List<Post>> requestMoreData({String? topic}) async => await _requestPosts(topic);

  Future<List<Post>> requestPinnedPosts({String? topic}) async => await _requestPinnedPosts(topic);
}
