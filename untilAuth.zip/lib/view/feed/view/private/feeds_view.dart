import 'package:easy_refresh/easy_refresh.dart';
import 'package:extended_nested_scroll_view/extended_nested_scroll_view.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gaya/components/skeleton.post.component.dart';
import 'package:gaya/utils/theme/app_colors.dart';
import 'package:gaya/view/feed/controller/for_you_controller.dart';
import 'package:get/get.dart';

import '../../../../utils/const.dart';
import '../../../../utils/refresh_builder_utils.dart';
import '../../../../utils/theme/app_typography.dart';
import '../../components/crown_total_count_widget.dart';
import '../../components/post_tile.dart';
import '../../controller/feeds_view_controller.dart';
import '../../controller/post_controller.dart';

class FeedsView extends StatelessWidget {
  const FeedsView({super.key});

  @override
  Widget build(BuildContext context) {
    final color = Theme.of(context).scaffoldBackgroundColor;
    return GetBuilder<FeedPageViewController>(
      init: Get.find<FeedPageViewController>(),
      builder: (pageController) {
        return ExtendedNestedScrollView(
          controller: pageController.scrollController,
          onlyOneScrollInBody: true,
          headerSliverBuilder: (context, _) {
            return [
              SliverAppBar(
                backgroundColor: color,
                floating: false,
                pinned: false,
                expandedHeight: 95,
                flexibleSpace: FlexibleSpaceBar(
                  background: Column(
                    children: [
                      TabBarWidget(
                        tabController: pageController.tabController,
                        onTabTap: pageController.onTabTap,
                      ),
                      const CrownTotalCountHomeWidget(),
                    ],
                  ),
                ),
              )
            ];
          },
          body: TabBarView(
            controller: pageController.tabController,
            children: const [
              ForYouFeedWidget(),
              OrganicFeedWidget(),
            ],
          ),
        );
      },
    );
  }
}

class OrganicFeedWidget extends StatelessWidget {
  const OrganicFeedWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final header = RefreshBuilderUtils.header;
    final footer = RefreshBuilderUtils.footer;
    final loadingSkeleton = SliverPadding(
      padding: const EdgeInsets.symmetric(horizontal: distance_16).r,
      sliver: SliverToBoxAdapter(
        child: Column(
          children: const [
            PostsSkeleton(isTextOnly: true),
            PostsSkeleton(),
            PostsSkeleton(),
          ],
        ),
      ),
    );
    return GetBuilder<FeedPostsController>(
        init: Get.find<FeedPostsController>(),
        builder: (controller) {
          return EasyRefresh(
            header: header,
            onRefresh: () async => controller.resetController(),
            onLoad: controller.posts.isEmpty
                ? null
                : () async {
                    await controller.requestMoreData();
                    return IndicatorMode.processing;
                  },
            footer: footer,
            child: CustomScrollView(
              slivers: [
                const HeaderLocator.sliver(),
                controller.isLoading
                    ? loadingSkeleton
                    : SliverList(
                        delegate: SliverChildBuilderDelegate((context, index) {
                          return Column(
                            children: [
                              if (index != 0) Container(color: AppColors.divider, height: 6.h),
                              PostTile(postModel: controller.posts[index]),
                            ],
                          );
                        }, childCount: controller.posts.length),
                      ),
                const FooterLocator.sliver(),
              ],
            ),
          );
        });
  }
}

class ForYouFeedWidget extends StatelessWidget {
  const ForYouFeedWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final header = RefreshBuilderUtils.header;
    final footer = RefreshBuilderUtils.footer;
    final loadingSkeleton = SliverPadding(
      padding: const EdgeInsets.symmetric(horizontal: distance_16).r,
      sliver: SliverToBoxAdapter(
        child: Column(
          children: const [
            PostsSkeleton(isTextOnly: true),
            PostsSkeleton(),
            PostsSkeleton(),
          ],
        ),
      ),
    );

    return GetBuilder<ForYouFeedController>(
        init: Get.find<ForYouFeedController>(),
        builder: (controller) {
          return EasyRefresh(
            header: header,
            onRefresh: () async => controller.resetController(),
            onLoad: controller.posts.isEmpty
                ? null
                : () async {
                    await controller.requestMoreData();
                    return IndicatorMode.processing;
                  },
            footer: footer,
            child: CustomScrollView(
              slivers: [
                const HeaderLocator.sliver(),
                controller.isLoading
                    ? loadingSkeleton
                    : SliverList(
                        delegate: SliverChildBuilderDelegate((context, index) {
                          return Column(
                            children: [
                              if (index != 0) Container(color: AppColors.divider, height: 6.h),
                              PostTile(postModel: controller.posts[index]),
                            ],
                          );
                        }, childCount: controller.posts.length),
                      ),
                const FooterLocator.sliver(),
              ],
            ),
          );
        });
  }
}

class TabBarWidget extends StatelessWidget {
  final TabController tabController;
  final Function(int) onTabTap;

  const TabBarWidget({Key? key, required this.tabController, required this.onTabTap}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return TabBar(
        indicatorSize: TabBarIndicatorSize.tab,
        controller: tabController,
        indicatorWeight: 3,
        unselectedLabelColor: kSecondaryColor,
        overlayColor: MaterialStateProperty.all<Color>(kTransparentColor),
        unselectedLabelStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
        indicatorPadding: const EdgeInsets.symmetric(horizontal: 8),
        indicatorColor: kprimaryColor,
        labelPadding: const EdgeInsets.only(bottom: 12),
        labelColor: kBlackColor,
        labelStyle: TextStyle(fontSize: 16.sp, fontWeight: FontWeight.w600, color: kBlackColor),
        // onTap: (index) => onTabTap!(index),

        onTap: onTabTap,
        tabs: [
          Text("Home", style: GayaTypography.titleMedium),
          Text("My Communities", style: GayaTypography.titleMedium),
        ]);
  }
}

/*
// switch between different widgets with animation
class FeedsAnimator extends StatelessWidget {
  final Widget Function() feed1;
  final Widget Function() feed2;
  final int currentIndex;
  final Duration? animationDuration;
  final Widget Function(Widget, Animation)? transitionBuilder;

  const FeedsAnimator({
    Key? key,
    required this.currentIndex,
    required this.feed1,
    required this.feed2,
    this.animationDuration,
    this.transitionBuilder,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return AnimatedSwitcher(
      duration: animationDuration ?? const Duration(milliseconds: 300),
      child: _getChild()(),
      transitionBuilder: transitionBuilder ??
          (child, animation) {
            return FadeTransition(
              opacity: animation,
              child: child,
            );
          },
    );
  }

  _getChild() {
    if (currentIndex == 0) {
      return feed1;
    } else {
      return feed2;
    }
  }
}*/
