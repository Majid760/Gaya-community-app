import 'package:gaya/view/feed/controller/post_controller.dart';
import 'package:get/get.dart';

import '../../../../model/community.model.dart';
import '../../../../model/create.post.model.dart';
import '../../../../model/user.model.dart';
import '../for_you_controller.dart';

class FeedControllerUtils {
  static likePost(String? postId, {UserModel? receiverUser}) {
    if (Get.isRegistered<ForYouFeedController>()) {
      final _forYouFeedController = Get.find<ForYouFeedController>();
      _forYouFeedController.likePost(postId, receiverUser: receiverUser);
    }
    if (Get.isRegistered<FeedPostsController>()) {
      final _homePageController = Get.find<FeedPostsController>();
      _homePageController.likePost(postId, receiverUser: receiverUser);
    }
  }

  static crownPost(String? postId, {UserModel? receiverUser}) {
    if (Get.isRegistered<ForYouFeedController>()) {
      final _forYouFeedController = Get.find<ForYouFeedController>();
      _forYouFeedController.crownPost(postId, receiverUser: receiverUser);
    }
    if (Get.isRegistered<FeedPostsController>()) {
      final _homePageController = Get.find<FeedPostsController>();
      _homePageController.crownPost(postId, receiverUser: receiverUser);
    }
  }

  static updatePostTopics({required Post post}) {
    if (Get.isRegistered<ForYouFeedController>()) {
      final _forYouFeedController = Get.find<ForYouFeedController>();
      _forYouFeedController.updatePostTopics(post: post);
    }
    if (Get.isRegistered<FeedPostsController>()) {
      final _homePageController = Get.find<FeedPostsController>();
      _homePageController.updatePostTopics(post: post);
    }
  }

  static updateAllOfTheCommunitieslocally(Community community) {
    if (Get.isRegistered<ForYouFeedController>()) {
      final _forYouFeedController = Get.find<ForYouFeedController>();
      _forYouFeedController.updateAllOfTheCommunitieslocally(community);
    }
    if (Get.isRegistered<FeedPostsController>()) {
      final _homePageController = Get.find<FeedPostsController>();
      _homePageController.updateAllOfTheCommunitieslocally(community);
    }
  }

  static addAPostLocally(Post post) {
    if (Get.isRegistered<ForYouFeedController>()) {
      final _forYouFeedController = Get.find<ForYouFeedController>();
      _forYouFeedController.addAPostLocally(post);
    }
    if (Get.isRegistered<FeedPostsController>()) {
      final _homePageController = Get.find<FeedPostsController>();
      _homePageController.addAPostLocally(post);
    }
  }

  static updatePostLocally(Post post, {bool shouldDelete = false}) {
    if (Get.isRegistered<ForYouFeedController>()) {
      final _forYouFeedController = Get.find<ForYouFeedController>();
      _forYouFeedController.updatePostLocally(post, shouldDelete: shouldDelete);
    }
    if (Get.isRegistered<FeedPostsController>()) {
      final _homePageController = Get.find<FeedPostsController>();
      _homePageController.updatePostLocally(post, shouldDelete: shouldDelete);
    }
  }

  static onHideCommunity({required String communityId}) {
    if (Get.isRegistered<ForYouFeedController>()) {
      final _forYouFeedController = Get.find<ForYouFeedController>();
      _forYouFeedController.onHideCommunity(communityId: communityId);
    }
    if (Get.isRegistered<FeedPostsController>()) {
      final _homePageController = Get.find<FeedPostsController>();
      _homePageController.onHideCommunity(communityId: communityId);
    }
  }

  static resetController() {
    if (Get.isRegistered<ForYouFeedController>()) {
      final _forYouFeedController = Get.find<ForYouFeedController>();
      _forYouFeedController.resetController();
    }
    if (Get.isRegistered<FeedPostsController>()) {
      final _homePageController = Get.find<FeedPostsController>();
      _homePageController.resetController();
    }
  }

  static requestMoreData({bool fromInit = false, bool isRefresh = false}) {
    if (Get.isRegistered<ForYouFeedController>()) {
      final _forYouFeedController = Get.find<ForYouFeedController>();
      _forYouFeedController.requestMoreData(fromInit: fromInit, isRefresh: isRefresh);
    }
    if (Get.isRegistered<FeedPostsController>()) {
      final _homePageController = Get.find<FeedPostsController>();
      _homePageController.requestMoreData(fromInit: fromInit, isRefresh: isRefresh);
    }
  }
}
