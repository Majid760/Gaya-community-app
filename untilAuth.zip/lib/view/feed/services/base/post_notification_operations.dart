//contains the implementation of the methods for the notificiation services interface
import '../../../../model/user.model.dart';
import '../../../../services/notification/notification_api/notification_api.dart';
import '../../../../services/services.dart';
import '../../../../utils/logger.dart';
import '../../../../utils/strings.dart';

mixin PostNotificationImpl {
  final _commonServices = Services();
  final _notificationApiHitting = NotificationApiHitting();

  NotificationApiHitting get notificationApi => _notificationApiHitting;

  Future<void> sendLikeNotification({required String postId, required UserModel user, required String communityId}) async {
    final myAppUser = UserModel.to;
    //don't send notification if the user is the same.
    if (myAppUser.uId == user.uId) return;

    //send fcm notification
    // await _notificationApiHitting.callOnFcmApiSendPushNotifications(gaya_message: postIsLikedNotification, fcmToken: user.fm_token);

    UserModel? userData = await _commonServices.getUserById(user.uId, forcefullyServer: true);
    if (userData?.uId == null) return;
    final fcmPostModel = FcmCreatePostModel(
      postid: postId,
      communityId: communityId,
      messageContent: "${myAppUser.name} liked your post.",
      messageTitle: postIsLikedNotification,
      receiverFcm: userData?.fm_token ?? '',
    );

    _notificationApiHitting.callOnFcmApiForPostRelatedNotifications(fcmPostModel);

    //add into user's table.
    await _commonServices.addNotification(
        isRead: false,
        posId: postId,
        message: postIsLikedNotification,
        receiverUserID: user.uId!,
        senderId: myAppUser.uId ?? "",
        senderName: myAppUser.name ?? "Gaya User",
        time: DateTime.now().toString(),
        type: "postLiked",
        userImage: myAppUser.profilePicture ?? "");
    MyLoggerServices.to.print("notification sent to ${user.name} for post $postId type: postLiked");
  }

  Future<void> sendFlowerNotification({required String postId, required UserModel user, required String communityId}) async {
    final myAppUser = UserModel.to;
    //don't send notification if the user is the same.
    if (myAppUser.uId == user.uId) return;
    //send fcm notification
    // await _notificationApiHitting.callOnFcmApiSendPushNotifications(gaya_message: flowerGivenNotification, fcmToken: user.fm_token);

    UserModel? userData = await _commonServices.getUserById(user.uId, forcefullyServer: true);
    final fcmPostModel = FcmCreatePostModel(
      postid: postId,
      communityId: communityId,
      messageContent: "${myAppUser.name} flowered on your post.",
      messageTitle: flowerGivenNotification,
      receiverFcm: userData?.fm_token ?? '',
    );

    _notificationApiHitting.callOnFcmApiForPostRelatedNotifications(fcmPostModel
        // gaya_message: "${usermodel.name} sent you a new message.", fcmToken: otherChatParticipantFcmToken
        );

    //add into user's table.
    await _commonServices.addNotification(
        isRead: false,
        posId: postId,
        message: flowerGivenNotification,
        receiverUserID: user.uId!,
        senderId: myAppUser.uId ?? "",
        senderName: myAppUser.name ?? "Gaya User",
        time: DateTime.now().toString(),
        type: "postFlower",
        userImage: myAppUser.profilePicture ?? "");
    MyLoggerServices.to.print("notification sent to ${user.name} for post $postId type: postFlower");
  }
}
