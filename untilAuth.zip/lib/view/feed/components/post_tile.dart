import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gaya/components/profile_image_widget.dart';
import 'package:gaya/utils/language/translation.dart';
import 'package:gaya/widgets/home_view_widgets/home.post.widget.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

import '../../../../components/show.full.picture.dart';
import '../../../controller/app_config_controller.dart';
import '../../../controller/create.post.controller.dart';
import '../../../controller/group.controller.dart';
import '../../../controller/homepage.controller.dart';
import '../../../controller/report_controller.dart';
import '../../../model/community.model.dart';
import '../../../model/create.post.model.dart';
import '../../../model/user.model.dart';
import '../../../routing/getx_route_methods.dart';
import '../../../utils/const.dart';
import '../../../utils/logger.dart';
import '../../../utils/methods.dart';
import '../../../utils/strings.dart';
import '../controller/base/base_feed_impl.dart';

class PostTile extends StatelessWidget {
  final Post postModel;

  const PostTile({Key? key, required this.postModel}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final Post _postModel = postModel;
    final Community _communityModel = postModel.community;

    final UserModel _userModel = postModel.postedBy;
    if (AppConfigurationController.to.isUserBlockedAlready(userId: _userModel.uId ?? "")) {
      return const SizedBox.shrink();
    }

    return HomePostWidget(
      pdfFiles: _postModel.pdfFiles,
      postModel: _postModel,
      anonymousPost: _postModel.isPostedAnonymously,

      onTap: () async {
        final post = await Routes.postDetailsScreen(post: _postModel, community: _communityModel);
        // final post = await Get.to(() => CommentWithPostScreen(postModel: _postModel, userModel: _userModel));
        MyLoggerServices.to.print("Post $post");

        if (post != null && post is Post) {
          FeedControllerUtils.updatePostLocally(post);
        }
      },
      createdAt: _postModel.approvedAt,
      onHideCommunity: () async {
        FeedControllerUtils.onHideCommunity(communityId: _communityModel.communityId ?? "");
      },
      //not in use
      hasVideo: (_postModel.video == null || _postModel.video == '') ? false : true,
      videoLink: _postModel.video,
      postImage: _postModel.multipleImages ?? [],
      crossAxis: _postModel.multipleImages == null
          ? 1
          : _postModel.multipleImages!.length < 2
              ? 1
              : 2,
      onDeleteTap: () async {
        Navigator.pop(context);
        await context.read<GroupController>().deleteYourPost(_postModel.postid!, context);
        FeedControllerUtils.updatePostLocally(_postModel, shouldDelete: true);
      },

      postId: _postModel.postid,
      report: () {
        Navigator.pop(context);
        ReportController.to.reportPost(_postModel.postid ?? "", context, _postModel.community.adminUid,
            communityId: postModel.community.communityId ?? "");
      },

      imageTap: () {
        (_postModel.multipleImages?.isEmpty ?? true)
            ? null
            : Navigator.of(context).push(MaterialPageRoute(
                builder: (context) => PostImages(allImages: _postModel.multipleImages ?? []),
              ));
      },
      doNotshowBottomrow: false,

      totalLikesCount: _postModel.likedBy?.length.toString() ?? "0",
      // totalCrownsCount: _postModel.crownsBy?.length.toString() ?? "0",

      totalCommentsCount: _postModel.totalCommentsCount ?? "0",

      likeIconColor: _postModel.likedBy?.contains(UserModel.to.uId) == true ? kRedColor : kSecondaryColor,
      savePostColor: kSecondaryColor,

      isPostHasImage: _postModel.multipleImages == null
          ? false
          : _postModel.multipleImages!.isEmpty == true
              ? false
              : true,
      //images
      overlapImage: GestureDetector(
        onTap: () {
          if (_postModel.isPostedAnonymously == true) {
          } else {
            Routes.viewProfile(uid: _userModel.uId, model: _userModel);
          }
        },
        child: CircleAvatar(
          backgroundColor: kWhiteColor,
          radius: 17.r,
          child: (_postModel.isPostedAnonymously == true)
              ? CircleAvatar(radius: 17.r, backgroundImage: const AssetImage("Assets/images/anonymous_user.png"))
              : _userModel.profilePicture == ''
                  ? CircleAvatar(radius: 17.r, backgroundImage: const AssetImage('Assets/images/user.png'))
                  : CircleAvatar(
                      radius: 17.r,
                      backgroundColor: kBaseGrey,
                      child: ProfileImageWidget(url: _userModel.profilePicture, size: const Size(100, 100))),
        ),
      ),

      //void call back on flower on tap

      likeOnTap: () => FeedControllerUtils.likePost(postModel.postid, receiverUser: _userModel),

      totalCrownsCount: postModel.crownsBy?.length.toString() ?? "0",
      posterCrownsCount: _userModel.userTotalCrowns?.toString() ?? "0",

      isCrowned: postModel.crownsBy?.contains(UserModel.to.uId) == true ? true : false,
      //void call back on crown on tap
      crownOnTap: () async {
        if (UserModel.to.userDailyCrowns == null &&
                postModel.crownsBy?.contains(UserModel.to.uId) == false &&
                _userModel.uId != UserModel.to.uId ||
            UserModel.to.userDailyCrowns == 0 &&
                postModel.crownsBy?.contains(UserModel.to.uId) == false &&
                _userModel.uId != UserModel.to.uId) {
          Methods.showCrownsTotalModalSheet(ctx: Get.context);
          return;
        }
        if (postModel.crownsBy == null && _userModel.uId != UserModel.to.uId) {
          FeedControllerUtils.crownPost(postModel.postid, receiverUser: postModel.postedBy);
        } else if (postModel.crownsBy!.contains(UserModel.to.uId) || _userModel.uId == UserModel.to.uId) {
        } else {
          FeedControllerUtils.crownPost(postModel.postid, receiverUser: postModel.postedBy);
        }
      },

      commentOntap: () async {
        final post = await Routes.postDetailsScreen(post: _postModel, community: _communityModel);
        MyLoggerServices.to.print("Post $post");
        if (post != null && post is Post) {
          FeedControllerUtils.updatePostLocally(post);
        }
      },
      save: AppConfigurationController.to.savedPostsID.contains(_postModel.postid) == true
          ? GayaStrings.unsave_txt.tr
          : GayaStrings.save_txt.tr,
      onTapSaved: () async {
        if (AppConfigurationController.to.savedPostsID.contains(_postModel.postid) == true) {
          Navigator.pop(context);
          AppConfigurationController.to.savedPostsID.remove(_postModel.postid);

          await context.read<HomePageController>().deleteUserSaveDocFromPostCollection(_postModel.postid!, context);
          await context.read<HomePageController>().deletePostFromUserCollection(_postModel.postid!);
        } else {
          Navigator.pop(context);
          AppConfigurationController.to.savedPostsID.add(_postModel.postid ?? "");
          await context.read<CreatePostController>().savePost(_postModel.postid!);

          await context.read<HomePageController>().setSavePostInUSerCollection(
              {'postId': _postModel.postid, 'communityId': _communityModel.communityId, 'userUid': UserModel.to.uId}, context);
        }
      },

      onUserTap: () async {
        Methods.showModalSheetToJoinCommunity(communityModel: _communityModel, communityId: _communityModel.communityId, ctx: context);
      },
      groupImage: _communityModel.CommunityPic.toString(),
      title: _communityModel.communityName.toString(),
      content: _postModel.postDescription.toString(),

      subtitle: _postModel.isPostedAnonymously == true ? anonymousUser : _userModel.name.toString(),
      approvalShow: false,
      currentUserPost: _postModel.memberId == UserModel.to.uId,

      onManageTopics: () async {
        Methods.showTopicPostUpdateModalSheet(
            community: _postModel.community,
            post: postModel,
            context: context,
            onDoneButtonPressed: (updatedPost) => FeedControllerUtils.updatePostTopics(post: updatedPost));
      },
    );
  }
}
