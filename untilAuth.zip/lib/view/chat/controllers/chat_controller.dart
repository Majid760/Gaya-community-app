import 'dart:async';
import 'dart:io';
import 'package:easy_refresh/easy_refresh.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gaya/components/show.friends.sheet.dart';
import 'package:gaya/model/user.model.dart';
import 'package:gaya/routing/getx_route_methods.dart';
import 'package:gaya/shared/service/media_service/file_picking_service.dart';
import 'package:gaya/shared/view/widget/gaya_snackbar.dart';
import 'package:gaya/utils/helper/helper.functions.dart';
import 'package:gaya/utils/language/translation.dart';
import 'package:gaya/utils/logger.dart';
import 'package:gaya/utils/theme/app_colors.dart';
import 'package:gaya/view/chat/controllers/base_controller.dart';
import 'package:gaya/view/chat/services/connectycube_members_services.dart';
import 'package:gaya/view/chat/utils/api_utils.dart';
import 'package:gaya/view/chat/utils/pref_util.dart';
import 'package:get/get.dart';
import 'package:get/get_rx/src/rx_workers/utils/debouncer.dart';
import 'package:helpers/helpers.dart';
import 'package:image_picker/image_picker.dart';
import 'package:universal_io/io.dart';
import 'package:gaya/view/chat/utils/configs.dart' as config;
import 'package:collection/collection.dart' show IterableExtension;
import 'package:connectycube_sdk/connectycube_sdk.dart';
import 'package:connectycube_sdk/connectycube_sdk.dart' as ConnectyCubeSdk;

class ChatController extends BaseController {
  ChatController();

  static ChatController to() => Get.find();
  static const String tag = "_BodyLayoutState";
  CubeUser? currentUser;
  CubeDialog? currentChat;
  List<ListItem<CubeDialog>> chatsList = [];
  var isChatsLoading = true;

  StreamSubscription<CubeMessage>? msgSubscription;
  ChatMessagesManager? chatMessagesManager = CubeChatConnection.instance.chatMessagesManager;
  List<CubeUser> groupAllMembers = [];

  List<CubeUser> searchedUsersList = [];
  List<CubeUser> selectedCubeUsersList = [];
  Set<int> selectedUsers = {};
  var isUserSearching = false;
  var isPrivateChat = true;
  String? userSearchQuery;
  String userSearchMessage = " ";

  @override
  void onClose() {
    // resetState();
    // setLoading(true);
    msgSubscription?.cancel();
    super.onClose();
  }

  @override
  void onInit() {
    msgSubscription = chatMessagesManager?.chatMessagesStream.listen(onReceiveChatMessage);
    // getAllChatsList();
    super.onInit();
  }

  getAllChatListAndUpdateCurrentUser(CubeUser user) async {
    currentUser = user;
    await getAllChatsList();
    update();
  }

  updateCubeUser(CubeUser user) {
    currentUser = user;
    // showAlertDialog(context, 'updateCubeUser(), user: ${user.login}', user);
    update();
  }

  updateCubeCurrentChat(CubeDialog chat) {
    currentChat = chat;
    update();
  }

  // login to connectycube
  Future<void> loginToCC(BuildContext context, CubeUser user, {bool saveUser = false, dynamic isFromDeepLink}) async {
    if (currentUser != null) return;
    init(config.APP_ID, config.AUTH_KEY, config.AUTH_SECRET);
    try {
      CubeChatConnection.instance.destroy();
    } catch (_) {}
    await createSession(user).then((cubeSession) async {
      var tempUser = user;
      user = cubeSession.user!..password = tempUser.login; //tempUser.password;
      if (saveUser) {
        SharedPrefs.instance.init().then((sharedPrefs) {
          sharedPrefs.saveNewUser(user);
        });
      }
      // showAlertDialog(context, 'createSession, link: $isFromDeepLink', user);
      _loginToCubeChat(context, user, isFromDeepLink);
    }).catchError((error) {});
    // }
  }

  _loginToCubeChat(BuildContext context, CubeUser user, dynamic isFromDeepLink) async {
    try {
      CubeChatConnectionSettings.instance.totalReconnections = 5;
      CubeChatConnection.instance.login(user).then((cubeUser) async {
        await getAllChatListAndUpdateCurrentUser(cubeUser);
      }).catchError((error) {});
    } catch (_) {}
  }

  void onReceiveChatMessage(CubeMessage message) {
    log("onReceiveChatMessage global message= $message");

    updateDialog(message);
  }

  getAllChatsList() {
    getDialogs().then((dialogs) {
      isChatsLoading = false;
      chatsList.clear();
      chatsList.addAll(dialogs!.items.map((dialog) => ListItem(dialog)).toList());
      update();
    }).catchError((exception) {
      log("chatch error on get chat dialogs= $exception");
    });
  }

  clearAllChatList() {
    try {
      currentUser = null;
      currentChat = null;
      chatsList.clear();
    } catch (_) {}
    update();
  }

  updatetextField() {
    update(['textfield']);
  }

  // dummy function to test new groups
  getAllUpdatedChatListIfNeeded() {
    getDialogs().then((dialogs) {
      isChatsLoading = false;
      int preGroups = chatsList.length;
      chatsList.clear();
      chatsList.addAll(dialogs!.items.map((dialog) => ListItem(dialog)).toList());
      int postGroups = chatsList.length;
      MyLoggerServices.to.print('Pre group: lenth is: $preGroups and post groups length is $postGroups');
      if (preGroups != postGroups) {
        update();
      }
      print('$preGroups and $postGroups');
    }).catchError((exception) {
      log("chatch error on get chat dialogs= $exception");
    });
  }

  updateDialog(CubeMessage msg) {
    ListItem<CubeDialog>? dialogItem = chatsList.firstWhereOrNull((dlg) => dlg.data.dialogId == msg.dialogId);
    if (dialogItem == null) return;
    dialogItem.data.lastMessage = msg.body;
    dialogItem.data.lastMessageDateSent = msg.dateSent;
    if (currentChat == null && msg.senderId != currentUser?.id) {
      dialogItem.data.unreadMessageCount = (dialogItem.data.unreadMessageCount == null || dialogItem.data.unreadMessageCount == 0)
          ? 1
          : dialogItem.data.unreadMessageCount! + 1;
    }
    update();
  }

  void refreshChatsList() {
    try {
      isChatsLoading = true;
      update();
      getAllChatsList();
    } catch (_) {
      isChatsLoading = false;
      update();
    }
  }

  searchUsers(value) async {
    if (value != null) {
      userSearchQuery = value;
      isUserSearching = true;
      await getSearchedUsersList();
      update();
    }
  }

  // deleteMessage(CubeMessage message, bool force) {
  //   List<String> ids = [message.messageId ?? ''];
  //   deleteMessages(ids, force).then((deleteItemsResult) {
  //     log("deleteMessages(): successful.");
  //     removeMessageFromListView(message);
  //   }).catchError((error) {
  //     log("deleteMessages(): catchError: $error");
  //   });
  // }

  deleteSingleConversation(String conversationId, bool force) {
    deleteDialog(conversationId, force).then((voidResult) {
      log("deleteSingleConversation(): successful.");
      getAllChatsList();
    }).catchError((error) {
      log("deleteSingleConversation(): catchError: $error");
    });
  }

  // deleteMultipleConversation(Set<String> ids, bool force) {
  //   deleteDialogs(ids, force).then((deleteItemsResult) {
  //     log("deleteSingleConversation(): successful.");
  //     getAllChatsList();
  //   }).catchError((error) {
  //     log("deleteSingleConversation(): catchError: $error");
  //   });
  // }

  Future<void> getSearchedUsersList() async {
    if (userSearchQuery != null && userSearchMessage.isNotEmpty) {
      // requestMoreSearchedUsers(fromInit: true);

      resetSearchedUsersController();

      // getUsersByFullName(userSearchQuery!).then((users) {
      //   log("getusers: $users");
      //   clearSearchValues();
      //   searchedUsersList.addAll(users!.items);
      //   update();
      // }).catchError((onError) {
      //   log("getusers catchError: $onError");
      //   clearSearchValues();
      //   userSearchMessage = "Couldn't find user";
      //   update();
      // });
    }
  }

  final allCubeUsers = [];
  bool isConnectyCubeUsersLoading = true;
  getAllCubeUsersList({bool shouldClearFields = false}) async {
    try {
      if (shouldClearFields) {
        clearSearchValues();
        clearNewGroupSelectedUsersValues();
      }

      requestMoreAllUsers(fromInit: true);
      // PagedResult<CubeUser>? cubeUsers = await getAllUsers();
      /// test code for paginated connectycube users ///
      // Map<String, dynamic> params = {"page": 1, "per_page": 10};
      // Map<String, dynamic> params2 = {"page": 13, "per_page": 100};
      // Map<String, dynamic> params3 = {"page": 14, "per_page": 100};
      // PagedResult<CubeUser>? paginatedUsers = await getAllPaginatedUsers(params);
      // PagedResult<CubeUser>? paginatedUsers2 = await getAllPaginatedUsers(params2);
      // PagedResult<CubeUser>? paginatedUsers3 = await getAllPaginatedUsers(params3);
      // MyLoggerServices.to.print(
      //     'first 10 users are: ${paginatedUsers?.items}, second 100 users are: ${paginatedUsers2?.items} , third 100 users are: ${paginatedUsers3?.items}');
      // List<dynamic> first10Users = [];
      // List<dynamic> next10Users = [];
      // CubeUsers.l
      // first10Users.add
      // MyLoggerServices.to.print('first 10 users are: $first10Users, next 10 users are: $next10Users,');
      /// ended ///////

      // if (cubeUsers != null) {
      //   isConnectyCubeUsersLoading = false;
      //   allCubeUsers.clear();
      //   allCubeUsers.addAll(cubeUsers.items.map<CubeUser>((user) => user).toList());
      //   update();
      // } else {
      //   isConnectyCubeUsersLoading = false;
      //   update();
      // }
    } catch (_) {
      isConnectyCubeUsersLoading = false;
      update();
    }
  }

  addRemoveUsersInNewGroupChatForSearchedUsers(int index) {
    if (isNewGroupChat == false) {
      selectedUsers.clear();
      selectedCubeUsersList.clear();
    }
    if (selectedUsers.contains(searchedUsersList[index].id)) {
      selectedUsers.remove(searchedUsersList[index].id);
      selectedCubeUsersList.removeWhere((element) => element.id == searchedUsersList[index].id);
    } else {
      selectedUsers.add(searchedUsersList[index].id!);
      selectedCubeUsersList.add(searchedUsersList[index]);
    }
    update();
  }

  addRemoveUsersInNewGroupChatForAllUsersList(int index) {
    if (isNewGroupChat == false) {
      selectedUsers.clear();
      selectedCubeUsersList.clear();
    }
    if (selectedUsers.contains(allCubeUsers[index].id)) {
      selectedUsers.remove(allCubeUsers[index].id);
      selectedCubeUsersList.removeWhere((element) => element.id == allCubeUsers[index].id);
    } else {
      selectedUsers.add(allCubeUsers[index].id!);
      selectedCubeUsersList.add(allCubeUsers[index]);
    }
    update();
  }

  bool isUserSelected(CubeUser user) {
    bool isAvailable = selectedCubeUsersList.containsWhere((e) => e.id == user.id);
    return isAvailable;
  }

  removeSelectedUsers(int index, CubeUser user) {
    if (selectedCubeUsersList.isEmpty) return;
    selectedUsers.remove(user.id);
    selectedCubeUsersList.remove(user);
    update();
  }

  clearSearchValues() {
    isUserSearching = false;
    userSearchQuery = null;
    userSearchMessage = " ";
    searchedUsersList.clear();
    groupNameTextField.clear();
    searchUsersTextField.clear();
  }

  clearNewGroupSelectedUsersValues() {
    selectedUsers.clear();
    selectedCubeUsersList.clear();
    isNewGroupChat = false;
    isCreateGroupEditFieldsScreenSelected = false;
  }

  changeNewChatStatus() {
    isPrivateChat = !isPrivateChat;
    selectedUsers.clear();
    update();
  }

  addRemoveUsersInNewGroupChat(int index) {
    if (selectedUsers.contains(searchedUsersList[index].id)) {
      selectedUsers.remove(searchedUsersList[index].id);
    } else {
      selectedUsers.add(searchedUsersList[index].id!);
    }
    update();
  }

  void createNewChat(BuildContext context, Set<int> users, bool isGroup) async {
    if (isGroup) {
      if (users.length < 2) return;
      CubeDialog newDialog = CubeDialog(CubeDialogType.GROUP, occupantsIds: users.toList());
      List<CubeUser> usersToAdd = users.map((id) => searchedUsersList.firstWhere((user) => user.id == id)).toList();
      if (currentUser != null) {
        selectedGroupUsers = usersToAdd;
        updateCubeCurrentChat(newDialog);
        Get.toNamed(
          RouteHelper.newGroup,
        );
      }
    } else {
      CubeDialog newDialog = CubeDialog(CubeDialogType.PRIVATE, occupantsIds: users.toList());
      createDialog(newDialog).then((createdDialog) {
        if (currentUser != null) {
          updateCubeCurrentChat(createdDialog);
          Get.offAndToNamed(
            RouteHelper.conversation,
          )?.then((value) => refreshChatsList());
        }
      }).catchError((error) {
        log("catch error on create new chat dialogs= $error");
      });
    }
  }

  /////////////////////////// Create and Edit Group Chat Methods below /////////////////////////

  List<CubeUser?>? selectedGroupUsers;
  TextEditingController groupNameTextField = TextEditingController();
  Uint8List? selectedGroupImage;
  bool isNewGroupChat = false;
  bool isCreateGroupEditFieldsScreenSelected = false;

  void disposeOfCreateNewGroupScreen() {
    groupNameTextField.clear();
    selectedGroupImage = null;
    selectedGroupUsers = [];
  }

  createNewGroupChat(BuildContext context) {
    if (groupNameTextField.text.isEmpty || groupNameTextField.text.length < 5) {
      // const GayaSnackBar(type: GayaSnackBarType.error, text: 'Enter more tha 4 characters group name');
      Get.showSnackbar(
        GetSnackBar(
          message: GayaStrings.for_char_group_name.tr, //'Enter more tha 4 characters group name.',
          duration: const Duration(seconds: 3),
          backgroundColor: AppColors.error,
          dismissDirection: DismissDirection.horizontal,
          margin: EdgeInsets.symmetric(horizontal: 20.w, vertical: 16.h),
        ),
      );
    } else {
      if (currentChat != null) {
        currentChat?.name = groupNameTextField.text.trim();
        createDialog(currentChat!).then((createdDialog) {
          createdDialog.occupantsIds?.removeWhere((element) => element == currentUser?.id);
          updateCubeCurrentChat(createdDialog);
          searchedUsersList.clear();
          selectedUsers.clear();
          selectedCubeUsersList.clear();
          searchUsersTextField.clear();
          Routes.openConversationAndRemoveCreateGroupChat(createdDialog);
          refreshChatsList();
        }).catchError((exception) {
          Get.showSnackbar(
            GetSnackBar(
              message: GayaStrings.upto_ten_user_group.tr, //'You can only add upto 10 users for a group chat.',
              duration: const Duration(seconds: 3),
              backgroundColor: AppColors.error,
              dismissDirection: DismissDirection.horizontal,
              margin: EdgeInsets.symmetric(horizontal: 20.w, vertical: 16.h),
            ),
          );
        });
      } else {
        Get.showSnackbar(
          GetSnackBar(
            message: GayaStrings.failed_create_group.tr, //'Failed to create new group.',
            duration: const Duration(seconds: 3),
            backgroundColor: AppColors.error,
            dismissDirection: DismissDirection.horizontal,
            margin: EdgeInsets.symmetric(horizontal: 20.w, vertical: 16.h),
          ),
        );
      }
    }
  }

  pickAndUploadNewGroupImage() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(
      type: FileType.image,
    );

    if (result == null) return;

    var image;

    if (kIsWeb) {
      image = result.files.single.bytes;
    } else {
      image = File(result.files.single.path!).readAsBytesSync();
    }

    var uploadImageFuture = getUploadingImageFuture(result);

    uploadImageFuture.then((cubeFile) {
      selectedGroupImage = image;
      var url = cubeFile.getPublicUrl();
      log("_createDialogImage url= $url");
      currentChat?.photo = url;
      update();
    }).catchError((exception) {
      const GayaSnackBar(type: GayaSnackBarType.error, text: 'Failed to upload new group profile image.');
    });
  }

  toggleIsNewGroupChat({bool shouldNotify = true, bool? customValue}) {
    isNewGroupChat = (customValue != null) ? customValue : !isNewGroupChat;
    if (shouldNotify) update();
  }

  void createNewConversation(BuildContext context, Set<int> users, bool isGroup) async {
    if (isGroup) {
      if (users.isEmpty) return;
      CubeDialog newDialog = CubeDialog(CubeDialogType.PUBLIC, occupantsIds: users.toList());
      List<CubeUser> usersToAdd = users.map((id) => selectedCubeUsersList.firstWhere((user) => user.id == id)).toList();
      if (currentUser != null) {
        selectedGroupUsers = [];
        selectedGroupUsers = usersToAdd;
        isCreateGroupEditFieldsScreenSelected = true;
        updateCubeCurrentChat(newDialog);
        // Get.toNamed(
        //   RouteHelper.newGroup,
        // );
      }
    } else {
      CubeDialog newDialog = CubeDialog(CubeDialogType.PRIVATE, occupantsIds: users.toList());
      createDialog(newDialog).then((createdDialog) {
        if (currentUser != null) {
          updateCubeCurrentChat(createdDialog);
          clearSearchValues();
          String previousRoute = Get.previousRoute;
          String currentRoute = Get.currentRoute;

          if (previousRoute == RouteHelper.switchView) {
            Get.toNamed(
              RouteHelper.conversation,
              arguments: {"dialog": createdDialog},
            )?.then((value) => ChatController.to().refreshChatsList());
          } else if (currentRoute == RouteHelper.switchView) {
            Get.toNamed(
              RouteHelper.conversation,
              arguments: {"dialog": createdDialog},
            )?.then((value) => ChatController.to().refreshChatsList());
          } else {
            Get.offAndToNamed(
              RouteHelper.conversation,
              arguments: {"dialog": createdDialog},
            )?.then((value) => refreshChatsList());
          }
        }
      }).catchError((error) {
        log("catch error on create new chat dialogs= $error");
      });
    }
  }

  goBackFromCreateGroupFieldsViewAndClearFields() {
    groupNameTextField.clear();
    searchUsersTextField.clear();
    selectedGroupImage = null;
    isCreateGroupEditFieldsScreenSelected = false;
    resetAllUsersController(isDisposing: false);
    update();
  }

// //////////////////////////////////////////// Paginated users and dialogs methods //////////////////////////////////
  TextEditingController searchUsersTextField = TextEditingController();
  ConnectyCubeMembersServices? _connectyCubeMembersServices;
  EasyRefreshController refreshController = EasyRefreshController();
  bool isFirstTimeGetAllUsers = false;
  final Debouncer _debouncer = Debouncer(delay: 1000.milliseconds);
  EasyRefreshController searchRefreshController = EasyRefreshController();
  EasyRefreshController groupChatMembersRefreshController = EasyRefreshController();
  bool isFirstTimeGetSearchedUsers = false;

  initializeCommunityMembersServices() {
    _connectyCubeMembersServices = ConnectyCubeMembersServices(currentUser: currentUser);
  }

  Future<void> requestMoreAllUsers({bool fromInit = false}) async {
    if (currentUser == null) return;
    // _communityMembersServices = CommunityMembersServices(communityId: createCommunityModel?.communityId ?? '');
    // to avoid double loading at top andbottom on screen
    if (fromInit == false) refreshController.callLoad();
    MyLoggerServices.to.print(" requestMoreData called");
    if (fromInit) {
      isConnectyCubeUsersLoading = true;
      // update();
    }
    isFirstTimeGetAllUsers = true;
    final newUsers = await _connectyCubeMembersServices!.requestAllUsersMoreData();
    MyLoggerServices.to.print("newMembers.length ${newUsers.length}");
    allCubeUsers.addAll(newUsers);
    isConnectyCubeUsersLoading = false;
    update();
  }

  // A dispose method.
  void resetAllUsersController({bool isDisposing = false}) async {
    allCubeUsers.clear();
    isFirstTimeGetAllUsers = false;

    isConnectyCubeUsersLoading = false;
    clearSearchValues();
    // clearNewGroupSelectedUsersValues();
    if (_connectyCubeMembersServices != null) {
      _connectyCubeMembersServices?.resetAllUsers();
    }
    if (isDisposing) {
      // WidgetsBinding.instance.addPostFrameCallback((_) {
      //   update();
      // });
    } else {
      await requestMoreAllUsers(
        fromInit: true,
      );
    }
    _debouncer.cancel();
  }

  // search connectycube users.
  Future<void> requestMoreSearchedUsers({bool fromInit = false}) async {
    if (currentUser == null || userSearchQuery == null) return;
    // _communityMembersServices = CommunityMembersServices(communityId: createCommunityModel?.communityId ?? '');
    // to avoid double loading at top andbottom on screen
    if (fromInit == false) searchRefreshController.callLoad();
    MyLoggerServices.to.print(" requestMoreData called");
    if (fromInit) {
      isConnectyCubeUsersLoading = true;
      // update();
    }
    isFirstTimeGetSearchedUsers = true;
    final newUsers = await _connectyCubeMembersServices!.requestSearchedUsersMoreData(query: userSearchQuery);
    MyLoggerServices.to.print("newMembers.length ${newUsers.length}");
    // searchedUsersList.addAll(newUsers);

    final usersList = newUsers.map<CubeUser>((user) {
      return user as CubeUser;
    }).toList();
    searchedUsersList.addAll(usersList);
    isConnectyCubeUsersLoading = false;
    update();
  }

//   // A dispose method for searched users.
  void resetSearchedUsersController({bool isDisposing = false}) async {
    searchedUsersList.clear();
    isFirstTimeGetSearchedUsers = false;
    log("searchedUsersList length is: ${searchedUsersList.length}");
    isConnectyCubeUsersLoading = false;
    // clearSearchValues();
    // clearNewGroupSelectedUsersValues();
    if (_connectyCubeMembersServices != null) {
      _connectyCubeMembersServices?.resetSearchedUsers();
    } else {
      initializeCommunityMembersServices();
    }
    if (isDisposing) {
      // WidgetsBinding.instance.addPostFrameCallback((_) {
      //   update();
      // });
    } else {
      await requestMoreSearchedUsers(
        fromInit: true,
      );
    }
    _debouncer.cancel();
  }

  Future<void> requestMoreGroupAllUsers({bool fromInit = false}) async {
    if (currentUser == null) return;
    // _communityMembersServices = CommunityMembersServices(communityId: createCommunityModel?.communityId ?? '');
    // to avoid double loading at top andbottom on screen
    if (fromInit == false) groupChatMembersRefreshController.callLoad();
    MyLoggerServices.to.print(" requestMoreData called");
    if (fromInit) {
      isConnectyCubeUsersLoading = true;
      // update();
    }
    isFirstTimeGetAllUsers = true;
    final newUsers = await _connectyCubeMembersServices!.requestGroupAllUsersMoreData();
    MyLoggerServices.to.print("newMembers.length ${newUsers.length}");
    groupAllMembers.addAll(newUsers);
    isConnectyCubeUsersLoading = false;
    update();
  }

  // A dispose method.
  void resetGroupAllUsersController({bool isDisposing = false}) async {
    groupAllMembers.clear();
    isFirstTimeGetAllUsers = false;
    log("allCubeUsers length is: ${groupAllMembers.length}");

    isConnectyCubeUsersLoading = false;
    clearSearchValues();
    // clearNewGroupSelectedUsersValues();
    if (_connectyCubeMembersServices != null) {
      _connectyCubeMembersServices?.resetGroupAllUsers();
    }
    if (isDisposing) {
      // WidgetsBinding.instance.addPostFrameCallback((_) {
      //   update();
      // });
    } else {
      await requestMoreGroupAllUsers(
        fromInit: true,
      );
    }
    _debouncer.cancel();
  }

// ////////////////////////////////////////////  Paginated users and dialogs ended  //////////////////////////////////
  HelperFunc helperFunc = HelperFunc();

  final MediaService _mediaService = MediaService();
  bool isImageUploading = false;

  Future<void> pickImageFromGallery({required BuildContext context, int imageQuality = 50}) async {
    try {
      isImageUploading = true;
      update();
      XFile? files = await _mediaService.pickImageFromPhotos(context: context, imageQuality: imageQuality);
      if (files != null) {
        File convertedFile = File(files.path);
        var uploadImageFuture = getUploadingImageFutureAsCubeFile(convertedFile);
        uploadImageFuture.then((cubeFile) {
          var url = cubeFile.getPublicUrl();
          log("_createDialogImage url= $url");
          currentChat?.photo = url;
          isImageUploading = false;
          update();
        }).catchError((exception) {
          GayaSnackBar(
            type: GayaSnackBarType.error,
            text: GayaStrings.failed_upload_group_profile.tr,
          );
          isImageUploading = false;
          update();
        });
      } else {
        isImageUploading = false;
        update();
      }
    } on PlatformException catch (e) {
      log(e.toString());
      isImageUploading = false;
      update();
    } catch (e) {
      log(e.toString());
      isImageUploading = false;
      update();
    }
  }

  // // by mak => picking image from camera with proper permission handling etc
  Future<void> pickImageFromCamera({required BuildContext context, int imageQuality = 50}) async {
    try {
      isImageUploading = true;
      update();
      XFile? file = await _mediaService.pickImageFromCamera(context: context, imageQuality: imageQuality);
      if (file != null && file.path.isNotEmpty) {
        File convertedFile = File(file.path);
        var uploadImageFuture = getUploadingImageFutureAsCubeFile(convertedFile);
        uploadImageFuture.then((cubeFile) {
          var url = cubeFile.getPublicUrl();
          log("_createDialogImage url= $url");
          currentChat?.photo = url;
          isImageUploading = false;
          update();
        }).catchError((exception) {
          GayaSnackBar(
            type: GayaSnackBarType.error,
            text: GayaStrings.failed_upload_group_profile.tr,
          );
          isImageUploading = false;
          update();
        });
      } else {
        isImageUploading = false;
        update();
      }
    } on PlatformException catch (e) {
      log(e.toString());
      isImageUploading = false;
      update();
    } catch (e) {
      log(e.toString());
      isImageUploading = false;
      update();
    }
  }

  List<UserModel> onlineFriendsList = [];
  bool isLoadingOnlineFriend = false;
  void getOnlineFriends(BuildContext context) async {
    // onlineFriendsList = [];
    // return;
    try {
      isLoadingOnlineFriend = true;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        update(['onlineFriendsList']);
      });
      final snapshot = await getUserFriends(context: context);
      if (snapshot == null || snapshot.docs.isEmpty == true) {
        isLoadingOnlineFriend = false;
        onlineFriendsList = [];
        WidgetsBinding.instance.addPostFrameCallback((_) {
          update(['onlineFriendsList']);
        });
      } else {
        snapshot.docs.forEach((user) {
          onlineFriendsList.add(UserModel.fromMap(user.data() as Map<String, dynamic>));
        });
        isLoadingOnlineFriend = false;
        WidgetsBinding.instance.addPostFrameCallback((_) {
          update(['onlineFriendsList']);
        });
      }
    } catch (_) {
      isLoadingOnlineFriend = false;
      onlineFriendsList = [];
      WidgetsBinding.instance.addPostFrameCallback((_) {
        update(['onlineFriendsList']);
      });
    }
  }
}





/*
  /////////////////////////// Single Conversation Methods below /////////////////////////

  // final Map<int?, CubeUser?> occupants = {};
  // bool isLoading = false;
  // late StreamSubscription<ConnectivityResult> connectivityStateSubscription;
  // String? imageUrl;
  // List<CubeMessage> chatMessagesList = [];
  // Timer? typingTimer;
  // bool isTyping = false;
  // String userStatus = '';
  // // ignore: constant_identifier_names
  // static const int TYPING_TIMEOUT = 700;
  // // ignore: constant_identifier_names
  // static const int STOP_TYPING_TIMEOUT = 2000;

  // int sendIsTypingTime = DateTime.now().millisecondsSinceEpoch;
  // Timer? sendStopTypingTimer;

  // final TextEditingController messageTextField = TextEditingController();
  // final ScrollController listScrollController = ScrollController();

  // StreamSubscription<CubeMessage>? messageSubscription;
  // StreamSubscription<MessageStatus>? deliveredSubscription;
  // StreamSubscription<MessageStatus>? readSubscription;
  // StreamSubscription<TypingStatus>? typingSubscription;
  // StreamSubscription<MessageStatus>? deleteSubscription;

  // List<CubeMessage> unreadMessages = [];
  // List<CubeMessage> unsentMessages = [];

  // static const int messagesPerPage = 50;
  // int lastPartSize = 0;

  // List<CubeMessage> oldMessages = [];

  // void conversationScreenInit() {
  //   // reLoginChatUser();
  //   initCubeChat();
  //   isLoading = false;
  //   imageUrl = '';
  //   listScrollController.addListener(onScrollChanged);
  //   connectivityStateSubscription = Connectivity().onConnectivityChanged.listen(onConnectivityChanged);
  // }

  // void conversationScreenDispose() {
  //   messageSubscription?.cancel();
  //   deliveredSubscription?.cancel();
  //   readSubscription?.cancel();
  //   typingSubscription?.cancel();
  //   deleteSubscription?.cancel();
  //   try {
  //     messageTextField.clear();
  //   } catch (_) {}
  //   connectivityStateSubscription.cancel();
  //   currentChat = null;
  //   chatMessagesList.clear();
  // }

  // reLoginChatUser() {
  //   String? userId = FirebaseAuth.instance.currentUser?.uid;
  //   CubeUser user = CubeUser(login: userId, password: userId);
  //   CubeChatConnectionSettings.instance.totalReconnections = 5;
  //   CubeUser? oldUser = CubeChatConnection.instance.currentUser;
  //   if (oldUser != null && oldUser.login == user.login) {
  //     ChatController.to().getAllChatListAndUpdateCurrentUser(oldUser);
  //   } else {
  //     CubeChatConnection.instance.login(user).then((cubeUser) async {
  //       await ChatController.to().getAllChatListAndUpdateCurrentUser(cubeUser);
  //       // PushNotificationsManager.instance.init();
  //       crashlytics.instance.recordError('Success',
  //           reason: "connectycube login successfully after session:  cubeUserId: ${cubeUser.id}, password:${cubeUser.fullName}");
  //     }).catchError((error) {
  //       crashlytics.instance.recordError(error,
  //           reason: "connectycube login error after session:$error,  cubeUserId: ${user.id}, password:${user.password}");
  //     });
  //   }
  // }

  // initChatListeners() {
  //   log("[_initChatListeners]");
  //   messageSubscription = CubeChatConnection.instance.chatMessagesManager!.chatMessagesStream.listen(onReceiveMessage);
  //   deliveredSubscription = CubeChatConnection.instance.messagesStatusesManager!.deliveredStream.listen(onDeliveredMessage);
  //   readSubscription = CubeChatConnection.instance.messagesStatusesManager!.readStream.listen(onReadMessage);
  //   typingSubscription = CubeChatConnection.instance.typingStatusesManager!.isTypingStream.listen(onTypingMessage);
  //   deleteSubscription = CubeChatConnection.instance.messagesStatusesManager!.deletedStream.listen(onDeleteMessage);
  // }

  // void initCubeChat() {
  //   log("_initCubeChat");
  //   bool isValid = CubeChatConnection.instance.isAuthenticated();
  //   if (isValid) {
  //     log("[_initCubeChat] isAuthenticated");
  //     initChatListeners();
  //   } else {
  //     log("[_initCubeChat] not authenticated");
  //     CubeChatConnection.instance.connectionStateStream.listen((state) {
  //       log("[_initCubeChat] state $state");
  //       if (CubeChatConnectionState.Ready == state) {
  //         initChatListeners();
  //         if (unreadMessages.isNotEmpty) {
  //           for (var cubeMessage in unreadMessages) {
  //             currentChat?.readMessage(cubeMessage);
  //           }
  //           unreadMessages.clear();
  //         }
  //         if (unsentMessages.isNotEmpty) {
  //           for (var cubeMessage in unsentMessages) {
  //             currentChat?.sendMessage(cubeMessage);
  //           }
  //           unsentMessages.clear();
  //         }
  //       }
  //     });
  //   }
  // }

  // final crashlytics = CrashlyticsController.to;

  // void openGallery() async {
  //   FilePickerResult? result = await FilePicker.platform.pickFiles(
  //     type: FileType.image,
  //   );

  //   if (result == null) return;

  //   isLoading = true;
  //   update();

  //   var uploadImageFuture = getUploadingImageFuture(result);
  //   var imageData;

  //   if (kIsWeb) {
  //     imageData = result.files.single.bytes!;
  //   } else {
  //     imageData = File(result.files.single.path!).readAsBytesSync();
  //   }

  //   var decodedImage = await decodeImageFromList(imageData);

  //   uploadImageFile(uploadImageFuture, decodedImage);
  // }

  // Future uploadImageFile(Future<CubeFile> uploadAction, imageData) async {
  //   uploadAction.then((cubeFile) {
  //     onSendChatAttachment(cubeFile, imageData);
  //   }).catchError((ex) {
  //     isLoading = false;
  //     update();

  //     Fluttertoast.showToast(msg: 'This file is not an image');
  //   });
  // }

  // void onReceiveMessage(CubeMessage message) {
  //   log("onReceiveMessage message= $message");
  //   if (message.dialogId != currentChat?.dialogId || message.senderId == currentUser?.id) return;

  //   addMessageToListView(message);
  // }

  // void onDeliveredMessage(MessageStatus status) {
  //   log("onDeliveredMessage message= $status");
  //   updateReadDeliveredStatusMessage(status, false);
  // }

  // void onDeleteMessage(MessageStatus status) {
  //   log("onDeliveredMessage message= $status");
  //   updateDeletedMessagesList(status);
  // }

  // void onReadMessage(MessageStatus status) {
  //   log("onReadMessage message= ${status.messageId}");
  //   updateReadDeliveredStatusMessage(status, true);
  // }

  // void onTypingMessage(TypingStatus status) {
  //   log("TypingStatus message= ${status.userId}");
  //   if (status.userId == currentUser?.id || (status.dialogId != null && status.dialogId != currentChat?.dialogId)) return;
  //   userStatus = occupants[status.userId]?.fullName ?? occupants[status.userId]?.login ?? '';
  //   if (userStatus.isEmpty) return;
  //   userStatus = "$userStatus is typing ...";

  //   if (isTyping != true) {
  //     isTyping = true;
  //     update();
  //   }
  //   startTypingTimer();
  // }

  // startTypingTimer() {
  //   typingTimer?.cancel();
  //   typingTimer = Timer(const Duration(milliseconds: 900), () {
  //     isTyping = false;
  //     update();
  //   });
  // }

  // void onSendChatAttachment(CubeFile cubeFile, imageData) async {
  //   final attachment = CubeAttachment();
  //   attachment.id = cubeFile.uid;
  //   attachment.type = CubeAttachmentType.IMAGE_TYPE;
  //   attachment.url = cubeFile.getPublicUrl();
  //   attachment.height = imageData.height;
  //   attachment.width = imageData.width;
  //   final message = createCubeMsg();
  //   message.body = "Attachment";
  //   message.attachments = [attachment];
  //   message.properties["metaData"] = "woopsi";
  //   onSendMessage(message);
  // }

  // CubeMessage createCubeMsg() {
  //   var message = CubeMessage();
  //   message.dateSent = DateTime.now().millisecondsSinceEpoch ~/ 1000;
  //   message.markable = true;
  //   message.saveToHistory = true;
  //   return message;
  // }

  // void onSendMessage(CubeMessage message) async {
  //   log("onSendMessage message= $message");

  //   messageTextField.clear();
  //   await currentChat?.sendMessage(message);
  //   message.senderId = currentUser?.id;

  //   addMessageToListView(message);
  //   listScrollController.animateTo(0.0, duration: const Duration(milliseconds: 300), curve: Curves.easeOut);
  // }

  // updateReadDeliveredStatusMessage(MessageStatus status, bool isRead) {
  //   log('[updateReadDeliveredStatusMessage]');
  //   CubeMessage? msg = chatMessagesList.firstWhereOrNull((msg) => msg.messageId == status.messageId);
  //   if (msg == null) return;
  //   if (isRead) {
  //     msg.readIds == null ? msg.readIds = [status.userId] : msg.readIds?.add(status.userId);
  //   } else {
  //     msg.deliveredIds == null ? msg.deliveredIds = [status.userId] : msg.deliveredIds?.add(status.userId);
  //   }

  //   log('[updateReadDeliveredStatusMessage] status updated for $msg');
  //   update();
  // }

  // updateDeletedMessagesList(MessageStatus status) {
  //   log('[updateReadDeliveredStatusMessage]');
  //   CubeMessage? msg = chatMessagesList.firstWhereOrNull((msg) => msg.messageId == status.messageId);
  //   if (msg == null) return;
  //   removeMessageFromListView(msg);
  //   log('[updateReadDeliveredStatusMessage] status updated for $msg');
  //   // update();
  // }

  // addMessageToListView(CubeMessage message) {
  //   try {
  //     isLoading = false;
  //     // isMessageUploading = false;
  //     int existMessageIndex = chatMessagesList.indexWhere((cubeMessage) {
  //       return cubeMessage.messageId == message.messageId;
  //     });

  //     if (existMessageIndex != -1) {
  //       chatMessagesList[existMessageIndex] = message;
  //     } else {
  //       chatMessagesList.insert(0, message);
  //     }
  //   } catch (_) {
  //   } finally {
  //     update();
  //   }
  // }

  // removeMessageFromListView(CubeMessage message) {
  //   isLoading = false;
  //   int existMessageIndex = chatMessagesList.indexWhere((cubeMessage) {
  //     return cubeMessage.messageId == message.messageId;
  //   });

  //   if (existMessageIndex != -1) {
  //     // chatMessagesList[existMessageIndex] = message;
  //     chatMessagesList.removeAt(existMessageIndex);
  //   } else {
  //     // chatMessagesList.insert(0, message);
  //   }
  //   update();
  // }

  // void onScrollChanged() {
  //   if ((listScrollController.position.pixels == listScrollController.position.maxScrollExtent) && messagesPerPage >= lastPartSize) {
  //     isLoading = true;

  //     if (oldMessages.isNotEmpty) {
  //       getMessagesBetweenDates(
  //               oldMessages.first.dateSent ?? 0, chatMessagesList.last.dateSent ?? DateTime.now().millisecondsSinceEpoch ~/ 1000)
  //           .then((newMessages) {
  //         isLoading = false;

  //         chatMessagesList.addAll(newMessages);

  //         if (newMessages.length < messagesPerPage) {
  //           oldMessages.insertAll(0, chatMessagesList);
  //           chatMessagesList = List.from(oldMessages);
  //           oldMessages.clear();
  //         }
  //         update();
  //       });
  //     } else {
  //       getMessagesByDate(chatMessagesList.last.dateSent ?? 0, false).then((messages) {
  //         isLoading = false;
  //         chatMessagesList.addAll(messages);
  //         update();
  //       });
  //     }
  //     update();
  //   }
  // }

  // void onConnectivityChanged(ConnectivityResult connectivityType) {
  //   log("[ConversationScreenBodyState] connectivityType changed to '$connectivityType'");

  //   if (connectivityType == ConnectivityResult.wifi || connectivityType == ConnectivityResult.mobile) {
  //     isLoading = true;
  //     update();

  //     getMessagesBetweenDates(chatMessagesList.first.dateSent ?? 0, DateTime.now().millisecondsSinceEpoch ~/ 1000).then((newMessages) {
  //       if (newMessages.length == messagesPerPage) {
  //         oldMessages = List.from(chatMessagesList);
  //         chatMessagesList = newMessages;
  //       } else {
  //         chatMessagesList.insertAll(0, newMessages);
  //       }
  //       update();
  //     }).whenComplete(() {
  //       isLoading = false;
  //       update();
  //     });
  //   }
  // }

  // Future<List<CubeMessage>> getMessagesByDate(int date, bool isLoadNew) async {
  //   var params = GetMessagesParameters();
  //   params.sorter = RequestSorter(SORT_DESC, '', 'date_sent');
  //   params.limit = messagesPerPage;
  //   params.filters = [RequestFilter('', 'date_sent', isLoadNew || date == 0 ? 'gt' : 'lt', date)];

  //   return getMessages(currentChat?.dialogId ?? '', params.getRequestParameters())
  //       .then((result) {
  //         lastPartSize = result!.items.length;

  //         return result.items;
  //       })
  //       .whenComplete(() {})
  //       .catchError((onError) {});
  // }

  // Future<List<CubeMessage>> getMessagesBetweenDates(int startDate, int endDate) async {
  //   var params = GetMessagesParameters();
  //   params.sorter = RequestSorter(SORT_DESC, '', 'date_sent');
  //   params.limit = messagesPerPage;
  //   params.filters = [RequestFilter('', 'date_sent', 'gt', startDate), RequestFilter('', 'date_sent', 'lt', endDate)];

  //   return getMessages(currentChat?.dialogId ?? '', params.getRequestParameters()).then((result) {
  //     return result!.items;
  //   });
  // }

  // void sendIsTypingStatus() {
  //   var currentTime = DateTime.now().millisecondsSinceEpoch;
  //   var isTypingTimeout = currentTime - sendIsTypingTime;
  //   if (isTypingTimeout >= TYPING_TIMEOUT) {
  //     sendIsTypingTime = currentTime;
  //     currentChat?.sendIsTypingStatus();
  //     _startStopTypingStatus();
  //   }
  // }

  // void _startStopTypingStatus() {
  //   sendStopTypingTimer?.cancel();
  //   sendStopTypingTimer = Timer(const Duration(milliseconds: STOP_TYPING_TIMEOUT), () {
  //     currentChat?.sendStopTypingStatus();
  //   });
  // }

  ////////////////////////////////////// Ended ///////////////////////////////////////
  
    //////////////////////////////// Single contact and group detail or setting screen methods below ///////////////////////

  // Map<int, CubeUser> chatDetailScreenOccupants = {};
  // var isChatDetailScreenLoading = false;
  // CubeUser? otherContactParticipiant;
  // String? groupPhotoUrl = "";
  // Set<int?> userstoRemoveFromGroup = {};
  // List<int>? usersToAddInGroup;
  // String userLastActivityTime = 'Not Available';

  // void initOfChatDetailInfoScreen() {
  //   getGroupOccupants();
  // }

  // void disposeOfChatDetailInfoScreen() {
  //   chatDetailScreenOccupants = {};
  //   isChatDetailScreenLoading = false;
  //   otherContactParticipiant = null;
  //   groupNameTextField.clear();
  //   groupPhotoUrl = '';
  //   usersToAddInGroup = null;
  //   userstoRemoveFromGroup.clear();
  // }

  // clearGroupChatDetailFieldsOnly() {
  //   groupNameTextField.clear();
  //   groupPhotoUrl = '';
  //   usersToAddInGroup = null;
  //   userstoRemoveFromGroup.clear();
  // }

  // initializeOtherContactOfContactChat() async {
  //   isChatDetailScreenLoading = true;
  //   WidgetsBinding.instance.addPostFrameCallback((_) {
  //     update();
  //   });
  //   var result = await getUsersByIds(currentChat!.occupantsIds!.toSet());
  //   chatDetailScreenOccupants.clear();
  //   chatDetailScreenOccupants.addAll(result);
  //   chatDetailScreenOccupants.remove(currentUser?.id);
  //   otherContactParticipiant =
  //       chatDetailScreenOccupants.values.isNotEmpty ? chatDetailScreenOccupants.values.first : CubeUser(fullName: "Absent");
  //   // if (otherContactParticipiant != null) {
  //   //   CubeChatConnection.instance.lastActivityManager?.subscribeToUserLastActivityStatus(otherContactParticipiant?.id ?? 0,
  //   //       callback: (seconds) {
  //   //     log("lastActivityEvent: userId = ${otherContactParticipiant?.id}, seconds = ${seconds}");
  //   //   });
  //   //   // CubeChatConnection.instance.getLasUserActivity(otherContactParticipiant?.id ?? 0).then((seconds) {
  //   //   //   userLastActivityTime = Jiffy(seconds).fromNow().toString();
  //   //   // }).catchError((error) {});
  //   // }
  //   isChatDetailScreenLoading = false;
  //   WidgetsBinding.instance.addPostFrameCallback((_) {
  //     update();
  //   });
  // }

  // getGroupOccupants() async {
  //   isChatDetailScreenLoading = true;
  //   try {
  //     if (currentChat!.type == CubeDialogType.GROUP) {
  //       if (currentChat?.occupantsIds == null || currentChat!.occupantsIds!.isEmpty) {
  //         isChatDetailScreenLoading = false;
  //         WidgetsBinding.instance.addPostFrameCallback((_) {
  //           update();
  //         });
  //         return;
  //       }

  //       var result = await getUsersByIds(currentChat!.occupantsIds!.toSet());
  //       chatDetailScreenOccupants.clear();
  //       chatDetailScreenOccupants.addAll(result);
  //       chatDetailScreenOccupants.remove(currentUser?.id);
  //       isChatDetailScreenLoading = false;
  //       WidgetsBinding.instance.addPostFrameCallback((_) {
  //         update();
  //       });
  //     } else if (currentChat!.type == CubeDialogType.PUBLIC) {
  //       if (currentChat == null) {
  //         isChatDetailScreenLoading = false;
  //         WidgetsBinding.instance.addPostFrameCallback((_) {
  //           update();
  //         });
  //         return;
  //       }
  //       await getDialogOccupants(currentChat!.dialogId ?? '').then((pagedResult) {
  //         if (pagedResult != null && pagedResult.items.isNotEmpty) {
  //           chatDetailScreenOccupants.clear();
  //           // for(int i =0 ; i< pagedResult.items.length; i++){
  //           //   chatDetailScreenOccupants.ad
  //           // }
  //           Map<int, CubeUser> map = {for (var item in pagedResult.items) item.id ?? 1: item};
  //           MyLoggerServices.to.print('pagedResult users map is: $map');
  //           chatDetailScreenOccupants.addAll(map);
  //           chatDetailScreenOccupants.remove(currentUser?.id);
  //           isChatDetailScreenLoading = false;
  //           // WidgetsBinding.instance.addPostFrameCallback((_) {
  //           update();
  //           // });
  //         }
  //       }).catchError((error) {
  //         isChatDetailScreenLoading = false;
  //         WidgetsBinding.instance.addPostFrameCallback((_) {
  //           update();
  //         });
  //       });
  //     }
  //   } catch (_) {
  //     isChatDetailScreenLoading = false;
  //     WidgetsBinding.instance.addPostFrameCallback((_) {
  //       update();
  //     });
  //   } finally {
  //     isChatDetailScreenLoading = false;
  //   }
  // }

  // changeGroupProfile() async {
  //   FilePickerResult? result = await FilePicker.platform.pickFiles(
  //     type: FileType.image,
  //   );

  //   if (result == null) return;
  //   isChatDetailScreenLoading = true;
  //   update();
  //   var uploadImageFuture = getUploadingImageFuture(result);
  //   uploadImageFuture.then((cubeFile) {
  //     groupPhotoUrl = cubeFile.getPublicUrl();
  //     currentChat?.photo = groupPhotoUrl;
  //     isChatDetailScreenLoading = false;
  //     update();
  //   }).catchError((error) {
  //     isChatDetailScreenLoading = false;
  //     update();
  //     log("changeGroupProfile(): catchError url= $error");
  //   });
  // }

  // navigateToaddOpponentsToGroupScreen(context) async {
  //   if (currentUser != null) {
  //     Get.toNamed(RouteHelper.addOponentsToGroup)?.then((users) {
  //       if (users != null && users!.isNotEmpty) {
  //         usersToAddInGroup = users;
  //         updateGroupOpponentsOnly();
  //       }
  //     });
  //   } else {}
  // }

  // navigateToSearchGroupMembersScreen(context) async {
  //   if (currentUser != null) {
  //     Get.toNamed(RouteHelper.searchGroupMembers)?.then((users) {
  //       if (users != null && users!.isNotEmpty) {
  //         usersToAddInGroup = users;
  //         updateGroupOpponentsOnly();
  //       }
  //     });
  //   } else {}
  // }

  // removeOpponentFromGroup() async {
  //   if (userstoRemoveFromGroup.isNotEmpty) updateGroupDetails();
  // }

  // void updateGroupDetails() {
  //   if (currentChat == null) {
  //     return;
  //   }
  //   if (groupNameTextField.text.isEmpty &&
  //       groupPhotoUrl!.isEmpty &&
  //       (usersToAddInGroup?.isEmpty ?? true) &&
  //       (userstoRemoveFromGroup.isEmpty)) {
  //     Fluttertoast.showToast(msg: 'Nothing to save');
  //     return;
  //   }
  //   Map<String, dynamic> params = {};
  //   if (groupNameTextField.text.isNotEmpty) params['name'] = groupNameTextField.text;
  //   if (groupPhotoUrl!.isNotEmpty) params['photo'] = groupPhotoUrl;
  //   if (usersToAddInGroup?.isNotEmpty ?? false) {
  //     params['push_all'] = {'occupants_ids': List.of(usersToAddInGroup!)};
  //   }
  //   if (userstoRemoveFromGroup.isNotEmpty) {
  //     params['pull_all'] = {'occupants_ids': List.of(userstoRemoveFromGroup)};
  //   }

  //   isChatDetailScreenLoading = true;
  //   update();
  //   ConnectyCubeSdk.updateDialog(currentChat!.dialogId!, params).then((dialog) {
  //     currentChat = dialog;
  //     Fluttertoast.showToast(msg: 'Success');

  //     if ((usersToAddInGroup?.isNotEmpty ?? false) || (userstoRemoveFromGroup.isNotEmpty)) {
  //       getGroupOccupants();
  //     }
  //     isChatDetailScreenLoading = false;
  //     clearGroupChatDetailFieldsOnly();
  //     update();
  //   }).catchError((error) {
  //     log("updateGroupDetails(): catchError url= $error");
  //   });
  // }

  // // update group opponents
  // void updateGroupOpponentsOnly() {
  //   try {
  //     if (currentChat == null) {
  //       return;
  //     }
  //     if ((usersToAddInGroup?.isEmpty ?? true) && (userstoRemoveFromGroup.isEmpty)) {
  //       Fluttertoast.showToast(msg: 'Nothing to save');
  //       return;
  //     }
  //     Map<String, dynamic> params = {};
  //     if (usersToAddInGroup?.isNotEmpty ?? false) {
  //       List<int> userIds = [];

  //       if (usersToAddInGroup!.length < 9 || usersToAddInGroup!.length == 9) {
  //         for (int i = 0; i < usersToAddInGroup!.length; i++) {
  //           userIds.add(usersToAddInGroup![i]);
  //         }
  //       } else {
  //         for (int i = 0; i < 9; i++) {
  //           userIds.add(usersToAddInGroup![i]);
  //         }
  //       }
  //       params['push_all'] = {'occupants_ids': List.of(usersToAddInGroup!)};
  //     }

  //     isChatDetailScreenLoading = true;
  //     WidgetsBinding.instance.addPostFrameCallback((_) {
  //       update();
  //     });
  //     ConnectyCubeSdk.updateDialog(currentChat!.dialogId!, params).then((dialog) {
  //       currentChat = dialog;
  //       Fluttertoast.showToast(msg: 'Success');

  //       if ((usersToAddInGroup?.isNotEmpty ?? false) || (userstoRemoveFromGroup.isNotEmpty)) {
  //         getGroupOccupants();
  //       }
  //       isChatDetailScreenLoading = false;
  //       clearGroupChatDetailFieldsOnly();
  //       usersToAddInGroup?.clear();
  //       WidgetsBinding.instance.addPostFrameCallback((_) {
  //         update();
  //       });
  //     }).catchError((error) {
  //       isChatDetailScreenLoading = false;
  //       clearGroupChatDetailFieldsOnly();
  //       usersToAddInGroup?.clear();
  //       WidgetsBinding.instance.addPostFrameCallback((_) {
  //         update();
  //       });
  //       Get.showSnackbar(
  //         GetSnackBar(
  //           message: 'Private group users are limited to only 10 users.',
  //           duration: const Duration(seconds: 3),
  //           backgroundColor: AppColors.error,
  //           dismissDirection: DismissDirection.horizontal,
  //           margin: EdgeInsets.symmetric(horizontal: 20.w, vertical: 16.h),
  //         ),
  //       );
  //     });
  //   } catch (_) {
  //     isChatDetailScreenLoading = false;
  //     clearGroupChatDetailFieldsOnly();
  //     usersToAddInGroup?.clear();
  //     WidgetsBinding.instance.addPostFrameCallback((_) {
  //       update();
  //     });
  //   }
  // }

  // exitGroup(context) {
  //   if (currentChat != null) {
  //     deleteDialog(currentChat!.dialogId!).then((onValue) {
  //       Fluttertoast.showToast(msg: 'Exit Successful.');
  //       // Navigator.pushReplacementNamed(context, 'select_dialog', arguments: {USER_ARG_NAME: currentUser});
  //       Routes.openAllChatsScreenAndRemoveGroupsviewAfterExit();
  //       getAllChatsList();
  //     }).catchError((error) {
  //       log("exitGroup(): error $error");
  //       disposeOfChatDetailInfoScreen();
  //       isChatDetailScreenLoading = false;
  //       update();
  //     });
  //   } else {
  //     print('Error ===================>exitGroup(): chatController.currentChat == null');
  //   }
  // }

  // toggleGroupOpponents(int index, bool toggle) {
  //   if (toggle) {
  //     userstoRemoveFromGroup.add(chatDetailScreenOccupants.values.elementAt(index).id);
  //   } else {
  //     userstoRemoveFromGroup.remove(chatDetailScreenOccupants.values.elementAt(index).id);
  //   }
  //   update();
  // }

  // // by mak => this function takes the image from gallery with permissin etc
  // final MediaService _mediaService = MediaService();
  bool isImageUploading = false;

  // Future<void> pickImageFromGallery({required BuildContext context, int imageQuality = 50}) async {
  //   try {
  //     isImageUploading = true;
  //     update();
  //     XFile? files = await _mediaService.pickImageFromPhotos(context: context, imageQuality: imageQuality);
  //     if (files != null) {
  //       File convertedFile = File(files.path);
  //       var uploadImageFuture = getUploadingImageFutureAsCubeFile(convertedFile);
  //       uploadImageFuture.then((cubeFile) {
  //         var url = cubeFile.getPublicUrl();
  //         log("_createDialogImage url= $url");
  //         currentChat?.photo = url;
  //         isImageUploading = false;
  //         update();
  //       }).catchError((exception) {
  //         const GayaSnackBar(type: GayaSnackBarType.error, text: 'Failed to upload new group profile image.');
  //         isImageUploading = false;
  //         update();
  //       });
  //     } else {
  //       isImageUploading = false;
  //       update();
  //     }
  //   } on PlatformException catch (e) {
  //     log(e.toString());
  //     isImageUploading = false;
  //     update();
  //   } catch (e) {
  //     log(e.toString());
  //     isImageUploading = false;
  //     update();
  //   }
  // }

  // // by mak => picking image from camera with proper permission handling etc
  // Future<void> pickImageFromCamera({required BuildContext context, int imageQuality = 50}) async {
  //   try {
  //     isImageUploading = true;
  //     update();
  //     XFile? file = await _mediaService.pickImageFromCamera(context: context, imageQuality: imageQuality);
  //     if (file != null && file.path.isNotEmpty) {
  //       File convertedFile = File(file.path);
  //       var uploadImageFuture = getUploadingImageFutureAsCubeFile(convertedFile);
  //       uploadImageFuture.then((cubeFile) {
  //         var url = cubeFile.getPublicUrl();
  //         log("_createDialogImage url= $url");
  //         currentChat?.photo = url;
  //         isImageUploading = false;
  //         update();
  //       }).catchError((exception) {
  //         const GayaSnackBar(type: GayaSnackBarType.error, text: 'Failed to upload new group profile image.');
  //         isImageUploading = false;
  //         update();
  //       });
  //     } else {
  //       isImageUploading = false;
  //       update();
  //     }
  //   } on PlatformException catch (e) {
  //     log(e.toString());
  //     isImageUploading = false;
  //     update();
  //   } catch (e) {
  //     log(e.toString());
  //     isImageUploading = false;
  //     update();
  //   }
  // }


////////////////////////////////////////////  Ubaid new chat UI methods below  //////////////////////////////////

  // // TextEditingController messagetextfieldController = TextEditingController();
  // TextEditingController documentTextField = TextEditingController();
  // List<File> pdfFiles = [];
  // Uint8List? pdfThumbnail;
  // bool isPdf = false;
  // // done by mak
  // bool isVideo = false;
  // File? messageImage;

  // // bool _isLoading = false;
  // // bool get isLoading => _isLoading;
  // bool documentUploadStatus = false;

  // String writtenMessage = '';
  // String? message;

  // // void setLoading(bool value, {bool notify = true}) {
  // //   _isLoading = value;
  // //   if (notify) update();
  // // }

  // Future cameraImage() async {
  //   try {
  //     clearNewMessagefields();

  //     XFile? imagePick = await ImagePicker().pickImage(source: ImageSource.camera, imageQuality: 50);

  //     if (imagePick != null) {
  //       File convertedFile = File(imagePick.path);
  //       messageImage = convertedFile;

  //       update();
  //       return messageImage;
  //       // uploadMessageImage(chatroom);
  //     } else {
  //       return;
  //     }
  //   } on PlatformException catch (e) {
  //     log(e.toString());
  //   }
  // }

  // Future pickGalleryImage({required BuildContext context, int imageQuality = 50}) async {
  //   try {
  //     clearNewMessagefields();
  //     XFile? galleryImage = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 50);

  //     if (galleryImage != null) {
  //       File convertedFile = File(galleryImage.path);
  //       messageImage = convertedFile;

  //       update();
  //       return messageImage;
  //       // uploadMessageImage(chatroom);
  //     } else {
  //       return;
  //     }
  //   } on PlatformException catch (e) {
  //     log(e.toString());
  //   }
  // }

  // // by mak => picking video from gallerey with proper permission handling etc
  // Future pickVideo({required BuildContext context, int imageQuality = 50}) async {
  //   try {
  //     clearNewMessagefields();

  //     isVideo = true;
  //     XFile? file = await _mediaService.pickVideoFromGallery(context: context);
  //     if (file != null) {
  //       messageImage = File(file.path);
  //       messageImage = await Routes.cropVideoView(video: messageImage!);
  //       update();
  //       return messageImage;
  //     }
  //   } on PlatformException catch (e) {
  //     log(e.toString());
  //   } catch (e) {
  //     log(e.toString());
  //   }
  // }

  // //GET THE Document FROM STORAGE
  // Future getPdfDocument(BuildContext context) async {
  //   try {
  //     clearNewMessagefields();

  //     messageTextField.clear();
  //     pdfFiles = [];
  //     messageImage = null;

  //     isPdf = true;
  //     final File? document = await _mediaService.pickFile(context: context);
  //     if (document != null) {
  //       pdfFiles.add(document);
  //     } else {
  //       MyLoggerServices.to.print('No Document picked');
  //     }
  //     update();
  //   } catch (e) {
  //     debugPrint('error during document picking!: ${e.toString()}');
  //   }
  // }

  // // Future<void> generateLocalPdfThumbnail({required String url}) async {
  // //   CacheServices cacheService = CacheServices();
  // //   pdfThumbnail = await cacheService.generatelocalPdfThumbnail(url: url);
  // //   setLoading(false);
  // // }
  // Future<void> generateLocalPdfThumbnail({required String url}) async {
  //   CacheServices cacheService = CacheServices();
  //   pdfThumbnail = await cacheService.generatelocalPdfThumbnail(url: url);
  //   update(['textfield']);
  // }

  // Future<File?> generateThumbnailFile({required String url}) async {
  //   CacheServices cacheService = CacheServices();
  //   return await cacheService.generateThumbnailFile(url: url);
  // }

  // Future<String> downloadAndCachePdf({required String url}) async {
  //   CacheServices cacheService = CacheServices();

  //   return await cacheService.downloadAndCachePdf(url: url);
  // }

  // updateDocumentUploadStatus() {
  //   documentUploadStatus = true;
  //   update();
  // }

  // void removeSelectedPdf() {
  //   try {
  //     documentTextField.clear();
  //     messageImage = null;
  //     pdfFiles = [];
  //     pdfThumbnail = null;
  //     isPdf = false;

  //     update();
  //   } catch (e) {
  //     log(e.toString());
  //   }
  // }

  // // uploadMessage(String message, bool isMe) {
  // //   messagetextfieldController.clear();
  // //   update();
  // // }

  // onChanged(value) {
  //   writtenMessage = value;
  //   update();
  // }

  // final CommentsServices service = CommentsServices();

  // sendMessage(BuildContext context, {File? audioFile}) async {
  //   try {
  //     if (messageImage != null || pdfFiles.isNotEmpty || audioFile != null) {
  //       MyLoggerServices.to.print('===> (messageImage != null || pdfFiles.isNotEmpty)');
  //       if (audioFile != null) {
  //         var cubeFile = getUploadingImageFutureAsCubeFile(audioFile);
  //         cubeFile.then((cubeFile) {
  //           sendAttachmentMessage(
  //             cubeFile,
  //             null,
  //             'audio',
  //           );
  //         }).catchError((ex) {
  //           Fluttertoast.showToast(msg: 'This file is not an image');
  //         });

  //         MyLoggerServices.to.print('===> (messageImage != null && !isVideo)');
  //       } else if (messageImage != null && !isVideo) {
  //         var cubeFile = getUploadingImageFutureAsCubeFile(messageImage!);
  //         var decodedImage = await decodeImageFromList(messageImage!.readAsBytesSync());
  //         cubeFile.then((cubeFile) {
  //           sendAttachmentMessage(
  //             cubeFile,
  //             decodedImage,
  //             'image',
  //           );
  //         }).catchError((ex) {
  //           Fluttertoast.showToast(msg: 'This file is not an image');
  //         });
  //         MyLoggerServices.to.print('===> (messageImage != null && !isVideo)');
  //       } else if (messageImage != null && isVideo) {
  //         var cubeFile = getUploadingImageFutureAsCubeFile(messageImage!);

  //         cubeFile.then((cubeFile) {
  //           sendAttachmentMessage(
  //             cubeFile,
  //             null,
  //             'video',
  //           );
  //         }).catchError((ex) {
  //           Fluttertoast.showToast(msg: 'This file is not an image');
  //         });
  //         MyLoggerServices.to.print('===> (messageImage != null && isVideo)');
  //       } else if (isPdf && pdfFiles.isNotEmpty) {
  //         File pdfFile = pdfFiles.first;
  //         var cubeFile = getUploadingImageFutureAsCubeFile(pdfFile);
  //         // var urrrl = await cubeFile.getPublicUrl();
  //         File? thumbnailFile = await generateThumbnailFile(url: pdfFile.path);

  //         cubeFile.then((cubeFile) {
  //           sendAttachmentMessage(cubeFile, null, 'document',
  //               attachmentData:
  //                   documentTextField.text.isNotEmpty ? documentTextField.text.trim() : pdfFile.path.split("/").last.split('-').last,
  //               documentThumbnail: thumbnailFile);
  //         }).catchError((ex) {
  //           Fluttertoast.showToast(msg: 'This file is not an image');
  //           isLoading = false;
  //           update();
  //         });
  //         MyLoggerServices.to.print('===> (isPdf && pdfFiles.isNotEmpty)');
  //       } else {
  //         MyLoggerServices.to.print('===> else');
  //       }
  //     } else if (messageTextField.text.isNotEmpty) {
  //       MyLoggerServices.to.print('===> (messageImage != null || pdfFiles.isNotEmpty)');
  //       onSendChatMessage(messageTextField.text.trim());
  //     }
  //     isLoading = true;
  //     // isMessageUploading = true;
  //     clearNewMessagefields();
  //     update();
  //   } catch (_) {
  //     isLoading = false;
  //     // isMessageUploading = true;
  //     clearNewMessagefields();
  //     update();
  //   }
  // }

  // bool isMessageUploading = false;

  // HelperFunc helperFunc = HelperFunc();

  // void createNewChatAndSendMessage(BuildContext context, Set<int> users, String type, {String attachmentData = ''}) {
  //   try {
  //     CubeDialog newDialog = CubeDialog(CubeDialogType.PRIVATE, occupantsIds: users.toList());
  //     createDialog(newDialog).then((createdDialog) {
  //       sendMessageFromOutsideOfChatModule(context, createdDialog, type, attachmentData: attachmentData);
  //     }).catchError((error) {
  //       log("catch error on create new chat dialogs= $error");
  //     });
  //   } catch (_) {
  //     log("catch error on create new chat dialogs= $_");
  //   }
  // }

  // sendMessageFromOutsideOfChatModule(context, CubeDialog newChat, String type, {String attachmentData = ''}) async {
  //   try {
  //     final attachment = CubeAttachment();
  //     final message = createCubeMsg();
  //     if (type == 'community') {
  //       MyLoggerServices.to.print('===> type == "community"');
  //       attachment.type = null;
  //       attachment.url = null;
  //       attachment.name = 'community';
  //       attachment.data = attachmentData;
  //       message.body = "Attachment";
  //       message.attachments = [attachment];
  //     } else if (type == 'post') {
  //       MyLoggerServices.to.print('===> type == "post"');
  //       attachment.type = null;
  //       attachment.url = null;
  //       attachment.name = 'post';
  //       attachment.data = attachmentData;
  //       message.body = "Attachment";
  //       message.attachments = [attachment];
  //     } else if (type == 'link') {
  //       MyLoggerServices.to.print('===> type == "link"');
  //       attachment.type = null;
  //       attachment.url = null;
  //       attachment.name = 'link';
  //       attachment.data = attachmentData;
  //       message.body = "Attachment";
  //       message.attachments = [attachment];
  //     } else {
  //       MyLoggerServices.to.print('=====================================> No Type Matched');
  //     }
  //     final newMessage = await newChat.sendMessage(message);
  //     print(newMessage);
  //   } catch (_) {
  //     print(_);
  //   }
  // }

  // void sendAttachmentMessage(CubeFile cubeFile, imageData, String type, {String attachmentData = '', File? documentThumbnail}) async {
  //   try {
  //     // clearNewMessagefields();
  //     // update();
  //     final attachment = CubeAttachment();
  //     attachment.id = cubeFile.uid;
  //     final message = createCubeMsg();

  //     if (type == 'image') {
  //       MyLoggerServices.to.print('===> type == "image"');
  //       attachment.type = CubeAttachmentType.IMAGE_TYPE;
  //       attachment.url = cubeFile.getPublicUrl();
  //       attachment.height = imageData.height;
  //       attachment.width = imageData.width;
  //       message.body = "Attachment";
  //       message.attachments = [attachment];
  //     } else if (type == 'video') {
  //       MyLoggerServices.to.print('===> type == "video"');

  //       attachment.type = CubeAttachmentType.VIDEO_TYPE;
  //       String? url = cubeFile.getPublicUrl();
  //       attachment.url = url;

  //       /// once media is uploaded, update the comment with real url
  //       var thumbnailFile = await service.getThumbnailFromVideoUrl(videoUrl: url ?? '');
  //       if (thumbnailFile != null) {
  //         var thumbnail = await getUploadingImageFutureAsCubeFile(thumbnailFile);
  //         String? thumbnailUrl = thumbnail.getPublicUrl();
  //         attachment.data = thumbnailUrl;
  //       }

  //       message.body = "Attachment";
  //       message.attachments = [attachment];
  //     } else if (type == 'audio') {
  //       MyLoggerServices.to.print('===> type == "audio"');
  //       attachment.type = CubeAttachmentType.AUDIO_TYPE;
  //       attachment.url = cubeFile.getPublicUrl();
  //       message.body = "Attachment";

  //       message.attachments = [attachment];
  //     } else if (type == 'document') {
  //       MyLoggerServices.to.print('===> type == "document"');
  //       attachment.type = null;
  //       attachment.url = cubeFile.getPublicUrl();
  //       attachment.name = 'document';
  //       if (documentThumbnail != null) {
  //         var thumbnail = await getUploadingImageFutureAsCubeFile(documentThumbnail);
  //         String? thumbnailUrl = thumbnail.getPublicUrl();
  //         attachment.data = thumbnailUrl;
  //       }
  //       message.body = "Attachment";
  //       message.attachments = [attachment];
  //     } else if (type == 'community') {
  //       MyLoggerServices.to.print('===> type == "community"');
  //       attachment.type = null;
  //       attachment.url = null;
  //       attachment.name = 'community';
  //       attachment.data = attachmentData;
  //       message.body = "Attachment";
  //       message.attachments = [attachment];
  //     } else if (type == 'post') {
  //       MyLoggerServices.to.print('===> type == "post"');
  //       attachment.type = null;
  //       attachment.url = null;
  //       attachment.name = 'post';
  //       attachment.data = attachmentData;
  //       message.body = "Attachment";
  //       message.attachments = [attachment];
  //     } else {
  //       MyLoggerServices.to.print('=====================================> No Type Matched');
  //     }

  //     onSendMessage(message);
  //   } catch (_) {
  //     MyLoggerServices.to.print('===> $_');
  //   }
  // }

  // void sendAttchmentMessageWithoutCubeFile(String type, {String attachmentData = ''}) {
  //   try {
  //     final attachment = CubeAttachment();
  //     final message = createCubeMsg();
  //     if (type == 'community') {
  //       MyLoggerServices.to.print('===> type == "community"');
  //       attachment.type = null;
  //       attachment.url = null;
  //       attachment.name = 'community';
  //       attachment.data = attachmentData;
  //       message.body = "Attachment";
  //       message.attachments = [attachment];
  //     } else if (type == 'post') {
  //       MyLoggerServices.to.print('===> type == "post"');
  //       attachment.type = null;
  //       attachment.url = null;
  //       attachment.name = 'post';
  //       attachment.data = attachmentData;
  //       message.body = "Attachment";
  //       message.attachments = [attachment];
  //     } else {
  //       MyLoggerServices.to.print('=====================================> No Type Matched');
  //     }
  //     onSendMessage(message);
  //   } catch (_) {}
  // }

  // void onSendChatMessage(String content) {
  //   if (content.trim() != '') {
  //     final message = createCubeMsg();
  //     message.body = content.trim();
  //     onSendMessage(message);
  //   } else {
  //     Fluttertoast.showToast(msg: 'Nothing to send');
  //   }
  // }

  // removeNewImage() {
  //   if (messageImage == null) return;
  //   messageImage = null;
  //   update();
  // }

  // clearNewMessagefields() {
  //   messageImage = null;
  //   try {
  //     messageTextField.clear();
  //     documentTextField.clear();
  //   } catch (_) {}

  //   isVideo = false;
  //   pdfFiles = [];
  //   pdfThumbnail = null;
  //   isPdf = false;
  // }
////////////////////////////////////////////  Ubaid new chat UI methods ended  //////////////////////////////////


// //// Sharing group chat methods ///

//   generateGroupChatSharableLink(context) async {
//     try {
//       if (currentChat == null) {
//         Fluttertoast.showToast(msg: 'Failed to generate shareable link');
//         return;
//       }
//       String queryParam = "";
//       GayaSocialTag? tag;
//       late DynamicLinkType type;

//       queryParam = queryParams;
//       tag = DynamicLinkUtils.generateTagGroupChat(userName: currentUser?.fullName, groupChatModel: currentChat);
//       type = DynamicLinkType.groupChat;

//       /// Engagement Score
//       // EngagementScoreController.to.instance.onShare(postId: post.postid);
//       final shareAbleLink = await GayaSharedController.to.createAShareableLink(queryParam: queryParam, tag: tag, type: type);
//       if (shareAbleLink != null) await Share.share(shareAbleLink);
//       AnalyticsController.to.instance.logShare(shareAbleLink ?? "", currentChat?.id == null ? "" : currentChat!.id.toString(), "Chat");
//     } catch (_) {
//       Fluttertoast.showToast(msg: 'Failed to generate shareable link');
//     }
//   }

//   String get queryParams =>
//       "?${QueryParamConst.id}=${currentChat?.dialogId}&${QueryParamConst.type}=$type&${QueryParamConst.isPrivate}=$isChatPrivate";

//   String get type => DynamicLinkType.groupChat.name;
//   bool get isChatPrivate => currentChat?.type == CubeDialogType.PRIVATE;



*/
