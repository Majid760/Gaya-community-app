import 'package:connectycube_sdk/connectycube_sdk.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gaya/utils/const.dart';
import 'package:gaya/utils/methods.dart';
import 'package:gaya/utils/textstyles.dart';
import 'package:gaya/view/chat/components/select_link_widget.dart';
import 'package:gaya/view/chat/helper/helper_functions.dart' as Helper;
import 'package:get/get_utils/get_utils.dart';
import 'package:gaya/view/chat/utils/consts.dart' as UtilColors;

class TextlinkWidget extends StatelessWidget {
  TextlinkWidget(
      {super.key,
      required this.isLink,
      this.userAvatar,
      required this.text,
      required this.currentMessage,
      required this.mySelf,
      required this.sentTime,
      required this.deliveryStatus});
  final bool isLink;
  final String text;
  final CubeMessage currentMessage;
  final bool mySelf;
  final Widget? userAvatar;
  String sentTime = '';
  String deliveryStatus = '';

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: mySelf ? MainAxisAlignment.end : MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (!mySelf) userAvatar ?? const SizedBox.shrink(),
        const SizedBox(width: 10),
        currentMessage.body!.length > 30
            ? Expanded(
                child: Container(
                  alignment: mySelf ? Alignment.centerRight : Alignment.centerLeft,
                  // padding: const EdgeInsets.symmetric(horizontal: distance_20, vertical: distance_10),
                  padding: const EdgeInsets.symmetric(horizontal: distance_12, vertical: distance_8),
                  decoration: BoxDecoration(
                      color: Helper.checkMessageType(currentMessage) == Helper.MessageType.post ||
                              (Helper.checkMessageType(currentMessage) == Helper.MessageType.community)
                          ? kTransparentColor
                          : mySelf
                              ? kprimaryColorLight
                              : kBaseGrey,
                      borderRadius:
                          // isAbsolute(currentMessage.body.toString())
                          //     ? BorderRadius.circular(borderRadius_8)
                          //     :
                          BorderRadius.only(
                              topLeft: const Radius.circular(16),
                              topRight: const Radius.circular(16),
                              bottomLeft: !mySelf ? const Radius.circular(4) : const Radius.circular(16),
                              bottomRight: !mySelf ? const Radius.circular(16) : const Radius.circular(4))),
                  child: Column(
                    crossAxisAlignment: Methods.isRTL(text) ? CrossAxisAlignment.end : CrossAxisAlignment.start,
                    children: [
                      isLink
                          ? SelectLinkWidget(
                              data: text,
                              onTap: () {
                                String? url = text;
                                if (url.contains("http")) {
                                  Methods.launchMyUrl(url, context: context);
                                } else {
                                  url = "https://";
                                  Methods.launchMyUrl(url, context: context);
                                }
                              },
                              style: const TextStyle(
                                color: Colors.blueAccent,
                                fontFamily: GayaFontTheme.primaryFont,
                              ),
                            )
                          : SelectableText(
                              text,
                              textDirection: Methods.isRTL(text) ? TextDirection.rtl : TextDirection.ltr,
                            ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          Text(
                            sentTime,
                            style: TextStyle(color: UtilColors.greyColor, fontSize: 10.0.sp, fontStyle: FontStyle.italic),
                          ),
                          (mySelf)
                              ? Row(
                                  children: [
                                    SizedBox(
                                      width: 4.r,
                                    ),
                                    getReadDeliveredWidget(deliveryStatus),
                                  ],
                                )
                              : const SizedBox.shrink()
                        ],
                      )
                    ],
                  ),
                ),
              )
            : Container(
                alignment: mySelf ? Alignment.centerLeft : Alignment.centerRight,
                padding: const EdgeInsets.symmetric(horizontal: distance_12, vertical: distance_8),
                decoration: BoxDecoration(
                    color: Helper.checkMessageType(currentMessage) == Helper.MessageType.post ||
                            Helper.checkMessageType(currentMessage) == Helper.MessageType.community
                        ? kTransparentColor
                        : mySelf
                            ? kprimaryColorLight
                            : kBaseGrey,
                    borderRadius: BorderRadius.only(
                        topLeft: const Radius.circular(16),
                        topRight: const Radius.circular(16),
                        bottomLeft: !mySelf ? const Radius.circular(4) : const Radius.circular(16),
                        bottomRight: !mySelf ? const Radius.circular(16) : const Radius.circular(4))),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    isLink
                        ? SelectLinkWidget(
                            data: text,
                            onTap: () {
                              String? url = text;
                              if (url.contains("http")) {
                                Methods.launchMyUrl(url, context: context);
                              } else {
                                url = "https://";
                                Methods.launchMyUrl(url, context: context);
                              }
                            },
                            style: const TextStyle(
                              color: Colors.blueAccent,
                              fontFamily: GayaFontTheme.primaryFont,
                            ),
                          )
                        : SelectableText(
                            text,
                            textDirection: Methods.isRTL(text) ? TextDirection.rtl : TextDirection.ltr,
                          ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Text(
                          sentTime,
                          style: TextStyle(color: UtilColors.greyColor, fontSize: 10.0.sp, fontStyle: FontStyle.italic),
                        ),
                        (mySelf)
                            ? Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  SizedBox(
                                    width: 4.r,
                                  ),
                                  getReadDeliveredWidget(deliveryStatus),
                                ],
                              )
                            : const SizedBox.shrink()
                      ],
                    )
                  ],
                ),
              ),
      ],
    );
  }
}

Widget getReadDeliveredWidget(String deliveryStatus) {
  if (deliveryStatus == 'read') {
    return Stack(children: <Widget>[
      Icon(
        Icons.check,
        size: 14.0.r,
        color: blueColor,
      ),
      Padding(
        padding: const EdgeInsets.only(left: 6),
        child: Icon(
          Icons.check,
          size: 14.0.r,
          color: blueColor,
        ),
      )
    ]);
  } else if (deliveryStatus == 'delivered') {
    return Stack(children: <Widget>[
      Icon(
        Icons.check,
        size: 14.0.r,
        color: UtilColors.greyColor,
      ),
      Padding(
        padding: const EdgeInsets.only(left: 6),
        child: Icon(
          Icons.check,
          size: 14.0.r,
          color: UtilColors.greyColor,
        ),
      )
    ]);
  } else {
    return Icon(
      Icons.check,
      size: 14.0.r,
      color: UtilColors.greyColor,
    );
  }
}
