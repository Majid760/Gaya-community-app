import 'package:connectycube_sdk/connectycube_sdk.dart' as Connectycube;
// import 'package:connectycube_sdk/connectycube_sdk.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gaya/components/image_swiper.dart';
import 'package:gaya/components/profile_image_widget.dart';
import 'package:gaya/routing/getx_route_methods.dart';
import 'package:gaya/utils/const.dart';
import 'package:gaya/utils/theme/app_colors.dart';
import 'package:gaya/view/chat/components/network_pdf_view.dart';
import 'package:gaya/view/chat/components/play_video_widget.dart';
import 'package:gaya/view/chat/components/text_link_widget.dart';
import 'package:gaya/view/chat/controllers/conversation_controller.dart';
import 'package:gaya/view/chat/helper/helper_functions.dart';
import 'package:gaya/view/chat/components/audio_widget.dart';
import 'package:gaya/view/messaging/components/load_message_as_communitypreview.dart';
import 'package:gaya/view/messaging/components/load_message_as_postpreview.dart';
import 'package:gaya/widgets/home_view_widgets/multiple_files_post.dart';
import 'package:get/get.dart';
import 'package:get/get_utils/src/get_utils/get_utils.dart';
import 'package:get/utils.dart';
import 'package:gaya/view/chat/utils/consts.dart' as UtilColors;
import 'package:intl/intl.dart';

class UserMessageWidget extends StatefulWidget {
  // final Message currentMessage;
  final VoidCallback onLongTap;
  final int index;
  final MessageType messageType;
  final Connectycube.CubeMessage? message;
  final String dialogId;
  String sentTime = '';
  String deliveryStatus = '';
  UserMessageWidget(
      {super.key,
      // required this.currentMessage,
      required this.onLongTap,
      required this.index,
      this.message,
      required this.messageType,
      required this.dialogId,
      required this.sentTime,
      required this.deliveryStatus});

  @override
  State<UserMessageWidget> createState() => _UserMessageWidgetState();
}

class _UserMessageWidgetState extends State<UserMessageWidget> {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onLongPress: widget.onLongTap,
      child: Padding(
        padding: const EdgeInsets.only(top: distance_10, bottom: distance_10),
        child: Align(
          alignment: Alignment.bottomRight,
          child: LayoutBuilder(
            builder: (context, constraints) {
              if ((widget.messageType == MessageType.nullAttachment) && (widget.message!.body == null || widget.message!.body!.isEmpty)) {
                return const SizedBox.shrink();
              } else {
                // returns type of widget whether it's text, image,video...
                if (widget.messageType == MessageType.community) {
                  return widget.message!.attachments != null && !isListEmptyOrNull(widget.message!.attachments)
                      ? LoadCommunityMessageWidget(
                          message: widget.message,
                          sentTime: widget.sentTime,
                          deliveryStatus: widget.deliveryStatus,
                        )
                      : const SizedBox.shrink();
                } else if (widget.messageType == MessageType.post) {
                  return widget.message!.attachments != null && !isListEmptyOrNull(widget.message!.attachments)
                      ? LoadPostMessageWidget(
                          message: widget.message,
                          sentTime: widget.sentTime,
                          deliveryStatus: widget.deliveryStatus,
                        )
                      // LoadPostMessage(postId: widget.message!.attachments!.first.data.toString(), isCurrentUser: false)
                      : const SizedBox.shrink();
                } else if (widget.messageType == MessageType.link) {
                  return widget.message!.attachments != null && !isListEmptyOrNull(widget.message!.attachments)
                      ? TextlinkWidget(
                          isLink: GetUtils.isURL(widget.message!.attachments!.first.data.toString()),
                          text: widget.message!.attachments!.first.data ?? '',
                          currentMessage: widget.message!,
                          mySelf: true,
                          sentTime: widget.sentTime,
                          deliveryStatus: widget.deliveryStatus,
                        )
                      : const SizedBox.shrink();
                } else if (widget.messageType == MessageType.image) {
                  return widget.message!.attachments != null && !isListEmptyOrNull(widget.message!.attachments)
                      ? SizedBox(
                          height: 200.h,
                          width: 150.w,
                          child: GestureDetector(
                            onTap: () {
                              if (widget.message!.attachments!.first.url != null) {
                                List<String> images = [widget.message!.attachments!.first.url!];
                                Routes.openImages(urls: images, index: 0, ctx: context);
                              }
                            },
                            child: Stack(
                              children: [
                                Container(
                                    clipBehavior: Clip.antiAlias,
                                    decoration: BoxDecoration(borderRadius: BorderRadius.circular(12).r),
                                    child: ScrolledHero(
                                        tag: widget.message!.attachments!.first,
                                        topOffset: 56,
                                        bottomOffset: 0,
                                        transitionOnUserGestures: true,
                                        child: PostImageWidget(url: widget.message!.attachments!.first.url))),
                                Positioned(
                                    bottom: 4.r,
                                    right: 4.r,
                                    child: Row(
                                      children: [
                                        Text(
                                          widget.sentTime,
                                          style: TextStyle(color: AppColors.white, fontSize: 10.0.sp, fontStyle: FontStyle.italic),
                                        ),
                                        Row(
                                          children: [
                                            SizedBox(
                                              width: 4.r,
                                            ),
                                            getReadDeliveredWidget(widget.deliveryStatus),
                                          ],
                                        )
                                      ],
                                    ))
                              ],
                            ),
                          ))
                      : const SizedBox.shrink();
                } else if (widget.messageType == MessageType.video) {
                  return PlayVideoWidget(
                    currentMessage: widget.message!,
                    sentTime: widget.sentTime,
                    deliveryStatus: widget.deliveryStatus,
                    mySelf: true,
                  );
                } else if (widget.messageType == MessageType.audio) {
                  return widget.message!.attachments != null && !isListEmptyOrNull(widget.message!.attachments)
                      ? AudioWidget(
                          isCurrentUser: true,
                          audioPath: widget.message!.attachments!.first.url!,
                          sentTime: widget.sentTime,
                          deliveryStatus: widget.deliveryStatus,
                        )
                      : const SizedBox.shrink();
                } else if (widget.messageType == MessageType.document) {
                  return widget.message!.attachments != null && !isListEmptyOrNull(widget.message!.attachments)
                      ? NetworkPDFView(
                          path: widget.message!.attachments!.first.url!,
                          filename: widget.message!.attachments!.first.name ?? '',
                          chatDialogId: widget.dialogId,
                          width: 230.w,
                          thumbnailUrl: widget.message!.attachments!.first.data,
                          sentTime: widget.sentTime,
                          deliveryStatus: widget.deliveryStatus,
                          mySelf: true,
                        )
                      : const SizedBox.shrink();
                }
                return widget.message!.body != null && (widget.message!.body?.isNotEmpty ?? false)
                    ? TextlinkWidget(
                        isLink: GetUtils.isURL(widget.message!.body.toString()),
                        text: widget.message!.body ?? '',
                        currentMessage: widget.message!,
                        mySelf: true,
                        sentTime: widget.sentTime,
                        deliveryStatus: widget.deliveryStatus,
                      )
                    : const SizedBox.shrink();
              }
            },
          ),
        ),
      ),
    );
  }
  // Widget getReadDeliveredWidget(String deliveryStatus) {
  //   if (deliveryStatus == 'read') {
  //     return Stack(children: <Widget>[
  //       Icon(
  //         Icons.check,
  //         size: 14.0.r,
  //         color: blueColor,
  //       ),
  //       Padding(
  //         padding: const EdgeInsets.only(left: 6),
  //         child: Icon(
  //           Icons.check,
  //           size: 14.0.r,
  //           color: blueColor,
  //         ),
  //       )
  //     ]);
  //   } else if (deliveryStatus == 'delivered') {
  //     return Stack(children: <Widget>[
  //       Icon(
  //         Icons.check,
  //         size: 14.0.r,
  //         color: UtilColors.greyColor,
  //       ),
  //       Padding(
  //         padding: const EdgeInsets.only(left: 6),
  //         child: Icon(
  //           Icons.check,
  //           size: 14.0.r,
  //           color: UtilColors.greyColor,
  //         ),
  //       )
  //     ]);
  //   } else {
  //     return Icon(
  //       Icons.check,
  //       size: 14.0.r,
  //       color: UtilColors.greyColor,
  //     );
  //   }
  // }

  // markAsReadIfNeed() {
  //   var isOpponentMsgRead = widget.message!.readIds != null && widget.message!.readIds!.contains(chatController.currentUser?.id);
  //   print("markAsReadIfNeed message= $widget.message!, isOpponentMsgRead= $isOpponentMsgRead");
  //   if (widget.message!.senderId != chatController.currentUser?.id && !isOpponentMsgRead) {
  //     if (widget.message!.readIds == null) {
  //       widget.message!.readIds = [chatController.currentUser?.id ?? 0];
  //     } else {
  //       widget.message!.readIds!.add(chatController.currentUser?.id ?? 0);
  //     }

  //     if (Connectycube.CubeChatConnection.instance.chatConnectionState == Connectycube.CubeChatConnectionState.Ready) {
  //       chatController.currentChat?.readMessage(widget.message!);
  //     } else {
  //       chatController.unreadMessages.add(widget.message!);
  //     }
  //   }
  // }

  // Widget getReadDeliveredWidget() {
  //   log("[getReadDeliveredWidget]");
  //   bool messageIsRead() {
  //     log("[getReadDeliveredWidget] messageIsRead");
  //     if (chatController.currentChat?.type == Connectycube.CubeDialogType.PRIVATE) {
  //       return widget.message!.readIds != null && (widget.message!.recipientId == null || widget.message!.readIds!.contains(widget.message!.recipientId));
  //     }
  //     return widget.message!.readIds != null &&
  //         widget.message!.readIds!.any((int id) => id != chatController.currentUser?.id && chatController.occupants.keys.contains(id));
  //   }

  //   bool messageIsDelivered() {
  //     log("[getReadDeliveredWidget] messageIsDelivered");
  //     if (chatController.currentChat?.type == Connectycube.CubeDialogType.PRIVATE) {
  //       return widget.message!.deliveredIds != null && (widget.message!.recipientId == null || widget.message!.deliveredIds!.contains(widget.message!.recipientId));
  //     }
  //     return widget.message!.deliveredIds != null &&
  //         widget.message!.deliveredIds!.any((int id) => id != chatController.currentUser?.id && chatController.occupants.keys.contains(id));
  //   }

  //   if (messageIsRead()) {
  //     log("[getReadDeliveredWidget] if messageIsRead");
  //     return Stack(children: const <Widget>[
  //       Icon(
  //         Icons.check,
  //         size: 15.0,
  //         color: blueColor,
  //       ),
  //       Padding(
  //         padding: EdgeInsets.only(left: 8),
  //         child: Icon(
  //           Icons.check,
  //           size: 15.0,
  //           color: blueColor,
  //         ),
  //       )
  //     ]);
  //   } else if (messageIsDelivered()) {
  //     log("[getReadDeliveredWidget] if messageIsDelivered");
  //     return Stack(children: <Widget>[
  //       Icon(
  //         Icons.check,
  //         size: 15.0,
  //         color: UtilColors.greyColor,
  //       ),
  //       Padding(
  //         padding: const EdgeInsets.only(left: 8),
  //         child: Icon(
  //           Icons.check,
  //           size: 15.0,
  //           color: UtilColors.greyColor,
  //         ),
  //       )
  //     ]);
  //   } else {
  //     log("[getReadDeliveredWidget] sent");
  //     return Icon(
  //       Icons.check,
  //       size: 15.0,
  //       color: UtilColors.greyColor,
  //     );
  //   }
  // }

  // Widget getDateWidget() {
  //   return Text(
  //     DateFormat('HH:mm').format(DateTime.fromMillisecondsSinceEpoch(widget.message!.dateSent! * 1000)),
  //     style: TextStyle(color: UtilColors.greyColor, fontSize: 12.0, fontStyle: FontStyle.italic),
  //   );
  // }

  // Widget getHeaderDateWidget() {
  //   return Container(
  //     alignment: Alignment.center,
  //     margin: const EdgeInsets.all(10.0),
  //     child: Text(
  //       DateFormat('dd MMMM').format(DateTime.fromMillisecondsSinceEpoch(widget.message!.dateSent! * 1000)),
  //       style: TextStyle(color: UtilColors.primaryColor, fontSize: 20.0, fontStyle: FontStyle.italic),
  //     ),
  //   );
  // }

  // bool isHeaderView(int index) {
  //   int headerId = int.parse(DateFormat('ddMMyyyy').format(DateTime.fromMillisecondsSinceEpoch(widget.message!.dateSent! * 1000)));
  //   if (index >= chatController.chatMessagesList.length - 1) {
  //     return false;
  //   }
  //   var msgPrev = chatController.chatMessagesList[index + 1];
  //   int nextItemHeaderId = int.parse(DateFormat('ddMMyyyy').format(DateTime.fromMillisecondsSinceEpoch(msgPrev.dateSent! * 1000)));
  //   var result = headerId != nextItemHeaderId;
  //   return result;
  // }
}
