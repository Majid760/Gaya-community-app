import 'package:flutter/material.dart';
import 'package:gaya/components/progress.indicator.component.dart';
import 'package:gaya/components/snackbar.component.dart';
import 'package:gaya/controller/create.post.controller.dart';
import 'package:gaya/utils/enum.dart';
import 'package:gaya/utils/language/translation.dart';
import 'package:gaya/utils/textstyles.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';
import '../utils/const.dart';
import '../widgets/create_recipe_widgets/create.recipe1.widget.dart';
import '../widgets/create_recipe_widgets/create.recipe2.widget.dart';

class CreateRecipeView extends StatelessWidget {
  final String? communityId;
  const CreateRecipeView({Key? key, this.communityId}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final createRecipeController =
        Provider.of<CreatePostController>(context, listen: true);
    return Scaffold(
      appBar: getAppbar(context, createRecipeController),
      body: getBody(createRecipeController, context),
    );
  }

//appbar
  PreferredSizeWidget getAppbar(
      BuildContext context, CreatePostController createPostController) {
    return AppBar(
      shape: Border(
          bottom: BorderSide(
        color: kBaseGrey.withOpacity(0.5),
      )),
      automaticallyImplyLeading: true,
      iconTheme: const IconThemeData(color: kBlackColor),
      actions: [
        createPostController.isloadingPost == true
            ? const Center(
                child: CircularProgressIndicator.adaptive(
                  backgroundColor: kprimaryColor,
                ),
              )
            : TextButton(
                onPressed: () async {
                  createPostController.setRecipeView(createRecipeEnum.two);
                  if (createPostController.aboutPostController.text.isEmpty ||
                      createPostController.image == null ||
                      createPostController.recipeName.text.isEmpty ||
                      createPostController.ingredients.isEmpty ||
                      createPostController.directions.isEmpty) {
                    snackBar(
                        context,
                        GayaStrings.fill_detail_before_post.tr,
                        kprimaryColor);
                  } else {
                    // await createPostController.postInCommunity(
                    //     context, communityId!);
                  }
                },
                child: Text(
                  createPostController.getRecipeView == createRecipeEnum.one
                      ?  GayaStrings.next_txt.tr
                      :  GayaStrings.done.tr,
                  style: const TextStyle(color: kprimaryColor),
                ))
      ],
      title: Text(
        GayaStrings.create_recipe.tr,
        style: bodyStyle,
      ),
      centerTitle: true,
      backgroundColor: kTransparentColor,
      elevation: 0,
    );
  }

//body
  Widget getBody(
      CreatePostController createRecipeController, BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: distance_20),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(
              height: distance_20,
            ),
            Row(
              children: [
                progressIndicator(
                    ontap: () => createRecipeController
                        .setRecipeView(createRecipeEnum.one),
                    color: kprimaryColor),
                const SizedBox(
                  width: distance_10,
                ),
                progressIndicator(
                  ontap: () => createRecipeController
                      .setRecipeView(createRecipeEnum.two),
                  color: createRecipeController.getRecipeView ==
                          createRecipeEnum.one
                      ? borderColor
                      : kprimaryColor,
                ),
              ],
            ),
            const SizedBox(
              height: distance_20,
            ),
            getRecipeViewWidget(createRecipeController.getRecipeView),
          ],
        ),
      ),
    );
  }

  Widget getRecipeViewWidget(createRecipeEnum getView) {
    switch (getView) {
      case createRecipeEnum.one:
        return const Recipe1Widget();
      case createRecipeEnum.two:
        return const Recipe2Widget();
    }
  }
}
