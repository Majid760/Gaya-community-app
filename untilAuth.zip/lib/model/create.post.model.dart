import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:gaya/model/community.model.dart';
import 'package:gaya/model/user.model.dart';
import 'package:gaya/shared/service/dynamic_link_service/enums/dynamic_link_type.dart';
import 'package:gaya/shared/service/dynamic_link_service/model/dynamic_link_type_string.dart';

import '../shared/service/dynamic_link_service/utils/query_param_consts.dart';

/// [postedBy] and [community] are required and initialised as late.
class Post implements DynamicLinkTypeString {
  late UserModel postedBy;
  late Community community;
  String? communityId;
  String? postDescription;
  String? memberId;
  String? postid;
  String? postPicture;
  DateTime? postCreatedOn;
  String? totaltime;
  bool? approve;
  bool? isPostedAnonymously;
  bool? isDeleted;
  String? totalCommentsCount;
  List<String>? likedBy;
  List<String>? crownsBy;
  List<dynamic>? multipleImages;
  String? video;
  DateTime? approvedAt;
  List<String>? postTopicList;
  bool? isPinned;
  List<Map<String, dynamic>>? pdfFiles;
  int? score;
  Post({
    required this.postedBy,
    required this.community,
    this.communityId,
    this.likedBy = const [],
    this.crownsBy = const [],
    this.postDescription,
    this.memberId,
    this.postPicture,
    this.postCreatedOn,
    this.totaltime,
    this.approve,
    this.isDeleted,
    this.postid,
    this.isPostedAnonymously,
    this.multipleImages,
    this.totalCommentsCount = "0",
    this.video,
    this.pdfFiles = const [],
    this.approvedAt,
    this.postTopicList,
    this.isPinned = false,
    this.score = 0,
  });

//for getting the data
  Post.fromMap(Map<String, dynamic> map) {
    try {
      totalCommentsCount = map['totalCommentsCount']?.toString() ?? "0";
      postedBy = UserModel.fromMap(map['postedBy']);
      community = Community.fromMap(map['community']);
      likedBy = map['likedBy'] == null ? [] : List<String>.from(map['likedBy']);
      crownsBy = map['crownsBy'] == null ? [] : List<String>.from(map['crownsBy']);

      communityId = map['communityId'];
      postDescription = map['postDescription'];
      memberId = map['memberId'];
      postPicture = map['postPicture'];
      // preparationTime = map['preparationTime'];
      postCreatedOn = map['createdOn'] != null ? (map['createdOn'] as Timestamp).toDate() : null;
      // totaltime = map['totalTime'];
      postid = map['postId'];
      approve = map['approve'];
      isPinned = map['isPinned'] ?? false;

      isDeleted = map["isDeleted"];
      // recipeName = map['reciepeName'];
      isPostedAnonymously = map['isPostedAnonymously'];
      multipleImages = map['multipleImages'];
      video = map['video'];
      pdfFiles = map['pdfFiles'] != null
          ? (map['pdfFiles'] as List)
              .map<Map<String, dynamic>>((file) =>
                  {"title": file['title'], "fileUrl": file['fileUrl'], "fileName": file['fileName'], "thumbnail": file['thumbnail']})
              .toList()
          : [];
      postTopicList = map['postTopicList'] == null ? [] : List<String>.from(map['postTopicList']);
      approvedAt = (map['approvedAt'] ?? map['createdOn'] as Timestamp).toDate();
      score = map['score'] ?? 0;
    } catch (_) {}
  }

  /// * This is for test purpose, create post with older schema.
  Map<String, dynamic> toOldMap() {
    return {
      'communityId': communityId,
      'postDescription': postDescription,
      'memberId': memberId,
      'postPicture': postPicture,
      'createdOn': postCreatedOn,
      'approve': approve,
      'isPinned': isPinned,
      'totalTime': totaltime,
      'postId': postid,
      'isDeleted': isDeleted,
      'isPostedAnonymously': isPostedAnonymously,
      'multipleImages': multipleImages,
      'video': video,
      'pdfFiles': pdfFiles
    };
  }

  //for sending the data
  Map<String, dynamic> toMap() {
    return {
      'postedBy': postedBy.toPublicJson(),
      'community': community.toMap(),
      'likedBy': likedBy ?? [],
      'crownsBy': crownsBy ?? [],
      'communityId': communityId,
      'postDescription': postDescription,
      'memberId': memberId,
      'postPicture': postPicture,
      'createdOn': postCreatedOn,
      'approve': approve,
      'isPinned': isPinned ?? false,
      'totalTime': totaltime,
      'postId': postid,
      'isDeleted': isDeleted,
      'isPostedAnonymously': isPostedAnonymously,
      'multipleImages': multipleImages,
      "totalCommentsCount": totalCommentsCount ?? "0",
      'video': video,
      'approvedAt': approvedAt,
      'postTopicList': (postTopicList == null) ? [] : postTopicList,
      'pdfFiles': pdfFiles ?? []
    };
  }

  bool get isCommunityPrivate => community.communityType == "Private";

  bool get isCommunityPublic => community.communityType == "Public";

  @override
  String get type => DynamicLinkType.shareCommunityPost.name;


  @override
  String get queryParams =>
      "?${QueryParamConst.id}=$postid&${QueryParamConst.type}=$type&${QueryParamConst.communityId}=$communityId&${QueryParamConst.isPrivate}=$isCommunityPrivate";
}
