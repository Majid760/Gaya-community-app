class TopicsModel {
  String image;
  String title;
  bool isSeleted;

  TopicsModel({
    required this.title,
    required this.image,
    required this.isSeleted,
  });

  @override
  bool operator ==(other) {
    if (identical(this, other)) return true;
    return other is TopicsModel && title == other.title;
  }

  @override
  int get hashCode => title.hashCode;

  factory TopicsModel.fromMap(Map<String, dynamic> map) {
    return TopicsModel(
      title: map['title'],
      image: map['image'],
      isSeleted: false,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'title': title,
      'image': image,
    };
  }
}

List<TopicsModel> topicsList = [
  TopicsModel(image: '🎯', title: 'Self development', isSeleted: false),
  TopicsModel(image: '😂', title: 'Funny', isSeleted: false),
  TopicsModel(image: '📚', title: 'School', isSeleted: false),
  TopicsModel(image: '👫', title: 'Friends', isSeleted: false),
  TopicsModel(image: '🎮', title: 'Gaming', isSeleted: false),
  TopicsModel(image: '💋', title: 'Relationships', isSeleted: false),
  TopicsModel(image: '🎨', title: 'Art', isSeleted: false),
  TopicsModel(image: '🌿', title: 'Health', isSeleted: false),
  TopicsModel(image: '🍔', title: 'Food', isSeleted: false),
  TopicsModel(image: '💅🏻', title: 'Beauty', isSeleted: false),
  TopicsModel(image: '💫', title: 'Life style', isSeleted: false),
  TopicsModel(image: '🏃🏽‍♀', title: 'Fitness', isSeleted: false),
  TopicsModel(image: '💡', title: 'Inspiration', isSeleted: false),
  TopicsModel(image: '🖌', title: 'DIY', isSeleted: false),
  TopicsModel(image: '🙏🏻', title: 'Advice', isSeleted: false),
  TopicsModel(image: '📝', title: 'Writing', isSeleted: false),
  TopicsModel(image: '❤️', title: 'Love', isSeleted: false),
  TopicsModel(image: '🎥', title: 'Movies', isSeleted: false),
  TopicsModel(image: '🐶', title: 'Animals', isSeleted: false),
  TopicsModel(image: '👗', title: 'Fashion', isSeleted: false),
  TopicsModel(image: '⚽', title: 'Sports', isSeleted: false),
  TopicsModel(image: '💁‍♀', title: 'Girls talk', isSeleted: false),
  TopicsModel(image: '📺', title: 'TV', isSeleted: false),
  TopicsModel(image: '✈️', title: 'Travel', isSeleted: false),
  TopicsModel(image: '🤫', title: 'Confessions', isSeleted: false),
  TopicsModel(image: '💡', title: 'Entrepreneurship', isSeleted: false),
  TopicsModel(image: '🎎', title: 'Anime', isSeleted: false),
  TopicsModel(image: '🎵', title: 'Music', isSeleted: false),
  TopicsModel(image: '👯‍♀️', title: 'Dance', isSeleted: false),
  TopicsModel(image: '📖', title: 'Poems', isSeleted: false),
  TopicsModel(image: '📷', title: 'Photography', isSeleted: false),
  TopicsModel(image: '📚', title: 'Books', isSeleted: false),
  TopicsModel(image: '🎉', title: 'Parties', isSeleted: false),
  TopicsModel(image: '🚗', title: 'Motorsport', isSeleted: false),
  TopicsModel(image: '🤘', title: 'Metal', isSeleted: false),
  TopicsModel(image: '🎼', title: 'K pop', isSeleted: false),
  TopicsModel(image: '🔐', title: 'Crypto', isSeleted: false),
  TopicsModel(image: '👩‍🎨', title: 'Design', isSeleted: false),
  TopicsModel(image: '🤔', title: 'Content creation', isSeleted: false),
  TopicsModel(image: '🚘', title: 'Cars', isSeleted: false),
  TopicsModel(image: '🤩', title: 'Marvel Nintendo DC', isSeleted: false),
  TopicsModel(image: '💻', title: 'Blog', isSeleted: false),
  TopicsModel(image: '🐎', title: 'Horse racing', isSeleted: false),
  TopicsModel(image: '📈', title: 'Business', isSeleted: false),
  TopicsModel(image: '💰', title: 'Money', isSeleted: false),
  TopicsModel(image: '🧬', title: 'Science', isSeleted: false),
  TopicsModel(image: '🧸', title: 'Hobbies', isSeleted: false),
  TopicsModel(image: '👩‍💻', title: 'Technology', isSeleted: false),
  TopicsModel(image: '📸', title: 'Celebrity', isSeleted: false),
  TopicsModel(image: '🪐', title: 'Space', isSeleted: false),
  TopicsModel(image: '🔑', title: 'Leadership', isSeleted: false),
  TopicsModel(image: '🎁', title: 'Board games', isSeleted: false),
  TopicsModel(image: '🥣', title: 'Cooking', isSeleted: false),
  TopicsModel(image: '🖥️', title: 'Programming', isSeleted: false),
  TopicsModel(image: '🫀', title: 'Astronomy', isSeleted: false),
  TopicsModel(image: '🏀', title: 'Basketball', isSeleted: false),
  TopicsModel(image: '⚽️', title: 'Football', isSeleted: false),
  TopicsModel(image: '🎾', title: 'Tennis', isSeleted: false),
  TopicsModel(image: '🤖', title: 'Cyber', isSeleted: false),
  TopicsModel(image: '👀', title: 'Nonsense', isSeleted: false),
  TopicsModel(image: '👣', title: 'Criminology', isSeleted: false),
  TopicsModel(image: '👩‍❤️‍👨', title: 'Dating', isSeleted: false),
  TopicsModel(image: '🏳️‍🌈', title: 'LGBTQ+', isSeleted: false),
];

class TopicsUtils {
  static List<TopicsModel> getTopicsList() => topicsList;

  /// get related topics for each topic to recommend to user
  /// for example: if user selected 'Fitness' topic, we will recommend 'Health' topic to him
  /// if no topics selected, return all topics
  static List<String> getRecommendedTopics(List<String> selectedTopics) {
    /// if no topics selected, return all topics
    if (selectedTopics.isEmpty) return allTopics;
    Map<String, String> recommendedTopics = <String, String>{};

    // get related topics
    for (String topic in selectedTopics) {
      relatedTopics[topic]?.forEach((element) {
        recommendedTopics[element] = element;
      });
    }

    return recommendedTopics.keys.toList();
  }

  static List<String> allTopics = [
    'Self development',
    'Funny',
    'School',
    'Friends',
    'Gaming',
    'Relationships',
    'Art',
    'Health',
    'Food',
    'Beauty',
    'Life style',
    'Fitness',
    'Inspiration',
    'DIY',
    'Advice',
    'Writing',
    'Love',
    'Movies',
    'Animals',
    'Fashion',
    'Sports',
    'Girls talk',
    'TV',
    'Travel',
    'Confessions',
    'Entrepreneurship',
    'Anime',
    'Music',
    'Dance',
    'Poems',
    'Photography',
    'Books',
    'Parties',
    'Motorsport',
    'Metal',
    'K pop',
    'Crypto',
    'Design',
    'Content creation',
    'Cars',
    'Marvel Nintendo DC',
    'Blog',
    'Horse racing',
    'Business',
    'Money',
    'Science',
    'Hobbies',
    'Technology',
    'Celebrity',
    'Space',
    'Leadership',
    'Gifts',
    'Board games',
    'Cooking',
    'Programming',
    'Astronomy',
    'Basketball',
    'Football',
    'Tennis',
    'Cyber',
    'Nonsense',
    'Criminology',
    'Dating',
    'LGBTQ+',
  ];
  static Map<String, List<String>> relatedTopics = {
    'Self development': ['Inspiration', 'Advice', 'Entrepreneurship', 'Money'],
    'Funny': ['Movies', 'TV', 'Celebrity'],
    'School': ['Books', 'Writing', 'Poems'],
    'Friends': ['Relationships', 'Girls talk', 'Travel', 'Parties', 'Confessions'],
    'Gaming': ['Motorsport', 'Technology', 'Dance', 'Sports'],
    'Relationships': ['Love', 'Confessions', 'Girls talk', 'Travel'],
    'Art': ['Design', 'Photography', 'Fashion', 'DIY'],
    'Health': ['Fitness', 'Food', 'Beauty', 'Life style'],
    'Food': ['Travel', 'Cooking', 'Hobbies'],
    'Beauty': ['Fashion', 'Design', 'Photography', 'Art'],
    'Life style': ['Fashion', 'Travel', 'Hobbies', 'Parties'],
    'Fitness': ['Health', 'Dance', 'Motorsport', 'Sports'],
    'Inspiration': ['Self development', 'Entrepreneurship', 'Leadership', 'Advice'],
    'DIY': ['Design', 'Photography', 'Art', 'Fashion', 'Hobbies'],
    'Advice': ['Self development', 'Entrepreneurship', 'Leadership', 'Inspiration'],
    'Writing': ['Books', 'School', 'Poems'],
    'Love': ['Relationships', 'Confessions', 'Girls talk', 'Travel'],
    'Movies': ['Funny', 'TV', 'Celebrity', 'Marvel Nintendo DC', 'Anime', 'Music'],
    'Animals': ['Travel'],
    'Fashion': ['Beauty', 'Life style', 'Design', 'Photography', 'Art'],
    'Sports': ['Motorsport', 'Horse racing'],
    'Girls talk': ['Relationships', 'Love', 'Confessions', 'Friends', 'Travel', 'Parties', 'Life style'],
    'TV': ['Funny', 'Movies', 'Celebrity', 'Marvel Nintendo DC', 'Anime', 'Music', 'Dance'],
    'Travel': ['Friends', 'Life style', 'Animals'],
    'Confessions': ['Love', 'Relationships', 'Girls talk'],
    'Entrepreneurship': ['Self development', 'Inspiration', 'Advice', 'Business'],
    'Anime': ['Design', 'Art'],
    'Music': ['K pop', 'Metal', 'Dance'],
    'Dance': ['Fitness', 'Motorsport', 'Gaming', 'K pop'],
    'Poems': ['Writing', 'School', 'Books'],
    'Photography': ['Design', 'Art'],
    'Books': ['Writing', 'School', 'Poems'],
    'Parties': ['Friends', 'Life style', 'Travel'],
    'Motorsport': [
      'Gaming',
      'Sports',
      'Fitness',
      'Cars',
      'Horse racing',
    ],
    'Metal': ['Music', 'K pop'],
    'K pop': ['Music', 'Dance', 'Metal'],
    'Crypto': ['Money', 'Technology', 'Business', 'Leadership'],
    'Design': ['Art', 'DIY', 'Content creation', 'Cars', 'Beauty'],
    'Content creation': ['Design', 'Technology', 'Business', 'Hobbies'],
    'Cars': ['Motorsport', 'Design'],
    'Marvel Nintendo DC': ['Movies', 'Gaming'],
    'Blog': [
      'Writing',
      'Technology',
      'Celebrity',
      'Fashion',
      'Life style',
      'Travel',
      'Animals',
      'Food',
      'Health',
      'Fitness',
      'Hobbies',
      'Cyber'
    ],
    'Horse racing': ['Sports', 'Motorsport', 'Travel', 'Animals', 'Life style'],
    'Business': ['Entrepreneurship', 'Money', 'Leadership'],
    'Money': ['Self development', 'Entrepreneurship', 'Crypto', 'Business', 'Leadership'],
    'Science': ['Technology', 'Space', 'Astronomy'],
    'Hobbies': ['Life style', 'Technology', 'Content creation', 'Programming'],
    'Technology': ['Gaming', 'Crypto', 'Design', 'Content creation', 'Science', 'Hobbies', 'Programming', 'Cyber'],
    'Celebrity': ['Funny', 'TV', 'Blog'],
    'Space': ['Science', 'Technology', 'Astronomy'],
    'Leadership': ['Self development', 'Entrepreneurship', 'Inspiration', 'Business'],
    'Gifts': ['Life style'],
    'Programming': ['Cyber', 'Technology', 'Content creation', 'Business'],
    'Astronomy': ['Science', 'Space', 'Photography', 'Technology'],
    'Basketball': ['Sports', 'Fitness', 'Health', 'Motorsport'],
    'Football': ['Sports', 'Fitness', 'Health', 'Motorsport'],
    'Tennis': ['Sports', 'Fitness', 'Health', 'Motorsport'],
    'Cyber': ['Programming', 'Technology'],
    'Nonsense': ['Funny', 'TV', 'Celebrity'],
    'Criminology': ['Science', 'Technology', 'Leadership', 'Business', 'Money', 'Entrepreneurship', 'Self development'],
    'LGBTQ+': ['Love', 'Relationships'],
  };

// TODO GENDER WISE
}
