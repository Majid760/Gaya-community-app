// ignore_for_file: avoid_returning_null_for_void

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:gaya/utils/language/translation.dart';
import 'package:gaya/widgets/create_recipe_widgets/timer.widget.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

import '../../components/dialogue.component.dart';
import '../../components/textfield.component.dart';
import '../../controller/create.post.controller.dart';
import '../../gen/assets.gen.dart';
import '../../utils/const.dart';
import '../../utils/textstyles.dart';
import '../../utils/vallidation.dart';
import '../profile.widgets/button.widget.dart';

class Recipe1Widget extends StatelessWidget {
  const Recipe1Widget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final createRecipeController = Provider.of<CreatePostController>(context, listen: true);
    final validation = FormValidation();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          GayaStrings.recipe_name.tr,
          style: secondaryFontStyleWeight,
        ),
        const SizedBox(
          height: distance_15,
        ),
        textField(
            isPassword: false,
            inputType: TextInputType.text,
            hintText: GayaStrings.custard.tr,
            controller: createRecipeController.recipeName,
            validation: validation.firstNameValidator,
            borderColor: borderColor),
        const SizedBox(
          height: distance_40,
        ),
        TimingWidget(
          title: GayaStrings.total_time.tr,
          onTap: () => null,
          time: createRecipeController.totalTime ?? '00',
        ),
        const SizedBox(
          height: distance_20,
        ),
        TimingWidget(title: GayaStrings.preparation_time.tr, onTap: () => null, time: createRecipeController.preparationTime ?? '00'),
        const SizedBox(
          height: distance_20,
        ),
        Text(
          'Ingredients',
          style: bodyStyle,
        ),
        const SizedBox(
          height: distance_15,
        ),
        ButtonWidget(
          icon: SvgPicture.asset(Assets.assets.icons.add_friends),
          onTap: () {
            showDialogue(
              createRecipeController.writeIngredients,
              validation.firstNameValidator,
              borderColor,
              () {
                createRecipeController.addIngredientsToList(context);
                Navigator.of(context).pop();
                createRecipeController.writeIngredients.clear();
              },
              GayaStrings.write_ingredients.tr,
              GayaStrings.add_ingredients.tr,
              context,
            );
          },
          buttonColor: kBaseGrey,
          color: kBlackColor.withOpacity(0.5),
          title: GayaStrings.add_ingredients.tr,
          style: secondaryFontStyleBig,
        ),
        const SizedBox(
          height: distance_15,
        ),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: List.generate(createRecipeController.ingredients.length, (index) {
            return IntrinsicWidth(
              child: Container(
                alignment: Alignment.center,
                padding: const EdgeInsets.symmetric(horizontal: distance_15, vertical: distance_10),
                decoration: BoxDecoration(color: kBaseGrey, borderRadius: BorderRadius.circular(borderRadius_4)),
                child: Text(
                  createRecipeController.ingredients[index],
                  style: body3Style,
                ),
              ),
            );
          }),
        ),
      ],
    );
  }
}
