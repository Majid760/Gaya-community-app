import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:gaya/utils/language/translation.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

import '../../components/dialogue.component.dart';
import '../../controller/create.post.controller.dart';
import '../../gen/assets.gen.dart';
import '../../utils/const.dart';
import '../../utils/textstyles.dart';
import '../../utils/vallidation.dart';
import '../profile.widgets/button.widget.dart';

class Recipe2Widget extends StatelessWidget {
  const Recipe2Widget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final createRecipeController = Provider.of<CreatePostController>(context, listen: true);
    final validation = FormValidation();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          GayaStrings.directions_txt.tr,
          style: bodyStyle,
        ),
        SizedBox(
          height: distance_10,
        ),
        ButtonWidget(
          icon: SvgPicture.asset(Assets.assets.icons.add_friends),
          onTap: () {
            showDialogue(
              createRecipeController.writeDirections,
              validation.firstNameValidator,
              borderColor,
              () {
                createRecipeController.addDirectionsToList(context);
                Navigator.of(context).pop();
                createRecipeController.writeDirections.clear();
              },
              GayaStrings.write_directions.tr,
              GayaStrings.add_directions.tr,
              context,
            );
          },
          buttonColor: kBaseGrey,
          color: kBlackColor.withOpacity(0.5),
          title: GayaStrings.add_new_direction.tr,
          style: secondaryFontStyleBig,
        ),
        SizedBox(
          height: distance_15,
        ),
        createRecipeController.directions.isEmpty
            ? SizedBox()
            : ListView.separated(
                shrinkWrap: true,
                itemBuilder: (context, index) {
                  return Container(
                    alignment: Alignment.center,
                    width: double.infinity,
                    decoration: BoxDecoration(color: kBaseGrey, borderRadius: BorderRadius.circular(borderRadius_4)),
                    padding: EdgeInsets.symmetric(horizontal: distance_15, vertical: distance_10),
                    child: Text(
                      createRecipeController.directions[index].toString(),
                      style: body4StyleLowWeight,
                    ),
                  );
                },
                separatorBuilder: (context, index) => SizedBox(
                      height: distance_10,
                    ),
                itemCount: createRecipeController.directions.length)
      ],
    );
  }
}
