import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gaya/routing/getx_route_methods.dart';
import 'package:gaya/utils/language/translation.dart';
import 'package:get/get.dart';

import '../../components/avatar.component.dart';
import '../../model/user.model.dart';
import '../../utils/const.dart';
import '../../utils/textstyles.dart';

class RequestNotificationWidget extends StatelessWidget {
  final String text;
  final String postedTime;
  final Widget pic;
  final Widget? widget1, widget2;
  final Color color;
  final String? profileImg;
  final user = FirebaseAuth.instance.currentUser;
  final String senderId;

  RequestNotificationWidget(
      {Key? key,
      this.profileImg,
      required this.text,
      required this.postedTime,
      required this.pic,
      required this.color,
      required this.senderId,
      this.widget1,
      this.widget2})
      : super(key: key);

  void openProfile({required UserModel userModel, required BuildContext context}) {
    Routes.viewProfile(uid: userModel.uId, model: userModel);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
      height: 118,
      width: MediaQuery.of(context).size.width,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          GestureDetector(
            onTap: () {
              openProfile(userModel: UserModel(uId: senderId, name: text, profilePicture: profileImg), context: context);
            },
            child: AvatarWidget(backgroundColor: color, imageWidget: pic, profileImg: profileImg!),
          ),
          const SizedBox(width: distance_12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                GestureDetector(
                  onTap: () {
                    openProfile(userModel: UserModel(uId: user?.uid ?? '', name: text, profilePicture: profileImg), context: context);
                  },
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(text, style: body4Style, maxLines: 2, overflow: TextOverflow.ellipsis),
                          Text(postedTime.toString(),
                              // "Time",
                              style: body3Style)
                        ],
                      ),
                      const SizedBox(height: 2),
                      Text(GayaStrings.wants_to_connect.tr,
                          style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w400), maxLines: 2, overflow: TextOverflow.ellipsis),
                    ],
                  ),
                ),
                // const Spacer(),
                const SizedBox(
                  height: distance_8,
                ),
                Row(
                  children: [
                    Expanded(child: widget1 ?? const SizedBox()),
                    const SizedBox(width: 8),
                    Expanded(child: widget2 ?? const SizedBox()),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class OtherNotificationWidget extends StatelessWidget {
  final String text;
  final String? postedTime;
  final Widget pic;
  final Color color;
  final String? profileImg;
  final String? message;
  final String? receiverUserId;
  final String? notificationId;
  final Color unreadMessageColor;
  final VoidCallback onTapNotification;

  const OtherNotificationWidget(
      {Key? key,
      this.profileImg,
      required this.text,
      this.postedTime,
      required this.pic,
      required this.color,
      required this.message,
      required this.receiverUserId,
      required this.notificationId,
      required this.unreadMessageColor,
      required this.onTapNotification})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTapNotification,
      child: Container(
        alignment: Alignment.center,
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 20).r,
        width: double.infinity,
        decoration: BoxDecoration(color: unreadMessageColor, border: Border.all(color: kBaseGrey)),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            (profileImg == null)
                ? Container(
                    alignment: Alignment.center,
                    child: ColorAvatarWidget(
                      backgroundColor: color,
                      imageWidget: pic,
                    ),
                  )
                : Container(
                    alignment: Alignment.center,
                    child: AvatarWidget(
                      backgroundColor: color,
                      imageWidget: pic,
                      profileImg: profileImg ?? "",
                    ),
                  ),
            const SizedBox(width: distance_12),
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      if (text.isBlank == false)
                        Flexible(
                          child: Text(
                            text,
                            style: body4Style,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      if (postedTime.isBlank == false)
                        Text(
                          // postedTime.toString(),
                          postedTime ?? '',
                          style: body3Style,
                        ),
                    ],
                  ),
                  const SizedBox(height: 2),
                  if (message.isBlank == false)
                    Text(
                      message ?? '',
                      style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w400),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
