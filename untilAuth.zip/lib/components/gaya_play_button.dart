import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:gaya/utils/const.dart';

class GayaPlayButtonWidget extends StatelessWidget {
  const GayaPlayButtonWidget(
      {Key? key, this.onClick, this.height, this.width, this.iconPath, this.iconHeight, this.iconWidth, this.iconColor})
      : super(key: key);
  final VoidCallback? onClick;
  final double? height;
  final double? width;
  final String? iconPath;
  final double? iconHeight;
  final double? iconWidth;
  final Color? iconColor;

  @override
  Widget build(BuildContext context) {
    return IconButton(
        icon: SvgPicture.asset("Assets/icons/play_button.svg", height: height ?? 50), iconSize: height ?? 50, onPressed: onClick);
    return InkWell(
      onTap: onClick,
      child: Container(
          height: height ?? 40,
          width: width ?? 40,
          alignment: Alignment.center,
          decoration: BoxDecoration(color: kprimaryColorLight, shape: BoxShape.circle, border: Border.all(color: kWhiteColor, width: 3)),
          child: Padding(
            padding: const EdgeInsets.only(left: 2.0),
            child: SvgPicture.asset(iconPath!, height: iconHeight ?? 16, width: iconWidth ?? 16, color: iconColor ?? kprimaryColor),
          )),
    );
  }
}
