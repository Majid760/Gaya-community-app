import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:gaya/components/button.component.dart';
import 'package:gaya/components/textfield.component.dart';
import 'package:gaya/utils/language/translation.dart';
import 'package:get/get.dart';

import '../utils/const.dart';
import '../utils/textstyles.dart';

showDialogue(TextEditingController controller, String? Function(dynamic) validator, Color borderColor, VoidCallback onTap, String hinText,
    String title, BuildContext context) {
  showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text(title),
          content: SizedBox(
            height: 150,
            child: Column(
              children: [
                textField(
                    isPassword: false,
                    inputType: TextInputType.text,
                    hintText: hinText,
                    controller: controller,
                    validation: validator,
                    borderColor: borderColor),
                const SizedBox(
                  height: distance_10,
                ),
                button(
                  borderColor: kTransparentColor,
                  primaryColor: kprimaryColor,
                  title: GayaStrings.add_txt.tr,
                  textStyle: mediumText,
                  onPressed: onTap,
                ),
              ],
            ),
          ),
        );
      });
}

showDialogueThanks(BuildContext context) {
  showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: SvgPicture.asset("Assets/icons/alert.svg"),
          content: SizedBox(
            height: 150,
            child: Column(
              children: [
                const SizedBox(
                  height: distance_10,
                ),
                Text(
                  GayaStrings.thank_on_response.tr,
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
                ),
                const SizedBox(
                  height: distance_10,
                ),
                Text(
                  GayaStrings.appreciate_feedback.tr,
                  style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w400, color: Colors.grey),
                ),
                const SizedBox(
                  height: distance_10,
                ),
                button(
                  height: 50,
                  borderColor: kprimaryColor,
                  primaryColor: kprimaryColor,
                  title: GayaStrings.ok_txt.tr,
                  textStyle: mediumText,
                  onPressed: () {
                    Navigator.pop(context);
                  },
                ),
              ],
            ),
          ),
        );
      });
}
