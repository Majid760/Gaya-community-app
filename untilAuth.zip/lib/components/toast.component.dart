import 'package:flutter/cupertino.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:gaya/utils/const.dart';

toast(String mainText,Color backgroundColor)
{
Fluttertoast.showToast(
        msg: mainText,
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.BOTTOM,
        timeInSecForIosWeb: 1,
        backgroundColor: backgroundColor,
        textColor: kWhiteColor,
        fontSize: 14.0
    );
}
