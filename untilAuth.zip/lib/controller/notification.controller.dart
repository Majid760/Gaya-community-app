import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class NotificationController extends ChangeNotifier {
  List docId = [];

  final FirebaseAuth _firebaseInstance = FirebaseAuth.instance;
  late ScrollController notificationsScrollController;
  bool isNotificationsLoaded = false;

  changeNotificationsLoadedStatus() {
    if (isNotificationsLoaded) return;
    isNotificationsLoaded = true;
    notifyListeners();
  }



  void scrollToTop() {
    try {
      if (notificationsScrollController.hasClients == false) return;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        notificationsScrollController.animateTo(
          notificationsScrollController.position.minScrollExtent,
          duration: const Duration(milliseconds: 350),
          curve: Curves.bounceIn,
        );
      });
    } catch (_) {}
  }

  Future<void> getNotifications() {
    return Future.delayed(const Duration(milliseconds: 500));
  }

  Stream<QuerySnapshot<Object?>>? friendrequestNotificationsStream() {
    try {
      User? user = _firebaseInstance.currentUser;

      if (user == null) return null;

      return FirebaseFirestore.instance
          .collection('friendship')
          .where('Recieveruid', isEqualTo: user.uid)
          .where('isaccepted', isEqualTo: false)
          .snapshots();
    } catch (e) {
      return null;
    }
  }

  aproveFriendRequest(String docId) async {
    try {
      await FirebaseFirestore.instance.collection('friendship').doc(docId).update({'isaccepted': true});
      notifyListeners();
    } catch (_) {}
  }

  rejectFriendrequest(String docId) async {
    try {
      await FirebaseFirestore.instance.collection('friendship').doc(docId).delete();
      notifyListeners();
    } catch (_) {}
  }
}
