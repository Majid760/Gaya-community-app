enum HomepageSwitch { home, message, groups, notifications, profile }

enum groupDetailsSwitch { About, Discussion, Recipe, Event }

enum createRecipeEnum { one, two }

enum communityType { Public, private, secret }

enum CreateCommunityViewEnum { CommunityView1, CommunityView2, CommunityView3, CommunityView4, CommunityView5 }

enum CrownRouteEnum { home, group, savePost, postWithComments }

enum ConnectionStatus {
  online,
  offline,
}
