import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gaya/utils/const.dart';
import 'package:gaya/utils/theme/app_typography.dart';
import 'package:google_fonts/google_fonts.dart';

class GayaTheme {
  static ThemeData themeData(context) => ThemeData(
        pageTransitionsTheme: const PageTransitionsTheme(
            builders: {TargetPlatform.android: CupertinoPageTransitionsBuilder(), TargetPlatform.iOS: CupertinoPageTransitionsBuilder()}),
        fontFamily: GayaFontTheme.primaryFont,
        textButtonTheme: TextButtonThemeData(style: TextButton.styleFrom(foregroundColor: kprimaryColor)),
        textTheme: GayaFontTheme.gayaTextTheme(context),
      );
}

class GayaFontTheme {
  /// font families consts
  static const String sfProDisplay = "SFProDisplay";
  static const String notoColorEmoji = "NotoColorEmoji";

  // my font families
  static const String primaryFont = sfProDisplay;

  static const String fallBackFont = notoColorEmoji;
  static TextStyle lexendDecaFont = GoogleFonts.lexendDeca();

  static const CupertinoThemeData cupertinoApp = CupertinoThemeData(
    textTheme: CupertinoTextThemeData(
      textStyle: TextStyle(
        fontFamily: sfProDisplay,
        fontFamilyFallback: [GayaFontTheme.notoColorEmoji],
      ),
    ),
  );

  static TextTheme gayaTextTheme(BuildContext context) {
    if (kIsWeb) return Theme.of(context).textTheme;
    if (DeviceCheck.isIOS) return Theme.of(context).textTheme;
    return Theme.of(context).textTheme.copyWith(
          bodyLarge: Theme.of(context).textTheme.bodyLarge?.copyWith(
              fontFamilyFallback: [fallBackFont], fontFamily: primaryFont),
          bodyMedium: Theme.of(context).textTheme.bodyMedium?.copyWith(
              fontFamilyFallback: [fallBackFont], fontFamily: primaryFont),
          displayLarge: Theme.of(context).textTheme.displayLarge?.copyWith(
              fontFamilyFallback: [fallBackFont], fontFamily: primaryFont),
          displayMedium: Theme.of(context).textTheme.displayMedium?.copyWith(
              fontFamilyFallback: [fallBackFont], fontFamily: primaryFont),
          titleMedium: Theme.of(context).textTheme.titleMedium?.copyWith(
              fontFamilyFallback: [fallBackFont], fontFamily: primaryFont),
          titleSmall: Theme.of(context).textTheme.titleSmall?.copyWith(
              fontFamilyFallback: [fallBackFont], fontFamily: primaryFont),
        );
  }
}

TextStyle mainHeadingStyle = TextStyle(
  fontWeight: FontWeight.w500,
  fontSize: 32.sp,
  fontFamily: GayaFontTheme.primaryFont,
  color: kBlackColor,
);
TextStyle headingStyle = TextStyle(
  fontWeight: FontWeight.w700,
  fontSize: 24.sp,
  fontFamily: GayaFontTheme.primaryFont,
  color: kBlackColor,
);
TextStyle headingStyle24 = TextStyle(
  fontWeight: FontWeight.w600,
  fontSize: 24.sp,
  fontFamily: GayaFontTheme.primaryFont,
  color: kBlackColor,
);
TextStyle headingStyle24Purple = TextStyle(
  fontWeight: FontWeight.w600,
  fontSize: 24.sp,
  fontFamily: GayaFontTheme.primaryFont,
  color: const Color(0xFF8500D6),
);
TextStyle headingStyleWhite = TextStyle(
  fontWeight: FontWeight.w500,
  fontSize: 24.sp,
  fontFamily: GayaFontTheme.primaryFont,
  color: kWhiteColor,
);

TextStyle subHeading = TextStyle(
  fontWeight: FontWeight.w600,
  fontSize: 20.sp,
  fontFamily: GayaFontTheme.primaryFont,
  color: kBlackColor,
);

TextStyle bodyStyle18 = TextStyle(
  fontWeight: FontWeight.w500,
  fontSize: 18.sp,
  fontFamily: GayaFontTheme.primaryFont,
  color: kBlackColor,
);

TextStyle bodyStyle17 = TextStyle(
  fontWeight: FontWeight.w400,
  fontSize: 18.sp,
  fontFamily: GayaFontTheme.primaryFont,
  color: kSecondaryColor,
  letterSpacing: -0.41,
);

TextStyle bodyStyle = TextStyle(
  fontWeight: FontWeight.w500,
  fontSize: 16.sp,
  fontFamily: GayaFontTheme.primaryFont,
  color: kBlackColor,
);

TextStyle body1Style = TextStyle(
  fontWeight: FontWeight.w500,
  height: 1.5,
  fontSize: 16.sp,
  color: kSecondaryColor,
  fontFamily: GayaFontTheme.primaryFont,
);
TextStyle body2Style = TextStyle(
  fontWeight: FontWeight.w500,
  fontSize: 16.sp,
  color: kWhiteColor,
);
TextStyle body2StyleWeight = TextStyle(
  fontWeight: FontWeight.w600,
  fontSize: 16.sp,
  fontFamily: GayaFontTheme.primaryFont,
  color: kWhiteColor,
);

TextStyle body2StyleWeightkPrimary = TextStyle(
  fontWeight: FontWeight.w600,
  fontSize: 16.sp,
  fontFamily: GayaFontTheme.primaryFont,
  color: kprimaryColor,
);
TextStyle body2StyleWeightBlack = TextStyle(
  fontWeight: FontWeight.w600,
  fontSize: 16.sp,
  fontFamily: GayaFontTheme.primaryFont,
  color: kBlackColor,
);
TextStyle body2StyleWeighGrey = TextStyle(
  fontWeight: FontWeight.w600,
  fontSize: 16.sp,
  fontFamily: GayaFontTheme.primaryFont,
  color: disableColor,
);
TextStyle body2DisableStyle = TextStyle(
  fontWeight: FontWeight.w500,
  fontSize: 16.sp,
  fontFamily: GayaFontTheme.primaryFont,
  color: disableColor,
);
TextStyle body2EnableStyle = TextStyle(
  fontWeight: FontWeight.w500,
  fontSize: 16.sp,
  fontFamily: GayaFontTheme.primaryFont,
  color: kWhiteColor,
);

TextStyle body2EnableStyle1 = TextStyle(
  fontWeight: FontWeight.w400,
  fontSize: 16.sp,
  fontFamily: GayaFontTheme.primaryFont,
  color: kBlackColor,
);

TextStyle secondaryFontStyleBig = TextStyle(
  fontWeight: FontWeight.w500,
  fontFamily: GayaFontTheme.primaryFont,
  fontSize: 15.sp,
  color: kBlackColor,
);
TextStyle secondaryFontStyle = TextStyle(
  fontWeight: FontWeight.w500,
  fontSize: 14.sp,
  fontFamily: GayaFontTheme.primaryFont,
  color: kSecondaryColor,
);
TextStyle secondaryFontStyleWeight = TextStyle(
  fontWeight: FontWeight.w400,
  fontSize: 14.sp,
  fontFamily: GayaFontTheme.primaryFont,
  color: kSecondaryColor,
);

TextStyle secondaryFontStyleWeightHeightlow = TextStyle(
    fontWeight: FontWeight.w500,
    fontSize: 14.sp,
    fontFamily: GayaFontTheme.primaryFont,
    color: kSecondaryColor,
    height: 1.5);
TextStyle secondaryFontStyleWeightHeight = TextStyle(
    fontWeight: FontWeight.w400,
    fontSize: 14.sp,
    fontFamily: GayaFontTheme.primaryFont,
    color: kSecondaryColor,
    height: 2);
TextStyle secondaryFontStyleWeightWithHeight = TextStyle(
  fontWeight: FontWeight.w400,
  height: 1.5,
  fontSize: 14.sp,
  fontFamily: GayaFontTheme.primaryFont,
  color: kSecondaryColor,
);

TextStyle mediumText = TextStyle(
  fontWeight: FontWeight.w700,
  fontSize: 14.sp,
  fontFamily: GayaFontTheme.primaryFont,
  color: kWhiteColor,
);

TextStyle body4Style = TextStyle(
  fontWeight: FontWeight.w500,
  fontSize: 14.sp,
  fontFamily: GayaFontTheme.primaryFont,
  color: kBlackColor,
);
TextStyle body4StyleLowWeight = TextStyle(
  fontWeight: FontWeight.w400,
  fontSize: 14.sp,
  fontFamily: GayaFontTheme.primaryFont,
  color: kBlackColor,
);
TextStyle body4StyleHeight = TextStyle(
  fontWeight: FontWeight.w500,
  height: 1.5,
  fontFamily: GayaFontTheme.primaryFont,
  fontSize: 14.sp,
  color: kBlackColor,
);
TextStyle body4StyleWhite = TextStyle(
  fontWeight: FontWeight.w500,
  fontSize: 14.sp,
  fontFamily: GayaFontTheme.primaryFont,
  color: kWhiteColor,
);

TextStyle unreadStyle = TextStyle(
  fontWeight: FontWeight.w500,
  height: 1.52,
  fontSize: 14.22.sp,
  fontFamily: GayaFontTheme.primaryFont,
  color: kBlackColor,
);

TextStyle bodyStyle4KPrimary = TextStyle(
  fontWeight: FontWeight.w500,
  fontSize: 14.sp,
  fontFamily: GayaFontTheme.primaryFont,
  color: kprimaryColor,
);
TextStyle body4StylePrimary = TextStyle(
  fontWeight: FontWeight.w500,
  fontSize: 14.sp,
  fontFamily: GayaFontTheme.primaryFont,
  color: kprimaryColor,
);
TextStyle body4StyleWhiteLessWeight = TextStyle(
  fontWeight: FontWeight.w400,
  fontSize: 14.sp,
  fontFamily: GayaFontTheme.primaryFont,
  color: kWhiteColor,
);
TextStyle body4StyleWhiteMoreWeight = TextStyle(
  fontWeight: FontWeight.w600,
  fontSize: 14.sp,
  fontFamily: GayaFontTheme.primaryFont,
  color: kWhiteColor,
);
TextStyle body4StyleLessWeight = TextStyle(
  fontWeight: FontWeight.w400,
  height: 1.5,
  fontSize: 14.sp,
  fontFamily: GayaFontTheme.primaryFont,
  color: kBlackColor,
);

TextStyle body3Style = TextStyle(
  fontWeight: FontWeight.w500,
  fontSize: 12.sp,
  fontFamily: GayaFontTheme.primaryFont,
  color: kSecondaryColor,
);

TextStyle body3MStyle = TextStyle(
  fontWeight: FontWeight.w400,
  fontSize: 12.sp,
  fontFamily: GayaFontTheme.primaryFont,
  color: kSecondaryColor,
);

TextStyle titleStyleWhite = TextStyle(
  fontWeight: FontWeight.w500,
  fontSize: 12.sp,
  fontFamily: GayaFontTheme.primaryFont,
  color: kWhiteColor,
);

TextStyle titleStyleWhiteWeight = TextStyle(
  fontWeight: FontWeight.w600,
  fontSize: 12.sp,
  fontFamily: GayaFontTheme.primaryFont,
  color: kWhiteColor,
);
TextStyle titleStyleBlack = TextStyle(
  fontWeight: FontWeight.w600,
  fontSize: 12.sp,
  fontFamily: GayaFontTheme.primaryFont,
  color: kBlackColor,
);

TextStyle body5StylePrimary = TextStyle(
  fontWeight: FontWeight.w400,
  fontSize: 12.sp,
  fontFamily: GayaFontTheme.primaryFont,
  color: kprimaryColor,
);

TextStyle yellowebodyStyle = TextStyle(
  fontWeight: FontWeight.w400,
  fontSize: 12.sp,
  fontFamily: GayaFontTheme.primaryFont,
  color: kYellowColor,
);
TextStyle dark12 = TextStyle(
  fontWeight: FontWeight.w500,
  fontSize: 12.sp,
  fontFamily: GayaFontTheme.primaryFont,
  color: kBlackColor,
);

TextStyle darkWhite12 = TextStyle(
  fontWeight: FontWeight.w500,
  fontSize: 12.sp,
  fontFamily: GayaFontTheme.primaryFont,
  color: kWhiteColor,
);

TextStyle smallPrimaryColor = TextStyle(
  fontWeight: FontWeight.w400,
  fontSize: 10.sp,
  fontFamily: GayaFontTheme.primaryFont,
  color: kprimaryColor,
);
TextStyle bottomBarUnSelectedTextStyle = TextStyle(
  fontWeight: FontWeight.w500,
  fontSize: 10.sp,
  fontFamily: GayaFontTheme.primaryFont,
  color: const Color(0xFF8E8E93),
);

TextStyle analyticsPercentageRed = TextStyle(
  fontWeight: FontWeight.w500,
  fontSize: 10.sp,
  fontFamily: GayaFontTheme.primaryFont,
  color: const Color(0xFFFF3B30),
);
TextStyle analyticsPercentageGreen = TextStyle(
  fontWeight: FontWeight.w500,
  fontSize: 10.sp,
  fontFamily: GayaFontTheme.primaryFont,
  color: const Color(0xFF34C759),
);
TextStyle analyticsPercentageGrey = TextStyle(
  fontWeight: FontWeight.w500,
  fontSize: 10.sp,
  fontFamily: GayaFontTheme.primaryFont,
  color: const Color(0xFF8E8E93),
);
TextStyle bottomBarSelectedTextStyle = TextStyle(
  fontWeight: FontWeight.w500,
  fontSize: 10.sp,
  fontFamily: GayaFontTheme.primaryFont,
  color: const Color(0xFF8500D6),
);

final linkStyle = body4StyleLessWeight.copyWith(color: kLinkColor);

final hashTagStyle = body4StyleLessWeight.copyWith(color: kHashTagColor);
final atTheRateTagStyle = body4StyleLessWeight.copyWith(color: kHashTagColor);
