// ignore_for_file: use_build_context_synchronously

import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gaya/components/button.component.dart';
import 'package:gaya/components/snackbar.component.dart';
import 'package:gaya/controller/app_config_controller.dart';
import 'package:gaya/controller/communities.controller.dart';
import 'package:gaya/controller/firebase_analytics_controller.dart';
import 'package:gaya/controller/group.controller.dart';
import 'package:gaya/model/communities.memebers.model.dart';
import 'package:gaya/model/community.model.dart';
import 'package:gaya/model/create.post.model.dart';
import 'package:gaya/model/user.model.dart';
import 'package:gaya/routing/getx_route_methods.dart';
import 'package:gaya/shared/view/widget/custom_post_options_list_tile.dart';
import 'package:gaya/shared/view/widget/gaya_alert_dialog.dart';
import 'package:gaya/shared/view/widget/gaya_snackbar.dart';
import 'package:gaya/utils/asset_images.dart';
import 'package:gaya/utils/assets_icons.dart';
import 'package:gaya/utils/const.dart';
import 'package:gaya/utils/strings.dart';
import 'package:gaya/utils/theme/app_colors.dart';
import 'package:gaya/utils/theme/app_spaces.dart';
import 'package:gaya/utils/theme/app_typography.dart';
import 'package:gaya/view/community/controllers/secret_community_controller.dart';
import 'package:get/get.dart';
import 'package:get/get_rx/src/rx_workers/utils/debouncer.dart';
import 'package:intl/intl.dart' as intl;
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

import '../bindings/initializing_dependencies.dart';
import '../components/progress.indicator.component.dart';
import '../services/services.dart';
import '../shared/constant/string_constant.dart';
import '../shared/service/cache_service/cache_services.dart';
import '../shared/view/widget/gaya_button_alert_dialog.dart';
import '../shared/view/widget/gaya_message_popup_modalsheet.dart';
import '../shared/view/widget/gaya_report_dialog.dart';
import '../view/community/components/community_joined_view.dart';
import '../view/community/components/give_crown_to_post_widget.dart';
import 'gaya_text_widget.dart';
import 'language/translation.dart';
import 'textstyles.dart';

class Methods {
  static final Services _firestoreServices = Services();

  static void showCommunityOperationModalSheet({
    required Community? communityModel,
    required BuildContext context,
    VoidCallback? onPin,
    VoidCallback? onHideUnhide,
    bool? isPinned,
    bool showPin = true,
    bool showReport = true,
    bool showNotification = true,
    bool showLeave = true,
    bool showHideUnhide = true,
    bool isHidden = false,
  }) async {
    final padding = const EdgeInsets.only(bottom: 8).r;
    showCircularModalSheet(
        context,
        FutureBuilder<CommunityMembership?>(
            future: _firestoreServices.getUserMembershipByCommunityId(communityId: communityModel?.communityId ?? ""),
            builder: (context, rawMembership) {
              if (rawMembership.connectionState == ConnectionState.waiting) {
                return SizedBox(
                  height: MediaQuery.of(context).size.height * .2,
                  child: const PrimaryCircularProgressIndicator.centered(),
                );
              }
              final membership = rawMembership.data;
              return Column(
                children: [
                  /// pin unpin community
                  if (showPin)
                    GayaListTileButton(
                        title: ((isPinned ?? false) ? GayaStrings.unpin_community : GayaStrings.pin_community).tr,
                        subtitle: (GayaStrings.pin_community_to_top).tr,
                        margin: padding,
                        leading: SvgIconWidget.pinOutlinee(height: 2.r, width: 2.r),
                        onTap: () {
                          GayaSnackBar.show(
                              context: context,
                              type: GayaSnackBarType.pin,
                              text: "${GayaStrings.community.tr} ${isPinned ?? false ? GayaStrings.unpinned.tr : GayaStrings.pinned.tr}");

                          Navigator.pop(context);
                          if (onPin != null) {
                            onPin();
                          }
                        }),

                  // report community
                  if (showReport && AppConfigurationController.to.isAdminOrModerator(communityId: communityModel?.communityId) == false)
                    GayaListTileButton(
                        title: (GayaStrings.report_community).tr,
                        subtitle: (GayaStrings.im_concerned_about_this_community).tr,
                        margin: padding,
                        leading: SvgIcons.problem(height: 20.r, width: 20.r),
                        onTap: () async {
                          final GroupController report = GroupController();
                          bool isReported = await report.didCommunityAlreadyReported(communityModel!.communityId!);
                          if (!isReported) {
                            reportTextFieldBottomModal(context, onSubmit: (String reportMsg) async {
                              Navigator.pop(context);
                              await report.reportCommunity(communityModel.communityId!, context, reportMsg);
                            });
                          } else {
                            snackBar(context, GayaStrings.community_already_reported.tr, kprimaryColor);
                            Navigator.pop(context);
                          }
                        }),

                  // enable disable notification
                  if (showNotification)
                    StatefulBuilder(builder: (context, updateState) {
                      return GayaListTileButton(
                          title: ((membership?.isNotificationEnabled ?? false)
                                  ? GayaStrings.turn_off_notification_community
                                  : GayaStrings.turn_on_notification_community)
                              .tr,
                          subtitle: (GayaStrings.subscribe_this_community).tr,
                          margin: padding,
                          leading: SvgIconWidget.bellOutline1(height: 20.r, width: 20.r),
                          onTap: () {
                            final isEnabled = !(membership?.isNotificationEnabled ?? false);
                            membership?.copyWith(isNotificationEnabled: membership.isNotificationEnabled = isEnabled);
                            _firestoreServices.changeNotificationSubscription(communityModel?.communityId ?? "", isEnabled);
                            GayaSnackBar.show(
                                context: context,
                                type: GayaSnackBarType.notification,
                                text: "${GayaStrings.notification.tr} ${isEnabled ? GayaStrings.enabled.tr : GayaStrings.disabled.tr}");
                            Navigator.pop(context);
                          });
                    }),

                  // leave community
                  if (showLeave && membership?.isAdmin != true)
                    GayaListTileButton(
                      title: "${GayaStrings.leave_txt.tr} ${communityModel?.communityName ?? ""}",
                      margin: padding,
                      leading: SvgIconWidget.logoutOutline(height: 20.r, width: 20.r),
                      onTap: () =>
                          showLeaveCommunityAlert(communityModel: communityModel, context: context, onLeave: () => Navigator.pop(context)),
                    ),

                  // hide community
                  if (showHideUnhide)
                    GayaListTileButton(
                        title: isHidden ? Gaya_Strings.unhide_this_community : GayaStrings.hide_this_community.tr,
                        subtitle: isHidden ? Gaya_Strings.i_want_to_see_this_community : GayaStrings.i_dont_want_to_see_this_community.tr,
                        margin: padding,
                        leading: SvgIconWidget.eyeOffOutline(height: 20.r, width: 20.r),
                        onTap: () {
                          Navigator.pop(context);
                          if (onHideUnhide != null) {
                            onHideUnhide();
                            return;
                          }
                          AppConfigurationController.to.hideOrUnHideCommunity(communityId: communityModel?.communityId);
                          DefaultSnackBar.hideOrUnHideCommunity(context: context);
                        }),

                  SizedBox(height: 10.r),
                ],
              );
            }));
  }

  static void showLeaveCommunityAlert(
      {required Community? communityModel, required BuildContext context, required VoidCallback onLeave}) async {
    final GroupController controller = GroupController();
    if (communityModel?.communityId == null) return;
    GayaAlertDialog(
        context: context,
        title: GayaStrings.leave_community.tr,
        body: "${GayaStrings.Do_you_want_to_leave.tr} ${communityModel?.communityName ?? ""} ${GayaStrings.community_join_later.tr}",
        okButtonText: GayaStrings.leave_txt.tr,
        tapOnOk: () async {
          try {
            GayaSnackBar.show(
                context: context,
                type: GayaSnackBarType.communities,
                text: Gaya_Strings.leave_communityByName(communityName: communityModel?.communityName ?? ""));
            Navigator.pop(context);
            onLeave();

            await controller.leaveTheCommunity(communityModel!.communityId!);
            await controller.deleteTheUserFromCommunity(communityModel.communityId!);
            await AppConfigurationController.to.leaveCommunity(communityModel.communityId!);
          } catch (_) {}
        },
        tapOnCancel: () {
          Navigator.pop(context);
        },
        cancleButtonText: GayaStrings.cancel_txt.tr);
  }

  static void showCommunityNotificationModalSheet({required Community community, required BuildContext context}) {
    showCircularModalSheet(
        context,
        FutureBuilder<CommunityMembership?>(
            future: _firestoreServices.getUserMembershipByCommunityId(communityId: community.communityId ?? ""),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return SizedBox(
                  height: MediaQuery.of(context).size.height * .1,
                  child: const PrimaryCircularProgressIndicator.centered(),
                );
              }
              final membership = snapshot.data;
              return SafeArea(
                child: Column(
                  children: [
                    Text(GayaStrings.community_subscription.tr, style: GayaTypography.titleMedium),
                    SizedBox(height: MySpaces.gap2.h),
                    StatefulBuilder(builder: (context, updateState) {
                      return GayaSwitchButtonListTile(
                          title: GayaStrings.new_community_posts.tr,
                          subtitle: GayaStrings.anonymous_usreceive_alerts_for_any_new_updates_communityer.tr,
                          value: membership?.isNotificationEnabled ?? false,
                          onChanged: (value) {
                            final isEnabled = !(membership?.isNotificationEnabled ?? false);
                            membership?.copyWith(isNotificationEnabled: membership.isNotificationEnabled = isEnabled);
                            _firestoreServices.changeNotificationSubscription(community.communityId ?? "", isEnabled);
                            updateState(() {});
                          });
                    }),
                    SizedBox(height: MySpaces.gap2.h),
                  ],
                ),
              );
            }));
  }

  // change auto post approval status for a community
  static void showCommunityAutoPostApprovalModalSheet({required Community community, required BuildContext context}) {
    showCircularModalSheet(
        context,
        FutureBuilder<Community?>(
            future: _firestoreServices.getCommunityDetailsModel(community.communityId ?? ""),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return SizedBox(
                  height: MediaQuery.of(context).size.height * .1,
                  child: const PrimaryCircularProgressIndicator.centered(),
                );
              }
              if (snapshot.data == null) {
                return SizedBox(
                  height: MediaQuery.of(context).size.height * .1,
                  child: Center(
                    child: Text(GayaStrings.something_went_wrong_fetching_community.tr),
                  ),
                );
              }
              final communityModel = snapshot.data;
              return SafeArea(
                child: Column(
                  children: [
                    Text(GayaStrings.approval_settings.tr, style: GayaTypography.titleMedium),
                    SizedBox(height: MySpaces.gap2.h),
                    StatefulBuilder(builder: (context, updateState) {
                      return GayaSwitchButtonListTile(
                          title: GayaStrings.post_approvals.tr,
                          subtitle: GayaStrings.post_approval_description.tr,
                          value: communityModel?.isPostApprovalNeeded ?? false,
                          onChanged: (value) {
                            final isEnabled = !(communityModel?.isPostApprovalNeeded ?? false);
                            communityModel?.copyWith(isPostApprovalNeeded: communityModel.isPostApprovalNeeded = isEnabled);
                            // createCommunity.to.update(UserModel.to.copyWith(allowToDm: isEnabled));
                            _firestoreServices.toggleCommunityAutoPostsApprovalStatus(communityModel?.communityId ?? "", isEnabled);
                            updateState(() {});
                          });
                    }),
                    SizedBox(height: MySpaces.gap2.h),
                  ],
                ),
              );
            }));
  }

  static void showDmStatusSettingModalSheet({required BuildContext context}) {
    showCircularModalSheet(
        context,
        FutureBuilder<UserModel?>(
            future: _firestoreServices.getUserById(UserModel.to.uId ?? ""),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return SizedBox(
                  height: MediaQuery.of(context).size.height * .1,
                  child: const PrimaryCircularProgressIndicator.centered(),
                );
              }
              if (snapshot.data == null) {
                return SizedBox(
                  height: MediaQuery.of(context).size.height * .1,
                  child: Center(
                    child: Text(GayaStrings.something_went_wrong_fetching_profile.tr),
                  ),
                );
              }
              final userModel = snapshot.data;
              return SafeArea(
                child: Column(
                  children: [
                    Text(GayaStrings.dm_setting.tr, style: GayaTypography.titleMedium),
                    SizedBox(height: MySpaces.gap2.h),
                    StatefulBuilder(builder: (context, updateState) {
                      return GayaSwitchButtonListTile(
                          title: GayaStrings.change_dm_status.tr,
                          subtitle: GayaStrings.allow_others_to_send_to_send_dm.tr,
                          value: userModel?.allowToDm ?? true,
                          onChanged: (value) {
                            final isEnabled = !(userModel?.allowToDm ?? true);
                            userModel?.copyWith(allowToDm: userModel.allowToDm = isEnabled);
                            UserModel.to.update(UserModel.to.copyWith(allowToDm: isEnabled));
                            _firestoreServices.toggleDmSettingStatus(UserModel.to.uId ?? "", isEnabled);
                            updateState(() {});
                          });
                    }),
                    SizedBox(height: MySpaces.gap2.h),
                  ],
                ),
              );
            }));
  }

  static void showLanguageSwitchModalSheet({required BuildContext context}) {
    late String selectedLanguageCode;
    showCircularModalSheet(
        context,
        SafeArea(
          child: Column(
            children: [
              Text(GayaStrings.language.tr, style: GayaTypography.titleMedium),
              SizedBox(height: MySpaces.gap2.h),
              GetBuilder<LocalizationController>(
                  autoRemove: false,
                  builder: (controller) {
                    selectedLanguageCode = controller.isHebrew ? "he" : "en";

                    /// radio buttons
                    return Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8).r,
                      child: Column(
                        children: [
                          RadioListTile(
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                            controlAffinity: ListTileControlAffinity.trailing,
                            title: Text("Hebrew", style: GayaTypography.body2),
                            contentPadding: const EdgeInsets.symmetric(horizontal: 12).r,
                            visualDensity: const VisualDensity(vertical: -2),
                            groupValue: selectedLanguageCode,
                            enableFeedback: false,
                            autofocus: true,
                            activeColor: kprimaryColor,
                            value: "he",
                            onChanged: (_) => controller.toggleLanguage(),
                          ),
                          RadioListTile(
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                            controlAffinity: ListTileControlAffinity.trailing,
                            title: Text("English", style: GayaTypography.body2),
                            contentPadding: const EdgeInsets.symmetric(horizontal: 12).r,
                            visualDensity: const VisualDensity(vertical: -2),
                            groupValue: selectedLanguageCode,
                            enableFeedback: false,
                            autofocus: true,
                            activeColor: kprimaryColor,
                            value: "en",
                            onChanged: (_) => controller.toggleLanguage(),
                          ),
                          SizedBox(height: MySpaces.gap6.r),
                          // end of dob and gender
                          button(
                              height: 50.r,
                              borderColor: kTransparentColor,
                              // textStyle: loginController.styleEmail,
                              textStyle: body2EnableStyle,
                              title: GayaStrings.continue_txt.tr,
                              onPressed: () => Navigator.pop(context),
                              primaryColor: kprimaryColor),
                          const SizedBox(height: distance_20),
                        ],
                      ),
                    );
                  }),
              SizedBox(height: MySpaces.gap2.h),
            ],
          ),
        ));
  }

  /// update post topics
  /// onDone is required to update the post topics in the post model
  static void showTopicPostUpdateModalSheet(
      {required Community community, required Post post, required BuildContext context, required Function(Post) onDoneButtonPressed}) {
    final services = Services();
    showModalBottomSheet(
      context: context,
      clipBehavior: Clip.antiAlias,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.only(topLeft: Radius.circular(13.0), topRight: Radius.circular(13.0)),
      ),
      builder: (modalContext) => SafeArea(
        child: FutureBuilder<Community?>(
            initialData: community,
            future: services.getCommunityDetailsModel(community.communityId!),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return SizedBox(
                  height: MediaQuery.of(context).size.height * .2,
                  child: const Center(child: CircularProgressIndicator()),
                );
              }
              final community = snapshot.data;
              return Container(
                padding: const EdgeInsets.all(20),
                width: MediaQuery.of(context).size.width,
                decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(topLeft: Radius.circular(13.0), topRight: Radius.circular(13.0)),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Container(height: 5, width: 40, decoration: const ShapeDecoration(color: borderColor, shape: StadiumBorder())),
                    const SizedBox(
                      height: distance_10,
                    ),
                    Text(GayaStrings.post_topic.tr, style: bodyStyle),
                    const SizedBox(height: distance_15),
                    (community == null || community.communityTopicList == null)
                        ? SizedBox(
                            height: MediaQuery.of(context).size.height * 0.1,
                            child: Center(
                              child: Text(GayaStrings.no_topic_found.tr, style: bodyStyle),
                            ),
                          )
                        : (community.communityTopicList!.isEmpty)
                            ? SizedBox(
                                height: MediaQuery.of(context).size.height * 0.1,
                                child: Center(child: Text(GayaStrings.no_topic_found_community.tr, style: bodyStyle)),
                              )
                            : SizedBox(
                                height: MediaQuery.of(context).size.height * 0.3,
                                child: StatefulBuilder(builder: (context, update) {
                                  return ListView.builder(
                                      itemCount: community.communityTopicList?.length ?? 0,
                                      // padding: const EdgeInsets.symmetric(horizontal: distance_15, vertical: distance_10),
                                      itemBuilder: (context, index) {
                                        String singleTopic = community.communityTopicList?[index] ?? '';

                                        return CheckboxListTile(
                                            checkColor: kWhiteColor,
                                            activeColor: kprimaryColor,
                                            controlAffinity: ListTileControlAffinity.leading,
                                            contentPadding: const EdgeInsets.symmetric(horizontal: 0),
                                            value:
                                                (post.postTopicList == null || !post.postTopicList!.contains(singleTopic)) ? false : true,
                                            title: Text(singleTopic, style: body2StyleWeightBlack),
                                            onChanged: (newValue) {
                                              if (post.postTopicList == null) {
                                                post.postTopicList = [singleTopic];
                                              } else {
                                                if (post.postTopicList!.contains(singleTopic)) {
                                                  post.postTopicList!.remove(singleTopic);
                                                } else {
                                                  post.postTopicList!.add(singleTopic);
                                                }
                                              }
                                              update(() {});
                                            });
                                      });
                                }),
                              ),
                    const SizedBox(
                      height: distance_15,
                    ),
                    button(
                        title: GayaStrings.done.tr,
                        onPressed: () async {
                          if (community?.communityTopicList == null && post.postTopicList == null) {
                            Navigator.pop(modalContext);
                          }

                          onDoneButtonPressed(post);
                          if (modalContext.mounted) {
                            Navigator.pop(modalContext);
                          }

                          // save topics locally in post lists to do
                        },
                        borderColor: kTransparentColor,
                        height: 48,
                        primaryColor: kprimaryColor,
                        textStyle: TextStyle(color: kWhiteColor, fontWeight: FontWeight.w500, fontSize: 14.sp),
                        width: MediaQuery.of(context).size.width),
                    const SizedBox(
                      height: distance_15,
                    ),
                  ],
                ),
              );
            }),
      ),
    );
  }

  /// Show a crown left modal sheet.
  static showCrownsTotalModalSheet({required BuildContext? ctx}) {
    if (ctx?.mounted == true && UserModel.to.uId != null) {
      AnalyticsController.to.instance.logViewCrownRemainingSheet();
      showCircularModalSheet(ctx ?? Get.context!, const GiveCrownToPostWidget());
    }
  }

  static final Debouncer _debouncer = Debouncer(delay: 200.milliseconds);

  //// routing to single community
  //// checking fingerprint for secret communities
  static routeToGroup({required Community community, bool clearPreviousRoutes = false, bool shouldReplace = false}) async {
    /// route to group
    if (community.communityType == 'Secret' && await AppConfigurationController.to.isFingerprintEnabled(community.communityId) != false) {
      _debouncer.call(() async {
        Get.lazyPut<SecretCommunityController>(() => SecretCommunityController(community: community));

        final fingerPrintStatus = await Get.find<SecretCommunityController>().checkFingerprintStatus();

        if (fingerPrintStatus == SupportState.supported) {
          String authorized =
              // ignore: use_build_context_synchronously
              await Get.find<SecretCommunityController>().authenticateWithBiometrics(Get.context);
          if (authorized == 'Authorized' || authorized == 'מורשה') {
            Routes.groupView(community: community, clearPreviousRoutes: clearPreviousRoutes, shouldReplace: shouldReplace);
          }
          print('finger print status $authorized');
        } else if (fingerPrintStatus == SupportState.unsupported) {
          Routes.groupView(community: community, clearPreviousRoutes: clearPreviousRoutes, shouldReplace: shouldReplace);
        }
        print('finger print status $fingerPrintStatus');
      });
    } else {
      Routes.groupView(community: community, clearPreviousRoutes: clearPreviousRoutes, shouldReplace: shouldReplace);
    }
  }

  /// If the user is not a member of the community, it will show a modal bottom sheet to join the community.
  /// if the user is a member of the community, it will navigate to the community.
  /// if the community is not found, it will show a snackbar.
  static showModalSheetToJoinCommunity(
      {Community? communityModel, required String? communityId, required BuildContext ctx, bool isFromDeepLink = false}) async {
    if (communityId == null) return;
    final services = Services.to;

    AnalyticsController.to.instance.logViewCommunityModal(communityId);
    if (AppConfigurationController.to.isMemberOfCommunity(communityId)) {
      debugPrint('is member of community');
      final Community community = AppConfigurationController.to.joinedCommunities
          .firstWhere((element) => element.communityId == communityId, orElse: () => Community());

      /// if the community is found, it will navigate to the community view
      if (community.communityId != null && community.communityName != null && community.communityName?.trim().isBlank == false) {
        /// todo: handle no internet connection
        if (communityModel == null) {
          return Methods.routeToGroup(community: community);
        } else {
          try {
            final communityDetail = await services.getCommunitiesDetails(communityId);
            if (communityDetail?.data() != null) {
              Community commModel = Community.fromMap(communityDetail?.data() as Map<String, dynamic>);
              return Methods.routeToGroup(community: commModel);
            } else {}
          } catch (_) {}
        }
      }
    }
    if (ctx.mounted) {
      showCircularModalSheet(
          ctx,
          FutureBuilder<Community?>(
              future: _firestoreServices.getCommunityDetailsModel(communityId),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return SizedBox(
                    height: MediaQuery.of(context).size.height * 0.2,
                    child: const PrimaryCircularProgressIndicator.centered(),
                  );
                }
                final community = snapshot.data;
                // if the community is not found, it will not found
                if (community == null || community.communityId == null) {
                  return GayaMessagePopUpModalSheet(title: GayaStrings.community_not_exists.tr);
                }

                /// If community is of secret type and not from deep link, then return
                /// as secret community can only be accessed from deep link
                if (community.communityType == "Secret" && !isFromDeepLink) {
                  return GayaMessagePopUpModalSheet(
                    title: GayaStrings.community_not_exists_permission.tr,
                  );
                }

                /// if the community is found, it will show the community details
                /// get the total members of the community to avoid multiple calls to the database
                /// while rebuilding the widget by readMore/less
                final joinCommunity = Provider.of<GroupController>(context, listen: false);
                final communityMembership = joinCommunity.getUserMembershipByCommunityId(communityId: community.communityId ?? "");

                /// disable readMore or readLess if text is less than 240 characters
                final canReadMore = GayaTextWidget.canReadMore((community.communityDescription ?? ""));
                bool isLoading = false;

                return SafeArea(
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 20).r,
                    width: MediaQuery.of(context).size.width,
                    child: StatefulBuilder(builder: (context, readMore) {
                      return SingleChildScrollView(
                        physics: const ClampingScrollPhysics(),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Text(community.communityName ?? "", style: CustomTypography.title24W600),
                            SizedBox(height: 8.h),
                            Row(
                              children: [
                                community.communityType == "Private"
                                    ? SvgIconWidget.lockOutline1(height: 16.h, width: 16.w)
                                    : SvgIconWidget.lockUnlockedOutline(height: 16.h, width: 16.w),
                                const SizedBox(width: 10),
                                Text(
                                    community.communityType.isBlank == true
                                        ? "${GayaStrings.public_txt} ${GayaStrings.community}".tr
                                        : "${community.communityType?.toLowerCase().toString() ?? GayaStrings.public_txt} ${GayaStrings.community}"
                                            .tr,
                                    style: CustomTypography.community.copyWith(height: 2)),
                                Container(
                                    width: 1,
                                    height: 10.h,
                                    margin: const EdgeInsets.symmetric(horizontal: 10).r,
                                    decoration: const BoxDecoration(color: kBaseGrey)),
                                Text(
                                    (community.communityMembers ?? 0) > 1
                                        ? " ${community.communityMembers ?? 0} ${GayaStrings.members_txt.tr}"
                                        : "${community.communityMembers ?? 0} ${GayaStrings.members_txt.tr}",
                                    style: CustomTypography.community.copyWith(height: 2)),
                              ],
                            ),
                            SizedBox(height: MySpaces.gap2.h),
                            Text(GayaStrings.about.tr, style: CustomTypography.title24W600.copyWith(fontSize: 16.sp, height: 1.5)),
                            SizedBox(height: MySpaces.gap2.h),
                            GayaTextWidget(
                              (community.communityDescription ?? ""),
                              style: CustomTypography.postCaptionStyle,
                              isReadMore: context.read<CommunitiesController>().isReadMore == false,
                              trimCollapsedText: " ",
                              trimExpandedText: "",
                              callback: (isReadMore) {
                                context.read<CommunitiesController>().isReadMore = isReadMore;
                                readMore(() {});
                              },
                              key: UniqueKey(),
                            ),
                            const SizedBox(height: 10),
                            button(
                                onPressed: (canReadMore == false)
                                    ? null
                                    : () {
                                        readMore(() => context.read<CommunitiesController>().isReadMore =
                                            !context.read<CommunitiesController>().isReadMore);
                                      },
                                height: 50.h,
                                title: (context.read<CommunitiesController>().isReadMore == false
                                    ? GayaStrings.read_more.tr
                                    : GayaStrings.read_less.tr),
                                textStyle: CustomTypography.postCaptionStyle
                                    .copyWith(color: canReadMore ? AppColors.black : AppColors.secondary2, fontWeight: FontWeight.w500),
                                primaryColor: kBaseGrey,
                                borderColor: kTransparentColor),
                            const SizedBox(height: 10),
                            StatefulBuilder(
                              builder: (BuildContext context, update) {
                                return FutureBuilder<CommunityMembership?>(
                                    future: communityMembership,
                                    builder: (context, value) {
                                      final membership = value.data;
                                      debugPrint("membership: ${membership?.toMap()}");
                                      if ((membership?.isMember == true)) {
                                        Navigator.pop(context);
                                        AppConfigurationController.to.joinACommunity(community);
                                        SchedulerBinding.instance.addPostFrameCallback((_) {
                                          Methods.routeToGroup(community: community);
                                        });
                                      }
                                      return buttonIcon(
                                        iconString: IconsAssetsPathUtils.userPlusOutline,
                                        iconColor: AppColors.white,
                                        height: 50.h,
                                        isLoading: isLoading || value.connectionState == ConnectionState.waiting,
                                        textStyle: CustomTypography.postCaptionStyle.copyWith(
                                          color: AppColors.white,
                                          fontWeight: FontWeight.w500,
                                        ),
                                        borderColor: kTransparentColor,
                                        title:
                                            membership?.isMember == false ? GayaStrings.waiting_approval.tr : GayaStrings.join_community.tr,
                                        primaryColor: kprimaryColor,
                                        onPressed: () async {
                                          if (membership?.isMember == false) {
                                            return;
                                          }
                                          if (UserModel.to.uId == null) {
                                            Routes.requiredLoginView();
                                            return;
                                          }
                                          bool shouldNavigateToGroup = false;

                                          try {
                                            // already member
                                            if (membership?.isMember == true) {
                                              AppConfigurationController.to.joinACommunity(community);
                                              SchedulerBinding.instance
                                                  .addPostFrameCallback((_) => Methods.routeToGroup(community: community));
                                              return;
                                            }
                                            isLoading = true;
                                            update(() {});

                                            /// if the community is not fetched, then fetch it
                                            /// and update the community, this happened when the community
                                            /// is having issue with fetching so upon joining it will
                                            /// fetch the community details and update it
                                            if (community.communityName == null) {
                                              final reFetchedCommunity = await _firestoreServices.getCommunityDetailsModel(communityId);
                                              if (reFetchedCommunity != null) {
                                                community.updateWith(community: reFetchedCommunity);
                                                update(() {});
                                              }
                                            }

                                            // if public.
                                            if (community.communityType == "Public") {
                                              AppConfigurationController.to.joinPublicCommunity(community);
                                              await joinCommunity.joinThePublicGroup(communityId);
                                              await joinCommunity.addCommunityToUserList(community.communityName ?? "", communityId);
                                              shouldNavigateToGroup = true;

                                              // logging member community joined log
                                              AnalyticsController.to.instance.logUserAddedToCommunity(
                                                communityId: communityId,
                                                userId: UserModel.to.uId ?? '',
                                              );

                                              if (context.mounted) {
                                                GayaSnackBar.show(
                                                    context: context,
                                                    type: GayaSnackBarType.communities,
                                                    text: GayaStrings.join_community_success.tr);
                                              }

                                              // onJoinedSuccessCallback();
                                            } else {
                                              await joinCommunity.joinTheGroup(communityId);
                                              await joinCommunity.sendCommunityJoiningApprovalNotificationToAdmin(community);

                                              // if (context.mounted) {
                                              //
                                              //   GayaSnackBar.show(
                                              //       context: context,
                                              //       type: GayaSnackBarType.communities,
                                              //       text: GayaStrings.request_send_success.tr);
                                              // }
                                            }
                                          } catch (e) {
                                            GayaSnackBar.show(
                                                context: context,
                                                type: GayaSnackBarType.communities,
                                                text: GayaStrings.unable_join_community.tr);
                                          } finally {
                                            isLoading = false;
                                            if (context.mounted) {
                                              Navigator.pop(context);
                                            }
                                            if (shouldNavigateToGroup) {
                                              SchedulerBinding.instance.addPostFrameCallback((_) {
                                                Methods.routeToGroup(community: community);
                                                return;
                                              });
                                            } else {
                                              Get.to(() => JoiningApprovalScreen(community: community), transition: Transition.topLevel);
                                            }
                                          }
                                        },
                                      );
                                    });
                              },
                            ),
                            MySpaces.bottom
                          ],
                        ),
                      );
                    }),
                  ),
                );
              }));
    }
  }

  static bool isRTL(String text) => intl.Bidi.detectRtlDirectionality(text);

  static List<List<T>> generateListOfChunks<T>(List<T> inList) {
    List<List<T>> outList = [];
    List<T> tmpList = [];
    int counter = 0;

    for (int current = 0; current < inList.length; current++) {
      if (counter != 10) {
        tmpList.add(inList[current]);
        counter++;
      }
      if (counter == 10 || current == inList.length - 1) {
        outList.add(tmpList.toList());
        tmpList.clear();
        counter = 0;
      }
    }

    return outList;
  }

  static Future showModalSheetComment(BuildContext context, VoidCallback onReport,
      {VoidCallback? onCommentDelete, VoidCallback? onReply}) async {
    showModalBottomSheet(
        context: context,
        builder: (context) {
          return SingleChildScrollView(
            child: SafeArea(
              child: Column(
                children: [
                  ListTile(
                    leading: const Icon(Icons.report),
                    title: Text(GayaStrings.report_comment.tr),
                    onTap: () {
                      onReport();
                      // Navigator.pop(context);
                    },
                  ),
                  Visibility(
                    visible: onReply != null,
                    child: ListTile(
                      leading: const Icon(Icons.reply),
                      title: Text(GayaStrings.reply_comment.tr),
                      onTap: () {
                        Navigator.pop(context);
                        onReply!();
                      },
                    ),
                  ),
                  Visibility(
                    visible: onCommentDelete != null,
                    child: ListTile(
                      leading: const Icon(Icons.delete),
                      title: Text(GayaStrings.delete_comment.tr),
                      onTap: () {
                        onCommentDelete!();
                        Navigator.pop(context);
                      },
                    ),
                  ),
                  //close
                  ListTile(
                    leading: const Icon(Icons.close),
                    title: Text(GayaStrings.close.tr),
                    onTap: () {
                      Navigator.pop(context);
                    },
                  ),
                  MySpaces.bottom
                ],
              ),
            ),
          );
        });
  }

  static Future showModalSheetProfilePicture(BuildContext context, VoidCallback? onChangePhoto, VoidCallback? onViewPhoto) async {
    if (DeviceCheck.isIOS) {
      final sheet = CupertinoActionSheet(
        actions: [
          CupertinoActionSheetAction(
            child: CupertinoListTile(
              title: Text(GayaStrings.view_photo.tr,
                  style: GayaTypography.titleMedium.copyWith(color: AppColors.cupertinoBlue, fontWeight: FontWeight.w400)),
              leading: SvgIconWidget.cameraOutline(color: AppColors.cupertinoBlue),
              // leading: SvgPicture.asset(Assets.assets.icons.picturePickerIcon, color: AppColors.cupertinoBlue),
            ),
            onPressed: () => onViewPhoto!(),
          ),
          CupertinoActionSheetAction(
            child: CupertinoListTile(
              title: Text(GayaStrings.change_photo.tr,
                  style: GayaTypography.titleMedium.copyWith(color: AppColors.cupertinoBlue, fontWeight: FontWeight.w400)),
              leading: SvgIconWidget.imageOutline(color: AppColors.cupertinoBlue),
              // leading: SvgPicture.asset(Assets.assets.icons.videoPickerIcon, color: AppColors.cupertinoBlue),
            ),
            onPressed: () => onChangePhoto!(),
          ),
        ],
        cancelButton: CupertinoActionSheetAction(
          child: Text(GayaStrings.cancel_txt.tr,
              style: GayaTypography.titleMedium.copyWith(color: AppColors.error, fontWeight: FontWeight.w400)),
          onPressed: () => Navigator.pop(context),
        ),
      );

      showCupertinoModalPopup(context: context, builder: (context) => sheet);
      return;
    }

    showModalBottomSheet(
        context: context,
        builder: (context) {
          return SingleChildScrollView(
            child: SafeArea(
              child: Column(
                children: [
                  ListTile(
                    leading: SvgIconWidget.cameraOutline(color: AppColors.primary),
                    // leading: SvgPicture.asset(Assets.assets.icons.picturePickerIcon),
                    title: Text(GayaStrings.view_photo.tr),
                    onTap: () {
                      onViewPhoto!();
                      //Navigator.pop(context);
                    },
                  ),

                  Visibility(
                    child: ListTile(
                      leading: SvgIconWidget.imageOutline(color: AppColors.primary),
                      // leading: SvgPicture.asset(Assets.assets.icons.videoPickerIcon),
                      title: Text(GayaStrings.change_photo.tr),
                      onTap: () => onChangePhoto!(),
                    ),
                  ),
                  //close
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10).r,
                    child: button(
                        height: 40.h,
                        borderColor: kTransparentColor,
                        // textStyle: loginController.styleEmail,
                        textStyle: GayaTypography.titleMedium.copyWith(color: AppColors.black),
                        title: GayaStrings.cancel_txt.tr,
                        onPressed: () {
                          Navigator.of(context, rootNavigator: true).pop("1");
                        },
                        primaryColor: AppColors.divider),
                  )
                ],
              ),
            ),
          );
        });
  }

  static showConfirmationDialogToOpenLink(Uri uri, BuildContext context) async {
    if (uri.toString().contains(Env.kDynamicLinkBaseUrl)) {
      return await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
    if (context.mounted == false) return;
    showGayaAlertDialogButton(
      context: context,
      actionText: '',
      actionMsg: GayaStrings.open_external_link.tr,
      tapOnYes: () async {
        await launchUrl(uri, mode: LaunchMode.externalApplication);
        if (context.mounted) {
          Navigator.pop(context);
        }
      },
      tapOnNo: () {
        Navigator.pop(context);
      },
    );
  }

  //shows dialogbox by default to open link
  static Future launchMyUrl(String url,
      {Map<String, dynamic>? params, required BuildContext context, bool showConfirmationToOpenLink = true}) async {
    try {
      final Uri uri = Uri.parse(url);

      if (url.contains("http") == false) {
        url = "http://$url";
      }

      if (await canLaunchUrl(uri)) {
        //show confirmation and open link on user interaction.
        showConfirmationToOpenLink ? showConfirmationDialogToOpenLink(uri, context) : await launchUrl(uri);
      }
    } catch (_) {
      GayaSnackBar.show(context: context, type: GayaSnackBarType.error, text: "Could not open the link");
    }
  }

  static showCircularModalSheet(BuildContext context, Widget child) {
    HapticFeedback.mediumImpact();
    showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        backgroundColor: Colors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: const Radius.circular(16.0).r),
        ),
        builder: (context) {
          return SingleChildScrollView(
            child: Column(
              children: [
                Container(
                  height: 5.h,
                  width: 40.w,
                  margin: const EdgeInsets.only(top: 12, bottom: 8).r,
                  decoration: ShapeDecoration(color: AppColors.divider, shape: const StadiumBorder()),
                ),
                child,
              ],
            ),
          );
        });
  }

  static void openPrivacyPolicy(BuildContext context) {
    launchMyUrl(Env.kPrivacyPolicyUrl, context: context);
  }

  static void openTermsAndConditions(BuildContext context) {
    launchMyUrl(Env.kTermsAndConditionsUrl, context: context);
  }

  static Future<Uint8List?> generateLocalPdfThumbnail({required String url}) async {
    CacheServices cacheService = CacheServices();
    return await cacheService.generatelocalPdfThumbnail(url: url);
  }
}
