import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:gaya/utils/theme/app_colors.dart';

class IconsAssetsPathUtils {
  IconsAssetsPathUtils._();

  static const String filledPath = "Assets/icons/filled/";
  static const String outlinePath = "Assets/icons/outline/";
  static const String notificationPath = "Assets/icons/notification_icon/";
  static const String appIconsPath = 'Assets/icons/';

  // notification icons getters
  static String get annonymous => '${notificationPath}annonymous.svg';

  static String get comment => '${notificationPath}comment.svg';

  static String get community => '${notificationPath}community.svg';

  static String get flower => '${notificationPath}flower.svg';

  static String get friend => '${notificationPath}friend.svg';

  static String get like => '${notificationPath}like.svg';

  // filled icons getters
  static String get annotationFilled => '${filledPath}annotation-dots_fill.svg';

  static String get bellFilled => '${filledPath}bell_fill.svg';

  static String get bookmarkFilled => '${filledPath}bookmark_fill.svg';

  static String get calendarDateFilled => '${filledPath}calendar-date_fill.svg';

  static String get cameraFilled => '${filledPath}camera_fill.svg';

  static String get checkVerifiedFilled => '${filledPath}check-verified_fill.svg';

  static String get clockFilled => '${filledPath}clock_fill.svg';

  static String get crownFilledd => '${filledPath}crown_fill.svg';

  static String get editFilled => '${filledPath}edit_fill.svg';

  static String get eyeOffFilled => '${filledPath}eye-off_fill.svg';

  static String get eyeFilled => '${filledPath}eye_fill.svg';

  static String get faceSmileFilled => '${filledPath}face-smile_fill.svg';

  static String get fileFilled => '${filledPath}file_fill.svg';

  static String get heartFilled => '${filledPath}heart_fill.svg';

  static String get homeLineFilled => '${filledPath}home-line_fill.svg';

  static String get infoCircleFilled => '${filledPath}info-circle_fill.svg';

  static String get lockUnlockedFilled => '${filledPath}lock-unlocked_fill.svg';

  static String get lockFilled => '${filledPath}lock_fill.svg';

  static String get logoutFilled => '${filledPath}log-out_fill.svg';

  static String get messageTextSquare1Filled => '${filledPath}message-text-square-1_fill.svg';

  static String get messageTextSquareFilled => '${filledPath}message-text-square_fill.svg';

  static String get microphoneFilled => '${filledPath}microphone_fill.svg';

  static String get minusCircleFilled => '${filledPath}minus-circle_fill.svg';

  static String get musicNoteFilled => '${filledPath}music-note_fill.svg';

  static String get paletteFilled => '${filledPath}palette_fill.svg';

  static String get pinFilled => '${filledPath}pin_fill.svg';

  static String get playFilled => '${filledPath}play_fill.svg';

  static String get plusCircleFilled => '${filledPath}plus-circle_fill.svg';

  static String get send1Filled => '${filledPath}send-01_fill.svg';

  static String get settingsFilled => '${filledPath}settings_fill.svg';

  static String get shareFilled => '${filledPath}share_fill.svg';

  static String get trashFilled => '${filledPath}trash_fill.svg';

  static String get userCheckFilled => '${filledPath}user-check_fill.svg';

  static String get userCircleFilled => '${filledPath}user-circle_fill.svg';

  static String get userMinusFilled => '${filledPath}user-minus_fill.svg';

  static String get userPlusFilled => '${filledPath}user-plus_fill.svg';

  static String get userRightFilled => '${filledPath}user-right_fill.svg';

  static String get userFilled => '${filledPath}user_fill.svg';

  static String get usersCheckFilled => '${filledPath}users-check_fill.svg';

  static String get usersMinusFilled => '${filledPath}users-minus_fill.svg';

  static String get usersFilled => '${filledPath}users_fill.svg';

  // end of filled icons getters

  // outlined icons getters
  static String get bellOutline => '${outlinePath}bell_outline.svg';

  static String get bookmarkOutline => '${outlinePath}bookmark_outline.svg';

  static String get calendarDateOutline => '${outlinePath}calendar-date_outline.svg';

  static String get cameraOutline => '${outlinePath}camera_outline.svg';

  static String get checkVerifiedOutline => '${outlinePath}check-verified_outline.svg';

  static String get checkOutline => '${outlinePath}check_outline.svg';

  static String get chevronDownOutline => '${outlinePath}chevron-down_outline.svg';

  static String get chevronLeftOutline => '${outlinePath}chevron-left_outline.svg';

  static String get clockOutline => '${outlinePath}clock_outline.svg';

  static String get commentOutline => '${outlinePath}comment_outline.svg';

  static String get cropOutline => '${outlinePath}crop_outline.svg';

  static String get crownOutline => '${outlinePath}crown_outline.svg';

  static String get dotsHorizontalOutline => '${outlinePath}dots-horizontal_outline.svg';

  static String get editOutline => '${outlinePath}edit_outline.svg';

  static String get eyeOffOutline => '${outlinePath}eye-off_outline.svg';

  static String get eyeOutline => '${outlinePath}eye_outline.svg';

  static String get faceSmileOutline => '${outlinePath}face-smile_outline.svg';

  static String get fileOutline => '${outlinePath}file_outline.svg';

  static String get heartOutline => '${outlinePath}heart_outline.svg';

  static String get homeLineOutline => '${outlinePath}home-line_outline.svg';

  static String get imageOutline => '${outlinePath}image_outline.svg';

  static String get infoCircleOutline => '${outlinePath}info-circle_outline.svg';

  static String get linkOutline => '${outlinePath}link_outline.svg';

  static String get loadingOutline => '${outlinePath}loading_outline.svg';

  static String get lockUnlockedOutline => '${outlinePath}lock-unlocked_outline.svg';

  static String get lockOutline => '${outlinePath}lock_outline.svg';

  static String get logoutOutline => '${outlinePath}log-out_outline.svg';

  static String get menuOutline => '${outlinePath}menu_outline.svg';

  static String get messageTextSquareOutline => '${outlinePath}message-text-square_outline.svg';

  static String get messagesOutline => '${outlinePath}messages_outline.svg';

  static String get microphoneOutline => '${outlinePath}microphone_outline.svg';

  static String get minusCircleOutline => '${outlinePath}minus-circle_outline.svg';

  static String get musicNoteOutline => '${outlinePath}music-note_outline.svg';

  static String get paletteOutline => '${outlinePath}palette_outline.svg';

  static String get pinOutlinee => '${outlinePath}pin_outline.svg';

  static String get playCircleOutline => '${outlinePath}play-circle_outline.svg';

  static String get playOutline => '${outlinePath}play_outline.svg';

  static String get plusCircleOutline => '${outlinePath}plus-circle_outline.svg';

  static String get plusOutline => '${outlinePath}plus_outline.svg';

  static String get searchLgOutline => '${outlinePath}search-lg_outline.svg';

  static String get sendOutline => '${outlinePath}send_outline.svg';

  static String get settingsOutline => '${outlinePath}settings_outline.svg';

  static String get shareOutline => '${outlinePath}share_outline.svg';

  static String get trash1Outline => '${outlinePath}trash-1_outline.svg';

  static String get trashOutline => '${outlinePath}trash_outline.svg';

  static String get userCheckOutline => '${outlinePath}user-check_outline.svg';

  static String get userCircleOutline => '${outlinePath}user-circle_outline.svg';

  static String get userMinusOutline => '${outlinePath}user-minus_outline.svg';

  static String get userPlusOutline => '${outlinePath}user-plus_outline.svg';

  static String get userRightOutline => '${outlinePath}user-right_outline.svg';

  static String get userShieldTickOutline => '${outlinePath}user-shield-tick_outline.svg';

  static String get userOutline => '${outlinePath}user_outline.svg';

  static String get usersCheckOutline => '${outlinePath}users-check_outline.svg';

  static String get usersMinusOutline => '${outlinePath}users-minus_outline.svg';

  static String get usersPlusOutline => '${outlinePath}users-plus_outline.svg';

  static String get usersRightOutline => '${outlinePath}users-right_outline.svg';

  static String get usersOutline => '${outlinePath}users_outline.svg';

  static String get xCloseOutline => '${outlinePath}x-close_outline.svg';
  static String get calendarOutline => '${outlinePath}calendar_outline.svg';
}

class SvgIconWidget {
  static Widget leftArrowIcon({required bool isLight}) =>
      SvgPicture.asset('${IconsAssetsPathUtils.appIconsPath}left_arrow.svg', color: isLight ? AppColors.white : AppColors.black);

  // (notification icons widgets)
  static Widget annonymous({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.annonymous, height: height, width: width, color: color);

  static Widget comment({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.comment, height: height, width: width, color: color);

  static Widget community({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.community, height: height, width: width, color: color);

  static Widget flower({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.flower, height: height, width: width, color: color);

  static Widget friend({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.friend, height: height, width: width, color: color);

  static Widget like({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.like, height: height, width: width, color: color);

  // (filled icons widgets)
  static Widget annotationFilled({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.annotationFilled, height: height, width: width, color: color);

  static Widget bellFilled({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.bellFilled, height: height, width: width, color: color);

  static Widget bookmarkFilled({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.bookmarkFilled, height: height, width: width, color: color);

  static Widget calendarDateFilled({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.calendarDateFilled, height: height, width: width, color: color);

  static Widget cameraFilled({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.cameraFilled, height: height, width: width, color: color);

  static Widget checkVerifiedFilled({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.checkVerifiedFilled, height: height, width: width, color: color);

  static Widget clockFilled({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.clockFilled, height: height, width: width, color: color);

  static Widget crownFilledd({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.crownFilledd, height: height, width: width, color: color);

  static Widget editFilled({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.editFilled, height: height, width: width, color: color);

  static Widget eyeOffFilled({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.eyeOffFilled, height: height, width: width, color: color);

  static Widget eyeFilled({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.eyeFilled, height: height, width: width, color: color);

  static Widget faceSmileFilled({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.faceSmileFilled, height: height, width: width, color: color);

  static Widget fileFilled({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.fileFilled, height: height, width: width, color: color);

  static Widget heartFilled({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.heartFilled, height: height, width: width, color: color);

  static Widget homeLineFilled({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.homeLineFilled, height: height, width: width, color: color);

  static Widget infoCircleFilled({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.infoCircleFilled, height: height, width: width, color: color);

  static Widget lockUnlockedFilled({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.lockUnlockedFilled, height: height, width: width, color: color);

  static Widget lockFilled({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.lockFilled, height: height, width: width, color: color);

  static Widget logoutFilled({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.logoutFilled, height: height, width: width, color: color);

  static Widget messageTextSquare1Filled({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.messageTextSquare1Filled, height: height, width: width, color: color);

  static Widget messageTextSquareFilled({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.messageTextSquareFilled, height: height, width: width, color: color);

  static Widget microphoneFilled({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.microphoneFilled, height: height, width: width, color: color);

  static Widget minusCircleFilled({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.minusCircleFilled, height: height, width: width, color: color);

  static Widget musicNoteFilled({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.musicNoteFilled, height: height, width: width, color: color);

  static Widget paletteFilled({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.paletteFilled, height: height, width: width, color: color);

  static Widget pinFilled({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.pinFilled, height: height, width: width, color: color);

  static Widget playFilled({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.playFilled, height: height, width: width, color: color);

  static Widget plusCircleFilled({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.plusCircleFilled, height: height, width: width, color: color);

  static Widget send1Filled({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.send1Filled, height: height, width: width, color: color);

  static Widget settingsFilled({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.settingsFilled, height: height, width: width, color: color);

  static Widget shareFilled({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.shareFilled, height: height, width: width, color: color);

  static Widget trashFilled({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.trashFilled, height: height, width: width, color: color);

  static Widget userCheckFilled({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.userCheckFilled, height: height, width: width, color: color);

  static Widget userCircleFilled({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.userCircleFilled, height: height, width: width, color: color);

  static Widget userMinusFilled({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.userMinusFilled, height: height, width: width, color: color);

  static Widget userPlusFilled({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.userPlusFilled, height: height, width: width, color: color);

  static Widget userRightFilled({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.userRightFilled, height: height, width: width, color: color);

  static Widget userFilled({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.userFilled, height: height, width: width, color: color);

  static Widget usersCheckFilled({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.usersCheckFilled, height: height, width: width, color: color);

  static Widget usersMinusFilled({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.usersMinusFilled, height: height, width: width, color: color);

  static Widget usersFilled({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.usersFilled, height: height, width: width, color: color);

  //  outline icons widgets
  static Widget bellOutline1({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.bellOutline, height: height, width: width, color: color);

  static Widget bookmarkOutline({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.bookmarkOutline, height: height, width: width, color: color);

  static Widget calendarDateOutline({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.calendarDateOutline, height: height, width: width, color: color);

  static Widget cameraOutline({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.cameraOutline, height: height, width: width, color: color);

  static Widget checkVerifiedOutline({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.checkVerifiedOutline, height: height, width: width, color: color);

  static Widget checkOutline({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.checkOutline, height: height, width: width, color: color);

  static Widget commentOutline({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.commentOutline, height: height, width: width, color: color);

  static Widget cropOutline({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.cropOutline, height: height, width: width, color: color);

  static Widget crownOutline({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.crownOutline, height: height, width: width, color: color);

  static Widget dotsHorizontalOutline({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.dotsHorizontalOutline, height: height, width: width, color: color);

  static Widget editOutline({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.editOutline, height: height, width: width, color: color);

  static Widget eyeOffOutline({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.eyeOffOutline, height: height, width: width, color: color);

  static Widget faceSmileOutline({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.faceSmileOutline, height: height, width: width, color: color);

  static Widget fileOutline({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.fileOutline, height: height, width: width, color: color);

  static Widget heartOutline({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.heartOutline, height: height, width: width, color: color);

  static Widget homeLineOutline({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.homeLineOutline, height: height, width: width, color: color);

  static Widget imageOutline({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.imageOutline, height: height, width: width, color: color);

  static Widget infoCircleOutline({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.infoCircleOutline, height: height, width: width, color: color);

  static Widget linkOutline1({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.linkOutline, height: height, width: width, color: color);

  static Widget loadingOutline({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.loadingOutline, height: height, width: width, color: color);

  static Widget clockOutline({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.clockOutline, height: height, width: width, color: color);

  static Widget lockUnlockedOutline({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.lockUnlockedOutline, height: height, width: width, color: color);

  static Widget lockOutline1({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.lockOutline, height: height, width: width, color: color);

  static Widget logoutOutline({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.logoutOutline, height: height, width: width, color: color);

  static Widget menuOutline({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.menuOutline, height: height, width: width, color: color);

  static Widget messageTextSquareOutline({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.messageTextSquareOutline, height: height, width: width, color: color);

  static Widget messagesOutline({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.messagesOutline, height: height, width: width, color: color);

  static Widget microphoneOutline({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.microphoneOutline, height: height, width: width, color: color);

  static Widget minusCircleOutline({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.minusCircleOutline, height: height, width: width, color: color);

  static Widget musicNoteOutline({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.musicNoteOutline, height: height, width: width, color: color);

  static Widget paletteOutline({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.paletteOutline, height: height, width: width, color: color);

  static Widget pinOutlinee({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.pinOutlinee, height: height, width: width, color: color);

  static Widget playCircleOutline({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.playCircleOutline, height: height, width: width, color: color);

  static Widget playOutline({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.playOutline, height: height, width: width, color: color);

  static Widget plusCircleOutline({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.plusCircleOutline, height: height, width: width, color: color);

  static Widget plusOutline({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.plusOutline, height: height, width: width, color: color);

  static Widget searchLgOutline({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.searchLgOutline, height: height, width: width, color: color);

  static Widget sendOutline({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.sendOutline, height: height, width: width, color: color);

  static Widget settingsOutline({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.settingsOutline, height: height, width: width, color: color);

  static Widget shareOutline({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.shareOutline, height: height, width: width, color: color);

  static Widget trash1Outline({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.trash1Outline, height: height, width: width, color: color);

  static Widget trashOutline({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.trashOutline, height: height, width: width, color: color);

  static Widget userCheckOutline({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.userCheckOutline, height: height, width: width, color: color);

  static Widget userCircleOutline({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.userCircleOutline, height: height, width: width, color: color);

  static Widget userMinusOutline({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.userMinusOutline, height: height, width: width, color: color);

  static Widget userPlusOutline({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.userPlusOutline, height: height, width: width, color: color);

  static Widget userRightOutline({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.userRightOutline, height: height, width: width, color: color);

  static Widget userShieldTickOutline({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.userShieldTickOutline, height: height, width: width, color: color);

  static Widget userOutline({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.userOutline, height: height, width: width, color: color);

  static Widget usersCheckOutline({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.usersCheckOutline, height: height, width: width, color: color);

  static Widget usersMinusOutline({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.usersMinusOutline, height: height, width: width, color: color);

  static Widget usersPlusOutline({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.usersPlusOutline, height: height, width: width, color: color);

  static Widget usersRightOutline({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.usersRightOutline, height: height, width: width, color: color);

  static Widget usersOutline({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.usersOutline, height: height, width: width, color: color);

  static Widget xCloseOutline({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.xCloseOutline, height: height, width: width, color: color);
 static Widget calendarOutline({double? height, double? width, Color? color}) =>
      GayaSvgAsset(IconsAssetsPathUtils.calendarOutline, height: height, width: width, color: color);
}

class GayaSvgAsset extends StatelessWidget {
  final String assetPath;
  final double? height;
  final double? width;
  final Color? color;

  const GayaSvgAsset(
    this.assetPath, {
    Key? key,
    this.height = 16,
    this.width = 16,
    this.color,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SvgPicture.asset(assetPath,
        height: height, width: width, colorFilter: color != null ? ColorFilter.mode(color!, BlendMode.srcIn) : null);
  }
}
