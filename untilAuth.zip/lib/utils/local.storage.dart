import 'dart:developer';

import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import "package:shared_preferences/shared_preferences.dart";

import '../model/topic.model.dart';

class LocalStorage {
  String interestUiKey = "IUK";

  //write the data
  Future writeData(String key, bool value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(key, value);
  }

  //read the data
  readData(String key) async {
    final prefs = await SharedPreferences.getInstance();
    prefs.getBool(key);
  }
}

//ignore_for_file_prefer_const_constructors, prefer_const_literals_to_create_immutables

class GetStorageController extends GetxController implements GetxService {
  final box = GetStorage();
  Future<void> initStorage() async {
    await GetStorage().initStorage;
  }

  @override
  void onInit() {
    super.onInit();
    log("Get Storage Controller Initialized:");
  }

  bool isHavingData = false;
  toggleIsHavingData(bool value) {
    isHavingData = value;
    update();
  }

  String? writeStorage({required String key, required String value}) {
    log("Saving key in Get Storage: Key is: $key and value is: $value");
    box.write(key, value);
    log("Token is saved in GetStorage: ${box.read(key)}");
    toggleIsHavingData(true);
    return null;
  }

  String? readStorage(String key) {
    return box.read(key);
  }

  Future<void> removeGetStorage() async {
    await box.erase();
    log("Get Storage Emptied : ");
    log("Value in Get Storage is: ${readStorage("user-token")}");
  }

  Future<void> removeStorage() async {
    await box.erase().then((value) async {
      toggleIsHavingData(false);
      log("Remove Storage: ");
      update();
    });
  }

  storeRecentSearchedList({required List<dynamic>? recentSearches}) {
    log("Recent Search List: ${recentSearches.toString()}");
    box.write("recentSearches", recentSearches);
    update();
    log("Recent Searches Stored Successfully:");
  }

  List<dynamic>? getRecentSearchedList() {
    List<dynamic>? data = box.read("recentSearches");
    update();
    if (data != null) {
      return data;
    } else {
      return null;
    }
  }
}

// save the community recent search

class GetCommunityStorageController extends GetxController implements GetxService {
  final communityBox = GetStorage();
  Future<void> initStorage() async {
    await GetStorage().initStorage;
  }

  @override
  void onInit() {
    super.onInit();
    log("Get Storage Controller Initialized:");
  }

  bool isHavingData = false;
  toggleIsHavingData(bool value) {
    isHavingData = value;
    update();
  }

  String? writeStorage({required String key, required String value}) {
    log("Saving key in Get Storage: Key is: $key and value is: $value");
    communityBox.write(key, value);
    log("Token is saved in GetStorage: ${communityBox.read(key)}");
    toggleIsHavingData(true);
    return null;
  }

  String? readStorage(String key) {
    return communityBox.read(key);
  }

  Future<void> removeGetStorage() async {
    await communityBox.erase();
    log("Get Storage Emptied : ");
    log("Value in Get Storage is: ${readStorage("user-token")}");
  }

  Future<void> removeStorage() async {
    await communityBox.erase().then((value) async {
      toggleIsHavingData(false);
      log("Remove Storage: ");
      update();
    });
  }

  storeRecentCommunitySearchedList({required List<dynamic>? recentSearches}) {
    log("Recent Search List: ${recentSearches.toString()}");
    communityBox.write("recentCommunitySearches", recentSearches);
    update();
    log("Recent Searches Stored Successfully:");
  }

  List<dynamic>? getRecentSearchedList() {
    List<dynamic>? data = communityBox.read("recentCommunitySearches");
    update();
    if (data != null) {
      return data;
    } else {
      return null;
    }
  }
}

// save the community user  recent search

class GetCommunityUsersStorageController extends GetxController implements GetxService {
  final communityUserBox = GetStorage();
  Future<void> initStorage() async {
    await GetStorage().initStorage;
  }

  @override
  void onInit() {
    super.onInit();
    log("Get Storage Controller Initialized:");
  }

  bool isHavingData = false;
  toggleIsHavingData(bool value) {
    isHavingData = value;
    update();
  }

  String? writeStorage({required String key, required String value}) {
    log("Saving key in Get Storage: Key is: $key and value is: $value");
    communityUserBox.write(key, value);
    log("Token is saved in GetStorage: ${communityUserBox.read(key)}");
    toggleIsHavingData(true);
    return null;
  }

  String? readStorage(String key) {
    return communityUserBox.read(key);
  }

  Future<void> removeGetStorage() async {
    await communityUserBox.erase();
    log("Get Storage Emptied : ");
    log("Value in Get Storage is: ${readStorage("user-token")}");
  }

  Future<void> removeStorage() async {
    await communityUserBox.erase().then((value) async {
      toggleIsHavingData(false);
      log("Remove Storage: ");
      update();
    });
  }

  storeRecentCommunitySearchedList({required List<dynamic>? recentSearches}) {
    log("Recent Search List: ${recentSearches.toString()}");
    communityUserBox.write("recentCommunityUsersSearches", recentSearches);
    update();
    log("Recent Searches Stored Successfully:");
  }

  List<dynamic>? getRecentSearchedList() {
    List<dynamic>? data = communityUserBox.read("recentCommunityUsersSearches");
    update();
    if (data != null) {
      return data;
    } else {
      return null;
    }
  }
}


// save   user  recent interests
class GetInterestStorageController extends GetxController implements GetxService {
  static GetInterestStorageController get to => Get.find();
  final userInterestBox = GetStorage();

  Future<void> initStorage() async {
    await GetStorage().initStorage;
  }

  @override
  void onInit() {
    super.onInit();
    log("Get Storage Controller Initialized:");
  }

  bool isHavingData = false;

  toggleIsHavingData(bool value) {
    isHavingData = value;
    update();
  }

  String? writeStorage({required String key, required String value}) {
    log("Saving key in Get Storage: Key is: $key and value is: $value");
    userInterestBox.write(key, value);
    log("Token is saved in GetStorage: ${userInterestBox.read(key)}");
    toggleIsHavingData(true);
    return null;
  }

  String? readStorage(String key) {
    return userInterestBox.read(key);
  }

  Future<void> removeGetStorage() async {
    await userInterestBox.erase();
    log("Get Storage Emptied : ");
    log("Value in Get Storage is: ${readStorage("user-token")}");
  }

  Future<void> removeStorage() async {
    await userInterestBox.erase().then((value) async {
      toggleIsHavingData(false);
      log("Remove Storage: ");
      update();
    });
  }

  storeInterestList({required List<dynamic>? recentInterests}) {
    log("Recent Search List: ${recentInterests.toString()}");
    userInterestBox.write("recentInterest", recentInterests);
    update();
    log("Recent Searches Stored Successfully:");
  }

  List<dynamic>? getInterestList() {
    List<dynamic>? data = userInterestBox.read("recentInterest");
    update();
    if (data != null) {
      return data;
    } else {
      return null;
    }
  }

  List<TopicsModel> getInterestModelList() {
    try {
      List data = userInterestBox.read("recentInterest");
      List<TopicsModel> resp = data.map((e) => TopicsModel.fromMap(e)).toList();
      update();
      if (data != null) {
        return resp;
      } else {
        return [];
      }
    } catch (e) {
      log("Error in getInterestList1: $e");
    }
    return [];
  }
}
