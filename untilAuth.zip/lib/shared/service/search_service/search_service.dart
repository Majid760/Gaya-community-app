import 'dart:async';

import 'package:algolia/algolia.dart';
import 'package:gaya/model/community.model.dart';
import 'package:gaya/model/create.post.model.dart';
import 'package:gaya/model/user.model.dart';
import 'package:gaya/utils/logger.dart';

class AlgoliaService {
  /// algolia api credential
  static const String algoliaAppId = "7V8WUJ2HVJ";
  static const String algoliaSearchKey = "48366a10f2f6da5c63b7d0ccafb37c91";
  //

  // indices
  final String userIndex = "users";
  // user index searchable fields
  List<String> usersSearchAbleFields = ['name'];
  final int userHitsPerPage = 60;

  final String communityIndex = "community";
  // community index searchable fields
  List<String> communitySearchAbleFields = ['name'];
  final int communityHitsPerPage = 60;
  final String postIndex = "posts";

  late Algolia algolia;
  AlgoliaService() {
    algolia = const Algolia.init(applicationId: algoliaAppId, apiKey: algoliaSearchKey);
  }
  Algolia get getAlgolia => algolia;

  // get the user from algolia database
  // algolia-users
  Future<List<UserModel>> getsAllUsers(String queryData) async {
    try {
      List<UserModel> users = [];
      AlgoliaQuery query = algolia.instance.index(userIndex).query(queryData);
      query.setRestrictSearchableAttributes(usersSearchAbleFields);
      AlgoliaQuerySnapshot snapshot = await query.setHitsPerPage(userHitsPerPage).getObjects();
      final usersRawHits = snapshot.toMap()['hits'] as List;
      users = List<UserModel>.from(usersRawHits.map((hit) => UserModel.fromAlgoliaMap(hit)));
      return users;
    } catch (e) {
      MyLoggerServices.to.print('error thrown here:=>${e.toString()}');
      return [];
    }
  }

  // algolia-users
  Future<List<dynamic>> getFeedsData(String queryData) async {
    try {
      List<UserModel> users = [];
      List<Community> communities = [];
      // queryA.
      AlgoliaQuery queryA = algolia.instance.index(userIndex).query(queryData);
      queryA.setRestrictSearchableAttributes(usersSearchAbleFields);
      // queryB
      AlgoliaQuery queryB = algolia.instance.index(communityIndex).query(queryData);
      queryB.setRestrictSearchableAttributes(communitySearchAbleFields);
      // Perform multiple facetFilters
      // queryA = queryA.facetFilter('status:active');
      // queryA = queryA.facetFilter('isDelete:false');
      // Get Result/Objects
      List<AlgoliaQuerySnapshot> algoliaSnapshots = await getAlgolia.multipleQueries
          .addQueries([queryA.setHitsPerPage(userHitsPerPage), queryB.setHitsPerPage(communityHitsPerPage)]).getObjects();
      final usersRawHits = algoliaSnapshots.first.toMap()['hits'] as List;
      final communitiesRawHits = algoliaSnapshots.last.toMap()['hits'] as List;
      users = List<UserModel>.from(usersRawHits.map((hit) => UserModel.fromAlgoliaMap(hit)));
      communities = List<Community>.from(communitiesRawHits.map((hit) => Community.fromAlgoliaMap(hit)));
      return [users, communities];
    } catch (e) {
      MyLoggerServices.to.print('error thrown here:=>${e.toString()}');
      return [];
    }
  }

  // algolia-community
  Future<List<Community>> getCommunities(String queryData) async {
    try {
      MyLoggerServices.to.print(('this is query:=>$queryData'));
      List<Community> communities = [];
      AlgoliaQuery query = getAlgolia.instance.index(communityIndex).query(queryData);
      query.setRestrictSearchableAttributes(communitySearchAbleFields);
      AlgoliaQuerySnapshot snapshot = await query.setHitsPerPage(communityHitsPerPage).getObjects();
      final communitiesRawHits = snapshot.toMap()['hits'] as List;
      communities = List<Community>.from(communitiesRawHits.map((hit) => Community.fromAlgoliaMap(hit)));
      MyLoggerServices.to.print('this is length:${communities.length}');
      return communities;
    } catch (e) {
      MyLoggerServices.to.print(('this is error:=>${e.toString()}'));
      return <Community>[];
    }
  }

// algolia-users
  Future<List<UserModel>> getCommunityMembers(String queryData) async {
    try {
      AlgoliaQuery query = getAlgolia.instance.index(communityIndex).query(queryData);
      // query.facetFilter('isTechnicianAssigned:false').facetFilter("orgId:${user.organizationId}");
      AlgoliaQuerySnapshot snapshot = await query.getObjects();
      final rawHits = snapshot.toMap()['hits'] as List;
      final hits = List<UserModel>.from(rawHits.map((hit) => UserModel.fromMap(hit)));
      if (hits.isEmpty) {
        return <UserModel>[];
      } else {
        return hits;
      }
    } catch (e) {
      return <UserModel>[];
    }
  }

  // algolia-post
  Future<List<Post>> getPosts(String queryData) async {
    try {
      AlgoliaQuery query = getAlgolia.instance.index(postIndex).query(queryData);
      // query.facetFilter('isTechnicianAssigned:false').facetFilter("orgId:${user.organizationId}");
      AlgoliaQuerySnapshot snapshot = await query.getObjects();
      final rawHits = snapshot.toMap()['hits'] as List;
      final hits = List<Post>.from(rawHits.map((hit) => Post.fromMap(hit)));
      if (hits.isEmpty) {
        return <Post>[];
      } else {
        return hits;
      }
    } catch (e) {
      return <Post>[];
    }
  }

  // algolia-users-and communities
  Future<List<Map<String, dynamic>>> getUserAndCommunitiesForMentions(String queryData) async {
    try {
      print('hiting for ${queryData}');
      List<Map<String, dynamic>> users = [];
      List<Map<String, dynamic>> communities = [];
      // queryA.
      AlgoliaQuery queryA = algolia.instance.index(userIndex).query(queryData);
      queryA.setRestrictSearchableAttributes(usersSearchAbleFields);
      // queryB
      AlgoliaQuery queryB = algolia.instance.index(communityIndex).query(queryData);
      queryB.setRestrictSearchableAttributes(communitySearchAbleFields);
      // Get Result/Objects
      List<AlgoliaQuerySnapshot> algoliaSnapshots =
          await getAlgolia.multipleQueries.addQueries([queryA.setHitsPerPage(30), queryB.setHitsPerPage(30)]).getObjects();
      final usersRawHits = algoliaSnapshots.first.toMap()['hits'] as List;
      final communitiesRawHits = algoliaSnapshots.last.toMap()['hits'] as List;
      users = List.from(usersRawHits.map((hit) {
        return {
          "id": hit['objectID'] ?? '',
          "display": hit['name'] ?? '',
          "senderUid": hit['objectID'] ?? '',
          "profilePic": hit['profilePic'] ?? ''
        };
      }));
      communities = List.from(communitiesRawHits.map((hit) {
        return {
          "id": hit['objectID'] ?? '',
          "display": hit['name'] ?? '',
          "senderUid": hit['objectID'] ?? '',
          "profilePic": hit['profilePicture'] ?? '',
          "isCommunity": true,
        };
      }));
     users.addAll(communities);
     return users;
    } catch (e) {
      rethrow;
    }
  }
}
