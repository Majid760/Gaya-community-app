import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:gaya/utils/const.dart';

class GayaFloatingActionButton extends StatelessWidget {
  const GayaFloatingActionButton({Key? key, required this.onPressed, required this.svgIconPath}) : super(key: key);
  final VoidCallback? onPressed;
  final String svgIconPath;

  @override
  Widget build(BuildContext context) {
    return FloatingActionButton(
      heroTag: null,
      materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
      onPressed: () {
        if (onPressed != null) {
          onPressed!();
          HapticFeedback.mediumImpact();
        }
      },
      backgroundColor: kTransparentColor,
      elevation: 0,
      child: Container(
          padding: const EdgeInsets.all(12).r,
          height: 48.r,
          width: 48.r,
          decoration: BoxDecoration(
            color: kprimaryColor,
            borderRadius: BorderRadius.circular(borderRadius_4).r,
          ),
          child:  SvgPicture.asset(
          svgIconPath,
          color: kWhiteColor,
        )
      ),
    );
  }
}
